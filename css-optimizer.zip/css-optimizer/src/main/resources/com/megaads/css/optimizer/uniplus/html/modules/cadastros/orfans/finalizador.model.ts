import { AbstractPojo } from "../../../core/crud/pojo";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class Finalizador extends AbstractPojo {
  nome = "";
  abreviacao = "";
  // troco: TipoTroco;
  // tipoParcela: TipoParcelaCrediarioECF;
  tipoEdicaoParcela = 0;
  tipoDocumentoRetaguarda = "";
  idTipoDocumentoDebito = 0;
  // tipoImpressao: TipoImpressaoCrediario;
  // tipoVencimento: TipoVencimento;
  // tipoRetaguarda: TipoRetaguarda;
  modeloComprovante = "";
  // formaPagamentoNfce: FormaPagamentoNFE;
  // tipoDocumento: TipoDocumentoFinalizador;
  // entrada: TipoFinalizadorEntrada;
  maximoParcelas = 0;
  tecla = 0;
  valorMaximo = 0;
  cliente: boolean;
  cpf: boolean;
  data: boolean;
  tipoVerificacao: boolean;
  valor: boolean;
  venda = 0;
  recebimento = 0;
  doacao = 0;
  cartaoFidelidade: boolean;
  recargaCelular: boolean;
  adiantamento: boolean;
  prePago: boolean;
  banco: boolean;
  agencia: boolean;
  conta: boolean;
  emitente: boolean;
  cadastraCliente: boolean;
  egracao = 0;
  sangria = 0;
  valePresente = 0;
  imprimeCheque = 0;
  tipoCartaoProprio = 0;
  formatoContasPagar = 0;
  pularParames = 0;
  diasUso = 0;
  quantidadeMaxima = 0;
;
  cartaoFidelidadeValor = 0;
  cartaoFidelidadePontos = 0;
  linhasEntreParcelas = 0;
  teclaVenda = 0;
  teclaRecebimento = 0;
  teclaValePresente = 0;
  garantiaEstendida: boolean;
  tipoCobrancaRetaguarda = "";
  valorMinimoParcela = 0;
  idPlanoConta = 0;
  informarAutorizacaoPOS: boolean;
  ticketRefeicao: boolean;
  agruparCentavosPrimeiraParcela: boolean;
}
