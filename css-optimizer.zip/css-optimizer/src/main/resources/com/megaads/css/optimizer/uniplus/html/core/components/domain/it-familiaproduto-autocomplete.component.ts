import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { FamiliaProduto } from "../../../modules/cadastros/orfans/familia-produto.model";

@Component({
    selector: "it-familiaproduto-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
// TODO OSIEL ESSE COMPONENTE PRECISA SER REFATORADO PARA TREEAUTOCOMPLETE
export class ItFamiliaProdutoAutocompleteComponent extends ItAutocompleteComponent<FamiliaProduto> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "nome";
        this.label = "Família";
        this.url = "familias-produto";
    }

}
