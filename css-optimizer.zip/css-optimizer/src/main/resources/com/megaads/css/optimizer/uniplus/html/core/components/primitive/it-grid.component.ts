import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from "@angular/core";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute, Router } from "@angular/router";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Subscription } from "rxjs/Subscription";

import { ColumnDefinition } from "../../crud/column-definition";
import { ICustomizableColumn } from "../../crud/customizable-column";
import { IFieldDefinition } from "../../crud/field-definition";
import { IFilter } from "../../crud/filter";
import { AbstractPojo } from "../../crud/pojo";
import { ServerError } from "../../models/server-error";
import { AutenticacaoService } from "../../services/autenticacao.service";
import { HttpService } from "../../services/http.service";
import { SpinnerService } from "../../services/spinner.service";
import { ToasterService } from "../../services/toaster.service";
import { NumberUtil } from "../../utils/number.util";
import { ItTableComponent } from "./it-table.component";

@Component({
  selector: "it-grid",
  template: `
    <it-table [columns$]="columns$" (selectedItemDoubleClicked$)="selectedItemDoubleClicked$.next($event)"></it-table>`,
})
export class ItGridComponent<POJO extends AbstractPojo> implements OnDestroy, OnInit {
  @Input() public moduleId: string;
  @Input() public filtersBasic$: Observable<IFilter[]>;
  @Input() public customizableColumns$: Observable<ICustomizableColumn[]>;

  @Output() public selectedItemDoubleClicked$: EventEmitter<POJO>;

  public columns$: Subject<ColumnDefinition[]>;
  public afterLoad$: BehaviorSubject<boolean>;

  @ViewChild(ItTableComponent) private itTable: ItTableComponent<POJO>;

  /**
   * parametros recebidos via query string
   */
  private params: {} = {};
  /**
   * fragmentos de url
   */
  private urls: string[] = [];
  private isChild = false;
  private loadData$: Subject<any>;
  private subscription: Subscription;

  constructor(private activatedRoute: ActivatedRoute, private httpService: HttpService,
              private router: Router, private toaster: ToasterService, private spinner: SpinnerService,
              private autenticacaoService: AutenticacaoService) {

    this.afterLoad$ = new BehaviorSubject(undefined);
    this.columns$ = new Subject();
    this.customizableColumns$ = Observable.of([]);
    this.loadData$ = new Subject();
    this.selectedItemDoubleClicked$ = new EventEmitter();
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public ngOnInit(): void {
    this.spinner.show();

    /**
     * Monta array parms que será usado para navegar pelas rotas do crud.
     */
    this.urls.push(this.moduleId);
    this.activatedRoute.url.subscribe((url) => url.forEach((urlSegment) => this.urls.push(urlSegment.path)));

    /**
     * Armazena os parametros recebidos via query string
     */
    this.activatedRoute.params.subscribe((params) => this.params = params);

    /**
     * Busca a estrutura da grid no servidor
     */
    this.httpService.get(this.url("fields-definition"))
      .combineLatest(this.customizableColumns$,
        (fields: IFieldDefinition[], columns: ICustomizableColumn[]) => ({fields, columns}))
      .subscribe((wrapperDefinition: { fields: IFieldDefinition[], columns: ICustomizableColumn[] }) => {
        const columns: ColumnDefinition[] = [];
        wrapperDefinition.fields.forEach((coluna) => {

          /**
           * Localiza a coluna customizada correspondente para aplicar os filtros.
           * @type {ICustomizableColumn}
           */
          const customizable: ICustomizableColumn =
            wrapperDefinition.columns.find((c: ICustomizableColumn) => c.binding === coluna.alias);

          columns.push(
            new ColumnDefinition(
              coluna.alias,
              coluna.label,
              coluna.type,
              coluna.width === 0 ? "*" : coluna.width,
              customizable ? customizable.format : null,
              coluna.visible,
              customizable ? customizable.enumClass : coluna.enumClass,
              customizable ? customizable.decimalColumn : null,
              customizable ? customizable.converter : null,
            ));
        });

        this.columns$.next(columns);
        this.columns$.complete();
        this.loadData$.next();
      }, (error: ServerError) => {
        this.handleError(error);
        this.spinner.hide();
      });

    /**
     * Carrega os dados do servidor utilizando os parâmetros.
     */
    this.subscription = this.loadData$
      .combineLatest(this.filtersBasic$.map((filters: IFilter[]) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("filter", JSON.stringify(filters));
        return params;
      }), (load, filter) => filter)
      .switchMap((params: URLSearchParams) => this.httpService.get(this.url(), {search: params}))
      .subscribe((resp: POJO[]) => {
        this.itTable.updateItemsSource(resp);
        this.itTable.clearSelection();
        this.spinner.hide();
        this.afterLoad$.next(true);
      }, (error: ServerError) => this.handleError(error));

  }

  /**
   * Retorna o objeto selecionado.
   * Exibe uma mensagem de aviso caso contrário
   * * @return {AbstractPojo}
   */
  public get selectedItem(): POJO {
    return this.itTable.selectedItem;
  }

  /**
   * Retorna os itens da table.
   * @return {AbstractPojo[]}
   */
  public get sourceCollection(): POJO[] {
    return this.itTable.sourceCollection;
  }

  /**
   * Determina se o registro existe na table.
   * @param {number} id
   * @return {boolean}
   */
  public exist(id: number): boolean {
    return this.sourceCollection.some((p: POJO) => NumberUtil.parseFloat(p.id.toString()) === id);
  }

  /**
   * Efetua um push do objeto na table.
   * @param pojo: POJO
   * @param generateId: boolean determina se deve gerar id dummy.
   */
  public push(pojo: POJO, generateId?: boolean) {
    this.itTable.push(pojo, generateId);
  }

  /**
   * Atualiza o objeto. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   */
  public update(pojo: POJO) {
    this.itTable.update(pojo);
  }

  /**
   * Exclui o objeto selecionado. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   * * @param idx?: number
   */
  public delete(pojo: POJO, idx?: number) {
    this.itTable.delete(pojo, idx);
  }

  /**
   * Comfirma a inclusão atualizando o Id do pojo.
   * @param pojo: POJO
   * @param id: number
   */
  public commitUpdateId(pojo: POJO, id: number): void {
    this.itTable.commitUpdateId(pojo, id);
  }

  /**
   * Pesquisa na grid
   * @param filter
   */
  public search(filter: string): void {
    this.itTable.search(filter);
  }

  /**
   * Invalida o flexgrid para reposicionar a table e o scroll.
   */
  public invalidateFlexGrid(): void {
    this.itTable.invalidateFlexGrid();
  }

  /**
   * Vai para uma grid passando por parametro o id selecionado
   */
  public goTo(destino: string) {
    const pojo = this.selectedItem;
    if (pojo) {
      this.navigate(pojo.id.toString(), destino);
    }
  }

  /**
   * Navega para um nivel superior de crud
   */
  public onReturn() {
    const route = this.urls.slice(0, this.urls.length - 2);
    this.router.navigate(route).catch(() => this.toaster.pop("error", "Não foi possível seguir a rota"));
  }

  /**
   * Seta uma grid como sendo filha de outra crud
   * Uma grid child usa a url para invocar os metodos da api
   */
  public set child(child: boolean) {
    this.isChild = child;
  }

  /**
   * Observable de seleção de item. A cada vez que for selecionada uma linha
   * o subject é disparado.
   *
   * @return {Observable<AbstractPojo>}
   */
  public get currentChanged$(): Observable<POJO> {
    return this.itTable.currentChanged$;
  }


  /**
   * Retorna url baseado nos parametros atuais.
   * @param segment: string
   * @return {string}
   */
  private url(segment?: string): string {
    /**
     * O primeiro valor é descartado porque se trata do modulo, que não é necessário para formar a url
     */
    if (this.isChild) {
      if (segment) {
        return this.urls.slice(1).join("/").concat("/", segment);
      } else {
        return this.urls.slice(1).join("/");
      }
    } else {
      if (segment) {
        return this.urls[this.urls.length - 1].concat("/", segment);
      } else {
        return this.urls[this.urls.length - 1];
      }
    }
  }

  /**
   * Navega para uma ação do grid
   * @param action
   */
  private navigate(...action: string[]) {
    const route = this.urls.slice().concat(action);
    this.router.navigate(route).catch(() => this.toaster.pop("error", "Não foi possível seguir a rota"));
  }

  /**
   * Tratamento de erros padrão da grid
   * @param error
   */
  private handleError(error: ServerError): void {
    if (this.autenticacaoService.isLogado() && (error.status)) {
      this.toaster.pop("error", "Não foi possível carregar os dados", error.mensagem);
    } else {
      localStorage.removeItem("usuario");
      this.router.navigate(["login"]).catch(() => {
        throw new Error("Não foi possível redirecionar para Login");
      });
    }
  }
}
