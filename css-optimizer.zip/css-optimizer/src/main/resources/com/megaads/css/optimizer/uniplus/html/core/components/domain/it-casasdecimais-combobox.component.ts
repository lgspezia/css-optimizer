import { Component } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { IDataItem } from "../../models/dataitem";
import { ItComboboxComponent } from "../primitive/it-combobox.component";

@Component({
  selector: "it-casasdecimais-combobox",
  templateUrl: "../primitive/it-combobox.component.html",
})
export class ItCasasDecimaisComboboxComponent extends ItComboboxComponent<IDataItem> {

  constructor() {
    super();
    this.label = "Casas decimais";

    this.itens$ = Observable.of([{id: 2, display: 2},
      {id: 3, display: 3}, {id: 4, display: 4},
      {id: 5, display: 5}, {id: 6, display: 6}]);
  }

}
