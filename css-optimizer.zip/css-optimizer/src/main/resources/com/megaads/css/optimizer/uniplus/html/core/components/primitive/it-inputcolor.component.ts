import { Component } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputcolor",
    templateUrl: "it-inputcolor.component.html",
})
export class ItInputColorComponent extends BaseFormComponent { }
