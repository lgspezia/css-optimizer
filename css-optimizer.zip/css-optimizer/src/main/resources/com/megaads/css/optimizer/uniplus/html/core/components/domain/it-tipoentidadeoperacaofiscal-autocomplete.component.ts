import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TipoEntidadeOperacaoFiscal } from "../../../modules/cadastros/orfans/tipo-entidade-operacao-fiscal.model";

@Component({
    selector: "it-tipoentidadeoperacaofiscal-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoEntidadeOperacaoFiscalAutocompleteComponent extends ItAutocompleteComponent<TipoEntidadeOperacaoFiscal> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "tipos-entidade-operacao";
        this.display = "descricao";
    }
}
