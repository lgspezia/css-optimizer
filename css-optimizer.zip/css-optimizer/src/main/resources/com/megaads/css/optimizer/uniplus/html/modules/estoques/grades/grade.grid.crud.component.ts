import { Component } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { GridCrud } from "../../../core/crud/grid.crud";
import { Grade } from "./grade";

/**
 * Grades
 *
 * @author Osiel.
 */
@Component({
  templateUrl: "grade.grid.crud.html",
})
export class GradeGridCrudComponent extends GridCrud<Grade> {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Grade(), "grades");
  }
}
