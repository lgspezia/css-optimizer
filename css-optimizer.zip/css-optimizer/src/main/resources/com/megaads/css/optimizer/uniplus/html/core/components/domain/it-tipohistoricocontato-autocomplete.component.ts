import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TipoHistoricoContato } from "../../../modules/entidades/tipos-historico-contato/tipo-historico-contato";

@Component({
    selector: "it-tipohistoricocontato-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoHistoricoContatoAutoCompleteComponent extends ItAutocompleteComponent<TipoHistoricoContato> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "descricao";
        this.label = "Tipo histórico";
        this.url = "tipos-historico-contato";
    }

}
