import { AbstractPojo } from "../../../core/crud/pojo";
import { CodigoPeriodoApuracao } from "./enums/codigo-periodo-apuracao.enum";
import { TipoValorGnre } from "./enums/tipo-valor-gnre.enum";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class GnreNaturezaOperacaoEstado extends AbstractPojo {
  public id: number;
  public idEstado: number;
  public estado = "";
  public idCfop: number;
  public idOperacaoFiscal: number;
  public receita: number;
  public idReceita: number;
  public detalhamentoReceita = "";
  public idDetalhamentoReceita: number;
  public periodoApuracao: CodigoPeriodoApuracao;
  public idPeriodoApuracao: number;
  public produto: number;
  public idProduto: number;
  public tipoDocumentoOrigem = "";
  public idTipoDocumentoOrigem: number;
  public inativo: boolean;
  public tipoValorGnre: TipoValorGnre;
}
