import { Component, EventEmitter, Input, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { FormGroup } from "@angular/forms";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Subscription } from "rxjs/Subscription";

import { ICustomizableColumn } from "../../crud/customizable-column";
import { IEditDetails, Result } from "../../crud/edit-details";
import { IFilter } from "../../crud/filter";
import { Modo } from "../../crud/grid.crud";
import { AbstractPojo, ProcessStatus } from "../../crud/pojo";
import { ToasterService } from "../../services/toaster.service";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";
import { ItGridComponent } from "./it-grid.component";

/**
 * Componente principal de grid e form para cadastros de crud.
 * Esse componente responsável por executar as chamadas de ações e reversão
 * de valores na grid, caso ocorra um erro.
 *
 * @author Osiel
 */
@Component({
  selector: "it-gridform",
  templateUrl: "it-gridform.component.html",
})
export class ItGridFormComponent<POJO extends AbstractPojo> implements OnDestroy, OnInit {
  /**
   * Esse observable permite mudar o comportamente de ocultação da grid.
   */
  @Input() public hiddenGrid$: Observable<boolean>;
  @Input() public title: string;
  @Input() public moduleId: string;
  /**
   * Utilizado para return em custom action.
   */
  @Input() public enableReturn = false;

  /**
   * Adiciona os parâmetros de filtros básicos de grid.
   */
  @Input() public filtersBasic$: Observable<IFilter[]>;

  /**
   * Lista de colunas custumizadas a aplicar os formatadores necessários.
   */
  @Input() public customizableColumns$: Observable<ICustomizableColumn[]>;

  /**
   * Manipular opções de inclusão, alteração e exclusão.
   */
  @Input() public allowCreate$: Observable<boolean>;
  @Input() public allowDelete$: Observable<boolean>;
  @Input() public allowRead$: Observable<boolean>;
  @Input() public allowUpdate$: Observable<boolean>;

  /**
   * Subjects public pois serão observados por GridCrud
   */
  public actionBeforeSubmit$: Subject<IEditDetails<POJO>>;
  public actionSubmit$: Subject<IEditDetails<POJO>>;
  public submitResult$: Subject<IEditDetails<POJO>>;
  public userAction$: Subject<IEditDetails<POJO>>;
  public formEditing$: BehaviorSubject<boolean>;
  public goTo$: Subject<string>;

  /**
   * Observables para mapeamentos de ações internas do componente e html.
   */
  public eventAction$: BehaviorSubject<Modo>;
  public userActionDescription$: BehaviorSubject<string>;
  public hidden$: Observable<boolean>;
  public eventSubmit$: Subject<FormGroup>;

  /**
   * Injetando o componente de grid.
   */
  @ViewChild(ItGridComponent) private itGridComponent: ItGridComponent<POJO>;

  private selectedItemDoubleClicked$: EventEmitter<POJO>;
  private subscription: Subscription;
  private _afterSave$: Subject<POJO>;

  constructor(private toasterService: ToasterService) {
    this.actionBeforeSubmit$ = new Subject();
    this._afterSave$ = new Subject();
    this.allowCreate$ = Observable.of(true);
    this.allowDelete$ = Observable.of(true);
    this.allowRead$ = Observable.of(true);
    this.actionSubmit$ = new Subject();
    this.allowUpdate$ = Observable.of(true);
    this.customizableColumns$ = Observable.of([]);
    this.eventAction$ = new BehaviorSubject(undefined);
    this.eventSubmit$ = new Subject();
    this.filtersBasic$ = Observable.of([]);
    this.formEditing$ = new BehaviorSubject(false);
    this.goTo$ = new Subject();
    this.hiddenGrid$ = Observable.of(true);
    this.selectedItemDoubleClicked$ = new EventEmitter();
    this.submitResult$ = new Subject();
    this.userActionDescription$ = new BehaviorSubject(undefined);
    this.userAction$ = new Subject();
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public ngOnInit(): void {
    /**
     * Determina se esconde a grid.
     */
    this.hidden$ = this.hiddenGrid$.combineLatest(this.formEditing$, (h: boolean, e: boolean) => h && e);

    /**
     * Problema de flex quando a grid esta oculta.
     */
    this.subscription = this.formEditing$.filter((e: boolean) => !e).skip(1)
      .subscribe(() => this.itGridComponent.invalidateFlexGrid());

    /**
     * Mapeia a ação do usuário setado via Grid. Ver mais em {@link ItGridBarComponent}.
     * @type {Subscription}
     */
    this.subscription
      .add(this.eventAction$
        .subscribe((action: Modo) => this.nextUserAction(action)));

    /**
     * Quando efetuado o double click seta para o eventAction o Modo de Update.
     */
    this.subscription
      .add(this.selectedItemDoubleClicked$
        .withLatestFrom(this.allowUpdate$, (item: POJO, allowUpdate: boolean) => allowUpdate)
        .filter((allowUpdate: boolean) => allowUpdate)
        .subscribe(() => this.eventAction$.next(Modo.UPDATE)));

    /**
     * Monta a descrição do resultado da ação tomada.
     */
    this.subscription
      .add(this.userAction$
        .subscribe((details: IEditDetails<POJO>) => this.userActionDescription$
          .next((details.modo === Modo.UPDATE ? "Alteração - " : details.modo === Modo.READ ? "Visualização - " :
            details.modo === Modo.DELETE ? "Exclusão - " : "Inclusão") +
            (details.modo !== Modo.CREATE ? !StringUtil.stringNullOrEmpty(details.original.codigo) ? details.original.codigo : "" : ""))));

    /**
     * É necessário combinar a ação, com o submit e form,
     * para que tenhámos as junções das ações resultantes. Para isso, foi
     * utilizado o withLatestFrom pois é necessário pegar o valor atual e não o anterior,
     */
    const actionSubmitForm$ = this.eventSubmit$
      .withLatestFrom(this.userAction$, (form: FormGroup, details: IEditDetails<POJO>) => {
        details.pojo = form.getRawValue();
        details.pojo.processStatus = ProcessStatus.PENDING;
        return details;
      });

    /**
     * Dispara a ação de before submit.
     */
    this.subscription
      .add(actionSubmitForm$
        .subscribe(this.actionBeforeSubmit$));

    /**
     * Quando a ação de submissão for executada o registro deve ser inserido na table.
     */
    this.subscription
      .add(this.actionSubmit$
        .subscribe((details: IEditDetails<POJO>) => this.updateChangeTable(details)));

    /**
     *  Mapeia o final do processamento da requisição http e efetua as medidas necessárias.
     */
    this.subscription
      .add(this.submitResult$
        .subscribe((details: IEditDetails<POJO>) => {
          if (details.result === Result.ERROR) {
            if (details.modo === Modo.UPDATE) {
              this.itGridComponent.update(details.original);
            } else if (details.modo === Modo.DELETE) {
              this.itGridComponent.push(details.original);
            } else {
              this.itGridComponent.delete(details.pojo);
            }
          } else {
            details.pojo.processStatus = ProcessStatus.COMPLETED;
            this.itGridComponent.commitUpdateId(details.pojo, details.id);
            this._afterSave$.next(details.pojo);
          }
        }));

    this.subscription
      .add(this.goTo$
        .subscribe((url) => this.itGridComponent.goTo(url)));
  }

  /**
   * Observable disparado após atualizar a grid com os dados do banco.
   * @return {Observable<number>}
   */
  public get afterLoad$(): Observable<boolean> {
    return this.itGridComponent.afterLoad$;
  }

  /**
   * Observable disparado após gravar o objeto com sucesso no servidor.
   * @return {Observable<AbstractPojo>}
   */
  public get afterSave$(): Observable<POJO> {
    return this._afterSave$.asObservable();
  }

  /**
   * Observable de seleção de item. A cada vez que for selecionada uma linha
   * o subject é disparado.
   *
   * @return {Observable<AbstractPojo>}
   */
  public get currentChanged$(): Observable<POJO> {
    return this.itGridComponent.currentChanged$;
  }

  /**
   * Retorna o objeto selecionado.
   * Exibe uma mensagem de aviso caso contrário
   * * @return {AbstractPojo}
   */
  public get selectedItem(): POJO {
    return this.itGridComponent.selectedItem;
  }

  /**
   * Retorna os itens da grid.
   * @return {AbstractPojo[]}
   */
  public get sourceCollection(): POJO[] {
    return this.itGridComponent.sourceCollection;
  }

  /**
   * Determina se o registro existe na table.
   * @param {number} id
   * @return {boolean}
   */
  public exist(id: number): boolean {
    return this.itGridComponent.exist(id);
  }

  /**
   * Atualiza o objeto. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   */
  public update(pojo: POJO) {
    this.itGridComponent.update(pojo);
  }

  /**
   * Exclui o objeto selecionado. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   * * @param idx?: number
   */
  public delete(pojo: POJO, idx?: number) {
    this.itGridComponent.delete(pojo, idx);
  }

  /**
   * Cancela a inclusão/alteração/exclusão no form.
   */
  public onCancel(): void {
    this.formEditing$.next(false);
  }

  /**
   * Retorna para um crud anterior (Custom action).
   */
  public onReturn(): void {
    this.itGridComponent.onReturn();
  }

  /**
   * Aciona o filtro de pesquisa.
   * @param filter: string texto pesquisado.
   */
  public onSearch(filter: string): void {
    this.itGridComponent.search(filter);
  }

  public eventDoubleClicked(pojo: POJO): void {
    this.selectedItemDoubleClicked$.emit(pojo);
  }

  /**
   * Atualiza o registro na gridtable e determina a ocultação do form.
   * @param details: IEditDetails<POJO>
   */
  private updateChangeTable(details: IEditDetails<POJO>): void {
    this.toasterService.pop("warning", "Aviso", "O processamento será executado em segundo plano");

    switch (details.modo) {
      case Modo.UPDATE:
        this.itGridComponent.update(details.pojo);
        break;
      case Modo.DELETE:
        this.itGridComponent.delete(details.pojo);
        break;
      default: {
        if (!NumberUtil.numberNullOrZero(details.pojo.id) && this.exist(details.pojo.id)) {
          this.itGridComponent.update(details.pojo);
        } else {
          this.itGridComponent.push(details.pojo, true);
        }
      }
    }

    /**
     * Oculta o form.
     */
    this.formEditing$.next(false);
  }

  private nextUserAction(action: Modo) {
    if (action !== undefined) {

      /**
       * Se for inclusão passa apenas o modo, caso contrário deve verificar
       * se possui item selecionado.
       */
      if (action === Modo.CREATE) {
        this.userAction$.next({modo: action});
      } else {
        const pojoSelecionado: POJO = this.selectedItem;

        /**
         * Se possui item selecionado e o id for maior que zero
         * (quando ocorrer inclusão pendente de processamento o id estara negativo)
         * determina o próximo clico.
         */
        if (pojoSelecionado !== null) {
          if (pojoSelecionado.processStatus === ProcessStatus.PENDING) {
            this.toasterService
              .pop("warning", "Atenção", "Não é possivel manipular itens não processados");
          } else {
            this.userAction$.next({modo: action, original: pojoSelecionado});
          }
        }
      }
    }
  }

}
