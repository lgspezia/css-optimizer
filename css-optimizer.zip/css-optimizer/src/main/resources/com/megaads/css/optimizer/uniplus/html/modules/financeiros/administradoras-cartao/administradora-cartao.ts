import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";
/**
 * @author Luan  on 27/07/2017.
 */
export class AdministradoraCartao extends AbstractPojo {

  public cnpj = "";
  public nome = "";
  public rede = "";
  public manual = TipoCartaoManual.DESABILITADO[EnumUtils.id];
  public idEntidade = 0;
  public prazoVencimentoCredito = 0;
  public prazoVencimentoDebito = 0;
  public parcelamentoPosCred = ParcelamentoPosDebCred.ESTABELECIMENTO[EnumUtils.id];
  public estabelecimento = 0;

  public chaveRequisicao = "";

}

export enum TipoCartaoManual {
  DESABILITADO = <any> {[EnumUtils.id]: "DESABILITADO", [EnumUtils.display]: "Desabilitado"},
  CREDITO_DEBITO = <any> {[EnumUtils.id]: "CREDITO_DEBITO", [EnumUtils.display]: "Crédito/Débito"},
  CREDITO = <any> {[EnumUtils.id]: "CREDITO", [EnumUtils.display]: "Crédito"},
  DEBITO = <any> {[EnumUtils.id]: "DEBITO", [EnumUtils.display]: "Débito"},
}

export enum ParcelamentoPosDebCred {
  ESTABELECIMENTO = <any> {[EnumUtils.id]: "ESTABELECIMENTO", [EnumUtils.display]: "Estabelecimento"},
  ADMINISTRADORA = <any> {[EnumUtils.id]: "ADMINISTRADORA", [EnumUtils.display]: "Administradora"},
}
