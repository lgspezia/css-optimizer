import { Component, Input } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-listbox",
    templateUrl: "it-listbox.component.html",
})
export class ItListboxComponent extends BaseFormComponent {
  @Input() public itens$: Observable<any>;
  @Input() public height = "";
}
