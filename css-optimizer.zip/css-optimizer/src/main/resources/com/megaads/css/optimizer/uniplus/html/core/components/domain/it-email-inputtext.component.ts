import { Component, OnInit } from "@angular/core";
import { AbstractControl, FormControl, Validators } from "@angular/forms";

import { StringUtil } from "../../utils/string.util";
import { ItInputTextComponent } from "../primitive/it-inputtext.component";

/**
 * Componente de e-mail.
 *
 * Created by Osiel S. Mello on 19/05/2017.
 */
@Component({
  selector: "it-email-inputtext",
  templateUrl: "../primitive/it-inputtext.component.html",
})
export class ItEmailInputTextComponent extends ItInputTextComponent implements OnInit {

  constructor() {
    super();
    this.len = 50;
  }

  public ngOnInit(): void {
    this.addSubscription(this.getControl()
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(this.len), emailValidator()])));
  }
}

/**
 * Validador de e-mail.
 * @return {(formControl:FormControl)}
 */
export function emailValidator() {
  return (formControl: FormControl): { emailValidate: string } => {
    const email: string = formControl.value;
    if (!StringUtil.stringNullOrEmpty(email)) {
      const filter = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
      if (!filter.test(email)) {
        return {emailValidate: "ENT15 - E-mail inválido"};
      }
    }
    return null;
  };
}
