import { Component } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { GridCrud } from "../../../core/crud/grid.crud";
import { AdministradoraCartao } from "./administradora-cartao";

/**
 * @author Luan  on 27/07/2017.
 */
@Component({
  templateUrl: "administradora-cartao.grid.crud.html"
})
export class AdministradoraCartaoGridCrudComponent extends GridCrud<AdministradoraCartao> {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new AdministradoraCartao(), "administradoras-cartao");

  }

  public eventAdmTaxa() {
    super.goTo("administradoras-cartao-taxas");
  }

  public eventRelacionarBandeira() {
    super.goTo("bandeiras-relacionadas");
  }
}
