import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { ItDynacomboboxComponent } from "./it-dynacombobox.component";

/**
 * Componente dynamico de combo que deve funcionar de acordo com os parâmetros de URLs.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-dynacombobox-params",
  templateUrl: "it-dynacombobox.component.html",
})
export class ItDynacomboboxParamsComponent<T extends any> extends ItDynacomboboxComponent<T> implements OnInit {
  @Input() public urlParams$: Observable<URLSearchParams>;

  /**
   * Cache para guardar os valores pesquisados.
   */
  private cache: any = {};

  constructor(protected httpService: HttpService) {
    super(httpService);
  }

  /**
   * Carrega os dados do servidor.
   */
  public ngOnInit() {
    this.addSubscription(this.urlParams$
      .switchMap((params: URLSearchParams) => {

        /**
         * Se achar em cache retorna o valor.
         */
        const cacheValue: any = this.cache[params.toString()];
        if (cacheValue) {
          return Observable.of(cacheValue).map((values: any) => ({params: params, values}));
        } else {
          return this.httpService.get(this.url, {search: params}).map((values: any[]) => ({params: params, values}));
        }
      })
      .subscribe((resp: { params: URLSearchParams, values: any[] }) => {

        /**
         * Cache
         */
        if (!this.cache[resp.params.toString()]) {
          this.cache[resp.params.toString()] = resp.values;
        }

        let values: any = this.insertNullOption ? [{id: 0, [this.display]: "-- selecione --"}] : [];
        values = values.concat(resp.values);
        this.combobox.itemsSource = values;

        this.afterLoad$.next();
      }, (error: ServerError) => this.handleError(error)));

    /**
     * FIXME Se houver outra maneria de fazer, esse fonte deverá ser melhorado.
     *
     * Como o componente trabalha em função de outro componente, nesse caso levo em consideração a alteração,
     * combinando para pegar o valor setado do banco, logo após aguardo o carregamento  e
     * seto o valor correto.
     */
    this.addSubscription(this.afterGet$
      .combineLatest(this.getControl(), (id: number, control: AbstractControl) => control.value)
      .combineLatest(this.afterLoad$, this.getControl(),
        (value: number, after: any, control: AbstractControl) => ({value, control}))
      .subscribe((wrapper: { value: number, control: AbstractControl }) => wrapper.control.setValue(wrapper.value)));

    this.clearItemsSource();
  }

}
