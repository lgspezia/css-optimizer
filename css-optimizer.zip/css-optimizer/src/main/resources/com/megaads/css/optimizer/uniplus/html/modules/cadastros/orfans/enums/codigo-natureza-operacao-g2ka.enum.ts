import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum CodigoNaturezaOperacaoG2ka {
  TRIBUTACAO_NO_MUNICIPIO = <any>   {[EnumUtils.id]: "1", [EnumUtils.display]: "Tributação no município"},
  TRIBUTACAO_FORA_MUNICIPIO = <any> {[EnumUtils.id]: "2", [EnumUtils.display]: "Tributação fora do município"},
  ISENCAO = <any>                   {[EnumUtils.id]: "3", [EnumUtils.display]: "Isenção"},
  IMUNE = <any>                     {[EnumUtils.id]: "4", [EnumUtils.display]: "Imune"},
  SUSPENSO_DECISAO_JUDICIAL = <any> {
    [EnumUtils.id]: "5",
    [EnumUtils.display]: "Exigibilidade suspensa por decisão judicial"
  },
  SUSPENSO_PROCEDIMENTO_ADMINISTRATIVO = <any> {
    [EnumUtils.id]: "6",
    [EnumUtils.display]: "Exigibilidade suspensa por procedimento administrativo"
  },
  SEM_DEDUCAO = <any>               {[EnumUtils.id]: "A", [EnumUtils.display]: "Sem Dedução"},
  COM_DEDUCAO = <any>               {[EnumUtils.id]: "B", [EnumUtils.display]: "Com Dedução/Materiais"},
  IMUNE_ISENTA = <any>              {[EnumUtils.id]: "C", [EnumUtils.display]: "Imune/Isenta de ISSQN"},
  DEVOLUCAO_SIMPLES_REMESSA = <any> {[EnumUtils.id]: "D", [EnumUtils.display]: "Devolução/Simples Remessa"},
  INTEMEDIACAO = <any>              {[EnumUtils.id]: "J", [EnumUtils.display]: "Intemediação"},
}
