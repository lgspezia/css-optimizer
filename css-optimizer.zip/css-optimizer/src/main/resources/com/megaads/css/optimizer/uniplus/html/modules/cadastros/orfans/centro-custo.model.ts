import { AbstractPojo } from "../../../core/crud/pojo";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class CentroCusto extends AbstractPojo {
  idEmpresa = 0;
  idCentroCustoPai = 0;
  // tipoCentroCust: TipoCentroCusto;
  descricao = "";
  codigoReduzido = "";
  codigoExtenso = "";
  inativa: boolean;
  nivelCentro = 0;
  numeroNivel1 = "";
  numeroNivel2 = "";
  numeroNivel3 = "";
  numeroNivel4 = "";
  numeroNivel5 = "";
  numeroNivel6 = "";
  numeroNivel7 = "";
  numeroNivel8 = "";
  numeroNivel9 = "";
  idUsuarioCadastrou = 0;
  dataCadastro: Date;
  idUltimoUsuarioAlteracao = 0;
  LocalDate: Date;
  dataUltimaAlteracao;
  codigoExtensoFormatado = "";
}
