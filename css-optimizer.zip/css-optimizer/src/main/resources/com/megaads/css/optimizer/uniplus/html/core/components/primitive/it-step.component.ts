import { Component, ContentChildren, EventEmitter, forwardRef, Input, Output, QueryList } from "@angular/core";

import { ItRowComponent } from "./it-row.component";

@Component({
  selector: "it-step",
  template:
    `
    <div [hidden]="!isActive">
      <ng-content></ng-content>
    </div>
  `
})
export class ItStepComponent {
  @Input() public title: string;
  @Input() public hidden: boolean;
  @Input() public isValid: boolean;
  @Input() public showNext: boolean;
  @Input() public showPrev: boolean;

  @Output() public onNext: EventEmitter<any> = new EventEmitter<any>();
  @Output() public onPrev: EventEmitter<any> = new EventEmitter<any>();
  // @Output() public onComplete: EventEmitter<any> = new EventEmitter<any>();

  public isDisabled: boolean;

  @ContentChildren(forwardRef(() => ItRowComponent)) private rows: QueryList<ItRowComponent>;

  private _isActive: boolean;

  constructor() {
    this.isValid = true;
    this.isDisabled = true;
    this.showNext = true;
    this.showPrev = true;
  }

  @Input("isActive")
  public set isActive(isActive: boolean) {
    this._isActive = isActive;
    this.isDisabled = false;
  }

  public get isActive(): boolean {
    return this._isActive;
  }

  /**
   * Invalida o flexgrid para reposicionar a table e o scroll.
   */
  public invalidateFlexGrid() {
    if (this.rows) {
      this.rows.forEach((row) => row.invalidateFlexGrid());
    }
  }
}
