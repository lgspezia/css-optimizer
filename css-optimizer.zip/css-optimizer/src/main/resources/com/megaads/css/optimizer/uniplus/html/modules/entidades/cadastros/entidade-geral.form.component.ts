import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { ItEnderecoComponent } from "../../../core/components/domain/it-endereco.component";
import { FormComponent } from "../../../core/crud/form-component";
import { identificationRequiredValidator, uniqueAsyncValidator } from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { StringUtil } from "../../../core/utils/string.util";
import { Estado } from "../../enderecos/estados/estado";
import { TipoContribuinte, TipoEntidade, TipoPessoa } from "./entidade";
import { Endereco } from "./utils/endereco";

/**
 * Componente aba Geral entidade.
 * Created by Osiel S. Mello on 16/05/2017.
 */
@Component({
  selector: "it-entidade-geral",
  templateUrl: "entidade-geral.form.component.html",
})
export class ItEntidadeGeralFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;
  @Input() public tipoEntidade$: Observable<TipoEntidade>;

  public controlEstado$: Observable<AbstractControl>;
  public formEndereco$: BehaviorSubject<FormGroup>;

  public apogeus$: Observable<boolean>;
  public comprador$: Observable<boolean>;
  public compras$: Observable<boolean>;
  public cliente$: Observable<boolean>;
  public clienteFornecedor$: Observable<boolean>;
  public checkMotorista$: Observable<boolean>;
  public dadosTrabalho$: Observable<boolean>;
  public emailsAdicionais$: Observable<boolean>;
  public estrangeiro$: Observable<boolean>;
  public fabricante$: Observable<boolean>;
  public fornecedor$: Observable<boolean>;
  public fornecedorRepresentante$: Observable<boolean>;
  public funcionalidadeComissao$: Observable<boolean>;
  public limiteCredito$: Observable<boolean>;
  public limiteCreditoDesativado$: Observable<boolean>;
  public moduloComissaoRepresentante$: Observable<boolean>;
  public motorista$: Observable<boolean>;
  public pessoaFisica$: Observable<boolean>;
  public pessoaJuridica$: Observable<boolean>;
  public portador$: Observable<boolean>;
  public planoContas$: Observable<boolean>;
  public regiao$: Observable<boolean>;
  public representante$: Observable<boolean>;
  public requiredCpfCnpj$: Observable<boolean>;
  public transportador$: Observable<boolean>;
  public tecnico$: Observable<boolean>;
  public unichef$: Observable<boolean>;

  public tipoContribuinte$: Observable<string>;
  public url$: Observable<string>;

  public tiposPessoa$: Observable<IDataItem[]>;

  @ViewChild("endereco") public itEndereco: ItEnderecoComponent;

  constructor(private contexto: ContextoService) {
    super();

    this.formEndereco$ = new BehaviorSubject(undefined);
    this.requiredCpfCnpj$ = Observable.of(false);

    this.emailsAdicionais$ = contexto.isFuncionalidade$("EMAILS_ADICIONAIS");
    this.dadosTrabalho$ = contexto.isFuncionalidade$("DADOS_TRABALHO");
    this.funcionalidadeComissao$ = contexto.isFuncionalidade$("COMISSAO");
    this.limiteCredito$ = contexto.isFuncionalidade$("LIMITE_CREDITO");
    this.unichef$ = contexto.isLicenciado$("UNICHEF2");

    this.checkMotorista$ = contexto.isModulo$("EXPEDICAO")
      .combineLatest(contexto.isModulo$("CTE"), contexto.isModulo$("MANIFESTO"),
        (e: boolean, c: boolean, m: boolean) => e || c || m);
    this.limiteCreditoDesativado$ = this.limiteCredito$.map((l: boolean) => !l);

    this.tiposPessoa$ = EnumUtils.getValues(TipoPessoa);
  }

  public ngOnInit(): void {
    /**
     * Mapeia o form de endereço.
     */
    this.addSubscription(this.getFormGroup("endereco", new Endereco()).subscribe(this.formEndereco$));

    this.controlEstado$ = this.getControl("idEstado", this.formEndereco$);

    /**
     * Tipos de entidade.
     */
    this.cliente$ = this.entidade$(TipoEntidade.CLIENTE);
    this.comprador$ = this.entidade$(TipoEntidade.COMPRADOR);
    this.fabricante$ = this.entidade$(TipoEntidade.FABRICANTE);
    this.fornecedor$ = this.entidade$(TipoEntidade.FORNECEDOR);
    this.portador$ = this.entidade$(TipoEntidade.PORTADOR);
    this.representante$ = this.entidade$(TipoEntidade.REPRESENTANTE);
    this.tecnico$ = this.entidade$(TipoEntidade.TECNICO);
    this.transportador$ = this.entidade$(TipoEntidade.TRANSPORTADORA);
    this.motorista$ = this.entidade$(TipoEntidade.MOTORISTA);

    this.clienteFornecedor$ = this.cliente$.combineLatest(this.fornecedor$, (c: boolean, f: boolean) => c || f);
    this.fornecedorRepresentante$ = this.fornecedor$
      .combineLatest(this.representante$, (f: boolean, r: boolean) => f || r);

    this.moduloComissaoRepresentante$ = this.representante$
      .combineLatest(this.contexto.isModulo$("COMISSAO"), (representante: boolean, comissao: boolean) => representante && comissao);

    this.apogeus$ = this.representante$
      .combineLatest(this.contexto.isFuncionalidade$("APOGEUS"), (representante: boolean, apogeus: boolean) => representante && apogeus);

    /**
     * Mapeia a url para geração de código.
     * @type {Observable<string>}
     */
    this.url$ = this.tipoEntidade$.map((tipoEntidade: TipoEntidade) => tipoEntidade[`url`]);

    /**
     * Se funcionalidade e crud de cliente.
     * @type {Observable<boolean>}
     */
    this.compras$ = this.contexto.isLicenciado$("COMPRAS")
      .combineLatest(this.fornecedor$, (l: boolean, f: boolean) => l && f);

    /**
     * Se funcionalidade e crud de cliente.
     * @type {Observable<boolean>}
     */
    this.planoContas$ =
      this.contexto.isFuncionalidade$("PLANO_DE_CONTAS")
        .combineLatest(this.transportador$, this.fornecedor$,
          (func: boolean, transp: boolean, forn: boolean) => (forn || transp) && func);

    /**
     * Se funcionalidade e crud de cliente.
     * @type {Observable<boolean>}
     */
    this.regiao$ = this.contexto.isFuncionalidade$("REGIAO")
      .combineLatest(this.cliente$, (f: boolean, c: boolean) => f && c);

    this.addValidators();
    this.addBehaviors();
  }


  /**
   * Validadores.
   */
  private addValidators(): void {
    this.addSubscription(this.getControl("codigo")
      .combineLatest(this.url$, (c: AbstractControl, url: string) => ({c, url}))
      .subscribe((config: { c: AbstractControl, url: string }) => {
        config.c.setValidators([Validators.required, Validators.maxLength(20)]);
        config.c.setAsyncValidators([uniqueAsyncValidator(config.url)]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("nome")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(60)])));

    this.addSubscription(this.getControl("idEstado", this.formEndereco$)
      .merge(this.getControl("idPais", this.formEndereco$))
      .subscribe((c: AbstractControl) => c.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("endereco", this.formEndereco$)
      .merge(this.getControl("bairro", this.formEndereco$), this.getControl("complemento", this.formEndereco$))
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("numero", this.formEndereco$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(6)])));

    this.addSubscription(this.getControl("telefone")
      .merge(this.getControl("celular"), this.getControl("fax"))
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(40)])));

    this.addSubscription(this.getControl("rntrcTransportador")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(8)])));

    this.addSubscription(this.getControl("numeroCnh")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(25)])));

    this.addSubscription(this.getControl("categoriaCnh")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(5)])));

    this.addSubscription(this.getControl("site")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("cnpjCpf")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(18)])));
  }

  /**
   * Adiciona os comportamentos de cada control.
   */
  private addBehaviors(): void {

    /**
     * Estrangeiro
     * @type {Observable<boolean>}
     */
    this.estrangeiro$ = this.getValueChanges("idEstado", this.formEndereco$)
      .map(() => {
        const estado: Estado = this.itEndereco.itEstado.selectedItem;
        if (estado && !StringUtil.stringNullOrEmpty(estado.codigo)) {
          return estado.codigo.toUpperCase() === "EX";
        }
        return false;
      })
      .startWith(false);

    /**
     * Pessoa física.
     * @type {Observable<boolean>}
     */
    this.pessoaFisica$ = this.estrangeiro$
      .combineLatest(this.getValueChanges("tipoPessoa").startWith(TipoPessoa.FISICA[EnumUtils.id]),
        (estrangeiro: boolean, tipoPessoa: string) => ({tipoPessoa, estrangeiro}))
      .map(({tipoPessoa, estrangeiro}) => tipoPessoa === TipoPessoa.FISICA[EnumUtils.id] && !estrangeiro);

    /**
     * Pessoa jurídica.
     * @type {Observable<boolean>}
     */
    this.pessoaJuridica$ = this.estrangeiro$
      .combineLatest(this.getValueChanges("tipoPessoa"),
        (estrangeiro: boolean, tipoPessoa: string) => ({tipoPessoa, estrangeiro}))
      .map(({tipoPessoa, estrangeiro}) => tipoPessoa === TipoPessoa.JURIDICA[EnumUtils.id] && !estrangeiro);

    /**
     * Desabilita o componente de razão social para evitar validação quando Pessoa Física.
     */
    this.addSubscription(this.getValueChanges("tipoPessoa")
      .combineLatest(this.getControl("razaoSocial"),
        (tipoPessoa: string, control: AbstractControl) => ({tipoPessoa, control}))
      .subscribe((wrapper: { tipoPessoa: string, control: AbstractControl }) => {

        if (TipoPessoa.JURIDICA[EnumUtils.id] === wrapper.tipoPessoa) {
          wrapper.control.enable();
        } else {
          wrapper.control.disable();
        }
      }));

    /**
     * Quando estrangeiro desabilita para evitar validação.
     */
    this.addSubscription(this.estrangeiro$
      .combineLatest(this.getControl("tipoPessoa"), this.getControl("razaoSocial"),
        (estrangeiro: boolean, tipoPessoa: AbstractControl, razaoSocial: AbstractControl) =>
          ({estrangeiro, tipoPessoa, razaoSocial}))
      .subscribe((wrapper: { estrangeiro: boolean, tipoPessoa: AbstractControl, razaoSocial: AbstractControl }) => {
        if (wrapper.estrangeiro) {
          wrapper.tipoPessoa.disable();
          wrapper.razaoSocial.disable();
        } else {
          wrapper.tipoPessoa.enable();
          wrapper.razaoSocial.enable();
        }
      }));

    /**
     * Atualiza o nome de estado para ser exibido em grid.
     */
    this.addSubscription(this.getValueChanges("idEstado", this.formEndereco$)
      .combineLatest(this.getControl("nomeEstado"), this.getControl("inscricaoEstadual"),
        (idEstado: number, nomeEstado: AbstractControl, ie: AbstractControl) => ({idEstado, nomeEstado, ie}))
      .subscribe((wrapper: { idEstado: number, nomeEstado: AbstractControl, ie: AbstractControl }) => {
        if (!NumberUtil.numberNullOrZero(wrapper.idEstado) && this.itEndereco.itEstado.selectedItem) {
          wrapper.nomeEstado.setValue(this.itEndereco.itEstado.selectedItem.nome);
        } else {
          wrapper.nomeEstado.setValue("");
        }
        /**
         * Atualiza a validação de Inscrição Estadual
         */
        wrapper.ie.updateValueAndValidity();
      }));

    /**
     * Atualiza o nome de cidade para ser exibido em grid.
     */
    this.addSubscription(this.getValueChanges("idCidade", this.formEndereco$)
      .combineLatest(this.getControl("nomeCidade"),
        (idCidade: number, nomeCidade: AbstractControl) => ({idCidade, nomeCidade}))
      .subscribe((wrapper: { idCidade: number, nomeCidade: AbstractControl }) => {
        if (!NumberUtil.numberNullOrZero(wrapper.idCidade) && this.itEndereco.itCidade.selectedItem) {
          wrapper.nomeCidade.setValue(this.itEndereco.itCidade.selectedItem.nome);
        } else {
          wrapper.nomeCidade.setValue("");
        }
      }));

    /**
     * Tipo de contribuinte
     * @type {Observable<string>}
     */
    this.tipoContribuinte$ = this.getValueChanges("tipoContribuinte")
      .startWith(TipoContribuinte.NAO_CONTRIBUINTE[EnumUtils.id]);

    this.updateCheck(this.cliente$, this.getControl("cliente"));
    this.updateCheck(this.tecnico$, this.getControl("tecnico"));
    this.updateCheck(this.portador$, this.getControl("portador"));
    this.updateCheck(this.motorista$, this.getControl("motorista"));
    this.updateCheck(this.fabricante$, this.getControl("fabricante"));
    this.updateCheck(this.fornecedor$, this.getControl("fornecedor"));
    this.updateCheck(this.comprador$, this.getControl("comprador"));
    this.updateCheck(this.representante$, this.getControl("representante"));
    this.updateCheck(this.transportador$, this.getControl("transportadora"));

  }

  /**
   * Retorna um novo observable de boolean atestando o valor passado.
   * @param tipo: TipoEntidade
   * @return {Observable<boolean>}
   */
  private entidade$(tipo: TipoEntidade): Observable<boolean> {
    return this.tipoEntidade$.map((t: TipoEntidade) => t[EnumUtils.id] === tipo[EnumUtils.id]);
  }

  /**
   * Se o valor do observable for true, seta valor e desabilita o control.
   * @param obs: Observable<boolean>
   * @param control: Observable<AbstractControl>
   */
  private updateCheck(obs: Observable<boolean>, control: Observable<AbstractControl>): void {
    this.addSubscription(obs
      .filter((value: boolean) => value)
      .switchMap(() => control)
      .subscribe((c: AbstractControl) => {
        c.disable();
        c.setValue(true);
      }));
  }

}

/**
 * Monta os parâmetros para a consulta de cidades.
 *
 * @param id: number
 * @return {URLSearchParams}
 */
export function mountParamsCidade(id: number): URLSearchParams {
  const params: URLSearchParams = new URLSearchParams();
  params.set("idEstado", id.toString());
  return params;
}
