import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum TipoCfopConsignacao {
  NENHUMA = <any> {[EnumUtils.id]: "NENHUMA", [EnumUtils.display]: "Nenhuma", prefixo: 0},
  SAIDA = <any>   {[EnumUtils.id]: "SAIDA", [EnumUtils.display]: "Saída", prefixo: 1},
  ENTRADA = <any> {[EnumUtils.id]: "ENTRADA", [EnumUtils.display]: "Entrada", prefixo: 2},
}
