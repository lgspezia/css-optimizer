import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItDynalistboxComponent } from "../primitive/it-dynalistbox.component";

/**
 * Componente de seleção de múltiplas empresas.
 * @author Osiel S. Mello on 06/05/2017.
 */
@Component({
    selector: "it-empresa-dynalistbox",
    templateUrl: "../primitive/it-dynalistbox.component.html",
})
export class ItEmpresaDynalistboxComponent extends ItDynalistboxComponent {

    constructor(httpService: HttpService) {
        super(httpService);
        this.label = "Empresa";
      this.display = "razaoSocial";
        this.checkedMemberPath = "selecionado";
        this.height = "60px";
        this.url = "empresas";
    }
}
