import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { EnumUtils } from "../../../enuns/enumutil";
import { IDataItem } from "../../../models/dataitem";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { TipoCampoExtra } from "./extras";

/**
 * Componente responsável por criar o form para configuração do campo extra.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-inputextra-config",
  templateUrl: "it-inputextra-config.component.html",
})
export class ItInputExtraConfigComponent extends BaseFormComponent implements OnInit {

  public form$: BehaviorSubject<FormGroup>;

  @Input() public control: string;
  @Input() public fieldtypeproperty: string;
  @Input() public fieldextraproperty: string;
  @Input() public typefield: string;

  public mask$: Observable<boolean>;
  public tiposExtra$: Observable<IDataItem[]>;

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  public ngOnInit(): void {
    this.form$ = new BehaviorSubject(this.formBuilder
      .group({
        [this.control]: ["Campo adicional", Validators.required],
        [this.fieldtypeproperty]: "TEXTO",
        [this.fieldextraproperty]: "",
        id: 0,
        item: "",
        nometabela: "",
        tipLabel: "",
      }));

    this.disable("tipLabel");

    this.tiposExtra$ = EnumUtils.getValues(TipoCampoExtra);

    /**
     * * O campo de máscara só deve existir nessas situações.
     */
    this.mask$ = this.getValueChanges(this.fieldtypeproperty)
      .map((type: string) => type !== TipoCampoExtra.CHECBOX[EnumUtils.id] &&
      type !== TipoCampoExtra.INTEIRO[EnumUtils.id] &&
      type !== TipoCampoExtra.DATA[EnumUtils.id] &&
      type !== TipoCampoExtra.DATA_HORA[EnumUtils.id]);

    /**
     * Combino o observable de mudança de valor com os controls para setar valores e validações.
     */
    this.addSubscription(
      this.getValueChanges(this.fieldtypeproperty)
        .combineLatest(this.getControl(this.fieldextraproperty), this.getControl("tipLabel"),
          (tipo: string, field: AbstractControl, tip: AbstractControl) => ({tipo, field, tip}))
        .subscribe(({tipo, field, tip}: { tipo: string, field: AbstractControl, tip: AbstractControl }) => {
          field.setValue(null);
          tip.setValue(TipoCampoExtra[tipo][`dica`]);

          /**
           * Quando selecionado combo, seta as validações para o campo.
           */
          if (tipo === TipoCampoExtra.COMBO[EnumUtils.id]) {
            field.setValidators([Validators.required]);
          } else {
            field.clearValidators();
          }
          field.updateValueAndValidity();
        }));

  }

}
