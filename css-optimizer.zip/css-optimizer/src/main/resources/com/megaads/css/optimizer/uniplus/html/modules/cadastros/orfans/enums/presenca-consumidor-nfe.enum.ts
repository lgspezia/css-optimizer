import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum PresencaConsumidorNFE {
  NAO_SE_APLICA = <any> {[EnumUtils.id]: "NAO_SE_APLICA", [EnumUtils.display]: "Não se aplica"},
  PRESENCIAL = <any> {[EnumUtils.id]: "PRESENCIAL", [EnumUtils.display]: "Presencial"},
  NAO_PRESENCIAL_INTERNET = <any> {
    [EnumUtils.id]: "NAO_PRESENCIAL_INTERNET",
    [EnumUtils.display]: "Não presencial pela internet"
  },
  NAO_PRESENCIAL_TELEATENDIMENTO = <any> {
    [EnumUtils.id]: "NAO_PRESENCIAL_TELEATENDIMENTO",
    [EnumUtils.display]: "Não presencial teleatendimento"
  },
  NFCE_ENTREGA_DOMICILIO = <any> {
    [EnumUtils.id]: "NFCE_ENTREGA_DOMICILIO",
    [EnumUtils.display]: "NFC-e com entrega a domicílio"
  },
  NAO_PRESENCIAL_OUTROS = <any> {[EnumUtils.id]: "NAO_PRESENCIAL_OUTROS", [EnumUtils.display]: "Não presencial outros"},
}
