import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { ItCidadeDynacomboboxComponent } from "../../../../core/components/domain/it-cidade-dynacombobox.component";
import { ItEstadoDynacomboboxComponent } from "../../../../core/components/domain/it-estado-dynacombobox.component";
import { ItFormTableComponent } from "../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { FormComponent } from "../../../../core/crud/form-component";
import { IParamsData } from "../../../../core/crud/param-data";
import { identificationRequiredValidator } from "../../../../core/crud/validadores";
import { ServerError } from "../../../../core/models/server-error";
import { NumberUtil } from "../../../../core/utils/number.util";
import { FilialCidadeCPOM } from "./filial-cidade-cpom";

/**
 * @author Luan  on 27/06/2017.
 */
@Component({
  selector: "it-filial-cidade-cpom",
  templateUrl: "filial-cidade-cpom.form.component.html",
})
export class ItFilialCidadeCPOMFomComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formCPOM$: BehaviorSubject<FormGroup>;
  public params$: Observable<IParamsData>;
  public paramsCidade$: Subject<URLSearchParams>;

  @ViewChild(ItFormTableComponent) public itFormTable: ItFormTableComponent<FilialCidadeCPOM>;
  @ViewChild(ItEstadoDynacomboboxComponent) public itEstado: ItEstadoDynacomboboxComponent;
  @ViewChild(ItCidadeDynacomboboxComponent) public itCidade: ItCidadeDynacomboboxComponent;

  constructor(private formBuilder: FormBuilder) {
    super();

    this.paramsCidade$ = new Subject();
  }


  public ngOnInit(): void {
    this.formCPOM$ = new BehaviorSubject(this.formBuilder.group(new FilialCidadeCPOM()));

    this.addSubscription(this.getControl("idEstado", this.formCPOM$).merge(this.getControl("idCidade", this.formCPOM$))
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    /**
     * Cria as colunas da table
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "ID", DataType.Number, 0, null, false),
      new ColumnDefinition("idFilial", "idFilial", DataType.Number, 0, null, false),
      new ColumnDefinition("idEstado", "Estado", DataType.String, 0, null, false),
      new ColumnDefinition("idCidade", "Cidade", DataType.String, 0, null, false),
      new ColumnDefinition("estado", "Estado", DataType.String, "*", null, true),
      new ColumnDefinition("cidade", "Cidade", DataType.String, "*", null, true),
    ]);

    /**
     * Passa os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idFilial", id.toString());
        return {endpoint: "cpom", search: params};
      });

    /**
     * Sempre que o id de estado for alterado será setado novos parâmetros para a busca de cidades.
     */
    this.addSubscription(this.getValueChanges("idEstado", this.formCPOM$)
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .subscribe((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEstado", id.toString());
        this.paramsCidade$.next(params);
      }));

    /**
     * Converte os dados que vem do banco, para não ter problema de vir como string
     */
    this.addSubscription(this.itFormTable.afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((filialCpom: FilialCidadeCPOM) => {
          if (filialCpom.idCidade) {
            filialCpom.idCidade = NumberUtil.parseFloat(filialCpom.idCidade.toString());
          }
          if (filialCpom.idEstado) {
            filialCpom.idEstado = NumberUtil.parseFloat(filialCpom.idEstado.toString());
          }
          if (filialCpom.id) {
            filialCpom.id = NumberUtil.parseFloat(filialCpom.id.toString());
          }
        })));

    /**
     * Limpa os campos ao clicar em incluir e limpa manualmente o combo de cidade
     */
    this.addSubscription(this.itFormTable.afterReset$
      .subscribe((form: FormGroup) => {
        form.reset(new FilialCidadeCPOM());
        this.itCidade.combobox.itemsSource = [];
      }));

    /**
     * Grava os campos na tabela e na base
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .combineLatest(this.afterGet$, (obj: FilialCidadeCPOM, id: number) => ({obj, id}))
      .subscribe((wrapper: { obj: FilialCidadeCPOM, id: number }) => {
        wrapper.obj.idFilial = wrapper.id;
        if (NumberUtil.numberNullOrZero(wrapper.obj.idEstado)) {
          this.itFormTable.handleError(new ServerError(null, "WWW59", "Campo Estado não informado"));
          return;
        }

        if (NumberUtil.numberNullOrZero(wrapper.obj.idCidade)) {
          this.itFormTable.handleError(new ServerError(null, "WWW60", "Campo Cidade não informado"));
          return;
        }

        wrapper.obj.estado = this.itEstado.selectedItem.nome;
        wrapper.obj.cidade = this.itCidade.selectedItem.nome;
        this.itFormTable.submit$.next(wrapper.obj);
      }));
  }
}
