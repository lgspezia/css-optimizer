/**
 * @author Luan  on 31/07/2017.
 */
import { AbstractPojo } from "../../../../../core/crud/pojo";

export class BandeiraRelacionadaTaxa extends AbstractPojo {

  public id = null;
  public idBandeiraAdm = 0;
  public idRelacionaBandeira = 0;
  public numeroParcelas = 1;
  public taxaCredito = 0;
  public taxaDebito = 0;
}
