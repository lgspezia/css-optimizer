import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TabelaFinanciamento } from "../../../modules/cadastros/orfans/tabela-financiamento.model";

@Component({
    selector: "it-tabelapagamento-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTabelaPagamentoAutocompleteComponent extends ItAutocompleteComponent<TabelaFinanciamento> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "tabelas-fianciamento";
        this.label = "Tabela de pagamento";
        this.display = "nome";
    }
}
