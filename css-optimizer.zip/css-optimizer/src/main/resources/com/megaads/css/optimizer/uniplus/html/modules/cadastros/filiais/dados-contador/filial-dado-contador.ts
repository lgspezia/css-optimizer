import { FormBuilder, FormGroup } from "@angular/forms";

import { Endereco } from "../../../entidades/cadastros/utils/endereco";
/**
 * @author Luan  on 23/06/2017.
 */
export class FilialContador {
  public nome = "";
  public cnpj = "";
  public cpf = "";
  public crc = "";
  public telefone = "";
  public fax = "";
  public email = "";

  public endereco: FormGroup = new FormBuilder().group(new Endereco());
}
