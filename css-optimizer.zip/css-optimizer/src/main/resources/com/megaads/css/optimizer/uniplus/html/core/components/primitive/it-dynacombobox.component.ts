import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl } from "@angular/forms";

import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { WjComboBox } from "wijmo/wijmo.angular2.input";

import { Modo } from "../../crud/grid.crud";
import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-dynacombobox",
  templateUrl: "it-dynacombobox.component.html",
})
export class ItDynacomboboxComponent<T extends any> extends BaseFormComponent implements OnInit {
  @Input() public display: string;
  @Input() public url: string;
  @Input() public afterGet$: Observable<number>;
  @Input() public insertNullOption: boolean;

  @ViewChild(WjComboBox) public combobox: WjComboBox;

  public afterLoad$: Subject<T[]>;

  constructor(protected httpService: HttpService) {
    super();
    this.afterLoad$ = new Subject();
  }

  /**
   * Carrega os dados do servidor.
   */
  public ngOnInit() {
    if (this.afterGet$) {
      /**
       * Assim que o valor for setado, busca os valores do banco guardando o id atual para setar para o componente.
       */
      this.addSubscription(this.afterGet$
        .switchMap(() => this.httpService.get(this.url)
          .combineLatest(this.getControl(), (resp: T[], control: AbstractControl) => ({resp, control})))
        .subscribe((wrapper: { resp: T[], control: AbstractControl }) => {
          const id = wrapper.control.value;
          this.loadData(wrapper.resp);
          this.afterLoad$.next(id);
        }, (error: ServerError) => this.handleError(error)));

      /**
       * Após carregar todos os dados, seta o valor selecionado.
       */
      this.addSubscription(this.afterGet$
        .combineLatest(this.afterLoad$, this.getControl(), (id: number, idAtual: any) => idAtual)
        .subscribe((idAtual: any) => {
          const object = this.combobox.itemsSource.find((item: T) => item.id === idAtual);
          if (object) {
            this.combobox.selectedValue = object.id;
          }
        }));
    }

    /**
     * Em Modo de criação busca todos os valores.
     */
    this.addSubscription(this.modo$
      .filter((modo: Modo) => modo === Modo.CREATE || modo === Modo.CUSTOM)
      .switchMap(() => this.httpService.get(this.url))
      .subscribe((resp: T[]) => this.loadData(resp), (error: ServerError) => this.handleError(error)));
  }

  /**
   * Retorna o objeto selecionado.
   * @return {T}
   */
  public get selectedItem(): T {
    return this.combobox.selectedItem;
  }

  public get selectedItemChangePC(): EventEmitter<{}> {
    return this.combobox.selectedItemChangePC;
  }

  /**
   * Limpa os itens.
   */
  public clearItemsSource(): void {
    this.combobox.itemsSource = [{}];
  }

  /**
   * Seleciona o valor passado via parâmetro.
   * @param value: any
   */
  public selectedValue(value: T): void {
    this.combobox.selectedValue = value;
  }

  /**
   * Carrega os valores do combo.
   * @param resp
   */
  protected loadData(resp: T[]) {
    let values: any = this.insertNullOption ? [{id: 0, [this.display]: "-- selecione --"}] : [];
    values = values.concat(resp);
    this.combobox.itemsSource = values;
  }
}
