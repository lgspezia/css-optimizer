import { AbstractPojo } from "../../../core/crud/pojo";

export class CfopTributacao extends AbstractPojo {
  public idCfopPai = 0;
  public percIcms = 0;
  public percIcmsImportado = 0;
  public percRedicms = 0;
  public percIcmsst = 0;
  public percRedicmsst = 0;
  public percIcmsDestino = 0;
  public percIcmsFundoPobrezaDestino = 0;
  public st = "";
  public percIcmsDiferido = 0;
  public idObservacaoLancamentoFiscal = 0;
  public idAjusteDocumentoFiscal = 0;
}
