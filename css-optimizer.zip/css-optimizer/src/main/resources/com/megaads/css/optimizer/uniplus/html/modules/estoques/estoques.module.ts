import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";

import { WjInputModule } from "wijmo/wijmo.angular2.input";

import { ComponentsModule } from "../../core/components/primitive/components.module";
import { ItAjusteEstoqueGeralFormComponent } from "./ajustes-estoque/ajuste-estoque-geral.form.component";
import { ItAjusteEstoqueItemFormComponent } from "./ajustes-estoque/ajuste-estoque-item/ajuste-estoque-item.form.component";
import { AjusteEstoqueGridCrudComponent } from "./ajustes-estoque/ajuste-estoque.grid.crud.component";
import { ItAjusteEstoqueTotalFormComponent } from "./ajustes-estoque/total/ajuste-estoque-total.form.component";
import { ItGradeFormComponent } from "./grades/grade.form.component";
import { GradeGridCrudComponent } from "./grades/grade.grid.crud.component";
import { MotivoAjusteEstoqueGridCrudComponent } from "./motivos-ajuste-estoque/motivo-ajuste-estoque.grid.crud.component";
import { ItUnidadeMedidaSinonimoFormComponent } from "./unidades-medida/sinonimos/unidademedida-sinonimo.form.component";
import { ItUnidadeMedidaGeralFormComponent } from "./unidades-medida/unidademedida-geral.form.component";
import { UnidadeMedidaGridCrudComponent } from "./unidades-medida/unidademedida.grid.crud.component";

const routes: Routes = [
  {path: "motivos-ajuste-estoque", component: MotivoAjusteEstoqueGridCrudComponent},
  {path: "unidades-medida", component: UnidadeMedidaGridCrudComponent},
  {path: "grades", component: GradeGridCrudComponent},
  {path: "ajustes-estoque", component: AjusteEstoqueGridCrudComponent},
];

@NgModule({
  declarations: [
    MotivoAjusteEstoqueGridCrudComponent, UnidadeMedidaGridCrudComponent, ItUnidadeMedidaGeralFormComponent,
    ItUnidadeMedidaSinonimoFormComponent, GradeGridCrudComponent, ItGradeFormComponent, AjusteEstoqueGridCrudComponent,
    ItAjusteEstoqueGeralFormComponent, ItAjusteEstoqueItemFormComponent, ItAjusteEstoqueTotalFormComponent,
  ],
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, ComponentsModule, ReactiveFormsModule, WjInputModule],
})
export class EstoquesModule {
}
