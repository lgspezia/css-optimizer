import { Component } from "@angular/core";

import { TipoEntidade } from "../../../modules/entidades/cadastros/entidade";
import { EnumUtils } from "../../enuns/enumutil";
import { HttpService } from "../../services/http.service";
import { ItEntidadeAutocompleteComponent } from "./it-entidade-autocomplete.component";

@Component({
  selector: "it-comprador-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
/**
 * Componente de representante, se necessário pode ser passado parâmetros como
 * ItEntidadeAutocompleteComponent#filtrarFilial ou ItEntidadeAutocompleteComponent#exibirInativos.
 * <p>
 * Para mais detalhes consultar ItEntidadeAutocompleteComponent.
 *
 * @Author Osiel.
 */
export class ItCompradorAutocompleteComponent extends ItEntidadeAutocompleteComponent {

  constructor(httpService: HttpService) {
    super(httpService);
    this.label = "Comprador";
    this.tipos = [TipoEntidade.COMPRADOR[EnumUtils.id]];
    this.urlUpdate = "compradores";
    this.configParams();
  }

}
