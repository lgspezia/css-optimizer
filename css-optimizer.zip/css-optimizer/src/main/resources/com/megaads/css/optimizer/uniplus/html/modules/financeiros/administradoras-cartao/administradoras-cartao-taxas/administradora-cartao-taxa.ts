/**
 * @author Luan  on 27/07/2017.
 */
import { AbstractPojo } from "../../../../core/crud/pojo";

export class AdministradoraCartaoTaxa extends AbstractPojo {

  public idAdministradora = 0;
  public numeroParcelas = 0;
  public taxaCredito = 0;
  public taxaDebito = 0;
}
