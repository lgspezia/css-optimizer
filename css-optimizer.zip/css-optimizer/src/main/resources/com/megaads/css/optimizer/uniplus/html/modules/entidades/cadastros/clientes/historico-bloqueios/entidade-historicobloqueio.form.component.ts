import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { applicationInjector } from "../../../../../app.module";
import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { EnumSimNao, enumSimNaoConverter } from "../../../../../core/enuns/enumutil";
import { ServerError } from "../../../../../core/models/server-error";
import { ContextoService } from "../../../../../core/services/contexto.service";
import { DateService } from "../../../../../core/services/date.service";
import { HttpService } from "../../../../../core/services/http.service";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { EntidadeHistoricoBloqueio } from "./entidade-historicobloqueio";

/**
 * Históricos de bloqueio.
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-historicobloqueio",
  templateUrl: "entidade-historicobloqueio.form.component.html",
})
export class ItEntidadeHistoricoBloqueioFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formBloqueio$: BehaviorSubject<FormGroup>;

  public bloqueado$: Observable<boolean>;
  public desbloqueado$: Observable<boolean>;

  public label$: Observable<string>;
  public icon$: Observable<string>;

  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<EntidadeHistoricoBloqueio>;

  constructor(private formBuider: FormBuilder, private contexto: ContextoService, private date: DateService) {
    super();
  }

  public ngOnInit(): void {
    this.formBloqueio$ = new BehaviorSubject(this.formBuider.group(new EntidadeHistoricoBloqueio()));

    this.bloqueado$ = this.getValueChanges("creditoRestrito")
      .merge(this.afterGet$.combineLatest(this.getControl("creditoRestrito"), (id: number, c: AbstractControl) => c.value))
      .startWith(false);

    this.desbloqueado$ = this.bloqueado$.map((bloqueado: boolean) => !bloqueado);

    this.label$ = this.bloqueado$.map((bloqueado: boolean) => bloqueado ? "Desbloquear" : "Bloquear");
    this.icon$ = this.bloqueado$.map((bloqueado: boolean) => bloqueado ? "unlock" : "lock");

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idCliente", "idCliente", DataType.Number, 0, null, false),
      new ColumnDefinition("idUsuarioResponsavel", "idUsuarioResponsavel", DataType.Number, 0, null, false),
      new ColumnDefinition("dataInclusao", "Data", DataType.Date, 170, "dd/MM/yyyy"),
      new ColumnDefinition("justificativa", "Justificativa", DataType.String, "*"),
      new ColumnDefinition("bloquear", "Bloqueado", DataType.String, 100, null, true, EnumSimNao, null, enumSimNaoConverter),
      new ColumnDefinition("usuarioResponsavel", "Usuário", DataType.String, "*"),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idCliente", id.toString());
        return {endpoint: "historico-bloqueios", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((historico: EntidadeHistoricoBloqueio) => {
          if (historico.id) {
            historico.id = NumberUtil.parseFloat(historico.id.toString());
          }
          if (historico.idCliente) {
            historico.idCliente = NumberUtil.parseFloat(historico.idCliente.toString());
          }
          if (historico.idUsuarioResponsavel) {
            historico.idUsuarioResponsavel = NumberUtil.parseFloat(historico.idUsuarioResponsavel.toString());
          }
        })));

    /**
     * TODO OSIEL TIPAGEM USUARIO
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((historico: EntidadeHistoricoBloqueio) => this.getControl("creditoRestrito")
        .switchMap((creditoRestrito: AbstractControl) => validateCreditoRestrito$(creditoRestrito.value === 1, this.afterGet$))
        .combineLatest(this.afterGet$, this.contexto.usuario$, this.getControl("creditoRestrito"),
          (validate: { validateCredito: string }, idEntidade: number, usuario: any, creditoRestrito: AbstractControl) =>
            ({validate, historico, idEntidade, usuario, creditoRestrito}))
      )
      .subscribe((obj: {
        validate: { validateCredito: string },
        historico: EntidadeHistoricoBloqueio,
        idEntidade: number,
        usuario: any,
        creditoRestrito: AbstractControl,
      }) => {

        if (obj.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validate.validateCredito));
          return;
        }

        obj.historico.idCliente = obj.idEntidade;
        obj.historico.idUsuarioResponsavel = obj.usuario.id;
        obj.historico.usuarioResponsavel = obj.usuario.nome;
        obj.historico.bloquear = obj.creditoRestrito.value === 0 ? 1 : 0;

        this.itFormTable.submit$.next(obj.historico);
        obj.creditoRestrito.setValue(obj.historico.bloquear);
        obj.historico.dataInclusao = this.date.today;
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new EntidadeHistoricoBloqueio())));
  }

}

/**
 * Verifica se o status é diferente do servidor.
 * @param valorAtual: boolean
 * @param afterGet$: Observable<number>
 * @return {Observable<{validateCredito: string}>}
 */
function validateCreditoRestrito$(valorAtual: boolean, afterGet$: Observable<number>): Observable<{ validateCredito: string }> {
  return afterGet$
    .switchMap((idEntidade: number) => {
      const http: HttpService = applicationInjector.get(HttpService);
      const params: URLSearchParams = new URLSearchParams();
      params.set("idEntidade", idEntidade.toString());

      return http.get(`historico-bloqueios/credito-restrito`, {search: params})
        .map((bloqueado: boolean) => bloqueado !== valorAtual ?
          {validateCredito: "WWW54 - O status de bloqueio atual é diferente do servidor. Por favor recarregue os dados."} : null);
    });
}
