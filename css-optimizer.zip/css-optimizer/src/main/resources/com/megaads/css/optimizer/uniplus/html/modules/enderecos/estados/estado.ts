import { AbstractPojo } from "../../../core/crud/pojo";

export class Estado extends AbstractPojo {
    public nome = "";
    public idPais = 0;
    public nomePais = "";
}
