import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { EnquadramentoIPI } from "../../../modules/notas-fiscais/enquadramentos-ipi/enquadramento-ipi";

@Component({
    selector: "it-enquadramentoipi-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItEnquadramentoIpiAutocompleteComponent extends ItAutocompleteComponent<EnquadramentoIPI> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "enquadramentos-ipi";
        this.display = "descricao";
    }
}
