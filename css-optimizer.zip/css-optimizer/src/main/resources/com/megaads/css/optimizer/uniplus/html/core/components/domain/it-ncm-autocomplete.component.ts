import { Component, Input, OnInit } from "@angular/core";

import { Ncm, TipoRegistroNcm } from "../../../modules/notas-fiscais/ncms/ncm";
import { EnumUtils } from "../../enuns/enumutil";
import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";

@Component({
  selector: "it-ncm-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItNcmAutocompleteComponent extends ItAutocompleteComponent<Ncm> implements OnInit {

  @Input() public tipo: string;

  constructor(httpService: HttpService) {
    super(httpService);
    this.url = "ncms/tipo-ncm";
    this.urlUpdate = "ncms";
    this.label = "NCM";
    this.display = "descricao";
    this.tipo = TipoRegistroNcm.PRODUTO[EnumUtils.id];
  }

  public ngOnInit(): void {
    this.addParams("tipoNcm", this.tipo);
    super.ngOnInit();
  }
}
