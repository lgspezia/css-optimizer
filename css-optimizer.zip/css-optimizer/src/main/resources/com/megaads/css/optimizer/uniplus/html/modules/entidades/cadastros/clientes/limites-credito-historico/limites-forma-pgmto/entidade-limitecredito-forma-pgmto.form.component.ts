import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { StringUtil } from "app/core/utils/string.util";
import { applicationInjector } from "../../../../../../app.module";
import {
  ItTipoDocumentoFinanceiroIntegracaoReceberAutocompleteComponent,
} from "../../../../../../core/components/domain/it-tipodocumentofinanceiro-integracao-receber-autocomplete.component";
import { ItFormTableComponent } from "../../../../../../core/components/primitive/it-formtable.component";
import { ItTableComponent } from "../../../../../../core/components/primitive/it-table.component";
import { ColumnDefinition } from "../../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../../core/crud/param-data";
import { identificationRequiredValidator } from "../../../../../../core/crud/validadores";
import { EnumUtils } from "../../../../../../core/enuns/enumutil";
import { ServerError } from "../../../../../../core/models/server-error";
import { ContextoService } from "../../../../../../core/services/contexto.service";
import { DateService } from "../../../../../../core/services/date.service";
import { HttpService } from "../../../../../../core/services/http.service";
import { NumberUtil } from "../../../../../../core/utils/number.util";
import { Usuario } from "../../../../../cadastros/usuarios/usuario";
import { TipoPessoa } from "../../../entidade";
import { LimiteCreditoHistorico } from "../limites-credito/entidade-limitecredito";
import { LimiteCreditoFormaPgmto } from "./entidade-limitecredito-formapgmto";

/**
 * Limites de créditos de clientes sem Meio de pagamento.
 *
 * Created by Osiel on 22/06/17.
 */
@Component({
  selector: "it-entidade-limitecredito-forma-pgmto",
  templateUrl: "entidade-limitecredito-forma-pgmto.form.component.html",
})
export class ItEntidadeLimiteCreditoFormaFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public columnsHistorico$: BehaviorSubject<ColumnDefinition[]>;
  public formLimiteCredito$: BehaviorSubject<FormGroup>;

  public disabledSituacaoAtual$: Observable<boolean>;
  public disabledSituacaoEspecial$: Observable<boolean>;
  public reloadFormaPagamento$: Subject<number>;
  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<LimiteCreditoFormaPgmto>;
  @ViewChild(ItTableComponent) private itTableHistorico: ItTableComponent<LimiteCreditoHistorico>;
  @ViewChild("formaPgmto") private itFormaPgmto: ItTipoDocumentoFinanceiroIntegracaoReceberAutocompleteComponent;
  @ViewChild("formaPgmtoEspecial") private itFormaPgmtoEspecial: ItTipoDocumentoFinanceiroIntegracaoReceberAutocompleteComponent;

  private tipoPessoa$: Observable<string>;
  private submit$: Subject<LimiteCreditoFormaPgmto>;

  constructor(private formBuilder: FormBuilder, private contexto: ContextoService, private date: DateService) {
    super();

    this.disabledSituacaoAtual$ = Observable.of(true);
    this.params$ = Observable.empty();
    this.reloadFormaPagamento$ = new Subject();
    this.submit$ = new Subject();
  }

  public ngOnInit(): void {
    this.formLimiteCredito$ = new BehaviorSubject(this.formBuilder.group(new LimiteCreditoFormaPgmto()));

    this.tipoPessoa$ = this.getControl("tipoPessoa").map((c: AbstractControl) => c.value);

    /**
     * Desabilita os controls de situação atual.
     */
    this.addSubscription(this.getControl("limiteCredito")
      .merge(this.getControl("limiteCreditoEspecial"), this.getControl("validadeInicialCreditoEspecial"),
        this.getControl("validadeFinalCreditoEspecial"))
      .subscribe((control: AbstractControl) => control.disable()));

    /**
     * Somente habilita os campos se marcado o checkbox.
     * @type {Observable<boolean>}
     */
    this.disabledSituacaoEspecial$ = this.getValueChanges("liberacaoEspecial", this.formLimiteCredito$)
      .map((liberacaoEspecial: boolean) => !liberacaoEspecial)
      .startWith(true);

    /**
     * Desabilita os componentes quando desmarcado a opção. Isso é por causa das validações.
     */
    this.addSubscription(this.disabledSituacaoEspecial$
      .combineLatest(this.getControl("valorLimiteCreditoEspecial", this.formLimiteCredito$),
        this.getControl("dataLiberacaoEspecialInicial", this.formLimiteCredito$),
        this.getControl("dataLiberacaoEspecialFinal", this.formLimiteCredito$),
        this.getControl("valorLimiteCredito", this.formLimiteCredito$),
        (disable: boolean, especial: AbstractControl, dataInicial: AbstractControl, dataFinal: AbstractControl, limite: AbstractControl) =>
          ({disable, especial, dataInicial, dataFinal, limite}))
      .combineLatest(this.getControl("idFormaPgmto", this.formLimiteCredito$),
        this.getControl("idFormaPgmtoEspecial", this.formLimiteCredito$),
        (wrapper: {
           disable: boolean, especial: AbstractControl, dataInicial: AbstractControl, dataFinal: AbstractControl, limite: AbstractControl,
         },
         formPgmto: AbstractControl, formPgmtoEspecial: AbstractControl) =>
          ({controls: wrapper, formPgmto, formPgmtoEspecial}))
      .subscribe((wrapper: {
        controls: {
          disable: boolean, especial: AbstractControl, dataInicial: AbstractControl, dataFinal: AbstractControl, limite: AbstractControl,
        }, formPgmto: AbstractControl, formPgmtoEspecial: AbstractControl
      }) => {
        if (wrapper.controls.disable) {
          wrapper.formPgmtoEspecial.disable();
          wrapper.controls.especial.disable();
          wrapper.controls.dataInicial.disable();
          wrapper.controls.dataFinal.disable();

          wrapper.controls.especial.setValue(0);
          wrapper.controls.dataInicial.setValue(new Date());
          wrapper.controls.dataFinal.setValue(new Date());
          wrapper.formPgmtoEspecial.setValue(null);

          wrapper.controls.limite.enable();
          wrapper.formPgmto.enable();
        } else {
          wrapper.formPgmtoEspecial.enable();
          wrapper.controls.especial.enable();
          wrapper.controls.dataInicial.enable();
          wrapper.controls.dataFinal.enable();

          wrapper.controls.limite.disable();
          wrapper.controls.limite.setValue(0);
          wrapper.formPgmto.disable();
          wrapper.formPgmto.setValue(null);
        }
      }));

    /**
     * Validadores.
     */
    this.addSubscription(this.getControl("dataLiberacaoEspecialInicial", this.formLimiteCredito$)
      .merge(this.getControl("dataLiberacaoEspecialFinal", this.formLimiteCredito$))
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("valorLimiteCredito", this.formLimiteCredito$)
      .subscribe((control: AbstractControl) => {
        control.setAsyncValidators([
          validatorLimiteAsync(this.tipoPessoa$), validatorLimiteDependenteAsync(this.afterGet$)]);
      }));

    this.addSubscription(this.getControl("valorLimiteCreditoEspecial", this.formLimiteCredito$)
      .subscribe((control: AbstractControl) => {
        control.setAsyncValidators([validatorLimiteAsync(this.tipoPessoa$, true), validatorLimiteDependenteAsync(this.afterGet$)]);
      }));

    this.addSubscription(this.getControl("idFormaPgmto", this.formLimiteCredito$)
      .merge(this.getControl("idFormaPgmtoEspecial", this.formLimiteCredito$))
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idCliente", "idCliente", DataType.Number, 0, null, false),
      new ColumnDefinition("formaPgmto", "Meio de Pgto", DataType.String, "*"),
      new ColumnDefinition("valorLimiteCredito", "Valor", DataType.Number, 180, "n2"),
      new ColumnDefinition("valorLimiteCreditoEspecial", "Liberação especial", DataType.Number, 180, "n2"),
      new ColumnDefinition("dataLiberacaoEspecialInicial", "Validade inicial", DataType.Date, 120, "dd/MM/yyyy"),
      new ColumnDefinition("dataLiberacaoEspecialFinal", "Validade final", DataType.Date, 100, "dd/MM/yyyy"),
    ]);

    /**
     * Monta as colunas.
     */
    this.columnsHistorico$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idCliente", "idCliente", DataType.Number, 0, null, false),
      new ColumnDefinition("idUsuarioResponsavel", "idUsuarioResponsavel", DataType.Number, 0, null, false),
      new ColumnDefinition("dataInclusao", "Emissão", DataType.Date, 80, "dd/MM/yyyy"),
      new ColumnDefinition("usuarioResponsavel", "Usuário", DataType.String, "*"),
      new ColumnDefinition("formaPgmto", "Meio de Pgto", DataType.String, "*"),
      new ColumnDefinition("valorLimiteCredito", "Valor", DataType.Number, 120, "n2"),
      new ColumnDefinition("valorLimiteCreditoEspecial", "Valor especial", DataType.Number, 120, "n2"),
      new ColumnDefinition("formaPgmtoEspecial", "Meio de Pgto Especial", DataType.Number, "*", "n2"),
      new ColumnDefinition("dataLiberacaoEspecialInicial", "Inicial", DataType.Date, 90, "dd/MM/yyyy"),
      new ColumnDefinition("dataLiberacaoEspecialFinal", "Final", DataType.Date, 90, "dd/MM/yyyy"),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.addSubscription(this.afterGet$
      .switchMap((id: number) => {
        this.itFormTable.spinnerService.show();
        const params: URLSearchParams = new URLSearchParams();
        params.set("idCliente", id.toString());
        return this.itFormTable.httpService.get(`limites-credito-forma-pgmto/buscar-limites`, {search: params});
      })
      .subscribe((wrapper: LimiteCreditoFormaPgmtoWrapper) => {
        this.itFormTable.updateItemsSource(wrapper.limites);
        this.itTableHistorico.updateItemsSource(wrapper.historicos);
        this.itTableHistorico.clearSelection();
        this.itFormTable.spinnerService.hide();
        this.itFormTable.nextAfterLoadData = true;
      }, (error: ServerError) => {
        this.itFormTable.spinnerService.hide();
        this.itFormTable.handleError(error);
      }));

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((limite: LimiteCreditoFormaPgmto) => {
          if (limite.id) {
            limite.id = NumberUtil.parseFloat(limite.id.toString());
          }
          if (limite.idCliente) {
            limite.idCliente = NumberUtil.parseFloat(limite.idCliente.toString());
          }
          if (limite.idUsuarioResponsavel) {
            limite.idUsuarioResponsavel = NumberUtil.parseFloat(limite.idUsuarioResponsavel.toString());
          }
          if (limite.idFormaPgmto) {
            limite.idFormaPgmto = NumberUtil.parseFloat(limite.idFormaPgmto.toString());
          }
          if (limite.idFormaPgmtoEspecial) {
            limite.idFormaPgmtoEspecial = NumberUtil.parseFloat(limite.idFormaPgmtoEspecial.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((limite: LimiteCreditoFormaPgmto) => validateLimite$(limite.valorLimiteCredito, false, this.tipoPessoa$)
        .combineLatest(validateLimite$(limite.valorLimiteCreditoEspecial, true, this.tipoPessoa$), this.afterGet$, this.contexto.usuario$,
          (validLimite: { limiteValidate: string }, validLimiteEspec: { limiteValidate: string }, idCliente: number, usuario: Usuario) =>
            ({validLimite, validLimiteEspec, idCliente, limite, usuario})))
      .subscribe((obj: {
        validLimite: { limiteValidate: string },
        validLimiteEspec: { limiteValidate: string },
        idCliente: number, limite: LimiteCreditoFormaPgmto,
        usuario: Usuario,
      }) => {

        /**
         * Validação de cartão.
         */
        if (obj.validLimite) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validLimite.limiteValidate));
          return;
        }

        if (obj.validLimiteEspec) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validLimiteEspec.limiteValidate));
          return;
        }

        obj.limite.idCliente = obj.idCliente;
        obj.limite.idUsuarioResponsavel = obj.usuario.id;

        if (!obj.limite.liberacaoEspecial) {
          obj.limite.dataLiberacaoEspecialInicial = null;
          obj.limite.dataLiberacaoEspecialFinal = null;
          obj.limite.valorLimiteCreditoEspecial = null;
          obj.limite.formaPgmto = this.itFormaPgmto.selectedItem.descricao;
        } else {
          obj.limite.valorLimiteCredito = null;
          obj.limite.idFormaPgmto = obj.limite.idFormaPgmtoEspecial;
          obj.limite.formaPgmto = this.itFormaPgmtoEspecial.selectedItem.descricao;
        }
        obj.limite.dataInclusao = this.date.today;

        this.submit$.next(obj.limite);
      }, (error) => this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Como preciso atualizar o item a cada inclusão, controlo a requisição manualmente.
     */
    this.addSubscription(this.submit$
      .switchMap((limite: LimiteCreditoFormaPgmto) => this.itFormTable.post(`limites-credito-forma-pgmto`, limite)
        .map((id: number) => ({id, limite})))
      .subscribe((wrapper: { id: number, limite: LimiteCreditoFormaPgmto }) => {
        const limitePgmto: LimiteCreditoFormaPgmto = this.itFormTable.sourceCollection
          .find((l: LimiteCreditoFormaPgmto) => l.idFormaPgmto === wrapper.limite.idFormaPgmto);

        if (limitePgmto) {
          if (wrapper.limite.liberacaoEspecial) {
            limitePgmto.valorLimiteCreditoEspecial = wrapper.limite.valorLimiteCreditoEspecial;
            limitePgmto.dataLiberacaoEspecialInicial = wrapper.limite.dataLiberacaoEspecialInicial;
            limitePgmto.dataLiberacaoEspecialFinal = wrapper.limite.dataLiberacaoEspecialFinal;
          } else {
            limitePgmto.valorLimiteCredito = wrapper.limite.valorLimiteCredito;
          }

          this.itFormTable.update(limitePgmto);
          this.itFormTable.success("Alteração realizada com sucesso");
        } else {
          wrapper.limite.id = wrapper.id;
          this.itFormTable.push(wrapper.limite);
          this.itFormTable.success("A inclusão foi feita com sucesso");
        }
        this.itFormTable.clear$.next();
        this.reloadFormaPagamento$.next();
        this.itFormTable.spinnerService.hide();
      }, (error: ServerError) => {
        this.itFormTable.spinnerService.hide();
        this.itFormTable.clear$.next();
        this.itFormTable.handleError(error);
      }));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new LimiteCreditoFormaPgmto())));
  }

}

/**
 * Validador de limite especial.
 * @return {(formControl:FormControl)=>Observable<{limiteValidate: string}>}
 */
function validatorLimiteAsync(tipoPessoa$: Observable<string>, especial: boolean = false) {
  return (formControl: FormControl) => {
    return validateLimite$(NumberUtil.parseFloat(formControl.value), especial, tipoPessoa$);
  };
}

/**
 * Realiza a consulta com o servidor para saber se o limite do dependente é válido.
 *
 * @param afterGet$: Observable<string>
 * @return {Observable<{ limiteValidate: string }>}
 */
function validatorLimiteDependenteAsync(afterGet$: Observable<number>) {
  return (formControl: FormControl) => {
    const http: HttpService = applicationInjector.get(HttpService);

    return afterGet$
      .switchMap((idCliente: number) => {
        if (NumberUtil.numberNullOrZero(formControl.value)) {
          return Observable.of(null);
        }

        const params: URLSearchParams = new URLSearchParams();
        params.set("idCliente", idCliente.toString());
        params.set("valorPretendido", formControl.value);

        return http.get(`historicos-limite-credito/validar`, {search: params});
      })
      .map(() => null)
      .catch((error: ServerError) => Observable.of({limiteDepValidate: `${error.codigo} - ${error.mensagem}`}))
      .first();
  };
}

/**
 * Observable de validação de limite.
 * @param limite: number
 * @param especial: boolean
 * @param tipoPessoa$: Observable<string>
 * @return {Observable<{ limiteValidate: string }>}
 */
function validateLimite$(limite: number, especial: boolean, tipoPessoa$: Observable<string>): Observable<{ limiteValidate: string }> {
  const contexto: ContextoService = applicationInjector.get(ContextoService);

  return contexto.usuario$
    .combineLatest(tipoPessoa$, contexto.isFuncionalidade$("LIMITE_CREDITO_FORMA_PGMTO"), contexto.getPropriedade$(599),
      (usuario: Usuario, tipoPessoa: string, meioPgmto: boolean, margemLimite: any) => {
        const maiorQueLimite: boolean = limite > NumberUtil.parseFloat(usuario.valorLimiteCredito.toString());

        if (especial) {
          return !maiorQueLimite ? null : {
            limiteValidate: "ENT29 - O valor pretendido para o limite de crédito especial é maior que o autorizado! Verifique.",
          };
        }

        if (maiorQueLimite && !(!meioPgmto && tipoPessoa === TipoPessoa.FISICA[EnumUtils.id] && NumberUtil.parseFloat(margemLimite) > 0)) {
          return {limiteValidate: "ENT33 - O valor pretendido para o limite de crédito é maior que o autorizado! Verifique."};
        }

        return null;
      })
    .first();
}

/**
 * Interface para representação de retorno de limites.
 */
interface LimiteCreditoFormaPgmtoWrapper {
  limites: LimiteCreditoFormaPgmto[];
  historicos: LimiteCreditoHistorico[];
}
