import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { LocalEstoque } from "../../../modules/estoques/locais-estoque/local-estoque";
import { Modo } from "../../crud/grid.crud";
import { ServerError } from "../../models/server-error";
import { ContextoService } from "../../services/contexto.service";
import { HttpService } from "../../services/http.service";
import { ItDynacomboboxComponent } from "../primitive/it-dynacombobox.component";

/**
 * @author Luan  on 19/07/2017.
 */
@Component({
  selector: "it-local-estoque-dynacombobox",
  templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItLocalEstoqueDynaComboboxComponent extends ItDynacomboboxComponent<LocalEstoque> implements OnInit {

  @Input() public urlParam$: Observable<URLSearchParams>;

  constructor(protected httpService: HttpService, protected contexto: ContextoService) {
    super(httpService);
    this.display = "descricao";
    this.url = "locais-estoques/local-estoque-filtrar-filial";
  }

  public ngOnInit(): any {

    const carregarPorFilial$: Observable<LocalEstoque[]> = this.urlParam$
      .switchMap((param: URLSearchParams) => this.httpService.get(this.url, {search: param}));

    if (this.afterGet$) {

      /**
       * Depois que selecionado, busca os valores no banco para guardar o id setado para o componente4
       */
      this.addSubscription(this.afterGet$
        .switchMap(() => carregarPorFilial$
          .combineLatest(this.getControl(), (locais: LocalEstoque[], control: AbstractControl) => ({locais, control})))
        .subscribe((wrapper: { locais: LocalEstoque[], control: AbstractControl }) => {
          const id = wrapper.control.value;
          this.loadData(wrapper.locais);
          this.afterLoad$.next(id);
        }, (error: ServerError) => this.handleError(error)));

      /**
       * FIXME Se houver outra maneria de fazer, esse fonte deverá ser melhorado.
       *
       * Como o componente trabalha em função de outro componente, nesse caso levo em consideração a alteração,
       * combinando para pegar o valor setado do banco, logo após aguardo o carregamento  e
       * seto o valor correto.
       */
      this.addSubscription(this.afterGet$
        .combineLatest(this.getControl(), (id: number, control: AbstractControl) => control.value)
        .combineLatest(this.afterLoad$, this.getControl(),
          (value: number, after: any, control: AbstractControl) => ({value, control}))
        .subscribe((wrapper: { value: number, control: AbstractControl }) => wrapper.control.setValue(wrapper.value)));
    }

    /**
     * quando modo de criação, busca todos os valores
     */
    this.addSubscription(this.modo$
      .filter((modo: Modo) => modo === undefined || modo === Modo.CUSTOM || modo === Modo.CREATE)
      .switchMap(() => carregarPorFilial$)
      .subscribe((resp: any) => this.loadData(resp), (error: ServerError) => this.handleError(error)));
  }
}
