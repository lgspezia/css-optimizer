import { CfopTributacao } from "./cfop-tributacao.model";

export class CfopEstado extends CfopTributacao {
  public idEstado = 0;
  public codigoEstado = "";
}
