import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { ContribuicaoPrevidenciaria } from "../../../modules/speds/contribuicoes-previdenciarias/contribuicao-previdenciaria";

@Component({
    selector: "it-contribuicaoprevidenciaria-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItContribuicaoPrevidenciariaAutocompleteComponent extends ItAutocompleteComponent<ContribuicaoPrevidenciaria> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "descricao";
        this.label = "Contribuição previdenciária";
        this.url = "contribuicoes-previdenciarias";
    }
}
