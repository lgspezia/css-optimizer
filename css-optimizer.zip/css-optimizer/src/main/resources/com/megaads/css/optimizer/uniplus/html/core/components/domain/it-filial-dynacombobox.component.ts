import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { Filial } from "../../../modules/cadastros/filiais/filial";
import { Usuario } from "../../../modules/cadastros/usuarios/usuario";
import { Modo } from "../../crud/grid.crud";
import { ServerError } from "../../models/server-error";
import { ContextoService } from "../../services/contexto.service";
import { HttpService } from "../../services/http.service";
import { NumberUtil } from "../../utils/number.util";
import { ItDynacomboboxComponent } from "../primitive/it-dynacombobox.component";

/**
 * AutoComplete de filial.
 *
 * Created by Osiel S. Mello on 03/05/2017.
 */
@Component({
  selector: "it-filial-dynacombobox",
  templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItFilialDynaComboboxComponent extends ItDynacomboboxComponent<Filial> implements OnInit {

  @Input() public filtrarCdm: boolean;
  @Input() public urlParam$: Observable<URLSearchParams>;

  constructor(protected httpService: HttpService, private contexto: ContextoService) {
    super(httpService);
    this.display = "descricao";
    this.label = "Filial";
    this.filtrarCdm = false;

    this.urlParam$ = this.contexto.usuario$
      .map((usuario: Usuario) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idPerfil", usuario.idPerfil.toString());
        params.set("cdm", this.filtrarCdm.toString());
        return params;
      });
  }

  public ngOnInit(): void {
    const obsPerfil$: Observable<Filial[]> = this.urlParam$
      .switchMap((urlParam: URLSearchParams) => this.httpService.get(`filiais/filtrar-por-perfil`, {search: urlParam}));

    if (this.afterGet$) {
      /**
       * Assim que o valor for setado, busca os valores do banco guardando o id atual para setar para o componente.
       */
      this.addSubscription(this.afterGet$
        .switchMap(() => obsPerfil$
          .combineLatest(this.getControl(), (filiais: Filial[], control: AbstractControl) => ({filiais, control})))
        .subscribe((wrapper: { filiais: Filial[], control: AbstractControl }) => {
          const id = wrapper.control.value;
          this.loadData(wrapper.filiais);
          this.afterLoad$.next(id);
        }, (error: ServerError) => this.handleError(error)));

      /**
       * Após carregar todos os dados, seta o valor selecionado.
       */
      this.addSubscription(this.afterGet$
        .combineLatest(this.afterLoad$, this.getControl(), (id: number, idAtual: any) => idAtual)
        .subscribe((idAtual: any) => {
          const object = this.combobox.itemsSource.find((item: any) => NumberUtil.parseFloat(item.id) === NumberUtil.parseFloat(idAtual));
          if (object) {
            this.combobox.selectedValue = object.id;
          }
        }));
    }

    /**
     * Em Modo de criação busca todos os valores.
     */
    this.addSubscription(this.modo$
      .filter((modo: Modo) => modo === undefined || modo === Modo.CUSTOM || modo === Modo.CREATE)
      .switchMap(() => obsPerfil$)
      .subscribe((resp: any) => this.loadData(resp), (error: ServerError) => this.handleError(error)));
  }

}
