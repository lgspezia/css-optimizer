import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { Cep } from "../../../modules/enderecos/estados/cidades/ceps/cep";
import { Estado } from "../../../modules/enderecos/estados/estado";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";
import { BaseFormComponent } from "../primitive/baseform.component";
import { ItCepInputCodeComponent } from "./it-cep-inputcode.component";
import { ItCidadeDynacomboboxComponent } from "./it-cidade-dynacombobox.component";
import { ItEstadoDynacomboboxComponent } from "./it-estado-dynacombobox.component";
import { ItPaisAutoCompleteComponent } from "./it-pais-autocomplete.component";

/**
 * Componente de endereço. O componente deve permitir a inclusão de valores e busca de CEP do banco de dados.
 *
 * Created by Osiel on 14/06/17.
 */
@Component({
  selector: "it-endereco",
  templateUrl: "it-endereco.component.html",
})
export class ItEnderecoComponent extends BaseFormComponent implements OnInit {

  @Input() public cep: string;
  @Input() public idEstado: string;
  @Input() public idPais: string;
  @Input() public idCidade: string;
  @Input() public endereco: string;
  @Input() public numero: string;
  @Input() public bairro: string;
  @Input() public complemento: string;
  @Input() public afterGet$: Observable<number>;
  @Input() public exibirPais: boolean;
  @Input() public requiredCep$: Observable<boolean>;
  @Input() public disableEstado$: Observable<boolean>;

  public disablePais$: Observable<boolean>;
  public paramsCidade$: Subject<URLSearchParams>;
  public reloadPais$: Subject<any>;

  @ViewChild("itCep") public itCep: ItCepInputCodeComponent;
  @ViewChild("itEstado") public itEstado: ItEstadoDynacomboboxComponent;
  @ViewChild("itCidade") public itCidade: ItCidadeDynacomboboxComponent;
  @ViewChild("itPais") private itPais: ItPaisAutoCompleteComponent;

  constructor() {
    super();

    this.cep = "cep";
    this.idEstado = "idEstado";
    this.idPais = "idPais";
    this.idCidade = "idCidade";
    this.endereco = "endereco";
    this.numero = "numero";
    this.bairro = "bairro";
    this.complemento = "complemento";

    this.exibirPais = true;
    this.paramsCidade$ = new Subject();
    this.reloadPais$ = new Subject();
    this.requiredCep$ = Observable.of(false);
    this.disableEstado$ = Observable.of(false);
  }

  public ngOnInit(): void {
    /**
     * Desabilita o pais quando estado for diferente de estrangeiro.
     * @type {Observable<boolean>}
     */
    this.disablePais$ = this.getValueChanges(this.idEstado)
      .filter(() => this.itEstado.selectedItem && !StringUtil.stringNullOrEmpty(this.itEstado.selectedItem.codigo))
      .map(() => this.itEstado.selectedItem.codigo.toUpperCase() !== "EX")
      .startWith(true)
      .combineLatest(this.isDeleteOrRead$, (disable: boolean, deleteOrRead: boolean) => disable || deleteOrRead);

    /**
     * Desabilita o estado quando definido ou quando modo de visualização ou exclusão.
     */
    this.addSubscription(this.disableEstado$
      .combineLatest(this.isDeleteOrRead$, this.getControl(this.idEstado),
        (disable: boolean, deleteOrRead: boolean, estado: AbstractControl) =>
          ({disable: disable || deleteOrRead, estado}))
      .subscribe((obj: { disable: boolean, estado: AbstractControl }) => obj.disable ? obj.estado.disable() : obj.estado.enable()));

    /**
     * Seta para o angular que o componente deve ser habilitado ou desabilidato.
     */
    if (this.exibirPais) {
      this.addSubscription(this.disablePais$
        .combineLatest(this.getControl(this.idPais),
          (disable: boolean, pais: AbstractControl) => ({disable, pais}))
        .subscribe((wrapper: { disable: boolean, pais: AbstractControl }) => {
          if (wrapper.disable) {
            wrapper.pais.disable();

            /**
             * Seta o pais selecionado.
             */
            if (this.itEstado.selectedItem && !NumberUtil.numberNullOrZero(this.itEstado.selectedItem.id)) {
              const estado: Estado = this.itEstado.selectedItem;
              wrapper.pais.setValue(estado.idPais);
              if (this.idPais && !this.itPais.selectedItem) {
                // Infelizmente isso é necessário pois se o valor não existir o auto complete setará null.
                wrapper.pais.setValue(estado.idPais);
                this.reloadPais$.next();
              }
            }
          } else {
            wrapper.pais.enable();
          }
        }));
    }

    /**
     * Sempre que o id de estado for alterado será setado novos parâmetros para a busca de cidades.
     */
    this.addSubscription(this.getValueChanges(this.idEstado)
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .subscribe((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set(this.idEstado, id.toString());
        this.paramsCidade$.next(params);
      }));

    /**
     * Atualiza os campos de acordo com o cep selecionado.
     */
    this.addSubscription(this.itCep.cep$
      .combineLatest(this.getControl(this.idEstado), this.getControl(this.endereco), this.getControl(this.bairro),
        (cep: Cep, estado: AbstractControl, endereco: AbstractControl, bairro: AbstractControl) =>
          ({cep, estado, endereco, bairro}))
      .subscribe((cepControls: {
        cep: Cep, estado: AbstractControl, endereco: AbstractControl,
        bairro: AbstractControl,
      }) => {
        cepControls.estado.setValue(cepControls.cep.idEstado);
        cepControls.endereco.setValue(cepControls.cep.endereco);
        cepControls.bairro.setValue(cepControls.cep.bairro);
      }));

    /**
     * Determina a cidade consultada no CEP.
     * É necessário fazer separado pois depende da consulta de estado.
     */
    this.addSubscription(this.itCidade.afterLoadData$
      .combineLatest(this.itCep.cep$, this.getControl(this.idCidade),
        (load: any, cep: Cep, cidade: AbstractControl) => ({cep, cidade}))
      .subscribe((result: { cep: Cep, cidade: AbstractControl }) => result.cidade.setValue(result.cep.idCidade)));

  }

}
