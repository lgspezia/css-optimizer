import { Component, Input, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { ContextoService } from "../../services/contexto.service";

/**
 * Div com as seguintes caracteristicas:
 * - visibilidade de acordo com modulo/funcionalidade
 * - largura configurável
 */
@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush, // valid
  selector: "it-div",
  template: `
    <div class="pad-left-0 pad-right-0 col-md-{{col}}" *ngIf="isAtivo$ | async">
      <ng-content></ng-content>
    </div>`,
})
export class ItDivComponent implements OnInit {
  @Input() public modulo: string;
  @Input() public funcionalidade: string;
  @Input() public licenca: string;
  @Input() public col = 12;
  @Input() public condicao$: Observable<boolean>;

  public isAtivo$: Observable<boolean> = Observable.of(true);

  constructor(private contextoService: ContextoService) {
  }

  /**
   * Se for definido condição, não irá validar modulo, funcionalidade e licença.
   */
  public ngOnInit(): void {
    if (this.modulo || this.funcionalidade || this.licenca) {
      this.isAtivo$ = this.contextoService
        .isAtivo$(this.modulo, this.funcionalidade, this.licenca)
        .first((ativo) => ativo);
    } else if (this.condicao$) {
      this.isAtivo$ = this.condicao$.map((ativo) => ativo);
    }
  }
}
