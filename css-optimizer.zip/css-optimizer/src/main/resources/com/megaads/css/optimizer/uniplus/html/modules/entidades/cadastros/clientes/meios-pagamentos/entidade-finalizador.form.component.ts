import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { ItFinalizadorAutocompleteComponent } from "../../../../../core/components/domain/it-finalizador-autocomplete.component";
import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { identificationRequiredValidator } from "../../../../../core/crud/validadores";
import { ServerError } from "../../../../../core/models/server-error";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { EntidadeFinalizador } from "./entidade-finalizador";

/**
 * Meios de pagamento por entidade
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-finalizador",
  templateUrl: "entidade-finalizador.form.component.html",
})
export class ItEntidadeFinalizadorFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formFinalizador$: BehaviorSubject<FormGroup>;

  public params$: Observable<IParamsData>;

  public reloadFinalizador$: Subject<any>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<EntidadeFinalizador>;
  @ViewChild(ItFinalizadorAutocompleteComponent) private itFinalizador: ItFinalizadorAutocompleteComponent;

  constructor(private formBuider: FormBuilder) {
    super();

    this.reloadFinalizador$ = new Subject();
  }

  public ngOnInit(): void {
    this.formFinalizador$ = new BehaviorSubject(this.formBuider.group(new EntidadeFinalizador()));

    this.addSubscription(this.getControl("idFinalizador", this.formFinalizador$)
      .subscribe((c: AbstractControl) => {
        c.setValidators([identificationRequiredValidator()]);
        c.setAsyncValidators([finalizadorAsyncValidate(this.itFormTable)]);
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idEntidade", "idEntidade", DataType.Number, 0, null, false),
      new ColumnDefinition("idFinalizador", "idFinalizador", DataType.Number, 0, null, false),
      new ColumnDefinition("descricaoFinalizador", "Finalizador", DataType.String, "*"),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEntidade", id.toString());
        return {endpoint: "finalizadores-entidade", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$.subscribe(() =>
        this.itFormTable.sourceCollection.forEach((finalizador: EntidadeFinalizador) => {
          if (finalizador.id) {
            finalizador.id = NumberUtil.parseFloat(finalizador.id.toString());
          }
          if (finalizador.idEntidade) {
            finalizador.idEntidade = NumberUtil.parseFloat(finalizador.idEntidade.toString());
          }
          if (finalizador.idFinalizador) {
            finalizador.idFinalizador = NumberUtil.parseFloat(finalizador.idFinalizador.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .switchMap((finalizador: EntidadeFinalizador) => finalizadorValidate$(this.itFormTable, finalizador.idFinalizador, finalizador.id)
        .combineLatest(this.afterGet$, (validate: { finValidate: string }, idEntidade: number) => ({
          validate,
          idEntidade,
          finalizador,
        })))
      .subscribe((wrapper: { validate: { finValidate: string }, idEntidade: number, finalizador: EntidadeFinalizador }) => {
        /**
         * Se não passou na validação, exibe a mensagem e retorna.
         */
        if (wrapper.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(wrapper.validate.finValidate));
          return;
        }

        wrapper.finalizador.idEntidade = wrapper.idEntidade;
        const finalizador = this.itFinalizador.selectedItem;
        if (!finalizador) {
          return;
        }
        wrapper.finalizador.descricaoFinalizador = finalizador.nome;

        this.itFormTable.submit$.next(wrapper.finalizador);
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Após a alteração, recarrega os dados para o autocomplete.
     */
    this.addSubscription(this.itFormTable.afterLoadUpdate$
      .withLatestFrom(this.getControl("idFinalizador", this.formFinalizador$),
        (finalizador: EntidadeFinalizador, idFinalizador: AbstractControl) => ({finalizador, idFinalizador}))
      .subscribe((wrapper: { finalizador: EntidadeFinalizador, idFinalizador: AbstractControl }) => {
        /**
         * Se não possuir item selecionado é porque não possui o objeto e deve ser
         * disparada uma requisição.
         */
        if (!this.itFinalizador.selectedItem) {
          if (!NumberUtil.numberNullOrZero(wrapper.finalizador.idFinalizador)) {
            if (NumberUtil.numberNullOrZero(wrapper.idFinalizador.value)) {
              wrapper.idFinalizador.setValue(wrapper.finalizador.idFinalizador);
            }
            this.reloadFinalizador$.next();
          }
        }
      }));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new EntidadeFinalizador())));
  }

}

/**
 * Validador de finalizador.
 * @param itFormTable: {@link ItFormTableComponent<EntidadeFinalizador>}
 * @return {(formControl:FormControl)=>Observable<{finValidate: string}>}
 */
function finalizadorAsyncValidate(itFormTable: ItFormTableComponent<EntidadeFinalizador>) {
  return (formControl: FormControl) => {
    return finalizadorValidate$(
      itFormTable,
      NumberUtil.parseFloat(formControl.value),
      NumberUtil.parseFloat(formControl.parent.get("id").value),
    );
  };
}

/**
 * Observable de validação assíncrona para finalizador.
 * @param itFormTable: {@link ItFormTableComponent<EntidadeFinalizador>}
 * @param idFinalizador: number
 * @param id: number
 * @return {Observable<{ finValidate: string }>}
 */
function finalizadorValidate$(itFormTable: ItFormTableComponent<EntidadeFinalizador>,
                              idFinalizador: number, id: number): Observable<{ finValidate: string }> {
  return itFormTable.afterLoadData$
    .map(() => {
      if (itFormTable.sourceCollection
          .some((f: EntidadeFinalizador) => f.idFinalizador === idFinalizador && (NumberUtil.numberNullOrZero(id) || id !== f.id))) {
        return {finValidate: "ENT26 - Este finalizador já foi incluído!"};
      }

      return null;
    }).first();
}
