import { AbstractPojo } from "../../../core/crud/pojo";

export class Hierarquia extends AbstractPojo {
  public nome = "";
  public filhos: Hierarquia[];
  public movendoGrupo: boolean;
  public idNovoGrupo = 0;
}
