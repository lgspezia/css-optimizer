import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TipoCredito } from "../../../modules/speds/tipos-credito/tipo-credito";

@Component({
    selector: "it-tipocredito-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoCreditoAutocompleteComponent extends ItAutocompleteComponent<TipoCredito> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "tipos-credito";
        this.display = "descricao";
        this.label = "Tipo de crédito";
    }
}
