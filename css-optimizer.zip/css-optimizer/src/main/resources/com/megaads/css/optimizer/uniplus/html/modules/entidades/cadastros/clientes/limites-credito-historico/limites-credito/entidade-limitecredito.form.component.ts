import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { StringUtil } from "app/core/utils/string.util";
import { applicationInjector } from "../../../../../../app.module";
import { ItFormTableComponent } from "../../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../../core/crud/param-data";
import { EnumUtils } from "../../../../../../core/enuns/enumutil";
import { ServerError } from "../../../../../../core/models/server-error";
import { ContextoService } from "../../../../../../core/services/contexto.service";
import { DateService } from "../../../../../../core/services/date.service";
import { HttpService } from "../../../../../../core/services/http.service";
import { NumberUtil } from "../../../../../../core/utils/number.util";
import { Usuario } from "../../../../../cadastros/usuarios/usuario";
import { TipoPessoa } from "../../../entidade";
import { LimiteCreditoHistorico } from "./entidade-limitecredito";

/**
 * Limites de créditos de clientes sem Meio de pagamento.
 *
 * Created by Osiel on 22/06/17.
 */
@Component({
  selector: "it-entidade-limitecredito",
  templateUrl: "entidade-limitecredito.form.component.html",
})
export class ItEntidadeLimiteCreditoFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formLimiteCredito$: BehaviorSubject<FormGroup>;

  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<LimiteCreditoHistorico>;

  private tipoPessoa$: Observable<string>;

  constructor(private formBuilder: FormBuilder, private contexto: ContextoService, private date: DateService) {
    super();
  }

  public ngOnInit(): void {
    this.formLimiteCredito$ = new BehaviorSubject(this.formBuilder.group(new LimiteCreditoHistorico()));

    this.tipoPessoa$ = this.getControl("tipoPessoa").map((c: AbstractControl) => c.value);

    /**
     * Desabilita os controls de situação atual.
     */
    this.addSubscription(this.getControl("limiteCredito")
      .merge(this.getControl("limiteCreditoEspecial"), this.getControl("validadeInicialCreditoEspecial"),
        this.getControl("validadeFinalCreditoEspecial"))
      .subscribe((control: AbstractControl) => control.disable()));

    /**
     * Somente habilita os campos se marcado o checkbox.
     * @type {Observable<boolean>}
     */
    const disabledSituacaoEspecial$ = this.getValueChanges("liberacaoEspecial", this.formLimiteCredito$)
      .map((liberacaoEspecial: boolean) => !liberacaoEspecial)
      .startWith(true);

    /**
     * Somente irá desabilitar o componente quando selecionado limite especial ou tipo pessoa fisica e
     * margem de renda configurada.
     * @type {Observable<boolean>}
     */
    const disabledLimite$ = disabledSituacaoEspecial$
      .combineLatest(this.contexto.getPropriedade$(599),
        this.getValueChanges("tipoPessoa")
          .merge(this.getControl("tipoPessoa").map((c: AbstractControl) => c.value)),
        (disableEspecial: boolean, margem: any, tipoPessoa: string) =>
          (!disableEspecial || (NumberUtil.parseInt(margem) > 0 && tipoPessoa === TipoPessoa.FISICA[EnumUtils.id])));

    this.addSubscription(disabledLimite$
      .combineLatest(this.isDeleteOrRead$, this.getControl("valorLimiteCredito", this.formLimiteCredito$),
        (disabled: boolean, deleteOrRead: boolean, valor: AbstractControl) =>
          ({disabled: disabled || deleteOrRead, valor}))
      .subscribe((obj: { disabled: boolean, valor: AbstractControl }) => obj.disabled ? obj.valor.disable() : obj.valor.enable()));

    /**
     * Desabilita os componentes quando desmarcado a opção. Isso é por causa das validações.
     */
    this.addSubscription(disabledSituacaoEspecial$
      .combineLatest(this.isDeleteOrRead$, this.getControl("valorLimiteCreditoEspecial", this.formLimiteCredito$),
        this.getControl("dataLiberacaoEspecialInicial", this.formLimiteCredito$),
        this.getControl("dataLiberacaoEspecialFinal", this.formLimiteCredito$),
        this.getControl("valorLimiteCredito", this.formLimiteCredito$),
        (disable: boolean, deleteOrRead: boolean, especial: AbstractControl, dataInicial: AbstractControl,
         dataFinal: AbstractControl, limite: AbstractControl) =>
          ({disable: disable || deleteOrRead, especial, dataInicial, dataFinal, limite}))
      .subscribe((wrapper: {
        disable: boolean, especial: AbstractControl, dataInicial: AbstractControl, dataFinal: AbstractControl, limite: AbstractControl,
      }) => {
        if (wrapper.disable) {
          wrapper.especial.disable();
          wrapper.dataInicial.disable();
          wrapper.dataFinal.disable();

          wrapper.especial.setValue(0);
          wrapper.dataInicial.setValue(new Date());
          wrapper.dataFinal.setValue(new Date());

          wrapper.limite.enable();
        } else {
          wrapper.especial.enable();
          wrapper.dataInicial.enable();
          wrapper.dataFinal.enable();

          wrapper.limite.disable();
          wrapper.limite.setValue(0);
        }
      }));

    /**
     * Validadores.
     */
    this.addSubscription(this.getControl("dataLiberacaoEspecialInicial", this.formLimiteCredito$)
      .merge(this.getControl("dataLiberacaoEspecialFinal", this.formLimiteCredito$))
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("valorLimiteCredito", this.formLimiteCredito$)
      .subscribe((control: AbstractControl) => {
        control.setAsyncValidators([
          validatorLimiteAsync(this.tipoPessoa$), validatorLimiteDependenteAsync(this.afterGet$)]);
      }));

    this.addSubscription(this.getControl("valorLimiteCreditoEspecial", this.formLimiteCredito$)
      .subscribe((control: AbstractControl) => {
        control.setAsyncValidators([validatorLimiteAsync(this.tipoPessoa$, true), validatorLimiteDependenteAsync(this.afterGet$)]);
      }));


    /**
     * Calcula o limite baseado na renda do cliente.
     *
     * Para prever as alteração de renda e tipo de pessoa, é usado o valueChanges e o merge é realizado para pegar o valor atual.
     */
    this.addSubscription(this.afterGet$
      .combineLatest(this.contexto.getPropriedade$(599),
        this.getValueChanges("renda")
          .merge(this.getControl("renda")
            .map((c: AbstractControl) => c.value)),
        this.getValueChanges("tipoPessoa")
          .merge(this.getControl("tipoPessoa")
            .map((c: AbstractControl) => c.value)),
        this.getControl("valorLimiteCredito", this.formLimiteCredito$),
        (id: number, margem: any, renda: number, tipoPessoa: string, limite: AbstractControl) =>
          ({margem, renda, tipoPessoa, limite}))
      .subscribe((wrapper: { margem: any, renda: number, tipoPessoa: string, limite: AbstractControl }) => {
        const percentualMargem: number = NumberUtil.parseInt(wrapper.margem);
        if (percentualMargem > 0 && wrapper.tipoPessoa === TipoPessoa.FISICA[EnumUtils.id]) {
          const limite: number = wrapper.renda * ( percentualMargem / 100);
          wrapper.limite.setValue(limite);
        } else {
          wrapper.limite.setValue(0);
        }
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idCliente", "idCliente", DataType.Number, 0, null, false),
      new ColumnDefinition("idUsuarioResponsavel", "idUsuarioResponsavel", DataType.Number, 0, null, false),
      new ColumnDefinition("dataInclusao", "Emissão", DataType.Date, 100, "dd/MM/yyyy"),
      new ColumnDefinition("usuarioResponsavel", "Usuário", DataType.String, "*"),
      new ColumnDefinition("valorLimiteCredito", "Valor", DataType.Number, 150, "n2"),
      new ColumnDefinition("valorLimiteCreditoEspecial", "Liberação especial", DataType.Number, 150, "n2"),
      new ColumnDefinition("dataLiberacaoEspecialInicial", "Validade inicial", DataType.Date, 120, "dd/MM/yyyy"),
      new ColumnDefinition("dataLiberacaoEspecialFinal", "Validade final", DataType.Date, 100, "dd/MM/yyyy"),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idCliente", id.toString());
        return {endpoint: "historicos-limite-credito", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((limite: LimiteCreditoHistorico) => {
          if (limite.id) {
            limite.id = NumberUtil.parseFloat(limite.id.toString());
          }
          if (limite.idCliente) {
            limite.idCliente = NumberUtil.parseFloat(limite.idCliente.toString());
          }
          if (limite.idUsuarioResponsavel) {
            limite.idUsuarioResponsavel = NumberUtil.parseFloat(limite.idUsuarioResponsavel.toString());
          }
          if (limite.idFormaPgmto) {
            limite.idFormaPgmto = NumberUtil.parseFloat(limite.idFormaPgmto.toString());
          }
          if (limite.idFormaPgmtoEspecial) {
            limite.idFormaPgmtoEspecial = NumberUtil.parseFloat(limite.idFormaPgmtoEspecial.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((limite: LimiteCreditoHistorico) => validateLimite$(limite.valorLimiteCredito, false, this.tipoPessoa$)
        .combineLatest(validateLimite$(limite.valorLimiteCreditoEspecial, true, this.tipoPessoa$), this.afterGet$, this.contexto.usuario$,
          (validLimite: { limiteValidate: string }, validLimiteEspec: { limiteValidate: string }, idCliente: number, usuario: Usuario) =>
            ({validLimite, validLimiteEspec, idCliente, limite, usuario})))
      .subscribe((obj: {
        validLimite: { limiteValidate: string },
        validLimiteEspec: { limiteValidate: string },
        idCliente: number, limite: LimiteCreditoHistorico,
        usuario: Usuario,
      }) => {

        /**
         * Validação de cartão.
         */
        if (obj.validLimite) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validLimite.limiteValidate));
          return;
        }

        if (obj.validLimiteEspec) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validLimiteEspec.limiteValidate));
          return;
        }

        obj.limite.idCliente = obj.idCliente;
        obj.limite.idUsuarioResponsavel = obj.usuario.id;
        obj.limite.usuarioResponsavel = obj.usuario.nome;

        if (!obj.limite.liberacaoEspecial) {
          obj.limite.dataLiberacaoEspecialInicial = null;
          obj.limite.dataLiberacaoEspecialFinal = null;
          obj.limite.valorLimiteCreditoEspecial = null;
        } else {
          obj.limite.valorLimiteCredito = null;
        }
        obj.limite.dataInclusao = this.date.today;

        this.itFormTable.submit$.next(obj.limite);
      }, (error) => this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Assim que a submissão for feita com sucesso, atualiza os valores dos campos de limites atuais.
     */
    this.addSubscription(this.itFormTable.afterSubmit$
      .combineLatest(this.getControl("limiteCredito"),
        this.getControl("limiteCreditoEspecial"),
        this.getControl("validadeInicialCreditoEspecial"),
        this.getControl("validadeFinalCreditoEspecial"),
        (limite: LimiteCreditoHistorico, limiteCredito: AbstractControl, especial: AbstractControl,
         inicial: AbstractControl, final: AbstractControl) => ({limite, limiteCredito, especial, inicial, final}))
      .subscribe((wrapper: {
        limite: LimiteCreditoHistorico,
        limiteCredito: AbstractControl,
        especial: AbstractControl,
        inicial: AbstractControl,
        final: AbstractControl,
      }) => {
        if (wrapper.limite.liberacaoEspecial) {
          wrapper.especial.setValue(wrapper.limite.valorLimiteCreditoEspecial);
          wrapper.inicial.setValue(wrapper.limite.dataLiberacaoEspecialInicial);
          wrapper.final.setValue(wrapper.limite.dataLiberacaoEspecialFinal);
        } else {
          wrapper.limiteCredito.setValue(wrapper.limite.valorLimiteCredito);
        }
      }));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new LimiteCreditoHistorico())));
  }

}

/**
 * Validador de limite especial.
 * @return {(formControl:FormControl)=>Observable<{limiteValidate: string}>}
 */
function validatorLimiteAsync(tipoPessoa$: Observable<string>, especial: boolean = false) {
  return (formControl: FormControl) => {
    return validateLimite$(NumberUtil.parseFloat(formControl.value), especial, tipoPessoa$);
  };
}

/**
 * Realiza a consulta com o servidor para saber se o limite do dependente é válido.
 *
 * @param afterGet$: Observable<string>
 * @return {Observable<{ limiteValidate: string }>}
 */
function validatorLimiteDependenteAsync(afterGet$: Observable<number>) {
  return (formControl: FormControl) => {
    const http: HttpService = applicationInjector.get(HttpService);

    return afterGet$
      .switchMap((idCliente: number) => {
        if (NumberUtil.numberNullOrZero(formControl.value)) {
          return Observable.of(null);
        }

        const params: URLSearchParams = new URLSearchParams();
        params.set("idCliente", idCliente.toString());
        params.set("valorPretendido", formControl.value);

        return http.get(`historicos-limite-credito/validar`, {search: params});
      })
      .map(() => null)
      .catch((error: ServerError) => Observable.of({limiteDepValidate: `${error.codigo} - ${error.mensagem}`}))
      .first();
  };
}

/**
 * Observable de validação de limite.
 * @param limite: number
 * @param especial: boolean
 * @param tipoPessoa$: Observable<string>
 * @return {Observable<{ limiteValidate: string }>}
 */
function validateLimite$(limite: number, especial: boolean, tipoPessoa$: Observable<string>): Observable<{ limiteValidate: string }> {
  const contexto: ContextoService = applicationInjector.get(ContextoService);

  return contexto.usuario$
    .combineLatest(tipoPessoa$, contexto.isFuncionalidade$("LIMITE_CREDITO_FORMA_PGMTO"), contexto.getPropriedade$(599),
      (usuario: Usuario, tipoPessoa: string, meioPgmto: boolean, margemLimite: any) => {
        const maiorQueLimite: boolean = limite > NumberUtil.parseFloat(usuario.valorLimiteCredito.toString());

        if (especial) {
          return !maiorQueLimite ? null : {
            limiteValidate: "ENT29 - O valor pretendido para o limite de crédito especial é maior que o autorizado! Verifique.",
          };
        }

        if (maiorQueLimite && !(!meioPgmto && tipoPessoa === TipoPessoa.FISICA[EnumUtils.id] && NumberUtil.parseFloat(margemLimite) > 0)) {
          return {limiteValidate: "ENT33 - O valor pretendido para o limite de crédito é maior que o autorizado! Verifique."};
        }

        return null;
      })
    .first();
}
