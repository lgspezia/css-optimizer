import { Component, Input, OnInit } from "@angular/core";

import { TributacaoProduto } from "../../../modules/produtos/produto";
import { TributacaoServico } from "../../../modules/servicos/servico";
import { EnumUtils } from "../../enuns/enumutil";
import { ItComboboxComponent } from "../primitive/it-combobox.component";

/**
 * @author Luan  on 09/08/2017.
 */
@Component({
  selector: "it-tributacao-combobox",
  templateUrl: "../primitive/it-combobox.component.html",
})
export class ItTributacaoComboboxComponent extends ItComboboxComponent<TributacaoServico | TributacaoProduto> implements OnInit {
  @Input() public servico: boolean;

  constructor() {
    super();
  }

  public ngOnInit(): void {
    this.itens$ = EnumUtils.getValues(this.servico ? TributacaoServico : TributacaoProduto);
  }
}
