import { Component, Input, OnInit } from "@angular/core";

import { BaseFormComponent } from "../primitive/baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-periododate",
  templateUrl: "it-periododate.component.html",
})
export class ItPeriodoDateComponent extends BaseFormComponent implements OnInit {
  @Input() public controlPeriodoInicial: string;
  @Input() public labelPeriodoInicial: string;
  @Input() public controlPeriodoFinal: string;
  @Input() public labelPeriodoFinal: string;
  @Input() public showTime: boolean;

  constructor() {
    super();
    this.showTime = false;
  }

  public ngOnInit(): void {
    if (!this.labelPeriodoInicial) {
      this.labelPeriodoInicial = this.showTime ? "Data e hora inicial" : "Data inicial";
    }
    if (!this.labelPeriodoFinal) {
      this.labelPeriodoFinal = this.showTime ? "Data e hora final" : "Data final";
    }
  }
}
