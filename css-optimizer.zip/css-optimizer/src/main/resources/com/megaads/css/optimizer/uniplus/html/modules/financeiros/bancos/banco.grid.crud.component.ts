import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { GridCrud } from "../../../core/crud/grid.crud";
import { uniqueAsyncValidator } from "../../../core/crud/validadores";
import { Banco } from "./banco";

/**
 * Created by luan on 24/05/17.
 */

@Component({
  templateUrl: "banco.grid.crud.html",
})
export class BancoGridCrudComponent extends GridCrud<Banco> {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Banco(), "bancos");

    this.addSubscription(this.getControl("codigo")
      .subscribe((controle: AbstractControl) => {
        controle.setValidators([Validators.required, Validators.maxLength(6)]);
        controle.setAsyncValidators([uniqueAsyncValidator("bancos")]);
      }));

    this.addSubscription(this.getControl("nome")
      .subscribe((controle: AbstractControl) => controle.setValidators([Validators.required, Validators.maxLength(60)])));

    this.disableWhenIsNotCreateMode("codigo");
  }
}
