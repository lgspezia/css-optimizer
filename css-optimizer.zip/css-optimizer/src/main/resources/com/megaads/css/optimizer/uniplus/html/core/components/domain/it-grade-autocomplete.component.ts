import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Grade } from "../../../modules/estoques/grades/grade";

@Component({
    selector: "it-grade-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItGradeAutoCompleteComponent extends ItAutocompleteComponent<Grade> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "descricao";
        this.url = "grades";
    }

}
