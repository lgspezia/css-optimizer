import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TipoComissao } from "../../../modules/financeiros/tipos-comissao/tipo-comissao";

@Component({
    selector: "it-tipocomissao-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoComissaoAutocompleteComponent extends ItAutocompleteComponent<TipoComissao> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "tipos-comissao";
        this.display = "descricao";
        this.label = "Tipo comissão";
    }
}
