import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";

import { DataType } from "wijmo/wijmo";
import { WjPopup } from "wijmo/wijmo.angular2.input";

import { Filial } from "app/modules/cadastros/filiais/filial";
import { Produto, TipoDataControleLote } from "../../../../modules/produtos/produto";
import { ColumnDefinition } from "../../../crud/column-definition";
import { AbstractPojo } from "../../../crud/pojo";
import { EnumUtils } from "../../../enuns/enumutil";
import { ContextoService } from "../../../services/contexto.service";
import { ArrayUtil } from "../../../utils/array.util";
import { NumberUtil } from "../../../utils/number.util";
import { StringUtil } from "../../../utils/string.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItFormTableComponent } from "../../primitive/it-formtable.component";
import { ItInputCodeComponent } from "../../primitive/it-inputcode.component";
import { TipoMovimento } from "../it-cfop-internaexterna-autocomplete.component";

/**
 * Componente de Lote de saída e entrada de Produto.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-produto-lote",
  templateUrl: "it-produto-lote.component.html",
})
export class ItProdutoLoteComponent extends BaseFormComponent implements OnInit {
  @Input() public afterGet$: string;
  @Input() public controlLoteSaida: string;
  @Input() public controlLoteEntrada: string;
  @Input() public controlLoteDate: string;
  @Input() public controlMapLote: string;
  @Input() public decimaisQtd$: Observable<number>;
  @Input() public eventBlur$: EventEmitter<any>;
  @Input() public idCrud$: Observable<number>;
  @Input() public informarLote$: Observable<boolean>;
  @Input() public modoDistribuicao$: Observable<boolean>;
  @Input() public produto$: Observable<Produto>;
  @Input() public resourceNameLote: string;
  @Input() public tipoMovimento$: Observable<TipoMovimento>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public descricaoProduto$: Observable<string>;
  public loteSaida$: Observable<boolean>;
  public loteEntrada$: Observable<boolean>;
  public labelDate$: Observable<string>;
  public formDistribuicao$: BehaviorSubject<FormGroup>;
  public formLote$: BehaviorSubject<FormGroup>;
  public urlParamsLoteSaida$: Observable<URLSearchParams>;

  @ViewChild(ItInputCodeComponent) private itLote: ItInputCodeComponent;
  @ViewChild("table") private itFormTable: ItFormTableComponent<LoteQuantidade>;
  @ViewChild(WjPopup) private popup: WjPopup;

  constructor(private contexto: ContextoService, private formBuilder: FormBuilder) {
    super();
    this.columns$ = new BehaviorSubject([]);
    this.informarLote$ = Observable.of(true);
    this.modoDistribuicao$ = Observable.of(false);
    this.decimaisQtd$ = Observable.of(0);
  }

  public ngOnInit(): void {
    if (this.itLote) {
      this.itLote.endPoint = `lotes/generate-code`;

      this.addSubscription(this.idCrud$
        .subscribe((id: number) => {
          this.itLote.addParams("id", id);
          this.itLote.addParams("resourceName", this.resourceNameLote);
        }));
    }

    /**
     * Inicializa um form dummy apenas para trabalhar com os componentes.
     * @type {BehaviorSubject<FormGroup>}
     */
    this.formLote$ = new BehaviorSubject(this.formBuilder.group({idLote: 0, lote: "", data: new Date()}));
    this.descricaoProduto$ = this.produto$.map((produto: Produto) => produto.nome.toUpperCase());

    this.addBehaviorsLoteSaida();
    this.addBehaviorsLoteEntrada();
    this.addDistributionsBehaviors();

    /**
     * Exibe o popup se possui lote ou limpa os dados para evitar lixo em produto errado.
     */
    this.addSubscription(this.eventBlur$
      .withLatestFrom(this.loteSaida$, this.loteEntrada$, this.informarLote$, this.getControl(this.controlLoteSaida, this.form$),
        this.getControl(this.controlLoteEntrada, this.form$), this.getControl(this.controlLoteDate, this.form$),
        (event: any, saida: boolean, entrada: boolean, informarLote: boolean, idLote: AbstractControl, lote: AbstractControl,
         data: AbstractControl) => ({possuiLote: saida || entrada, informarLote, idLote, lote, data}))
      .subscribe((wrapper: {
        possuiLote: boolean, informarLote: boolean, idLote: AbstractControl, lote: AbstractControl, data: AbstractControl,
      }) => {
        if (wrapper.possuiLote && wrapper.informarLote) {
          this.show();
        } else if (!StringUtil.stringNullOrEmpty(wrapper.lote.value) || !NumberUtil.numberNullOrZero(wrapper.idLote.value)) {
          wrapper.idLote.setValue(0);
          wrapper.lote.setValue("");
          wrapper.data.setValue(null);
        }
      }));

    /**
     * Por causa das validações.
     */
    this.addSubscription(this.loteSaida$
      .combineLatest(this.getControl("lote", this.formLote$), this.getControl("data", this.formLote$),
        (saida: boolean, lote: AbstractControl, data: AbstractControl) => ({saida, lote, data}))
      .subscribe((wrapper: { saida: boolean, lote: AbstractControl, data: AbstractControl }) => {
        if (wrapper.saida) {
          wrapper.lote.disable();
          wrapper.data.disable();
        } else {
          wrapper.lote.enable();
          wrapper.data.enable();
        }
      }));
  }

  /**
   * Exibe a dialog para informar os lotes.
   */
  public show(): void {
    /**
     * Seta os valores já confirmados anteriormente para o caso de alteração, como é algo especifico, já mata o OBS.
     * @type {Subscription}
     */
    const subscription: Subscription = this.formLote$
      .combineLatest(this.getControl(this.controlLoteSaida, this.form$).map((c: AbstractControl) => c.value),
        this.getControl(this.controlLoteEntrada, this.form$).map((c: AbstractControl) => c.value),
        this.getControl(this.controlLoteDate, this.form$).map((c: AbstractControl) => c.value),
        this.getControl(this.controlMapLote, this.form$).map((c: AbstractControl) => c.value),
        (form: FormGroup, idLote: number, lote: string, data: Date, map: [{ id: number, qtd: number }]) =>
          ({value: {idLote, lote, data}, form}))
      .subscribe((obj: { value: { idLote: number, lote: string, data: Date }, form: FormGroup }) => obj.form.patchValue(obj.value));

    subscription.unsubscribe();

    /**
     * Quando terminar limpa o form.
     */
    this.popup.show(true, () => {
      this.addSubscription(this.formLote$.subscribe((form: FormGroup) => form.reset()));
    });
  }

  /**
   * Atribui os valores ao form caso correto.
   */
  public submitDialog(): void {
    this.formLote$
      .combineLatest(this.getControl(this.controlLoteSaida, this.form$), this.getControl(this.controlLoteEntrada, this.form$),
        this.getControl(this.controlLoteDate, this.form$), this.getControl(this.controlMapLote, this.form$), this.modoDistribuicao$,
        (form, saida, entrada, date, map, distribuicao) => ({form, saida, entrada, date, map, distribuicao}))
      .subscribe((obj: {
        form: FormGroup, saida: AbstractControl, entrada: AbstractControl, date: AbstractControl, map: AbstractControl,
        distribuicao: boolean,
      }) => {
        if (obj.distribuicao) {
          /**
           * Formato de array * Ex: {3: 20}, {102: 10}
           */
          const map = {};
          this.itFormTable.sourceCollection
            .forEach((lote: LoteQuantidade) => map[lote.id] = lote.quantidade);
          obj.map.setValue(map);

          this.popup.hide();
        } else {
          obj.form.updateValueAndValidity();

          if (obj.form.valid) {
            const wrapperValue: { idLote: number, lote: string, data: Date } = obj.form.value;
            if (wrapperValue.idLote === 0) {
              wrapperValue.idLote = null;
            }

            obj.saida.setValue(wrapperValue.idLote);
            obj.entrada.setValue(wrapperValue.lote);
            obj.date.setValue(wrapperValue.data);

            this.popup.hide();
          }
        }
      }).unsubscribe();
  }

  /**
   * Comportamentos e validações para lote de saída.
   */
  private addBehaviorsLoteSaida(): void {
    /**
     * Define se exibirá lote de saída.
     * @type {Observable<boolean>}
     */
    this.loteSaida$ = this.produto$
      .withLatestFrom(this.contexto.isFuncionalidade$("LOTE"), this.tipoMovimento$, this.contexto.filial$,
        (produto: Produto, lote: boolean, tipoMovimento: TipoMovimento, filial: Filial) =>
          lote && tipoMovimento[EnumUtils.id] === TipoMovimento.SAIDA[EnumUtils.id] && produto.possuiLote && !filial.usarPeps)
      .startWith(false);

    this.urlParamsLoteSaida$ = this.produto$
      .filter((produto: Produto) => produto.possuiLote)
      .combineLatest(this.contexto.filial$, (produto: Produto, filial: Filial) => ({produto, filial}))
      .map((wrapper: { produto: Produto, filial: Filial }) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", wrapper.produto.id.toString());
        params.set("idFilial", wrapper.filial.id.toString());
        return params;
      });

  }

  /**
   * Comportamentos e validações para lote de entrada.
   */
  private addBehaviorsLoteEntrada(): void {
    this.addSubscription(this.getControl("lote", this.formLote$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(30)])));

    this.addSubscription(this.getControl("data", this.formLote$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required])));

    /**
     * Define se exibirá lote de saída.
     * @type {Observable<boolean>}
     */
    this.loteEntrada$ = this.produto$
      .withLatestFrom(this.contexto.isFuncionalidade$("LOTE"), this.tipoMovimento$,
        (produto: Produto, lote: boolean, tipoMovimento: TipoMovimento) =>
          lote && tipoMovimento[EnumUtils.id] === TipoMovimento.ENTRADA[EnumUtils.id] && produto.possuiLote)
      .startWith(false);

    this.labelDate$ = this.produto$
      .map((p: Produto) => p.tipoDataControleLote === TipoDataControleLote.FABRICACAO[EnumUtils.id] ? `Fabricação` : `Vencimento`);

    if (this.itLote) {
      this.addSubscription(this.produto$
        .subscribe((produto: Produto) => this.itLote.addParams("idProduto", produto.id.toString())));
    }
  }

  private addDistributionsBehaviors(): void {
    this.formDistribuicao$ = new BehaviorSubject(this.formBuilder.group(new LoteQuantidade()));

    /**
     * Cria as colunas.
     */
    this.addSubscription(this.decimaisQtd$
      .subscribe((decimais: number) => {
        this.columns$.next([
          new ColumnDefinition("id", "idLote", DataType.String, 0, null, false),
          new ColumnDefinition("codigo", "Lote", DataType.String, "*"),
          new ColumnDefinition("quantidade", "Quantidade", DataType.Number, "*", `n${decimais}`),
        ]);
      }));

    this.addSubscription(this.getControl("codigo", this.formDistribuicao$)
      .subscribe((control: AbstractControl) => control.disable()));

    /**
     * Faz a requisição para trazer todos os lotes a serem distribuídos.
     * Se já houver distribuição seta as quantidades existentes.
     */
    this.addSubscription(this.produto$
      .withLatestFrom(this.contexto.isFuncionalidade$("LOTE"), this.modoDistribuicao$,
        (produto: Produto, lote: boolean, modoDistribuicao: boolean) =>
          ({distribuir: lote && modoDistribuicao && produto.possuiLote, produto}))
      .filter((obj: { distribuir: boolean, produto: Produto }) => obj.distribuir)
      .switchMap((obj: { distribuir: boolean, produto: Produto }) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", obj.produto.id.toString());
        return this.itFormTable.httpService.get(`lotes/distribuicao`, {search: params})
          .combineLatest(this.getValue(this.controlMapLote), (lotes: LoteQuantidade[], map: any[]) => ({lotes, map}));
      })
      .subscribe((obj: { lotes: LoteQuantidade[], map: any[] }) => {

        if (!ArrayUtil.nullOrEmpty(obj.map)) {
          obj.lotes.forEach((lote: LoteQuantidade) => {
            const qtd: number = obj.map[lote.id];
            if (qtd) {
              lote.quantidade = qtd;
            }
          });
        }

        this.itFormTable.updateItemsSource(obj.lotes);
      }));

    /**
     * Atualiza a quantidade o lote selecionado.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .subscribe((lote: LoteQuantidade) => {

        const loteExiste: boolean = this.itFormTable.sourceCollection.some((l: LoteQuantidade) => l.codigo === lote.codigo);

        /**
         * Se não passou na validação, exibe a mensagem e retorna.
         */
        if (!loteExiste) {
          this.itFormTable.handleError({
            status: null,
            codigo: "WWW112",
            mensagem: "O lote não existe. Por favor selecione um lote!"
          });
          return;
        }

        this.itFormTable.update(lote);
        this.itFormTable.success(`Quantidade informada para o lote ${lote.codigo}`);

        this.itFormTable.clear$.next();
      }));

    /**
     * Limpa o componente.
     */
    this.addSubscription(this.itFormTable.afterReset$
      .withLatestFrom(this.getControl("codigo", this.formDistribuicao$),
        (form: FormGroup, codigo: AbstractControl) => ({form, codigo}))
      .subscribe((obj: { form: FormGroup, codigo: AbstractControl }) => {
        obj.form.reset(new LoteQuantidade());
        obj.codigo.disable();
      }));
  }
}

/**
 * Pojo dummy para auxilio.
 */
export class LoteQuantidade extends AbstractPojo {
  public id = 0;
  public codigo = "";
  public quantidade = 0;
}
