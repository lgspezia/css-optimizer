import { AbstractPojo } from "../../../../../core/crud/pojo";

/**
 * Historico de bloqueio
 *
 * Created by Osiel on 26/05/17.
 */
export class EntidadeHistoricoBloqueio extends AbstractPojo {

  public idCliente = 0;
  public idUsuarioResponsavel = 0;
  public dataInclusao: Date = new Date();
  public justificativa = "";
  public usuarioResponsavel = "";
  public bloquear = 0;

}
