import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { isNullOrUndefined } from "util";
import { applicationInjector } from "../../../../app.module";
import { TipoMovimento } from "../../../../core/components/domain/it-cfop-internaexterna-autocomplete.component";
import { Kit } from "../../../../core/components/domain/kit/it-kit-popup";
import { ItProdutoItemComponent } from "../../../../core/components/domain/produto/it-produto-item.component";
import { ItAutocompleteComponent } from "../../../../core/components/primitive/it-autocomplete.component";
import { ItFormTableComponent } from "../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { FormComponent } from "../../../../core/crud/form-component";
import { IParamsData } from "../../../../core/crud/param-data";
import {
  identificationRequiredValidator, saldoValidator$,
  valueDifferentOfValidator
} from "../../../../core/crud/validadores";
import { EnumUtils, TipoConfiguracaoEstoqueNegativo } from "../../../../core/enuns/enumutil";
import { ServerError } from "../../../../core/models/server-error";
import { ContextoService } from "../../../../core/services/contexto.service";
import { HttpService } from "../../../../core/services/http.service";
import { ArrayUtil } from "../../../../core/utils/array.util";
import { NumberUtil } from "../../../../core/utils/number.util";
import { StringUtil } from "../../../../core/utils/string.util";
import { Produto, TipoKit } from "../../../produtos/produto";
import {
  MotivoAjusteEstoque,
  MovimentacaoMotivoAjusteEstoque,
  ValorizacaoMotivoAjusteEstoque
} from "../../motivos-ajuste-estoque/motivo-ajuste-estoque";
import { AjusteEstoque, AjusteEstoqueWrapper, TipoAjusteEstoque } from "../ajuste-estoque";
import { AjusteEstoqueItem } from "./ajuste-estoque-item";
import { CentroCusto } from "../../../cadastros/orfans/centro-custo.model";


@Component({
  selector: "it-ajuste-estoque-item",
  templateUrl: "ajuste-estoque-item.form.component.html",
})
export class ItAjusteEstoqueItemFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;
  @Input() public centroCusto$: Observable<boolean>;
  @Input() public motivo$: Observable<MotivoAjusteEstoque>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;

  /**
   * Determina se o botão gravar deve estar desabilitado, isso se deve a necessidade de inclusão de ao menos
   * um item na table.
   * @return {Observable<boolean>}
   */
  public centroCustoItem$: Observable<boolean>;
  public disableForm$: BehaviorSubject<boolean>;
  public formItem$: BehaviorSubject<FormGroup>;
  public formGroup$: BehaviorSubject<FormGroup>;
  public params$: Observable<IParamsData>;

  /**
   * Custo
   */
  public labelCustoUN$: Observable<string>;
  public exibirCusto$: Observable<boolean>;
  public decimaisCusto$: Observable<number>;
  public disabledCusto$: Observable<boolean>;
  public disabledTotal$: Observable<boolean>;
  public minValueCusto$: Observable<number>;
  public reloadCentroCusto$: Subject<any>;

  /**
   * Quantidade
   */
  public modoLevantamento$: BehaviorSubject<boolean>;
  public disabledQuantidade$: Observable<boolean>;

  /**
   * Embalagem
   */
  public disableEmbalagem$: Observable<boolean>;
  public forcarUNProduto$: Observable<boolean>;

  /**
   * Grade e Número de série
   */
  public informarGrade$: Observable<boolean>;
  public numeroSerieGradeLote$: Observable<boolean>;
  public tipoMovimento$: Observable<TipoMovimento>;
  public validarSerie$: Observable<boolean>;
  public validarSaldoGrade$: Observable<boolean>;
  public idCrud$: Observable<number>;
  public idLocalEstoque$: Observable<number>;
  public initPojo: AjusteEstoqueItem;
  public reloadProduto$: Subject<boolean>;


  @ViewChild(ItFormTableComponent) public itFormTable: ItFormTableComponent<AjusteEstoqueItem>;
  @ViewChild(ItProdutoItemComponent) public itProdutoItem: ItProdutoItemComponent;
  @ViewChild("centroCusto") public itCentroCusto: ItAutocompleteComponent<CentroCusto>;

  /**
   * Criado para auxiliar quanto setar a quantidade informada através de grade ou número de série.
   */
  private quantidadeInformada$: Subject<boolean>;
  private submitWrapper$: Subject<AjusteEstoqueWrapper>;

  constructor(private contexto: ContextoService) {
    super();
    this.columns$ = new BehaviorSubject([]);
    this.decimaisCusto$ = Observable.of(6);
    this.disableEmbalagem$ = Observable.of(true);
    this.disableForm$ = new BehaviorSubject(true);
    this.forcarUNProduto$ = Observable.of(true);
    this.labelCustoUN$ = Observable.of("Custo unitário");
    this.minValueCusto$ = Observable.of(0.000001);
    this.initPojo = new AjusteEstoqueItem();
    this.modoLevantamento$ = new BehaviorSubject(false);
    this.quantidadeInformada$ = new Subject();
    this.reloadCentroCusto$ = new Subject();
    this.reloadProduto$ = new Subject();
    this.submitWrapper$ = new Subject();
  }

  public ngOnInit(): void {
    this.idCrud$ = this.getValueChanges("id")
      .merge(this.getValue("id"));

    this.idLocalEstoque$ = this.getValueChanges("idLocalEstoqueOrigem")
      .merge(this.getValue("idLocalEstoqueOrigem"));

    this.formItem$ = new BehaviorSubject(new FormBuilder().group(this.initPojo));
    this.formGroup$ = new BehaviorSubject(new FormBuilder().group({leitor: false, agruparProdutos: false}));

    /**
     * Se for visualização desabilita o form.
     */
    this.addSubscription(this.isRead$()
      .filter((read: boolean) => read)
      .switchMap(() => this.formGroup$)
      .subscribe((form: FormGroup) => form.disable()));

    this.addColumns();

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idAjuste", id.toString());
        return {endpoint: "itens-ajuste-estoque/buscar", search: params};
      });

    /**
     * O botão gravar só deve ser habilitado se possuir ao menos um item.
     */
    this.addSubscription(this.itFormTable.afterLoadData$
      .startWith(true)
      .combineLatest(this.itFormTable.clear$,
        () => !this.itFormTable.sourceCollection || this.itFormTable.sourceCollection.length === 0)
      .startWith(true)
      .subscribe(this.disableForm$));

    this.addValidations();
    this.addGeneralBehaviors();
    this.actionsFormTable();
    this.addSerialNumberVariationBehaviors();
    this.calculateTotal();
    this.loadInformationsProduct();
    this.productGroup();

  }

  /**
   * Monta as colunas.
   */
  private addColumns(): void {
    this.addSubscription(this.motivo$
      .subscribe((motivo: MotivoAjusteEstoque) => {
        let columns: ColumnDefinition[] = [
          new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
          new ColumnDefinition("idInventarioEstoque", "idInventarioEstoque", DataType.Number, 0, null, false),
          new ColumnDefinition("idProduto", "idProduto", DataType.Number, 0, null, false),
          new ColumnDefinition("idLote", "idLote", DataType.Number, 0, null, false),
          new ColumnDefinition("idCentroCusto", "idCentroCusto", DataType.Number, 0, null, false),
          new ColumnDefinition("casasDecimaisUN", "casasDecimaisUN", DataType.Number, 0, null, false),
          new ColumnDefinition("casasDecimaisCusto", "casasDecimaisCusto", DataType.Number, 0, null, false),

          new ColumnDefinition("codigoProduto", "Produto", DataType.String, 120),
          new ColumnDefinition("descricaoProduto", "Descrição", DataType.String, "*"),
          new ColumnDefinition("unidadeMedida", "UN", DataType.String, 70),
        ];

        const columnQtd: ColumnDefinition =
          new ColumnDefinition("quantidade", "Quantidade", DataType.Number, 100, null, true, null, "casasDecimaisUN");

        const movimentos: [MovimentacaoMotivoAjusteEstoque] =
          [MovimentacaoMotivoAjusteEstoque.QUANTIDADE_E_VALOR, MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR];

        if (motivo != null && EnumUtils.valueExistIn(motivo.movimentacao.toString(), movimentos)) {
          columns = columns
            .concat([
              columnQtd,
              new ColumnDefinition("preco", "Custo unitário", DataType.Number, 100, null, true, null, "casasDecimaisCusto"),
              new ColumnDefinition("total", "Total", DataType.Number, 100, "n2"),
            ]);
        } else {
          columns = columns
            .concat(motivo === null || !motivo.centroCustoObrigatorio ? [columnQtd] :
              [columnQtd, new ColumnDefinition("centroCusto", "Centro de custo", DataType.String, 150)]);
        }

        this.columns$.next(columns);
      }));
  }

  /**
   * Desabilitaos compononentes do form (com exceção de observação).
   * Não deve emitir evento pois não pode atualizar os campos dynacombobox que existem na tela.
   * @param {FormGroup} form
   */
  public disableForm(form: FormGroup): void {
    Object.keys(form.controls)
      .filter((key: string) => key !== "observacao")
      .forEach((key: any) => form.get(key).disable({onlySelf: true, emitEvent: false}));
  }

  /**
   * Validações.
   */
  private addValidations(): void {
    this.addSubscription(this.getControl("idProduto", this.formItem$)
      .subscribe((c: AbstractControl) =>
        c.setAsyncValidators([kitAsyncValidation(this.itProdutoItem.produtoSelecionado$, this.itFormTable)])));

    this.addSubscription(this.getControl("preco", this.formItem$)
      .subscribe((control: AbstractControl) => control.setValidators([valueDifferentOfValidator(0)])));

    this.addSubscription(this.getControl("total", this.formItem$)
      .subscribe((control: AbstractControl) => control.setValidators([valueDifferentOfValidator(0)])));

    /**
     * Adiciona o validador de saldo de acordo com os parâmetros necessários.
     */
    this.addSubscription(this.getControl("quantidade", this.formItem$)
      .combineLatest(this.getValueChanges("id").merge(this.getValue("id")),
        this.getValueChanges("tipoMovimento").merge(this.getValue("tipoMovimento")),
        this.getValueChanges("idLocalEstoqueOrigem").merge(this.getValue("idLocalEstoqueOrigem")),
        (control, id, tipo, idLocalEstoque) => ({control, id, tipo, idLocalEstoque}))
      .subscribe((wrapper: { control: AbstractControl, id: number, tipo: string, idLocalEstoque: number }) => {

        wrapper.control.clearAsyncValidators();
        if (EnumUtils.valueExistIn(wrapper.tipo, [TipoAjusteEstoque.SAIDA, TipoAjusteEstoque.TRANSFERENCIA_LOCAL_ESTOQUE])) {
          wrapper.control.setAsyncValidators([saldoValidation(wrapper.id, wrapper.idLocalEstoque)]);
        }
      }));

    /**
     * Como o saldo depende de lote valida novamente.
     */
    this.addSubscription(this.getValueChanges("idLote", this.formItem$)
      .combineLatest(this.getControl("quantidade", this.formItem$), (lote, quantidade) => quantidade)
      .subscribe((quantidade: AbstractControl) => quantidade.updateValueAndValidity()));

    /**
     * Validadores de centro de custo
     */
    this.addSubscription(this.getControl("idCentroCusto", this.formItem$)
      .subscribe((control: AbstractControl) => {
        control.setValidators([identificationRequiredValidator()]);
        control.setAsyncValidators([centroCustoValidation]);
      }));
  }

  /**
   * Adiciona os comportamentos gerais para vários componentes.
   */
  private addGeneralBehaviors(): void {

    /**
     * Determina se deve exibir o centro de custo.
     * @type {Observable<boolean>}
     */
    this.centroCustoItem$ = this.motivo$
      .combineLatest(this.contexto.isFuncionalidade$("CENTRO_CUSTO"),
        (motivo: MotivoAjusteEstoque, centro: boolean) => motivo !== null && motivo.centroCustoObrigatorio && centro)
      .startWith(false);

    /**
     * Quando informar somente valor, tanto quantidade quanto custo devem estar zerados.
     * @type {Observable<boolean>}
     */
    const somenteValor$: Observable<boolean> = this.motivo$
      .map((m: MotivoAjusteEstoque) => m !== null && m.movimentacao === MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR[EnumUtils.id])
      .startWith(false);

    /**
     * Deve desabilitar a quantidade quando a mesma ja foi informada através de grade ou número de série ou
     * somente valor.
     * @type {Observable<any[]> | Observable<any>}
     */
    this.disabledQuantidade$ = somenteValor$
      .combineLatest(this.quantidadeInformada$, this.isDeleteOrRead$,
        (somenteValor: boolean, informouQtd: boolean, read: boolean) => somenteValor || informouQtd || read);

    /**
     * Desabilita o total quando diferente de somente valor.
     * @type {Observable<boolean>}
     */
    this.disabledTotal$ = this.motivo$
      .map((m: MotivoAjusteEstoque) => m !== null && m.movimentacao !== MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR[EnumUtils.id])
      .combineLatest(this.isDeleteOrRead$, (somenteValor: boolean, read: boolean) => somenteValor || read);

    /**
     *Desabilita o custo unitário sempre que não for custo digitado.
     * @type {Observable<boolean>}
     */
    this.disabledCusto$ = this.motivo$
      .map((m: MotivoAjusteEstoque) => m !== null && m.valorizacao !== ValorizacaoMotivoAjusteEstoque.CUSTO_DIGITADO[EnumUtils.id])
      .combineLatest(this.isDeleteOrRead$, (custoDigitado: boolean, read: boolean) => custoDigitado || read);

    /**
     * Determina se deve exibir o custo baseado na configuração de motivo.
     * @type {Observable<boolean>}
     */
    this.exibirCusto$ = this.motivo$
      .map((m: MotivoAjusteEstoque) => m !== null && EnumUtils.valueExistIn(m.movimentacao.toString(),
        [MovimentacaoMotivoAjusteEstoque.QUANTIDADE_E_VALOR, MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR]));

    /**
     * Quando for SOMENTE_VALOR não deve pedir número de série, grade e lote.
     * @type {Observable<boolean>}
     */
    this.numeroSerieGradeLote$ = somenteValor$.map((somenteValor: boolean) => !somenteValor);

    /**
     * Quando for Levantamento é possivel incluir quantidade zero.
     * @type {Observable<boolean>}
     */
    this.addSubscription(this.getValueChanges("tipoMovimento")
      .subscribe((tipo: String) => this.modoLevantamento$.next(tipo === TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id])));

    /**
     * Converte o tipo de ajuste para o tipo de documento.
     * @type {Observable<TipoMovimento>}
     */
    this.tipoMovimento$ = this.getValueChanges("tipoMovimento")
      .map((tipo: String) => tipo === TipoAjusteEstoque.ENTRADA[EnumUtils.id] ? TipoMovimento.ENTRADA : TipoMovimento.SAIDA)
      .startWith(TipoMovimento.ENTRADA);

    /**
     * Se for levantamento não deve validar.
     * @type {Observable<boolean>}
     */
    this.validarSerie$ = this.getValueChanges("tipoMovimento")
      .map((tipo: String) => tipo !== TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id])
      .startWith(true);

    /**
     * Só deve validar saldo de for saída ou tranferência.
     * @type {Observable<boolean>}
     */
    this.validarSaldoGrade$ = this.getValueChanges("tipoMovimento")
      .map((tipo: string) => EnumUtils.valueExistIn(tipo, [TipoAjusteEstoque.SAIDA, TipoAjusteEstoque.TRANSFERENCIA_LOCAL_ESTOQUE]))
      .startWith(false);

    /**
     * Desabilita o leitor quando custo digitado.
     */
    this.addSubscription(this.isDeleteOrRead$
      .filter((isRead: boolean) => !isRead)
      .switchMap(() => this.motivo$
        .combineLatest(this.getControl("leitor", this.formGroup$),
          (m: MotivoAjusteEstoque, control: AbstractControl) => ({
            disable: m !== null && m.valorizacao === ValorizacaoMotivoAjusteEstoque.CUSTO_DIGITADO[EnumUtils.id],
            control,
          })))
      .subscribe((wrapper: { disable: boolean, control: AbstractControl }) => {
        if (wrapper.disable) {
          wrapper.control.disable();
          wrapper.control.setValue(false);
        } else if (wrapper.control.disabled) {
          wrapper.control.enable();
        }
      }));

    /**
     * Quando selecionado somente valor zera os valores dos campos.
     */
    this.addSubscription(somenteValor$
      .filter((somenteValor: boolean) => somenteValor)
      .switchMap(() => this.getControl("quantidade", this.formItem$)
        .combineLatest(this.getControl("preco", this.formItem$),
          (quantidade: AbstractControl, preco: AbstractControl) => ({quantidade, preco})))
      .subscribe((controls: { quantidade: AbstractControl, preco: AbstractControl }) => {
        controls.quantidade.setValue(0);
        controls.preco.setValue(0);
      }));

    /**
     * Seta o centro de custo do cabeçalho. Se não existir, busca o valor.
     */
    this.addSubscription(this.getValueChanges("idCentroCusto")
      .filter((idCentroCusto: number) => !NumberUtil.numberNullOrZero(idCentroCusto))
      .combineLatest(this.getControl("idCentroCusto", this.formItem$),
        (idCentroCusto: number, control: AbstractControl) => ({idCentroCusto, control}))
      .subscribe((wrapper: { idCentroCusto: number, control: AbstractControl }) => {
        wrapper.control.setValue(wrapper.idCentroCusto);
        if (!this.itCentroCusto.selectedItem) {
          this.reloadCentroCusto$.next();
        }
      }));

    /**
     * Habilita ou desabilita o control para as validações.
     */
    this.addSubscription(this.centroCustoItem$
      .combineLatest(this.getControl("idCentroCusto", this.formItem$),
        (usarCentroCusto: boolean, control: AbstractControl) => ({usarCentroCusto, control}))
      .subscribe((obj: { usarCentroCusto: boolean, control: AbstractControl }) =>
        obj.usarCentroCusto ? obj.control.enable() : obj.control.disable()));

    /**
     * Atualiza a validação sempre que altera o produto.
     */
    this.addSubscription(this.itProdutoItem.produtoSelecionado$
      .withLatestFrom(this.getControl("idProduto", this.formItem$), (p: Produto, control: AbstractControl) => control)
      .subscribe((c: AbstractControl) => c.updateValueAndValidity()));
  }

  /**
   * Calcula o total.
   */
  private calculateTotal(): void {
    this.addSubscription(this.motivo$
      .filter((m: MotivoAjusteEstoque) => m !== null && m.movimentacao !== MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR[EnumUtils.id])
      .switchMap(() => this.getValueChanges("quantidade", this.formItem$).merge(this.getValue("quantidade", this.formItem$))
        .combineLatest(this.getValueChanges("preco", this.formItem$).merge(this.getValue("preco", this.formItem$)),
          this.getControl("total", this.formItem$),
          (quantidade: number, preco: number, control: AbstractControl) => ({quantidade, preco, control})))
      .subscribe((valores: { quantidade: number, preco: number, control: AbstractControl }) => {
        const total: number = NumberUtil.parseFloat((valores.quantidade * valores.preco).toFixed(3));
        valores.control.setValue(total);
      }));
  }

  /**
   * Carrega informações baseado na alteração de produto.
   * É realizado um withLatestFrom a partir do carregamento de embalagem pois o item pode já ser incluso na table quando
   * selecionado a opção leitor e para isso é necessário as informações de embalagens.
   */
  private loadInformationsProduct(): void {
    this.addSubscription(this.itProdutoItem.itEmbalagem.afterLoad$
      .withLatestFrom(this.itProdutoItem.produtoSelecionado$, this.motivo$, this.itFormTable.updating$,
        (change, produto, motivo, updating) => ({produto, motivo, updating}))
      .switchMap((obj: { produto: Produto, motivo: MotivoAjusteEstoque, updating: boolean }) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", obj.produto.id.toString());

        /**
         * Retorna as informações de custo combinando com os controles de preco, tpoKit e fator de conversão, passando o
         * produto para setar as informações.
         */
        return this.itFormTable.httpService.get(`custos/por-filial-sessao`, {search: params})
          .combineLatest(this.getControl("preco", this.formItem$), this.getControl("tipoKit", this.formItem$),
            this.getControl("fatorConversaoEmbalagem", this.formItem$), this.getControl("quantidade", this.formItem$),
            this.getValue("leitor", this.formGroup$), this.formItem$,
            (custo: any, preco: AbstractControl, kit: AbstractControl, fator: AbstractControl, qtd: AbstractControl,
             leitor: boolean, form: FormGroup) => ({
              preco,
              kit,
              fator,
              custo,
              produto: obj.produto,
              valorizacao: obj.motivo ? obj.motivo.valorizacao : null,
              updating: obj.updating,
              qtd,
              leitor,
              form,
            }));
      })
      .subscribe((obj: {
        preco: AbstractControl, kit: AbstractControl, fator: AbstractControl, custo: any, produto: Produto,
        valorizacao: ValorizacaoMotivoAjusteEstoque, updating: boolean, qtd: AbstractControl, leitor: boolean, form: FormGroup,
      }) => {
        if (obj.valorizacao === ValorizacaoMotivoAjusteEstoque.PRECO_COMPRA[EnumUtils.id]) {
          obj.preco.setValue(obj.custo.precoUltimaCompra);
        } else if (obj.valorizacao === ValorizacaoMotivoAjusteEstoque.CUSTO_COMPRA[EnumUtils.id]) {
          obj.preco.setValue(obj.custo.precoCusto);
        } else if (obj.valorizacao === ValorizacaoMotivoAjusteEstoque.CUSTO_MEDIO[EnumUtils.id]) {
          obj.preco.setValue(obj.custo.custoMedio);
        }

        obj.kit.setValue(obj.produto.kit ? TipoKit.KIT_PAI[`value`] : TipoKit.SEM_KIT[`value`]);
        obj.fator.setValue(!isNullOrUndefined(obj.produto.embalagem) ? obj.produto.embalagem.fatorConversao : 1);
        if (obj.produto.pesoProduto) {
          obj.qtd.setValue(obj.produto.pesoProduto);
        }

        /**
         * Se utiliza leitor e não possuir lote, variação ou numero de série inclui o item automaticamente.
         */
        if (obj.leitor && !obj.produto.possuiVariacao && !obj.produto.possuiLote && !obj.produto.numeroSerie && !obj.updating) {
          obj.qtd.setValue(1);
          this.itFormTable.beforeSubmit$.next(obj.form.getRawValue());
        }
      }));

  }

  /**
   * Atualiza as informações de quantidade baseado nas informações de grade e número de série. Em determinadas situações
   * o item é incluído automaticamente na table.
   */
  private addSerialNumberVariationBehaviors(): void {

    /**
     * Monitora a mudança de valor para números de série e atualiza a quantidade e submete o item se for o caso.
     */
    this.addSubscription(this.getValueChanges("listaNumeroSeries", this.formItem$)
      .withLatestFrom(this.motivo$, this.getControl("quantidade", this.formItem$),
        this.formItem$, this.itFormTable.updating$,
        (numerosSeries, motivo, qtd, form, updating) => ({form, numerosSeries, motivo, qtd, updating}))
      .filter((obj: {
        form: FormGroup, numerosSeries: any[], motivo: MotivoAjusteEstoque, qtd: AbstractControl, updating: boolean
      }) => !ArrayUtil.nullOrEmpty(obj.numerosSeries))
      .subscribe((obj: { form: FormGroup, numerosSeries: any[], motivo: MotivoAjusteEstoque, qtd: AbstractControl, updating: boolean }) => {

        const quantidade = obj.numerosSeries.length;
        obj.qtd.setValue(quantidade);
        this.quantidadeInformada$.next(true);

        /**
         * Se for número de série e não for custo digitado e nem somente valor pode se fazer a inclusão direta do item.
         */
        if (!obj.updating) {
          if ((obj.motivo == null || isNullOrUndefined(obj.motivo.movimentacao)) ||
            (obj.motivo.movimentacao !== MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR[EnumUtils.id] &&
              obj.motivo.valorizacao !== ValorizacaoMotivoAjusteEstoque.CUSTO_DIGITADO[EnumUtils.id])) {
            this.itFormTable.beforeSubmit$.next(obj.form.getRawValue());
          }
        }
      }));

    /**
     * Monitora a mudança dos valores de variação e seta a quantidade distribuída, se for o caso ja incluí o item.
     */
    this.addSubscription(this.getValueChanges("variacoes", this.formItem$)
      .withLatestFrom(this.itProdutoItem.itVariacao.quantidadeDistribuida$.startWith(0),
        this.motivo$, this.getControl("quantidade", this.formItem$),
        this.formItem$, this.itFormTable.updating$,
        this.getValueChanges("tipoMovimento").startWith(TipoAjusteEstoque.ENTRADA[EnumUtils.id]),
        (variacoes, qtdGrade, motivo, qtd, form, updating, tipo) =>
          ({form, variacoes, qtdGrade, motivo, qtd, tipo, updating}))
      .filter((obj: {
        form: FormGroup, variacoes: string, qtdGrade: number, motivo: MotivoAjusteEstoque, qtd: AbstractControl,
        updating: boolean, tipo: string,
      }) => {
        return (!StringUtil.stringNullOrEmpty(obj.variacoes) && !NumberUtil.numberNullOrZero(obj.qtdGrade)) &&
          obj.tipo !== TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id];
      })
      .subscribe((obj: {
        form: FormGroup, variacoes: string, qtdGrade: number, motivo: MotivoAjusteEstoque, qtd: AbstractControl,
        updating: boolean, tipo: string,
      }) => {
        obj.qtd.setValue(obj.qtdGrade);
        this.quantidadeInformada$.next(true);

        /**
         * Se for grade e não for custo digitado e nem somente valor pode se fazer a inclusão direta do item.
         */
        if (!obj.updating) {
          if ((obj.motivo.movimentacao !== MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR[EnumUtils.id] &&
              obj.motivo.valorizacao !== ValorizacaoMotivoAjusteEstoque.CUSTO_DIGITADO[EnumUtils.id])) {
            this.itFormTable.beforeSubmit$.next(obj.form.getRawValue());
          }
        }
      }));

    /**
     * Monitora a mudança dos valores de map de lote quando levantamento e seta a quantidade distribuída, se for o caso ja incluí o item.
     */
    this.addSubscription(this.getValueChanges("mapLote", this.formItem$)
      .withLatestFrom(this.getControl("quantidade", this.formItem$), this.itFormTable.updating$, this.formItem$,
        this.getValueChanges("tipoMovimento").startWith(TipoAjusteEstoque.ENTRADA[EnumUtils.id]),
        (mapLote, quantidade, updating, form, tipo) => ({form, mapLote, quantidade, tipo, updating}))
      .filter((obj: { form: FormGroup, mapLote: any[], quantidade: AbstractControl, tipo: string, updating: boolean }) =>
        !ArrayUtil.nullOrEmpty(obj.mapLote) && obj.tipo === TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id])
      .subscribe((obj: { form: FormGroup, mapLote: any[], quantidade: AbstractControl, tipo: string, updating: boolean }) => {

        /**
         * Soma a quantidade
         * @type {number}
         */
        const qtd: number = Object.keys(obj.mapLote)
          .map((key) => obj.mapLote[key])
          .reduce((qtd1: number, qtd2: number) => qtd1 + qtd2, 0);

        obj.quantidade.setValue(qtd);
        this.quantidadeInformada$.next(true);

        /**
         * Submit do item.
         */
        if (!obj.updating) {
          this.itFormTable.beforeSubmit$.next(obj.form.getRawValue());
        }
      }));

    /**
     * Quando a variação foi identificada através de código de barras, é necessário informar a quantidade para a variação
     * manualmante.
     */
    this.addSubscription(this.getValueChanges("quantidade", this.formItem$)
      .combineLatest(this.quantidadeInformada$.startWith(false), this.getControl("variacoes", this.formItem$),
        (qtd: number, qtdInformada: boolean, control: AbstractControl) => ({qtd, qtdInformada, control}))
      .filter((obj: { qtd: number, qtdInformada: boolean, control: AbstractControl }) => !obj.qtdInformada)
      .subscribe((obj: { qtd: number, control: AbstractControl }) => {
        const variacoes: string = obj.control.value;
        if (!StringUtil.stringNullOrEmpty(variacoes) && variacoes.split(";").length === 1) {
          obj.control.setValue(`${variacoes.split(";")[0].split("=")[0]}=${obj.qtd}`);
        }
      }));
  }

  private actionsFormTable(): void {

    /**
     * Se informou valor zerado limpa o fomulário.
     */
    this.addSubscription(this.getControl("idProduto", this.formItem$)
      .filter((control: AbstractControl) => NumberUtil.numberNullOrZero(control.value))
      .subscribe(() => this.itFormTable.clear$.next()));

    /**
     * Carrega o item para alteração. Força o carregamento do produto.
     */
    this.addSubscription(this.itFormTable.afterLoadUpdate$
      .subscribe((item: AjusteEstoqueItem) => this.reloadProduto$.next(true)));


    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$.subscribe(() =>
        this.itFormTable.sourceCollection.forEach((item: AjusteEstoqueItem) => {
          if (item.id) {
            item.id = NumberUtil.parseFloat(item.id.toString());
          }
          if (item.idInventarioEstoque) {
            item.idInventarioEstoque = NumberUtil.parseFloat(item.idInventarioEstoque.toString());
          }
          if (item.idProduto) {
            item.idProduto = NumberUtil.parseFloat(item.idProduto.toString());
          }
          if (item.idLote) {
            item.idLote = NumberUtil.parseFloat(item.idLote.toString());
          }
          if (item.idCentroCusto) {
            item.idCentroCusto = NumberUtil.parseFloat(item.idCentroCusto.toString());
          }
          if (item.idEmbalagem) {
            item.idEmbalagem = NumberUtil.parseFloat(item.idEmbalagem.toString());
          }
          if (item.idUnidadeMedida) {
            item.idUnidadeMedida = NumberUtil.parseFloat(item.idUnidadeMedida.toString());
          }
          if (item.idProdutoKit) {
            item.idProdutoKit = NumberUtil.parseFloat(item.idProdutoKit.toString());
          }
        })));

    /**
     * Após a inclusão ou alteração se tiver marcado para agrupar, realiza o agrupamento dos itens.
     */
    this.productGroupSubscribe(this.itFormTable.afterSubmit$
      .withLatestFrom(this.getValueChanges("agruparProdutos", this.formGroup$),
        (after: AjusteEstoqueItem, group: boolean) => group)
      .filter((value: boolean) => value)
      .switchMap(() => {
        this.itFormTable.spinnerService.show();
        return this.httpProductGroup();
      }));

    /**
     * Preparação para gravação de item e cabeçalho
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .withLatestFrom(this.form$, this.itProdutoItem.produtoSelecionado$, this.motivo$,
        this.getValue("agruparProdutos", this.formGroup$),
        (item, form, produto, motivo, agruparProduto) => ({form, item, produto, motivo, agruparProduto}))
      .switchMap((obj: {
        form: FormGroup, item: AjusteEstoqueItem, produto: Produto, motivo: MotivoAjusteEstoque, agruparProduto: boolean,
      }) => {
        const tipo: string = obj.form.get("tipoMovimento").value;

        /**
         * Por default as variações são validadas na própria janela de distribuição, porém ocorre que quando digitado por código
         * de barras, não é aberto a janela de variaçõa, assim se faz necessário validar manualmente.
         */
        let variacao: number = null;
        if (!StringUtil.stringNullOrEmpty(obj.item.variacoes)) {
          const split: string[] = obj.item.variacoes.split(";");
          if (split.length === 1) {
            variacao = NumberUtil.parseInt(split[0].split("=")[0]);
          }
        }

        if (EnumUtils.valueExistIn(tipo, [TipoAjusteEstoque.SAIDA, TipoAjusteEstoque.TRANSFERENCIA_LOCAL_ESTOQUE])) {
          return saldoValidator$("ajustes-estoque-saldo", obj.item.idProduto, obj.item.quantidade, obj.form.get("id").value,
            obj.item.id, null, variacao, obj.item.idLote, obj.form.get("idLocalEstoqueOrigem").value)
            .combineLatest(kitValidator$(obj.item.id, obj.item.idProduto, this.itProdutoItem.produtoSelecionado$, this.itFormTable),
              (saldo: { saldoValidate: string }, kit: { kitValidate: string }) => ({saldo, kit}))
            .map((validations: { saldo: { saldoValidate: string }, kit: { kitValidate: string } }) => ({
              form: obj.form,
              item: obj.item,
              produto: obj.produto,
              motivo: obj.motivo,
              agruparProduto: obj.agruparProduto,
              saldo: validations.saldo,
              kit: validations.kit,
            }));
        }

        return kitValidator$(obj.item.id, obj.item.idProduto, this.itProdutoItem.produtoSelecionado$, this.itFormTable)
          .map((kit: { kitValidate: string }) => ({
            form: obj.form,
            item: obj.item,
            produto: obj.produto,
            motivo: obj.motivo,
            agruparProduto: obj.agruparProduto,
            saldo: null,
            kit,
          }));

      })
      .subscribe((wrapper: {
        form: FormGroup, item: AjusteEstoqueItem, produto: Produto, motivo: MotivoAjusteEstoque, agruparProduto: boolean,
        saldo: { saldoValidate: string }, kit: { kitValidate: string },
      }) => {

        if (wrapper.form.invalid) {
          this.itFormTable.warning({
            status: null,
            codigo: "WWW110",
            mensagem: "Por favor verifique os valores informados no formulário geral."
          });
          return;
        }

        /**
         * Validação de saldo de estoque ou kit.
         */
        if (wrapper.saldo || wrapper.kit) {
          this.itFormTable.warning(StringUtil.splitErrorCode(wrapper.saldo ? wrapper.saldo.saldoValidate : wrapper.kit.kitValidate));
          return;
        }

        const ajuste: AjusteEstoque = wrapper.form.getRawValue();
        if (!this.validarItem(ajuste, wrapper.item, wrapper.motivo, wrapper.produto, wrapper.agruparProduto)) {
          this.itFormTable.clear$.next();
          return;
        }

        wrapper.item.codigoProduto = wrapper.produto.codigo;
        wrapper.item.descricaoProduto = wrapper.produto.nome;
        wrapper.item.unidadeMedida = this.itProdutoItem.itEmbalagem.selectedItem.codigo;
        wrapper.item.casasDecimaisUN = this.itProdutoItem.itEmbalagem.selectedItem.casasDecimais;

        if (this.itCentroCusto && this.itCentroCusto.selectedItem) {
          wrapper.item.centroCusto = this.itCentroCusto.selectedItem.descricao;
        }

        if (NumberUtil.numberNullOrZero(ajuste.id)) {
          this.itFormTable.spinnerService.show();
          const ajusteWrapper: AjusteEstoqueWrapper = new AjusteEstoqueWrapper();
          ajusteWrapper.ajusteEstoque = ajuste;
          ajusteWrapper.ajusteEstoqueItem = wrapper.item;

          this.submitWrapper$.next(ajusteWrapper);
        } else {
          wrapper.item.idInventarioEstoque = ajuste.id;
          this.itFormTable.submit$.next(wrapper.item);
        }
      }));


    /**
     * Submit de Cabeçalho e item quando for a inclusão do primeiro item, desabilita os componentes na aba anterior,
     * pois os mesmos não podem ser alterados, apenas observação esta liberada.
     */
    this.addSubscription(this.submitWrapper$
      .switchMap((wrapper: AjusteEstoqueWrapper) => this.itFormTable.httpService
        .post(`ajustes-estoque/create-ajuste-estoque`, wrapper)
        .combineLatest(this.form$, (resp: { id: number, idItem: number }, form: FormGroup) =>
          ({resp, form, ajusteWrapper: wrapper})))
      .subscribe((obj: { resp: { id: number, idItem: number }, form: FormGroup, ajusteWrapper: AjusteEstoqueWrapper }) => {
        obj.ajusteWrapper.ajusteEstoqueItem.id = obj.resp.idItem;
        obj.ajusteWrapper.ajusteEstoque.id = obj.resp.id;
        obj.form.get(`id`).setValue(obj.resp.id);

        this.itFormTable.push(obj.ajusteWrapper.ajusteEstoqueItem);
        this.disableForm(obj.form);
        this.itFormTable.spinnerService.hide();
        this.itFormTable.success("A inclusão foi feita com sucesso");
        this.itFormTable.afterSubmit$.next(obj.ajusteWrapper.ajusteEstoqueItem);
        this.itFormTable.clear$.next();
      }));

    /**
     * Limpa o form.
     */
    this.addSubscription(this.itFormTable.afterReset$
      .withLatestFrom(this.exibirCusto$
          .combineLatest(this.disabledCusto$, this.disabledTotal$, this.centroCustoItem$,
            (exibir: boolean, disableCusto: boolean, disableTotal: boolean, exibirCentroCusto: boolean) =>
              ({disableCusto: !exibir || disableCusto, disableTotal: !exibir || disableTotal, exibirCentroCusto})),
        this.getControl("preco", this.formItem$),
        this.getControl("total", this.formItem$),
        this.getControl("idCentroCusto", this.formItem$),
        (form: FormGroup, behaviors: { disableCusto: boolean, disableTotal: boolean, exibirCentroCusto: boolean },
         preco: AbstractControl, total: AbstractControl, centroCusto: AbstractControl) =>
          ({form, behaviors, preco, total, centroCusto}))
      .subscribe((obj: {
        form: FormGroup, behaviors: { disableCusto: boolean, disableTotal: boolean, exibirCentroCusto: boolean },
        preco: AbstractControl, total: AbstractControl, centroCusto: AbstractControl,
      }) => {

        obj.form.reset(this.initPojo);
        this.quantidadeInformada$.next(false);

        /**
         * Volta os componentes para o estado anterior.
         */
        if (obj.behaviors.disableCusto) {
          obj.preco.disable();
        }
        if (obj.behaviors.disableTotal) {
          obj.total.disable();
        }
        obj.behaviors.exibirCentroCusto ? obj.centroCusto.enable() : obj.centroCusto.disable();
      }));

    /**
     * Quando disparado o botão de seleção de kit, monta os dados do kit pai.
     * @type {Observable<Kit>}
     */
    this.addSubscription(this.itFormTable.currentChanged$
      .filter((item: AjusteEstoqueItem) => item.tipoKit === TipoKit.KIT_PAI[`value`])
      .map((item: AjusteEstoqueItem) => {
        const kitWrapper: Kit = new Kit();
        kitWrapper.idprodutokit = item.idProduto;
        kitWrapper.codigoProduto = item.codigoProduto;
        kitWrapper.descricaoProduto = item.descricaoProduto;
        kitWrapper.quantidade = item.quantidade;

        return kitWrapper;
      })
      .subscribe(this.itFormTable.paramsKit$));
  }

  /**
   * Verifica se o item é válido para inclusão.
   * @param {AjusteEstoque} ajuste
   * @param {AjusteEstoqueItem} item
   * @param {MotivoAjusteEstoque} motivo
   * @param {Produto} produto
   * @param {boolean} agruparProduto
   * @return {boolean}
   */
  private validarItem(ajuste: AjusteEstoque, item: AjusteEstoqueItem,
                      motivo: MotivoAjusteEstoque, produto: Produto, agruparProduto: boolean): boolean {

    /*
     * Número de série
     */
    if (produto.numeroSerie && ArrayUtil.nullOrEmpty(item.listaNumeroSeries) && (isNullOrUndefined(motivo) ||
        motivo.movimentacao !== MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR[EnumUtils.id])) {
      this.itFormTable.warning({status: null, codigo: "WWW109", mensagem: "Número de série não informado."});
      return;
    }

    /*
     * Quantidade.
     */
    if (ajuste.tipoMovimento !== TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id] && item.quantidade === 0) {
      if (motivo != null && motivo.movimentacao !== MovimentacaoMotivoAjusteEstoque.SOMENTE_VALOR) {
        this.itFormTable.warning({
          status: null,
          codigo: "EST28",
          mensagem: "Não é possível incluir entrada ou saída de um item com quantidade zerada.",
        });
        return;
      }
    }

    /*
     * Lote
     */
    if (produto.possuiLote) {
      if (ajuste.tipoMovimento === TipoAjusteEstoque.ENTRADA[EnumUtils.id]) {
        if (StringUtil.stringNullOrEmpty(item.lote)) {
          this.itFormTable.warning({status: null, codigo: "COM213", mensagem: "É necessário informar a lote."});
          return;
        }

        if (!item.dataLote) {
          this.itFormTable.warning({
            status: null,
            codigo: "COM214",
            mensagem: "É necessário informar a data para o lote."
          });
          return;
        }

      } else if (ajuste.tipoMovimento === TipoAjusteEstoque.SAIDA[EnumUtils.id]) {
        if (NumberUtil.numberNullOrZero(item.idLote)) {
          this.itFormTable.warning({status: null, codigo: "COM215", mensagem: "É necessário informar a lote"});
          return;
        }
      } else if (ArrayUtil.nullOrEmpty(item.mapLote)) {
        this.itFormTable.warning({status: null, codigo: "EST28", mensagem: "É necessário informar a lote"});
      }
    }

    /*
     * Variação
     */
    if (produto.possuiVariacao && StringUtil.stringNullOrEmpty(item.variacoes) &&
      (ajuste.tipoMovimento !== TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id] || item.quantidade > 0)) {
      this.itFormTable.warning({status: null, codigo: "WWW111", mensagem: "É necessário informar a grade do produto."});
      return;
    }

    /*
     * Item existente.
     */
    if (ajuste.tipoMovimento === TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id] && !agruparProduto && this.produtoExistente(item)) {
      this.itFormTable.warning({
        status: null,
        codigo: "EST45",
        mensagem: "Esse item já existe na lista, para a inclusão de itens repetidos habilite a opção 'Agrupar produtos'.",
      });
      return;

    }

    return true;
  }

  /**
   * Verifica se o produto existe na table levando em consideração o lote.
   * @param {AjusteEstoqueItem} item
   * @return {boolean}
   */
  private produtoExistente(item: AjusteEstoqueItem): boolean {
    return this.itFormTable.sourceCollection
      .some((i: AjusteEstoqueItem) => i.idProduto === item.idProduto &&
        (NumberUtil.numberNullOrZero(item.id) || item.id !== i.id) &&
        (NumberUtil.numberNullOrZero(item.idLote) || i.idLote !== item.idLote));
  }

  /**
   * Realiza o agrupamento de produtos quando clicado no switch.
   */
  private productGroup(): void {
    this.productGroupSubscribe(this.getValueChanges("agruparProdutos", this.formGroup$)
      .filter((value: boolean) => value)
      .switchMap(() => this.httpProductGroup()));
  }

  /**
   * Monta os parâmetros e executa o agrupamento no servidor.
   * @return {Observable<AjusteEstoqueItem[]>}
   */
  private httpProductGroup(): Observable<AjusteEstoqueItem[]> {
    return this.getValue("id")
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .switchMap((id: number) => {
        this.itFormTable.spinnerService.show();
        const params: URLSearchParams = new URLSearchParams();
        params.set("id", id.toString());

        return this.itFormTable.httpService.get(`itens-ajuste-estoque/agrupar`, {search: params});
      });
  }

  /**
   * Subscribe de consulta de agrupamento.
   * @param {Observable<AjusteEstoqueItem[]>} obs
   */
  private productGroupSubscribe(obs: Observable<AjusteEstoqueItem[]>): void {
    this.addSubscription(obs.subscribe((itens: AjusteEstoqueItem[]) => {
      this.itFormTable.updateItemsSource(itens);
      this.itFormTable.spinnerService.hide();
    }));
  }

}

/**
 * Validação de saldo de estoque.
 * @param {number} idCrud
 * @param {number} idLocalEstoque
 * @return {(form: FormControl) => Observable<{saldoValidate: string}>}
 */
function saldoValidation(idCrud: number, idLocalEstoque: number) {
  return (form: FormControl): Observable<{ saldoValidate: string }> => {

    return applicationInjector.get(ContextoService).getPropriedade$(75)
      .switchMap((confEstoque: string) => {

        const idProduto: number = form.parent.get("idProduto").value;
        const idItemAtual: number = form.parent.get("id").value;
        const idLote: number = form.parent.get("idLote").value;
        const quantidade: number = form.value;

        let variacao: number = null;
        if (!StringUtil.stringNullOrEmpty(form.parent.get("variacoes").value)) {
          const split: string[] = form.parent.get("variacoes").value.split(";");
          if (split.length === 1) {
            variacao = NumberUtil.parseInt(split[0].split("=")[0]);
          }
        }

        /**
         * Se permite negativo nem valida.
         */
        if (NumberUtil.parseInt(confEstoque) === TipoConfiguracaoEstoqueNegativo.PERMITIR || NumberUtil.numberNullOrZero(idProduto)) {
          return Observable.of(null);
        }

        return saldoValidator$("ajustes-estoque-saldo", idProduto, quantidade, idCrud, idItemAtual, null, variacao, idLote, idLocalEstoque);
      })
      .first();
  };
}

/**
 * Valdação de centro de custo.
 * @param {FormControl} form
 * @return {Observable<{centroCustoValidate: string}>}
 */
function centroCustoValidation(form: FormControl): Observable<{ centroCustoValidate: string }> {
  if (NumberUtil.numberNullOrZero(NumberUtil.parseFloat(form.value))) {
    return null;
  }

  const params: URLSearchParams = new URLSearchParams();
  params.set("id", form.value);

  return applicationInjector.get(HttpService).get(`centros-custo/validar-sintetico`, {search: params})
    .map(() => null)
    .catch((error: ServerError) => Observable.of({centroCustoValidate: `${error.codigo} - ${error.mensagem}`}))
    .first();
}

/**
 * Validação de kit.
 * @param {Observable<Produto>} produtoSelecionado$
 * @param {ItFormTableComponent<AjusteEstoqueItem>} table
 * @return {(form: FormControl) => Observable<{kitValidate: string}>}
 */
function kitAsyncValidation(produtoSelecionado$: Observable<Produto>, table: ItFormTableComponent<AjusteEstoqueItem>) {
  return (form: FormControl) => {
    return kitValidator$(NumberUtil.parseFloat(form.parent.get("id").value), NumberUtil.parseFloat(form.value), produtoSelecionado$, table);
  };
}

/**
 * Validador de kit já incluso na table.
 * @param {number} idCrud
 * @param {number} idProduto
 * @param {Observable<Produto>} produtoSelecionado$
 * @param {ItFormTableComponent<AjusteEstoqueItem>} table
 * @return {Observable<{kitValidate: string}>}
 */
function kitValidator$(idCrud: number, idProduto: number, produtoSelecionado$: Observable<Produto>,
                       table: ItFormTableComponent<AjusteEstoqueItem>): Observable<{ kitValidate: string }> {

  return produtoSelecionado$
    .map((produto: Produto) => {

      const produtoKitExiste: boolean = produto.kit && !NumberUtil.numberNullOrZero(idProduto) && idProduto === produto.id &&
        table.sourceCollection
          .some((i: AjusteEstoqueItem) => i.idProduto === produto.id && (NumberUtil.numberNullOrZero(idCrud) || idCrud !== i.id));

      if (produtoKitExiste) {
        return {kitValidate: "O Kit já foi incluído. Por favor altere a quantidade do item existente."};
      }

      return null;
    }).first();
}
