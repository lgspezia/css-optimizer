import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { ItAutocompleteComponent } from "../../../core/components/primitive/it-autocomplete.component";
import { FormComponent } from "../../../core/crud/form-component";
import { identificationRequiredValidator } from "../../../core/crud/validadores";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { Filial } from "../filiais/filial";
import { PreferenciaUsuario } from "./usuarios-preferencias/usuario-preferencia";
import { Perfil } from "../orfans/perfil.model";

/**
 * @author Luan  on 18/07/2017.
 */
@Component({
  selector: "it-usuario-geral",
  templateUrl: "usuario-geral.form.component.html",
})
export class ItUsuarioGeralFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public isEnterprise$: Observable<boolean>;
  public paramLocalEstoque$: Observable<URLSearchParams>;

  public paramFilialTrabalho$: Observable<URLSearchParams>;

  @ViewChild("itPerfil") private itPerfil: ItAutocompleteComponent<Perfil>;

  constructor(public contexto: ContextoService) {
    super();
    // TODO-LUAN tem que ajustar o carregamento da licenca de interprise para fazer essa validação
    this.isEnterprise$ = Observable.of(true); // contexto.isEnterprise$();
  }

  public ngOnInit() {

    this.addSubscription(this.getControl("codigo").subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("nome").subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required, Validators.maxLength(60)])));

    this.addSubscription(this.getControl("idPerfil")
      .merge(this.getControl("idFilialTrabalho"), this.getControl("idLocalEstoqueTrabalho"))
      .subscribe((control: AbstractControl) =>
        control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.contexto.isFuncionalidade$("LOCAL_ESTOQUE")
      .combineLatest(this.getControl("idLocalEstoqueTrabalho"),
        (ativaLocalEstoque: boolean, localEstoque: AbstractControl) => ({ativaLocalEstoque, localEstoque}))
      .subscribe((obj: { ativaLocalEstoque: boolean, localEstoque: AbstractControl }) => {
        if (obj.ativaLocalEstoque) {
          obj.localEstoque.enable();
        } else {
          obj.localEstoque.disable();
        }
      }));

    // carrega informações de filial de trabalho de acordo com o perfil selecionado
    this.paramFilialTrabalho$ = this.getValueChanges("idPerfil")
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .map((id: number) => {
        const param: URLSearchParams = new URLSearchParams();
        param.set("idPerfil", id.toString());
        return param;
      });

    // seleciona o local de estoque, de acordo com a filial selececionada
    this.paramLocalEstoque$ = this.contexto.filial$
      .combineLatest(this.getValueChanges("idFilialTrabalho").startWith(0),
        (filial: Filial, idFilialTrabalho: number) => {
          const param: URLSearchParams = new URLSearchParams();
          const idFilial: number = !NumberUtil.numberNullOrZero(idFilialTrabalho) ? idFilialTrabalho : filial.id;
          param.set("idFilial", idFilial.toString());
          return param;
        });

    // quando alteração, pega o que vem da base e seta em uma outra variavel aux
    this.addSubscription(this.afterGet$
      .combineLatest(this.getControl("inativo"), this.getControl("inativoAux"),
        (id: number, inativo: AbstractControl, inativoAux: AbstractControl) => ({inativo, inativoAux}))
      .subscribe((wrapper: { inativo: AbstractControl, inativoAux: AbstractControl }) =>
        wrapper.inativoAux.setValue(wrapper.inativo.value === 1)));

    // quando alteração, pega o que vem da base e seta em uma outra variavel aux
    this.addSubscription(this.afterGet$
      .combineLatest(this.getControl("supervisor"), this.getControl("supervisorAux"),
        (id: number, supervisor: AbstractControl, supervisorAux: AbstractControl) => ({supervisor, supervisorAux}))
      .subscribe((wrapper: { supervisor: AbstractControl, supervisorAux: AbstractControl }) =>
        wrapper.supervisorAux.setValue(wrapper.supervisor.value === 1)));

    // Seta o nome do campo para o campo auxiliar que é utilizado na grid
    this.addSubscription(this.getValueChanges("idPerfil")
      .combineLatest(this.getControl("nomePerfil"),
        (idPerfil: number, perfil: AbstractControl) => ({idPerfil, perfil}))
      .subscribe((wrapper: { idPerfil: number, perfil: AbstractControl }) => {
        if (!NumberUtil.numberNullOrZero(wrapper.idPerfil) && this.itPerfil.selectedItem) {
          wrapper.perfil.setValue(this.itPerfil.selectedItem.nome);
        }
      }));
  }
}
