/**
 * Classe de representação de Pojo.
 *
 * @author Osiel
 */
export class Extras {
    public id: number;
    public  nometabela: string;
    public  extra1: string;
    public  extra2: string;
    public  extra3: string;
    public  extra4: string;
    public  extra5: string;
    public  extra6: string;
    public  extra7: string;
    public  extra8: string;
    public  extra9: string;
    public  extra10: string;
    public  extra11: string;
    public  extra12: string;
    public  extra13: string;
    public  extra14: string;
    public  extra15: string;
    public  extra16: string;
    public  tipoExtra1: TipoCampoExtra;
    public  tipoExtra2: TipoCampoExtra;
    public  tipoExtra3: TipoCampoExtra;
    public  tipoExtra4: TipoCampoExtra;
    public  tipoExtra5: TipoCampoExtra;
    public  tipoExtra6: TipoCampoExtra;
    public  tipoExtra7: TipoCampoExtra;
    public  tipoExtra8: TipoCampoExtra;
    public  tipoExtra9: TipoCampoExtra;
    public  tipoExtra10: TipoCampoExtra;
    public  tipoExtra11: TipoCampoExtra;
    public  tipoExtra12: TipoCampoExtra;
    public  tipoExtra13: TipoCampoExtra;
    public  tipoExtra14: TipoCampoExtra;
    public  tipoExtra15: TipoCampoExtra;
    public  tipoExtra16: TipoCampoExtra;
    public  mascaraExtra1: string;
    public  mascaraExtra2: string;
    public  mascaraExtra3: string;
    public  mascaraExtra4: string;
    public  mascaraExtra5: string;
    public  mascaraExtra6: string;
    public  mascaraExtra7: string;
    public  mascaraExtra8: string;
    public  mascaraExtra9: string;
    public  mascaraExtra10: string;
    public  mascaraExtra11: string;
    public  mascaraExtra12: string;
    public  mascaraExtra13: string;
    public  mascaraExtra14: string;
    public  mascaraExtra15: string;
    public  mascaraExtra16: string;
}

export enum TipoCampoExtra {
    // tslint:disable-next-line:no-angle-bracket-type-assertion
    TEXTO = <any> {id: "TEXTO", value: 0, display: "Texto", dica: "Tamanho do conteúdo. Máximo 50. Ex: 20"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    DATA = <any> {id: "DATA", value: 1, display: "Data", dica: ""},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    DATA_HORA = <any> {id: "DATA_HORA", value: 2, display: "Data e hora", dica: ""},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    NUMERO = <any> {
        dica: "Tamanho do número e tamanho das casas decimais separados por vírgula. Ex: 12,2",
        display: "Número",
        id: "NUMERO",
        value: 3,
    },
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    INTEIRO = <any> {id: "INTEIRO", value: 4, display: "Inteiro", dica: ""},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    COMBO = <any> {
        dica: "Lista de valores separados por ponto e vírgula. Ex: Item 1; Item 2; Item 3",
        display: "Lista de valores",
        id: "COMBO",
        value: 5,
    },
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    CHECBOX = <any> {id: "CHECBOX", value: 6, display: "Caixa de seleção", dica: ""},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    MASCARA = <any> {
        dica: "CPF: 000.000.000-00 CNPJ: 00.000.000/0000-00 Telefone: (0xx00)00000-0000",
        display: "Campo com máscara",
        id: "MASCARA",
        value: 7,
    },
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    TEXTO_GRANDE = <any> {id: "TEXTO_GRANDE", value: 8, display: "Texto grande", dica: ""},
}
