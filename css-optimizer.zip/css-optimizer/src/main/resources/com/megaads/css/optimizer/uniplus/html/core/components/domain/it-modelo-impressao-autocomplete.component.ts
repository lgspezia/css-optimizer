import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { ModeloEtiqueta } from "../../../modules/cadastros/orfans/modelo-etiqueta.model";

/**
 * @author Luan  on 21/07/2017.
 */
@Component({
  selector: "it-modelo-impressao-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItModeloImpressaoAutocompleteComponent extends ItAutocompleteComponent<ModeloEtiqueta> {

  constructor(httpService: HttpService) {
    super(httpService);
    this.display = "descricao";
    this.url = "modelos-produto/buscar-modelo-produto";
    this.urlUpdate = "modelos-produto";
  }
}
