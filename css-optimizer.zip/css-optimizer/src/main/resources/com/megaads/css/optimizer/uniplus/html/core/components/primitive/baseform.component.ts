import { Input, OnDestroy } from "@angular/core";
import { AbstractControl, FormGroup } from "@angular/forms";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";

import { applicationInjector } from "../../../app.module";
import { Modo } from "../../crud/grid.crud";
import { ServerError } from "../../models/server-error";
import { ToasterService } from "../../services/toaster.service";

/**
 * Classe base para todos os componentes, por default implementa OnDestroy
 * para efetuar unsubscribe nos subscriptions adicionados, se esse método
 * for implementado nas classes filhas, será necessário chamar o super.
 */
export class BaseFormComponent implements OnDestroy {

  @Input() public form$: BehaviorSubject<FormGroup>;
  @Input() public modo$: BehaviorSubject<Modo>;
  @Input() public control: string;
  @Input() public label: string;
  @Input() public col = 12;

  protected toaster: ToasterService;

  private subscription: Subscription;

  constructor() {
    this.modo$ = new BehaviorSubject(undefined);
    this.subscription = new Subscription();

    this.toaster = applicationInjector.get(ToasterService);
  }

  /**
   * Destroy o subscribe.
   */
  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Tratamento de erros padrão do componente
   * @param error: ServerError
   */
  public handleError(error: ServerError): void {
    this.toaster.pop("error", "Não conectou com o servidor", error.mensagem);
  }

  /**
   * Desabilita um campo do form de acordo com uma condição
   * Caso não seja passado uma condição por parametro o campo do form sempre será desabilitado.
   *
   * @param control:? string
   * @param condicao:? boolean
   */
  public disable(control: string = this.control, condicao: boolean = true): void {
    if (condicao) {
      this.addSubscription(this.getControl(control).subscribe((ac: AbstractControl) => ac.disable()));
    }
  }

  /**
   * Habilita um campo do form de acordo com uma condição
   * Caso não seja passado uma condição por parametro o campo do form sempre será desabilitado.
   *
   * @param control:? string
   * @param condicao:? boolean
   */
  public enable(control: string = this.control, condicao: boolean = true): void {
    if (condicao) {
      this.addSubscription(this.getControl(control).subscribe((ac: AbstractControl) => ac.enable()));
    }
  }

  /**
   * Verifica se um campo do form está desabilitado
   * @param control:? string
   * @return {Observable<boolean>}
   */
  public isDisabled(control: string = this.control): Observable<boolean> {
    return this.getControl(control).map((ac: AbstractControl) => ac.disabled);
  }

  /**
   * Verifica se um campo do form está habilitado.
   * @param control:? string
   * @return {Observable<boolean>}
   */
  public isEnabled(control: string = this.control): Observable<boolean> {
    return this.getControl(control).map((ac: AbstractControl) => ac.enabled);
  }

  /**
   * Seta o valor de um campo do form.
   * * @param value
   * @param control:? string
   */
  public setValue(value: any, control: string = this.control): void {
    this.addSubscription(this.getControl(control).subscribe((ac) => ac.setValue(value)));
  }

  /**
   * Retorna um observable de valor do componente.
   * @param control:? string
   * @return {Observable<any>}
   */
  public getValue(control: string = this.control): Observable<any> {
    return this.getControl(control).map((ac: AbstractControl) => ac.value);
  }

  /**
   * Retorna o Observable do component.
   *
   * @param control: string
   * @param form$: {@link BehaviorSubject<FormGroup>} não é necessário especificar o form,
   * pois ele esta dentro da classe. Porém as vezes estamos trabalhando com mais de um form.
   * @return {Observable<any>}
   */
  public getValueChanges(control: string = this.control, form$: BehaviorSubject<FormGroup> = this.form$): Observable<any> {
    const abControl: AbstractControl = form$.getValue().get(control);
    if (!abControl) {
      throw new Error("Campo não existe: " + control);
    }
    return abControl.valueChanges;
  }

  /**
   * Mapeia o control desejado, validando se existe.
   * @param control:? string
   * @param form$: {@link BehaviorSubject<FormGroup>} não é necessário especificar o form,
   * pois ele esta dentro da classe. Porém as vezes estamos trabalhando com mais de um form.
   * @return {Observable<AbstractControl>}
   */
  public getControl(control: string = this.control, form$: BehaviorSubject<FormGroup> = this.form$): Observable<AbstractControl> {

    return form$.map((fg: FormGroup) => {
      const abControl: AbstractControl = fg.get(control);
      if (!abControl) {
        throw new Error("Campo não existe: " + control);
      }
      return abControl;
    });
  }

  /**
   * Observable de boolean para determinar modo de leitura ou alteração.
   * @return {Observable<boolean>}
   */
  public get isDeleteOrRead$(): Observable<boolean> {
    return this.modo$
      .map((modo) => modo === Modo.READ || modo === Modo.DELETE);
  }

  /**
   * Adiciona o subscription para executar unsubscribe no OnDestroy.
   * @param subscription
   */
  public addSubscription(subscription: Subscription) {
    this.subscription.add(subscription);
  }

}
