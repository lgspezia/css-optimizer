import { AbstractPojo } from "../../../../core/crud/pojo";
import { EnumUtils } from "../../../../core/enuns/enumutil";

/**
 * @author Luan  on 20/07/2017.
 */
export class PreferenciaUsuario extends AbstractPojo {

  public idUsuario = 0;

  // OS
  public apresentacaoSaldoEstoque = ApresentacaoSaldoEstoque.UNDEFINED[EnumUtils.id];
  public permiteVisualizarPrecoOS = false;
  public permiteFaturarOrdemServico = false;
  public permiteAlterarOS = false;
  public permiteAlterarOSFinalizada = false;
  public permiteExcluirOS = false;
  public permiteReabrirOS = false;
  public permiteFinalizarOS = false;

  // Email
  public emailPadrao = "";
  public usuarioServidorSmtp = "";
  public senhaServidorSmtp = "";
  public servidorSmtp = "";
  public portaServidorSmtp = 0;
  public usaSSL = false;
  public usaTSL = false;

  public permiteAlterarPreco = false;
  public naoMostraEventoBackup = false;
  public permiteManipularEntradaBaixa = false;
  public permiteManipularJurosMulta = false;
  public permiteLanctoRetroativoCaixa = false;
  public permiteAlterarCamposAdicionais = false;
  public permiteManipularCondicao = false;
  public permiteDarBrindes = false;

  // etiqueta
  public idUltimoModeloEtiquetaProduto = 0;
  public portaImpressoraEtiqueta = "";

  public diasVencimentoFinanciamento = 0;
}

export enum ApresentacaoSaldoEstoque {

  UNDEFINED = <any> {[EnumUtils.id]: "UNDEFINED", [EnumUtils.display]: "-- selecione --"},
  NAO_APRESENTA = <any> {[EnumUtils.id]: "NAO_APRESENTA", [EnumUtils.display]: "Não apresenta saldo do estoque"},
  APRESENTA_DA_LOJA_CORRENTE = <any> {
    [EnumUtils.id]: "APRESENTA_DA_LOJA_CORRENTE",
    [EnumUtils.display]: "Apresenta saldo do estoque da loja corrente"
  },
  APRESENTA_POR_LOJA = <any> {
    [EnumUtils.id]: "APRESENTA_POR_LOJA",
    [EnumUtils.display]: "Apresenta saldo do estoque por loja"
  },
  APRESENTA_DO_ESTOQUE_TOTAL = <any> {
    [EnumUtils.id]: "APRESENTA_DO_ESTOQUE_TOTAL",
    [EnumUtils.display]: "Apresenta saldo do estoque total"
  },
}
