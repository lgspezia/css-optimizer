/**
 * Pojo de Endereco.
 *
 * Created by Osiel S. Mello on 16/05/2017.
 */
export class Endereco {
    public cep = "";
    public endereco = "";
    public numero = "";
    public complemento = "";
    public bairro = "";
    public idCidade = 0;
    public idEstado = 0;
    public idPais = 0;
}
