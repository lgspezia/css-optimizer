import { AbstractPojo } from "../../../core/crud/pojo";

export class ConfiguracaoCartaoFidelidade extends AbstractPojo {
    public geraNumeracaoCartao = false;
    public pautaPreco = 0;
    public prefixoNumeroCartao = 100000;
    public proximoNumeroCartao = 1;
    public tamanhoDigitoVerificador = 2;
    public tamanhoNumeroCartao = 12;
    public usarPrecoDiferenciado = false;
    public usarSenha = false;
}
