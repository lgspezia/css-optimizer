import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Rota } from "../../../modules/expedicoes/rotas/rota";

@Component({
    selector: "it-rota-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItRotaAutocompleteComponent extends ItAutocompleteComponent<Rota> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "rotas";
        this.label = "Rota";
        this.display = "descricao";
    }
}
