import { Component } from "@angular/core";
import { IAT } from "../../../modules/produtos/produto";
import { EnumUtils } from "../../enuns/enumutil";
import { ItComboboxComponent } from "../primitive/it-combobox.component";

/**
 * @author Luan  on 09/08/2017.
 */
@Component({
  selector: "it-iat-combobox",
  templateUrl: "../primitive/it-combobox.component.html",
})
export class ItIatComboboxComponent extends ItComboboxComponent<IAT> {

  constructor() {
    super();
    this.itens$ = EnumUtils.getValues(IAT);
  }
}
