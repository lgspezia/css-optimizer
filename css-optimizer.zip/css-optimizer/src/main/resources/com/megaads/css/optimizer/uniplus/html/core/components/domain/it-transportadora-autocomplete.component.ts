import { Component } from "@angular/core";

import { TipoEntidade } from "../../../modules/entidades/cadastros/entidade";
import { EnumUtils } from "../../enuns/enumutil";
import { HttpService } from "../../services/http.service";
import { ItEntidadeAutocompleteComponent } from "./it-entidade-autocomplete.component";

/**
 * Componente de representante, se necessário pode ser passado parâmetros como
 * ItEntidadeAutocompleteComponent#filtrarFilial ou ItEntidadeAutocompleteComponent#exibirInativos.
 * <p>
 * Para mais detalhes consultar ItEntidadeAutocompleteComponent.
 *
 * @Author Osiel.
 */
@Component({
  selector: "it-transportadora-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTransportadoraAutocompleteComponent extends ItEntidadeAutocompleteComponent {

  constructor(httpService: HttpService) {
    super(httpService);
    this.label = "Transportadora";
    this.tipos = [TipoEntidade.TRANSPORTADORA[EnumUtils.id]];
    this.urlUpdate = "transportadoras";
    this.configParams();
  }

}
