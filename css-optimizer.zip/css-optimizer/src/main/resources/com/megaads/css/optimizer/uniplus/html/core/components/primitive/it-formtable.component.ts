import { Component, EventEmitter, Input, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { FormGroup } from "@angular/forms";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Subscription } from "rxjs/Subscription";

import { WjPopup } from "wijmo/wijmo.angular2.input";

import { isNullOrUndefined } from "util";
import { TipoKit } from "../../../modules/produtos/produto";
import { ICellEditTable } from "../../crud/cell-edit-table";
import { ColumnDefinition } from "../../crud/column-definition";
import { Modo } from "../../crud/grid.crud";
import { IParamsData } from "../../crud/param-data";
import { AbstractPojo } from "../../crud/pojo";
import { EnumUtils } from "../../enuns/enumutil";
import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { SpinnerService } from "../../services/spinner.service";
import { ToasterService } from "../../services/toaster.service";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";
import { ItKitPopupComponent, Kit } from "../domain/kit/it-kit-popup";
import { ItTableComponent } from "./it-table.component";
import { AbstractWrapper } from "../../wrappers/AbstracWrapper";

/**
 * Classe base para a criação de paineis com tabelas, tendo o seguinte fluxo:
 * <p>
 *     * {@link clear$} -  Subject acionado após o clique no botão "Incluir", combina com o {@link form$} e
 *     dispara o {@link updating$} como false e o {@link afterReset$} passando o {@link FormGroup}. Nesse
 *     caso é preciso limpar o form com o {@link FormGroup.reset}.
 * <p>
 *     * {@link update$} - Disparado quando executado a ação "Alterar" e possuir item selecionado.
 *     Combina com o {@link form$} e atualiza o {@link updating$} como true, seta o {@link FormGroup.patchValue}
 *     e aciona o {@link afterLoadUpdate$} passando o {@link AbstractPojo}. No {@link afterLoadUpdate$} deverá ser
 *     feita as validações após o carregamento de dados.
 * <p>
 *     * {@link beforeSubmit$} - Disparado quando submeter o {@link form$}, sendo que será enviado
 *     o {@link AbstractPojo}. Logo após ser validado deve-se dispara manualmente o {@link submit$} caso não haja
 *     validação deve-se realizar apenas o subscribe {@link this.beforeSubmit$.subscribe(this.submit$)}, lembrando
 *     de realizar o {@link Subject.unsubscribe}. Após isso será executado o POST ou PUT de acordo
 *     com o {@link AbstractPojo.id}.
 * <p>
 *     * {@link delete$} - Acionado após o clique do botão excluir, nesse caso não há interação com o fluxo, pois será
 *     realizado o delete automático, desde que selecionado um objeto.
 * <p>
 *     * {@link loadData$} - Carrega os dados do servidor para a table de acordo com os parâmetros.
 * <p>
 *     * {@link edit$} - Observable disparado quando houver edição de checkbox no {@link ItTableComponent}.
 * <p>
 *     * {@link currentChanged$} - Observable disparado a cada seleção de item no {@link ItTableComponent}.
 * <p>
 *     * {@link afterLoadUpdate$} - Observable disparado após o patch value de alteração.
 * <p>
 *     * {@link afterSubmit$} - Observable disparado após o submit válido do formulário.
 * <p>
 *     * {@link beforeSubmit$} - Observable disparado antes do submit.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-formtable",
  templateUrl: "it-formtable.component.html",
})
export class ItFormTableComponent<POJO extends AbstractPojo> implements OnDestroy, OnInit {

// ---------------------------------------------------------------------------------------------------------------------
// Inputs                                                                                                              |
// ---------------------------------------------------------------------------------------------------------------------

  /**
   * Nome do botão submit do formulário para a table. Default "Ok".
   */
  @Input() public action$: Observable<string>;
  /**
   * Determina se pode excluir. Se for false remove o botão do html. Valor default true.
   */
  @Input() public allowDelete: boolean;
  /**
   * Determina se pode alterar ou excluir dinâmicamente.
   */
  @Input() public allowEdit$: Observable<boolean>;
  /**
   * Determina se a exclusão é realizada automaticamente ou se abrirá um popup para confirmar a exclusão. Default true.
   */
  @Input() public allowPopupDelete: boolean;
  /**
   * Determina se pode editar. Se for false remove o botão do html. Valor default true.
   */
  @Input() public allowUpdate: boolean;
  /**
   * Personalização das colunas da table.
   */
  @Input() public columns$: BehaviorSubject<ColumnDefinition[]>;
  /**
   * Endpoint para inclusão, alteração e exclusão de dados.
   */
  @Input() public endpoint: string;
  /**
   * Form principal para inclusão dos dados.
   */
  @Input() public form$: BehaviorSubject<FormGroup>;
  /**
   * Ícone de botão submit do formulário para a table. Default "check".
   */
  @Input() public icon$: Observable<string>;
  /**
   * Determina nome do atributo que controla Kit, quando possuir valor irá exibir o campo para visualização de kit,
   * de acordo com o tipo de kit.
   */
  @Input() public kitTypeName: string;
  /**
   * Quando true sempre irá manter um registro na table, ou seja, o usuário não conseguirá excluir todos os registros,
   * isso deve ser utilizado em telas de movimentação, vendas, etc. Por default o valor é false.
   */
  @Input() public keepLastRecord: boolean;
  /**
   * Parâmetros necessários para carregar os dados do servidor.
   */
  @Input() public loadData$: Observable<IParamsData>;
  /**
   * Modo atual do crud.
   */
  @Input() public modo$: BehaviorSubject<Modo>;
  /**
   * Título do formulário.
   */
  @Input() public title: string;
  /**
   * Título da table de itens, se não informado irá usar titulo do fomulário.
   */
  @Input() public tableTitle: string;


// ---------------------------------------------------------------------------------------------------------------------
// Variáveis publicas usadas em HTML ou externamente.                                                                  |
// ---------------------------------------------------------------------------------------------------------------------

  /**
   * Subject disparado após pressionar o botão "Limpar" ou após acionado eventos de inclusão/alteração/exclusão na table.
   */
  public afterReset$: Subject<FormGroup>;
  /**
   *{@link afterLoadUpdate$} - Observable disparado após o patch value de alteração.
   */
  public afterLoadUpdate$: Subject<POJO>;
  /**
   * Disparado após executar POST ou PUT no servidor.
   */
  public afterSubmit$: Subject<POJO>;
  /**
   * Disparado após pressionar o botão para inclusão de item na table. Após isso deve ser definido manualmente o próximo ciclo de vida.
   */
  public beforeSubmit$: Subject<POJO>;
  /**
   * Chamado manualmente depois do {@link beforeSubmit$} para efetuar o POST e PUT.
   */
  public submit$: Subject<POJO>;
  /**
   * Subject para limpar o formulário.
   */
  public clear$: Subject<any>;
  /**
   * Utilizado para desabilitar dinâmicamente os botões de exclusão e alteração.
   */
  public disableEdit$: Observable<boolean>;
  /**
   * Desabilita o kit quando não for kit.
   */
  public disableKit$: BehaviorSubject<boolean>;
  /**
   * Subject de exclusão de registro;
   */
  public delete$: Subject<POJO>;
  /**
   * Evento de delete.
   */
  public eventDelete$: EventEmitter<any>;
  /**
   * Subject que determina a edição de um objeto selecionado na table, isso só ocorre quando a table pode ser
   * editada diretamente, como por exemplos por checkbox.
   */
  public editing$: Subject<ICellEditTable<POJO>>;
  /**
   * Parametros com os dados de Kit pai para busca e exibição de kits.
   */
  public paramsKit$: BehaviorSubject<Kit>;
  /**
   * Subject que determina se estou em modo de alteração no formulário.
   */
  public updating$: BehaviorSubject<boolean>;


// ---------------------------------------------------------------------------------------------------------------------
// Variáveis privadas usadas em HTML ou externamente.                                                                  |
// ---------------------------------------------------------------------------------------------------------------------

  @ViewChild("actiondelete") public buttonDelete: any;
  @ViewChild(ItKitPopupComponent) private itKitPopup: ItKitPopupComponent;
  @ViewChild("popup") private popup: WjPopup;
  @ViewChild(ItTableComponent) private tableComponent: ItTableComponent<POJO>;

  private afterLoad$: BehaviorSubject<boolean>;
  private eventClear$: EventEmitter<any>;
  private eventSubmit$: EventEmitter<any>;
  private eventUpdate$: EventEmitter<any>;
  private selectedItemDoubleClicked$: EventEmitter<POJO>;
  private subscriptions: Subscription;
  private update$: Subject<POJO>;

  constructor(public httpService: HttpService, public spinnerService: SpinnerService,
              public toasterService: ToasterService) {

    this.action$ = Observable.of("Ok");
    this.afterLoad$ = new BehaviorSubject(undefined);
    this.afterLoadUpdate$ = new Subject();
    this.afterReset$ = new Subject();
    this.afterSubmit$ = new Subject();
    this.allowDelete = true;
    this.allowEdit$ = Observable.of(true);
    this.allowPopupDelete = true;
    this.allowUpdate = true;
    this.beforeSubmit$ = new Subject();
    this.clear$ = new Subject();
    this.columns$ = new BehaviorSubject(undefined);
    this.delete$ = new Subject();
    this.disableKit$ = new BehaviorSubject(true);
    this.editing$ = new Subject();
    this.eventClear$ = new EventEmitter();
    this.eventDelete$ = new EventEmitter();
    this.eventSubmit$ = new EventEmitter();
    this.eventUpdate$ = new EventEmitter();
    this.icon$ = Observable.of("check");
    this.keepLastRecord = false;
    this.loadData$ = Observable.empty();
    this.modo$ = new BehaviorSubject(undefined);
    this.paramsKit$ = new BehaviorSubject(undefined);
    this.selectedItemDoubleClicked$ = new EventEmitter();
    this.submit$ = new Subject();
    this.subscriptions = new Subscription();
    this.update$ = new Subject();
    this.updating$ = new BehaviorSubject(false);
  }

  public ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  public ngOnInit(): void {
    /**
     * Para iniciar a table.
     */
    this.updateItemsSource(null);

    /**
     * Desablita todos os componentes do form.
     * @type {Subscription}
     */
    this.addSubscriptions(this.modo$
      .filter((modo: Modo) => modo === Modo.READ || modo === Modo.DELETE)
      .switchMap(() => this.form$)
      .subscribe((form: FormGroup) => form.disable()));

    if (StringUtil.stringNullOrEmpty(this.tableTitle)) {
      this.tableTitle = this.title;
    }

    /**
     * Observa a ação de submit.
     */
    this.addSubscriptions(this.eventSubmit$
      .withLatestFrom(this.form$, (submit, form: FormGroup) => form)
      .subscribe((form: FormGroup) => {
        if (!form.invalid) {
          /**
           * É necessário habilitar os componentes para pegar o valor.
           */
          Object.keys(form.controls)
            .filter((key: string) => form.controls[key].disabled)
            .map((key: string) => form.controls[key].enable());
          this.beforeSubmit$.next(form.value);
        }
      }));

    /**
     * Monitora a ação de um novo item.
     */
    this.addSubscriptions(this.eventClear$.subscribe(this.clear$));

    /**
     * Monitora a ação de update.
     */
    this.addSubscriptions(this.eventUpdate$
      .withLatestFrom(this.allowEdit$, (evt, allowEdit: boolean) => allowEdit)
      .filter((allowEdit: boolean) => allowEdit)
      .subscribe(() => {
        const pojo: POJO = this.selectedItem;
        if (pojo) {
          this.update$.next(pojo);
        }
      }));

    /**
     * Monitora a ação de double clicked e carrega o item para alteração.
     */
    this.addSubscriptions(this.selectedItemDoubleClicked$
      .withLatestFrom(this.allowEdit$, (pojo: POJO, allowEdit: boolean) => ({pojo, allowEdit}))
      .filter((obj: { pojo: POJO, allowEdit: boolean }) => obj.allowEdit && this.allowUpdate)
      .subscribe((obj: { pojo: POJO, allowEdit: boolean }) => this.update$.next(obj.pojo)));

    /**
     * Monitora a exclusão do item.
     */
    this.addSubscriptions(this.eventDelete$
      .withLatestFrom(this.allowEdit$, (evt, allowEdit: boolean) => allowEdit)
      .filter((allowEdit: boolean) => allowEdit)
      .subscribe(() => {
        const pojo: POJO = this.selectedItem;
        if (pojo) {
          this.delete$.next(pojo);
        }
      }));

    this.disableEdit$ = this.allowEdit$
      .combineLatest(this.updating$, (a: boolean, u: boolean) => !a || u);

    /**
     * Busca os dados e atualiza a table.
     */
    if (this.loadData$) {
      this.addSubscriptions(this.loadData$
        .switchMap((params: IParamsData) => {
          this.spinnerService.show();
          return this.httpService.get(params.endpoint, {search: params.search});
        })
        .subscribe((pojos: POJO[]) => {
          this.updateItemsSource(pojos);
          this.spinnerService.hide();
          this.afterLoad$.next(true);
        }, (error: ServerError) => {
          this.spinnerService.hide();
          this.handleError(error);
        }));
    }

    /**
     * Seta false para update e aciona e dispara o afterReset.
     */
    this.addSubscriptions(this.clear$
      .withLatestFrom(this.form$, (clear: any, form: FormGroup) => form)
      .subscribe((form: FormGroup) => {
        this.updating$.next(false);
        this.afterReset$.next(form);
      }));

    /**
     * Quando selecionado a opção update, limpa o form, na sequência seta os valores
     * e próximo passo de afterLoadUpdate.
     */
    this.addSubscriptions(this.update$
      .withLatestFrom(this.form$, (pojo: POJO, form: FormGroup) => ({form, pojo}))
      .subscribe(({form, pojo}: { form: FormGroup, pojo: POJO }) => {
        this.updating$.next(true);
        form.patchValue(pojo);
        this.afterLoadUpdate$.next(pojo);
      }));

    /**
     * Exclui o item selecionado.
     */
    this.addSubscriptions(this.delete$
      .filter(() => this.allowPopupDelete)
      .switchMap((pojo: POJO) => {
        this.spinnerService.show();
        return this.delete(this.endpoint, pojo)
          .map(() => pojo);
      })
      .subscribe((pojo: POJO) => {
          this.deletePojo(pojo);
          this.spinnerService.hide();
          this.success("Exclusão realizada com sucesso");
          this.clear$.next();
        },
        (error: ServerError) => {
          this.spinnerService.hide();
          this.clear$.next();
          this.handleError(error);
        }));

    /**
     * Após acionado o submit gera um novo observable para inclusão ou update.
     */
    this.addSubscriptions(this.submit$
      .switchMap((pojo: POJO) => {
        this.spinnerService.show();

        return NumberUtil.numberNullOrZero(pojo.id) ?
          this.post(this.endpoint, pojo)
            .map((id: number) => ({id, pojo})) :
          this.put(this.endpoint, pojo)
            .map(() => ({pojo}));
      })
      .subscribe((wrapper: { id: number, pojo: POJO }) => {
        if (wrapper.id) {
          wrapper.pojo.id = wrapper.id;
          this.push(wrapper.pojo);
          this.spinnerService.hide();
          this.success("A inclusão foi feita com sucesso");
        } else {
          this.update(wrapper.pojo);
          this.spinnerService.hide();
          this.success("Alteração realizada com sucesso");
        }

        this.afterSubmit$.next(wrapper.pojo);
        this.clear$.next();
      }, (error: ServerError) => {
        this.spinnerService.hide();
        this.clear$.next();
        this.handleError(error);
      }));

    this.disableEditTable();
    this.addBehaviorsKit();
  }

  /**
   * Atualiza a fonte de dados da table.
   * @param pojos: AbstractPojo
   */
  public updateItemsSource(pojos: POJO[]) {
    this.tableComponent.updateItemsSource(pojos);
    this.tableComponent.clearSelection();
  }

  /**
   * Efetua um push do objeto na table.
   * @param pojo: POJO
   * @param generateId: boolean determina se deve gerar id dummy.
   */
  public push(pojo: POJO, generateId = false) {
    this.tableComponent.push(pojo, generateId);
  }

  /**
   * Atualiza o objeto. Para determinar o idx é utilizado o id do POJO.
   * @param object: any
   */
  public update(object: POJO) {
    this.tableComponent.update(object);
  }

  /**
   * Exclui o objeto selecionado. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   * @param idx?: number
   */
  public deletePojo(pojo: POJO, idx?: number) {
    this.tableComponent.delete(pojo, idx);
  }

  /**
   * Retorna o pojo seleionado.
   * @return {any}
   */
  public get selectedItem(): POJO {
    return this.tableComponent.selectedItem;
  }

  /**
   * Aciona o commit das alterações e limpa as alterações.
   */
  public clearChanges() {
    this.clear$.next();
    this.tableComponent.commitAndClearChanges();
  }

  /**
   * Retorna os itens da table.
   * @return {AbstractPojo[]}
   */
  public get sourceCollection(): POJO[] {
    return this.tableComponent.sourceCollection;
  }

  /**
   * Invalida o flexgrid para reposicionar a table e o scroll.
   */
  public invalidateFlexGrid(): void {
    this.tableComponent.invalidateFlexGrid();
  }

  /**
   * Mensagem de sucesso.
   * @param mensage
   */
  public success(mensage: string): void {
    this.toasterService.pop("success", "Sucesso", mensage);
  }

  /**
   * Mensagem de erro.
   * @param error
   */
  public handleError(error: ServerError) {
    this.toasterService.pop("error", "Falha na gravação", `${error.codigo} - ${error.mensagem}`);
  }

  /**
   * Mensagem de warning.
   * @param error
   */
  public warning(error: ServerError) {
    this.toasterService.pop("warning", "Atenção", `${error.codigo} - ${error.mensagem}`);
  }

  /**
   * Retorna o observable para chamada após edição de valores na table.
   * @return {Subject<ICellEditTable<?>>}
   */
  public edit$(): Observable<ICellEditTable<POJO>> {
    return this.editing$.asObservable();
  }

  /**
   * Observable de seleção de item. A cada vez que for selecionada uma linha
   * o subject é disparado.
   *
   * @return {Observable<AbstractPojo>}
   */
  public get currentChanged$(): Observable<POJO> {
    return this.tableComponent.currentChanged$;
  }

  /**
   * Inclui o novo objeto de embalagem no banco de dados e atualiza a table.
   *
   * @param url: string
   * @param pojo: AbstractPojo
   * @return {Observable<any>}
   */
  public post(url: string, pojo: POJO): Observable<any> {
    return this.httpService.post(url, pojo);
  }

  /**
   * Update do objeto.
   *
   * @param url: string
   * @param pojo: AbstractPojo
   * @return {Observable<boolean>}
   */
  public put(url: string, pojo: POJO): Observable<number> {
    return this.httpService.put(url, pojo);
  }

  /**
   * Deleta o objeto.
   *
   * @param url: string
   * @param pojo: AbstractPojo
   * @return {Observable<boolean>}
   */
  public delete(url: string, pojo: POJO): Observable<boolean> {
    return this.httpService.delete(url, pojo.id);
  }

  /**
   * Retorna true após carregar os dados do servidor.
   * @return {Observable<boolean>}
   */
  public get afterLoadData$(): Observable<boolean> {
    return this.afterLoad$.filter((value) => value !== undefined);
  }

  /**
   * Força a inicialização dos dados na table simulando um carregamento, isso pode ser necessário quando é preciso inicializar
   * a fonte de dados.
   * @param {boolean} value
   */
  public set nextAfterLoadData(value: boolean) {
    this.afterLoad$.next(value);
  }

  /**
   * Atualiza as células da grid.
   */
  public refreshCells(): void {
    this.tableComponent.refreshCells();
  }

  public eventClear(): void {
    this.clear$.next();
  }

  /**
   * Evento de exclusão.
   */
  public eventDelete(): void {
    this.addSubscriptions(this.filterReadOrDelete$()
      .subscribe(() => {
        if (this.keepLastRecord && this.sourceCollection.length === 1) {
          this.warning({
            status: null,
            codigo: "WWW115",
            mensagem: "Não é possível deixar o documento sem itens. Inclua um novo item antes de excluir o último."
          });
          return;
        }

        if (this.allowPopupDelete) {
          this.popup.show(true);
        } else {
          this.eventDelete$.next();
        }
      }));
  }

  public eventSubmit(): void {
    this.addSubscriptions(this.filterReadOrDelete$()
      .subscribe(this.eventSubmit$));
  }

  public eventUpdate(): void {
    this.addSubscriptions(this.filterReadOrDelete$()
      .subscribe(this.eventUpdate$));
  }

  public eventDoubleClicked(pojo: POJO): void {
    this.addSubscriptions(this.filterReadOrDelete$()
      .subscribe(() => this.selectedItemDoubleClicked$.emit(pojo)));
  }

  /**
   * Quando o botão for acionado, deve verificar se não esta desabilitado e se possuir os dados de kit, se possuir passa
   * o valor para o componente de kit. O observable já é finalizado pois seu ciclo termina após a ação.
   */
  public eventKit(): void {
    this.disableKit$
      .combineLatest(this.paramsKit$, (disable: boolean, kitPai: Kit) => ({disable, kitPai}))
      .filter((obj: { disable: boolean, kitPai: Kit }) => !obj.disable &&
        !StringUtil.stringNullOrEmpty(this.kitTypeName) && !isNullOrUndefined(obj.kitPai))
      .subscribe((obj: { disable: boolean, kitPai: Kit }) => this.itKitPopup.kitPai = obj.kitPai)
      .unsubscribe();
  }

  /**
   * Filtra o modo e emite evento ser for diferente de visualização ou exclusão.
   * @return {Observable<Modo>}
   */
  private filterReadOrDelete$(): Observable<Modo> {
    return this.modo$
      .filter((modo: Modo) => Modo.READ !== modo && Modo.DELETE !== modo);
  }

  /**
   * Adiciona o subscription para efetuar um unsubscribe
   * @param {Subscription} subscription
   */
  private addSubscriptions(subscription: Subscription): void {
    this.subscriptions.add(subscription);
  }

  /**
   * Comportamentos de Kit.
   */
  private addBehaviorsKit(): void {

    /**
     * Determina se habilita ou desabilita o botão de Kit.
     */
    this.addSubscriptions(this.currentChanged$
      .map((item: AbstractPojo) => {
        if (StringUtil.stringNullOrEmpty(this.kitTypeName)) {
          return true;
        }

        const value: any = item[this.kitTypeName];
        return !(StringUtil.isString(value) ? TipoKit.KIT_PAI[EnumUtils.id] === value : TipoKit.KIT_PAI[`value`] === value);
      }).subscribe(this.disableKit$));
  }

  /**
   * Desabilita a edição de table quando alteração ou exclusão.
   */
  private disableEditTable(): void {
    this.addSubscriptions(this.modo$
      .filter((modo: Modo) => modo === Modo.READ || modo === Modo.DELETE)
      .switchMap(() => this.columns$)
      .subscribe((columns: ColumnDefinition[]) => columns.forEach((c: ColumnDefinition) => c.isReadOnly = true)));
  }
}
