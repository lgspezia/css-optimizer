import { AbstractPojo } from "../../../../../core/crud/pojo";
import { EnumUtils } from "../../../../../core/enuns/enumutil";

/**
 * SPC
 *
 * Created by Osiel on 26/05/17.
 */
export class EntidadeSPCHistorico extends AbstractPojo {

  public idEntidade = 0;
  public idusuarioalteracao = 0;
  public dataOperacao: Date = new Date();
  public tipoOperacaoSPC: TipoOperacaoSPC = TipoOperacaoSPC.ICLUSAO[EnumUtils.id];
  public usuarioalteracao = "";

}

export enum TipoOperacaoSPC {
  ICLUSAO = <any> {[EnumUtils.id]: "ICLUSAO", [EnumUtils.display]: "Inclusão"},
  EXCLUSAO = <any> {[EnumUtils.id]: "EXCLUSAO", [EnumUtils.display]: "Retirada"},
}
