import { AbstractPojo } from "../../../core/crud/pojo";

/**
 * Created by Osiel on 18/07/17.
 */
export class GradeValor extends AbstractPojo {

  public idGrade = 0;
  public ordem;
  public valor = "";
  public inativo = false;
  public numMaxCombinacao = 0;
  public selecionado = false;
}
