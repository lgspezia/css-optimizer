import { AbstractPojo } from "../../../../core/crud/pojo";
import { EnumUtils } from "../../../../core/enuns/enumutil";
/**
 * @author Luan  on 26/06/2017.
 */
export class Signatario extends AbstractPojo {
  public nome = "";
  public cpf = "";
  public identificacaoSignatario = IdentificacaoSignatario.UNDEFINED[EnumUtils.id];
  public idFilial = 0;
}

export enum IdentificacaoSignatario {
  UNDEFINED = <any> {[EnumUtils.id]: "UNDEFINED", [EnumUtils.display]: "-- selecione --"},
  DIRETOR = <any> {[EnumUtils.id]: "DIRETOR", [EnumUtils.display]: "Diretor"},
  CONSELHEIRO = <any> {[EnumUtils.id]: "CONSELHEIRO", [EnumUtils.display]: "Conselheiro de Administração"},
  ADMINISTRADOR = <any> {[EnumUtils.id]: "ADMINISTRADOR", [EnumUtils.display]: "Administrador"},
  ADMINISTRADOR_GRUPO = <any> {[EnumUtils.id]: "ADMINISTRADOR_GRUPO", [EnumUtils.display]: "Administrador de Grupo"},
  ADMINISTRADOR_SOCIEDADE = <any> {
    [EnumUtils.id]: "ADMINISTRADOR_SOCIEDADE",
    [EnumUtils.display]: "Administrador de Sociedade Filiada "
  },
  ADMINISTRADOR_JUDICIAL_PF = <any> {
    [EnumUtils.id]: "ADMINISTRADOR_JUDICIAL_PF",
    [EnumUtils.display]: "Administrador Judicial – Pessoa Físic"
  },
  ADMINISTRADOR_JUDICIAL_PJ = <any> {
    [EnumUtils.id]: "ADMINISTRADOR_JUDICIAL_PJ",
    [EnumUtils.display]: "Administrador Judicial – Pessoa Jurídica – Profissional Responsável"
  },
  ADMINISTRADOR_JUDICIAL_GESTOR = <any> {
    [EnumUtils.id]: "ADMINISTRADOR_JUDICIAL_GESTOR",
    [EnumUtils.display]: "Administrador Judicial/Gestor"
  },
  GESTOR_JUDICIAL = <any> {[EnumUtils.id]: "GESTOR_JUDICIAL", [EnumUtils.display]: "Gestor Judicial"},
  PROCURADOR = <any> {[EnumUtils.id]: "PROCURADOR", [EnumUtils.display]: "Procurador"},
  INVENTARIANTE = <any> {[EnumUtils.id]: "INVENTARIANTE", [EnumUtils.display]: "Inventariante"},
  LIQUIDANTE = <any> {[EnumUtils.id]: "LIQUIDANTE", [EnumUtils.display]: "Liquidante"},
  INTERVENTOR = <any> {[EnumUtils.id]: "INTERVENTOR", [EnumUtils.display]: "Interventor"},
  EMPRESARIO = <any> {[EnumUtils.id]: "EMPRESARIO", [EnumUtils.display]: "Empresário"},
  CONTADOR = <any> {[EnumUtils.id]: "CONTADOR", [EnumUtils.display]: "Contador"},
  OUTROS = <any> {[EnumUtils.id]: "OUTROS", [EnumUtils.display]: "Outros"},
}
