import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Usuario } from "../../../modules/cadastros/usuarios/usuario";

@Component({
    selector: "it-usuario-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItUsuarioAutocompleteComponent extends ItAutocompleteComponent<Usuario> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "usuarios";
        this.display = "nome";
        this.label = "Usuário";
    }
}
