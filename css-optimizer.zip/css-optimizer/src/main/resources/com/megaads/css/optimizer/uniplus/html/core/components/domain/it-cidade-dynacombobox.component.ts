import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { Cidade } from "app/modules/enderecos/estados/cidades/cidade";
import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { ItDynacomboboxComponent } from "../primitive/it-dynacombobox.component";

/**
 * Componente criado para pesquisar cidades de acordo com a seleção de estado.
 * Este componente deve guardar um cache para evitar a busca desnecessárias de dados.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-cidade-dynacombobox",
  templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItCidadeDynacomboboxComponent extends ItDynacomboboxComponent<Cidade> implements OnInit {
  @Input() public urlParams$: Observable<URLSearchParams>;
  @Input() public afterLoadEstado$: Observable<any>;

  /**
   * Cache para guardar os valores pesquisados.
   */
  private cache: any = {};

  constructor(httpService: HttpService) {
    super(httpService);
    this.display = "nome";
    this.label = "Cidade";
    this.url = "cidades/filtrar-por-estado";
  }

  public ngOnInit() {
    this.addSubscription(this.urlParams$
      .switchMap((url: URLSearchParams) => {
        /**
         * Se achar em cache retorna o valor.
         */
        const cacheValue: any = this.cache[url.get("idEstado")];
        if (cacheValue) {
          return Observable.of(cacheValue).map((cidades: any) => ({url, cidades}));
        } else {
          return this.httpService.get(this.url, {search: url}).map((cidades: Cidade[]) => ({url, cidades}));
        }
      })
      .subscribe((resp: { url: URLSearchParams, cidades: any[] }) => {
        /**
         * Cache
         */
        if (!this.cache[resp.url.get("idEstado")]) {
          this.cache[resp.url.get("idEstado")] = resp.cidades;
        }

        this.combobox.itemsSource = resp.cidades;
        this.afterLoad$.next();
      }, (error: ServerError) => this.handleError(error)));

    /**
     * FIXME Se houver outra maneria de fazer, esse fonte deverá ser melhorado.
     *
     * Como o componente trabalha em função de estado, nesse caso levo em consideração a alteração,
     * combinando para pegar o valor setado do banco, logo após aguardo o carregamento de estado e
     * seto o valor correto.
     */
    if (this.afterGet$) {
      this.addSubscription(this.afterGet$
        .combineLatest(this.getControl(), (id: number, control: AbstractControl) => control.value)
        .combineLatest(this.afterLoadEstado$, this.getControl(),
          (value: number, after: any, control: AbstractControl) => ({value, control}))
        .subscribe((wrapper: { value: number, control: AbstractControl }) => wrapper.control.setValue(wrapper.value)));
    }

    this.clearItemsSource();
  }

  /**
   * Observable para determinar que as cidades foram recarregadas.
   * @return {any}
   */
  public get afterLoadData$(): Observable<any> {
    return this.afterLoad$.asObservable();
  }
}
