import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { AbstractControl, ValidatorFn, Validators } from "@angular/forms";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { URLSearchParams } from "@angular/http";
import { Cep } from "../../../modules/enderecos/estados/cidades/ceps/cep";
import { HttpService } from "../../services/http.service";
import { StringUtil } from "../../utils/string.util";
import { ItInputCodeComponent } from "../primitive/it-inputcode.component";

/**
 * Componente para a busca e formatação de CEP.
 *
 * Created by Osiel S. Mello on 16/05/2017.
 */
@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-cep",
  templateUrl: "../primitive/it-inputcode.component.html",
})
export class ItCepInputCodeComponent extends ItInputCodeComponent implements OnInit {
  @Input() public required$: Observable<boolean>;
  @Input() public afterGet$: Observable<number>;

  @Output() public gerar$: EventEmitter<any>;

  /**
   * Cache para guardar os valores pesquisados.
   */
  private cache: any = {};
  private cepSub$: Subject<Cep>;

  constructor(protected httpService: HttpService) {
    super(httpService);
    this.len = 9;
    this.icon = "refresh";
    this.label = "CEP";
    this.required$ = Observable.of(false);
    this.cepSub$ = new Subject();
  }

  public ngOnInit(): void {

    this.addSubscription(this.getValueChanges()
      .combineLatest(this.getControl(), (value: string, control: AbstractControl) => ({value, control}))
      .filter((wrapper: { value: string, control: AbstractControl }) =>
          /**
           * Testa o regex
           */
        !StringUtil.stringNullOrEmpty(wrapper.value) &&
        wrapper.value.length === 8 && /^[0-9]{8}$/.test(wrapper.value),
      )
      .debounceTime(150)
      .distinctUntilChanged()
      .subscribe((wrapper: { value: string, control: AbstractControl }) => {
        wrapper.control.setValue(wrapper.value.substring(0, 5).concat("-").concat(wrapper.value.substring(5)));
        // TODO OSIEL POR ENQUANTO NÂO TEM COMO IMPLEMENTAR A BUSCA AUTOMATICA, UMA VEZ QUE
        // EM MODO DE ALTERAÇÃO A BUSCA É REFEITA MUDANDO O ENDEREÇO EM CIDADES DE UM UNICO CEP
        // this.gerar();
      }));

    /**
     * Validadores.
     */
    this.addSubscription(this.required$
      .combineLatest(this.getControl(),
        (required: boolean, control: AbstractControl) => ({required, control}))
      .subscribe((wrapper: { required: boolean, control: AbstractControl }) => {
        const validadores: ValidatorFn[] = [Validators.pattern("[0-9]{5}-[0-9]{3}")];
        if (wrapper.required) {
          validadores.push(Validators.required);
        }
        wrapper.control.setValidators(validadores);
      }));

    /**
     * Busca o cep no retaguarda.
     */
    this.addSubscription(this.gerar$
      .withLatestFrom(this.getControl(), (gerar: any, c: AbstractControl) => c)
      .filter((c: AbstractControl) => c.valid && !StringUtil.stringNullOrEmpty(c.value))
      .switchMap((c: AbstractControl): Observable<Cep> => {
        /**
         * Verifica se existe em cache.
         */
        const cep: string = c.value.replace("-", "");
        const cacheValue: Cep = this.cache[cep];
        if (cacheValue) {
          return Observable.of(cacheValue);
        } else {
          const params: URLSearchParams = new URLSearchParams();
          params.set("cep", cep);
          return this.httpService.get(`ceps/buscar-cep`, {search: params});
        }
      })
      .subscribe((cep: Cep) => {
        if (!StringUtil.stringNullOrEmpty(cep.cep)) {
          if (!this.cache[cep.cep]) {
            this.cache[cep.cep] = cep;
          }
          this.cepSub$.next(cep);
        }
      }));
  }

  /**
   * Retorna o observable de cep.
   * @return {Observable<Cep>}
   */
  public get cep$(): Observable<Cep> {
    return this.cepSub$.asObservable();
  }
}
