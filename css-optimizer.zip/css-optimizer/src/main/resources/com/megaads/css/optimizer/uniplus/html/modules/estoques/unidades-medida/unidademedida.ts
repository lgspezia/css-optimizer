import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";

/**
 * @author Osiel.
 */
export class UnidadeMedida extends AbstractPojo {

  public codigo = "";
  public nome = "";
  public casasdecimais = 0;
  public tipoValor: TipoValorUnidadeMedida = null;

}

export enum TipoValorUnidadeMedida {
  QUANTIDADE = <any> {[EnumUtils.id]: "QUANTIDADE", [EnumUtils.display]: "Quantidade"},
  HORA = <any> {[EnumUtils.id]: "HORA", [EnumUtils.display]: "Hora"},
}
