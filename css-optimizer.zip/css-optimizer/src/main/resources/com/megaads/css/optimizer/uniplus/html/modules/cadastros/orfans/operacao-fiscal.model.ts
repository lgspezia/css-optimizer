import { CodigoNaturezaOperacaoG2ka } from "./enums/codigo-natureza-operacao-g2ka.enum";
import { FinalidadeEmissaoNfeCFOP } from "./enums/finalidade-emissao-nfe-cfop.enum";
import { PresencaConsumidorNFE } from "./enums/presenca-consumidor-nfe.enum";
import { TipoCfopConsignacao } from "./enums/tipo-cfop-consignacao.enum";
import { TipoIntegracaoFinanceiro } from "./enums/tipo-integracao-financeiro.enum";
import { TipoValorPreco } from "./enums/tipo-valor-preco.enum";
import { GnreNaturezaOperacaoEstado } from "./gnre-natureza-operacao-estado.model";
import { ParametrosNotaFiscalInterface } from "./parametros-nota-fiscal-interface.model";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class OperacaoFiscal extends ParametrosNotaFiscalInterface {
  nome = "";
  digitarImpostosItemNotaSaida: boolean;
  informarTotaisManualmente: boolean;
  finalidadeEmissaoNfe: FinalidadeEmissaoNfeCFOP;
  presencaConsumidor: PresencaConsumidorNFE;
  considerarProduto: boolean;
  considerarServico: boolean;
  idplanocontas = 0;
  consignacao: TipoCfopConsignacao;
  consideraDevolucaoVenda: boolean;
  integracao: TipoIntegracaoFinanceiro;
  habilitaBaseIpiItemNota: boolean;
  habilitaBasePisCofinsItemNota: boolean;
  importacao: boolean;
  exportacao: boolean;
  idCondicaoPagamento = 0;
  idtipodocumentofinanceiro = 0;
  adicionarPisCofinsInfComp: boolean;
  somarPisOutrasDesp: boolean;
  somarCofinsOutrasDesp: boolean;
  somarSiscomexOutrasDesp: boolean;
  somarDespAcesOutrasDesp: boolean;
  somarIcmsOutrasDesp: boolean;
  consideravenda: boolean;
  naoConsideraTribEspecProduto: boolean;
  permitirBaixarLoteVencido: boolean;
  conferenciaNotaFiscal: boolean;
  conferenciaPedido: boolean;
  tipoValorPreco: TipoValorPreco;
  consideraInscricaoEstadualSub: boolean;
  codigoCfopServicoG2ka: CodigoNaturezaOperacaoG2ka;
  regimeEspecial: boolean;
  fundamentacaoLegalEstado = "";
  idObsLancFiscalCreditoIcms = 0;
  idAjusteDocFiscalCreditoIcms = 0;
  consumidorFinal: boolean;
  exigirDocumentoReferenciado: boolean;
  listaNaturezaOperacaoEstado: GnreNaturezaOperacaoEstado[];
}
