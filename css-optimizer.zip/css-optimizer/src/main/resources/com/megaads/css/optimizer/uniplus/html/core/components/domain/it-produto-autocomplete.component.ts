import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Produto } from "../../../modules/produtos/produto";

@Component({
    selector: "it-produto-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
// TODO OSIEL COMPONENTE PRECISA SER ALTERADO POSTERIORMENTE.
export class ItProdutoAutoCompleteComponent extends ItAutocompleteComponent<Produto> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "nome";
        this.label = "Produto";
        this.url = "produtos";
    }

}
