import { Component, Input, OnInit } from "@angular/core";

import {
  CondicaoPagamento, EscopoCondicaoPagamento
} from "../../../modules/vendas/condicoes-pagamento/condicao-pagamento";
import { EnumUtils } from "../../enuns/enumutil";
import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";

@Component({
  selector: "it-condicaopagamento-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItCondicaoPagamentoAutocompleteComponent extends ItAutocompleteComponent<CondicaoPagamento> implements OnInit {
  @Input() public escopo: string;

  constructor(httpService: HttpService) {
    super(httpService);

    this.escopo = EscopoCondicaoPagamento.COMPRA_VENDA[EnumUtils.id];
    this.display = "descricao";
    this.label = "Condição de pagamento";
    this.url = "condicoes-pagamento/filtrar-por-escopo";
  }

  public ngOnInit(): void {
    this.addParams("escopo", EscopoCondicaoPagamento[this.escopo][EnumUtils.id]);
    super.ngOnInit();
  }
}
