import { Component, OnInit } from "@angular/core";
import { AbstractControl, Validators } from "@angular/forms";

import { ContextoService } from "../../services/contexto.service";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";
import { ItInputTextComponent } from "../primitive/it-inputtext.component";

@Component({
  selector: "it-referenciaproduto-inputtext",
  templateUrl: "../primitive/it-inputtext.component.html",
})
export class ItReferenciaProdutoInputTextComponent extends ItInputTextComponent implements OnInit {

  constructor(private contexto: ContextoService) {
    super();
    this.label = "Referência";
    this.len = 60;
  }

  public ngOnInit(): void {
    /**
     * Adiciona o regex de validação.
     */
    this.addSubscription(this.getControl()
      .combineLatest(this.contexto.getPropriedade$(486),
        (control: AbstractControl, pattern: string) => ({control, pattern}))
      .subscribe(({control, pattern}: { control: AbstractControl, pattern: string }) =>
        control.setValidators([Validators.pattern(pattern)])));

    /**
     * Upper case. Para isso quando houver mudança filtra o valor para saber se é string
     * e espera um tempo para setar o upper case.
     */
    this.addSubscription(this.getValueChanges()
      .withLatestFrom(this.getControl(), (value: string, control: AbstractControl) => ({value, control}))
      .filter(({value, control}) => !NumberUtil.isNumber(value) && !StringUtil.stringNullOrEmpty(value))
      .debounceTime(200)
      .distinctUntilChanged()
      .subscribe(({value, control}: { value: string, control: AbstractControl }) => control.setValue(value.toUpperCase())));
  }
}
