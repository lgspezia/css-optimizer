import { AbstractPojo } from "../../../core/crud/pojo";

export class Pais extends AbstractPojo {
    public nome = "";
    public codigoIbge = 0;
}
