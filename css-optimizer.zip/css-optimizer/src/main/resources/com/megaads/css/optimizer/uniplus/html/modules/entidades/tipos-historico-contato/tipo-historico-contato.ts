import { AbstractPojo } from "../../../core/crud/pojo";

/**
 * @author Osiel
 */
export class TipoHistoricoContato extends AbstractPojo {

  public descricao = "";
}
