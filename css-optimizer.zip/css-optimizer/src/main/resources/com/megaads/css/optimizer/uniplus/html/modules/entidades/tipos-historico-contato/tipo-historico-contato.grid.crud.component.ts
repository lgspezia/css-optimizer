import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { GridCrud } from "../../../core/crud/grid.crud";
import { uniqueAsyncValidator } from "../../../core/crud/validadores";
import { TipoHistoricoContato } from "./tipo-historico-contato";

/**
 * Históricos de contato.
 *
 * @author Osiel.
 */

@Component({
  templateUrl: "tipo-historico-contato.grid.crud.html",
})
export class TipoHistoricoContatoGridCrudComponent extends GridCrud<TipoHistoricoContato> {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new TipoHistoricoContato(), "tipos-historico-contato");

    this.addSubscription(this.getControl("codigo")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(6)]);
        control.setAsyncValidators([uniqueAsyncValidator("tipos-historico-contato")]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("descricao")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(50)])));

  }
}
