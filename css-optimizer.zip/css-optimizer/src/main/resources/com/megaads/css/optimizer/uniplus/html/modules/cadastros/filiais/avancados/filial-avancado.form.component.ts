import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, Validators } from "@angular/forms";

import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";
import { EnumUtils } from "../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../core/models/dataitem";
import { TipoDataBaixaEstoquePEPS, TipoEmitenteManifesto, TipoTransportador } from "../filial";
/**
 * @author Luan  on 21/06/2017.
 */

@Component({
  selector: "it-filial-avancado",
  templateUrl: "filial-avancado.form.component.html"
})
export class ItFilialAvancadoFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public tipoBaixaPeps$: Observable<IDataItem[]>;
  public tipoManifesto$: Observable<IDataItem[]>;
  public tipoTransportador$: Observable<IDataItem[]>;

  constructor() {
    super();
    this.tipoBaixaPeps$ = EnumUtils.getValues(TipoDataBaixaEstoquePEPS, EnumUtils.display, false);
    this.tipoManifesto$ = EnumUtils.getValues(TipoEmitenteManifesto, EnumUtils.display, false);
    this.tipoTransportador$ = EnumUtils.getValues(TipoTransportador, EnumUtils.display, false);
  }

  public ngOnInit() {

    this.addSubscription(this.getControl("registroNacionalTransportador")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(8)])));

    /**
     * Valida os campos de hora para que seja um valor valido
     */
    this.addSubscription(this.getControl("primeiroTurnoHoraInicial").merge(this.getControl("primeiroTurnoHoraFinal"),
      this.getControl("segundoTurnoHoraInicial"), this.getControl("segundoTurnoHoraFinal"),
      this.getControl("terceiroTurnoHoraInicial"), this.getControl("terceiroTurnoHoraFinal"),
      this.getControl("quartoTurnoHoraInicial"), this.getControl("quartoTurnoHoraFinal"))
      .subscribe((control: AbstractControl) =>
        control.setValidators([Validators.pattern("([0-1][0-9]|2[0-3])\:[0-5][0-9]|(__:__)")])));
  }
}
