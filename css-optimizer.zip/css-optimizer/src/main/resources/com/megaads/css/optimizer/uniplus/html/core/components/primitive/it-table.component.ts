import { AfterViewInit, Component, EventEmitter, Input, OnDestroy, Output, ViewChild } from "@angular/core";

import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Subscription } from "rxjs/Subscription";

import { CollectionView, DataType, Point } from "wijmo/wijmo";
import { CellEditEndingEventArgs, CellType, FlexGrid, FormatItemEventArgs, GridPanel } from "wijmo/wijmo.grid";

import { isNullOrUndefined } from "util";
import { ICellEditTable } from "../../crud/cell-edit-table";
import { ColumnDefinition } from "../../crud/column-definition";
import { AbstractPojo } from "../../crud/pojo";
import { ToasterService } from "../../services/toaster.service";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";

/**
 * Componente de Table para inclusão de cruds em tela. Pode ser utilizado
 * em conjunto com ItFormTableComponent;
 *
 * @author Osiel
 */
@Component({
  selector: "it-table",
  template: `
    <wj-flex-grid #ittable class="grid" (dblclick)="onRowDblclicked()"></wj-flex-grid>`,
})
export class ItTableComponent<POJO extends AbstractPojo> implements AfterViewInit, OnDestroy {

  @Input() public selectAll: boolean;
  @Input() public columns$: Subject<ColumnDefinition[]>;
  @Input() public editing$: Subject<ICellEditTable<POJO>>;

  @Output() public selectedItemDoubleClicked$: EventEmitter<POJO>;

  @ViewChild("ittable") private grid: FlexGrid;

  private collectionView: CollectionView;
  private currentItem$: Subject<POJO>;
  private subscription: Subscription;
  private filter: string;

  constructor(private toasterService: ToasterService) {
    this.currentItem$ = new Subject();
    this.selectAll = false;
    this.selectedItemDoubleClicked$ = new EventEmitter();
  }

  public ngAfterViewInit(): void {
    this.grid.selectionMode = 3;
    this.grid.autoGenerateColumns = false;

    this.subscription = this.columns$.subscribe((columns) => {
      this.grid.columns.clear();

      /**
       * Adiciona as colunas.
       */
      columns.forEach((column: ColumnDefinition) => this.grid.columns.push(column));

      /**
       * Aplica os formatadores.
       */
      this.grid.formatItem.addHandler((flexGrid: FlexGrid, format: FormatItemEventArgs) => {
        const column: ColumnDefinition = columns[format.col];
        if (format.panel === this.grid.cells && column) {

          if ((!StringUtil.stringNullOrEmpty(column.enumClass) || column.converter || column.decimalColumn)) {

            const value = this.grid.getCellData(format.row, format.col, false);
            if (!StringUtil.stringNullOrEmpty(column.enumClass)) {
              /*
               * Enum converter.
               */
              format.cell.innerHTML = column.converter(value, column.enumClass);
            } else if (column.converter) {
              /*
               * Converter definido manualmente
               */
              format.cell.innerHTML = column.converter(value);
            } else if (column.decimalColumn) {
              /*
               * Formata as casas decimais.
               */
              const idx = columns.findIndex((c: ColumnDefinition) => c.binding === column.decimalColumn);

              let valueDecimal = this.grid.getCellData(format.row, idx, false);
              if (isNullOrUndefined(valueDecimal)) {
                /*
                 *  Se não informado, irá usar o default.
                 */
                valueDecimal = 2;
              }

              const decimal: number = NumberUtil.isNumber(valueDecimal) ?
                valueDecimal : NumberUtil.parseInt(valueDecimal);

              let formatedValue: number;
              if (!NumberUtil.isNumber(value)) {
                formatedValue = value;
              } else {
                formatedValue = NumberUtil.parseFloat(value);
              }

              /*
               * Quando number if(number) tambem valida ZERO
               * por isso uso !== undefined
               */
              if (formatedValue !== undefined) {
                format.cell.innerHTML = formatedValue.toFixed(decimal);
              }
            }
          }

        }
      });

      /**
       * Inclui o checkbox para selecionar todos os itens.
       */
      if (this.selectAll) {
        this.grid.itemFormatter = (panel: GridPanel, row: number, col: number, cell: HTMLElement) => {
          if (panel.cellType === CellType.ColumnHeader) {

            const flex: FlexGrid = panel.grid;
            const column = flex.columns[col];

            if (column.dataType === DataType.Boolean) {
              column.allowSorting = false;

              let cnt = 0;
              for (let i = 0; i < flex.rows.length; i++) {
                if (flex.getCellData(i, col, false) === true) {
                  cnt++;
                }
              }

              cell.innerHTML = `<input type="checkbox"> ${cell.innerHTML}`;
              const cb: any = cell.firstChild, checked = cnt > 0;

              const indeterminate = cnt > 0 && cnt < flex.rows.length;

              cb.checked = checked || indeterminate;
              cb.indeterminate = indeterminate;
              cb.addEventListener(`click`, function () {
                flex.beginUpdate();
                for (let i = 0; i < flex.rows.length; i++) {
                  flex.setCellData(i, col, cb.checked || indeterminate);
                }
                flex.endUpdate();
              });
              cb.addEventListener(`mousedown`, function () {
                setTimeout(function () {
                  if (cb.indeterminate) {
                    cb.click();
                  }
                });
              });
            }
          }
        };
      }

      /**
       * Adiciona handler para capturar edição. Por definição apenas campos de checbox poderão ser editáveis.
       */
      this.grid.cellEditEnded.addHandler((flexGrid: FlexGrid, cell: CellEditEndingEventArgs) => {
        if (this.editing$) {
          this.collectionView.beginUpdate();
          this.editing$.next({
            cellEdit: cell,
            oldValue: !flexGrid.getCellData(cell.row, cell.col, false),
            pojo: this.selectedItem,
          });
        }
      });

    });

  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Emite um novo evento com o item selecionado.
   */
  public onRowDblclicked(): void {
    const row = this.grid.selectedRows[0];
    if (row) {
      const item: POJO = row.dataItem;
      if (item) {
        this.selectedItemDoubleClicked$.emit(item);
      }
    }
  }

  /**
   * Atualiza as células da grid.
   */
  public refreshCells(): void {
    this.grid.refreshCells(false);
  }

  /**
   * Observable de seleção de item. A cada vez que for selecionada uma linha
   * o subject é disparado.
   *
   * @return {Observable<AbstractPojo>}
   */
  public get currentChanged$(): Observable<POJO> {
    return this.currentItem$.filter((pojo) => pojo !== null);
  }

  /**
   * Limpa a seleção da grid.
   */
  public clearSelection(): void {
    this.grid.select(-1, -1);
  }

  /**
   * Invalida o flexgrid para reposicionar a table e o scroll.
   */
  public invalidateFlexGrid(): void {
    this.grid.scrollPosition = new Point(0, 0);
    this.grid.invalidate(true);
  }

  /**
   * Aciona o commit das alterações e limpa as alterações.
   */
  public commitAndClearChanges() {
    this.collectionView.commitEdit();
    this.collectionView.clearChanges();
  }

  /**
   * Atualiza a fonte de dados.
   *
   * @param source: POJO []
   */
  public updateItemsSource(source: POJO[]) {
    this.collectionView = new CollectionView(source);
    this.collectionView.filter = this.gridFilter.bind(this);
    this.collectionView.trackChanges = true;
    this.grid.itemsSource = this.collectionView;

    this.collectionView.currentChanged.addHandler(() => this.currentItem$.next(this.collectionView.currentItem));
  }

  /**
   * Efetua um push do objeto na table.
   * @param pojo: POJO
   * @param generateId: boolean determina se deve gerar id dummy.
   */
  public push(pojo: POJO, generateId?: boolean) {
    if (generateId) {
      pojo.id = -Math.abs(this.collectionView.sourceCollection.length + 1);
    }
    this.collectionView.sourceCollection.push(pojo);
    this.collectionView.refresh();
    this.clearSelection();
  }

  /**
   * Atualiza o objeto. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   */
  public update(pojo: POJO) {
    const idx: number = this.findIndex(pojo);
    if (idx === -1) {
      throw new Error("Index não encontrado. Verifique o id do objeto");
    }
    this.collectionView.sourceCollection[idx] = pojo;
    this.collectionView.refresh();
    this.clearSelection();
  }

  /**
   * Exclui o objeto selecionado. Para determinar o idx é utilizado o id do POJO.
   * @param pojo: POJO
   * @param idx?: number
   */
  public delete(pojo: POJO, idx?: number) {
    if (idx === undefined || idx === -1) {
      idx = this.findIndex(pojo);
    }

    if (idx === -1) {
      throw new Error("Index não encontrado. Verifique o id do objeto");
    }

    this.collectionView.removeAt(idx);
    this.collectionView.refresh();
    this.clearSelection();
  }

  /**
   * Comfirma a inclusão atualizando o Id do pojo.
   * @param pojo: POJO
   * @param id: number
   */
  public commitUpdateId(pojo: POJO, id: number): void {
    const idx = this.findIndex(pojo);
    if (id) {
      pojo.id = id;
    }
    this.collectionView.sourceCollection[idx] = pojo;
    this.collectionView.refresh();
  }

  /**
   * Retorna o objeto selecionado.
   * Exibe uma mensagem de aviso caso contrário
   * * @return {AbstractPojo}
   */
  public get selectedItem(): POJO {
    const isSelecionado = this.grid.selectedItems[0];
    if (!isSelecionado) {
      this.toasterService.pop("warning", "Atenção", "Selecione uma linha para executar a operação");
      return null;
    }
    isSelecionado.id = NumberUtil.parseFloat(isSelecionado.id);
    return isSelecionado;
  }

  /**
   * Retorna os itens da table.
   * @return {AbstractPojo[]}
   */
  public get sourceCollection(): POJO[] {
    if (this.collectionView) {
      return this.collectionView.sourceCollection;
    }
    return [];
  }

  /**
   * Atualiza o collectionview.
   */
  public search(filter: string): void {
    this.filter = filter;
    this.collectionView.refresh();
  }

  /**
   *  Define uma função para filtrar a grid. O valor a ser pesquisado foi setado em onSearch()
   * @param item
   * @return {boolean}
   */
  private gridFilter(item): boolean {
    if (!this.filter) {
      return true;
    }
    const filterLower = this.filter.toLowerCase();
    for (const col in item) {
      if (item.hasOwnProperty(col)) {
        if (this.grid.columns.getColumn(col) !== null && this.grid.columns.getColumn(col).isVisible) {
          const val = item[col]; // aqui talvez verificar se val é uma String
          if (val.toString().toLowerCase().indexOf(filterLower) >= 0) {
            return true;
          }
        }
      }
    }
    return false;
  }

  /**
   * Procura pelo index de acordo com o id;
   * @param pojo: POJO
   */
  private findIndex(pojo: POJO): number {
    return this.collectionView.sourceCollection.findIndex((e) => NumberUtil.parseFloat(e.id) === pojo.id);
  }
}
