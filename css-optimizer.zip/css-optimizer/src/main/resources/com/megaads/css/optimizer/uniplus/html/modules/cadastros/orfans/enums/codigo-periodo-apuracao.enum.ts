import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum CodigoPeriodoApuracao {
  MENSAL = <any> {[EnumUtils.id]: "MENSAL", [EnumUtils.display]: "Mensal"},
  PRIMEIRA_QUIZENA = <any>   {[EnumUtils.id]: "PRIMEIRA_QUIZENA", [EnumUtils.display]: "1 Quinzena"},
  SEGUNDA_QUIZENA = <any> {[EnumUtils.id]: "TOTAL_BRUTO_NOTA", [EnumUtils.display]: "2 Quinzena"},
  PRIMEIRO_DECENDIO = <any> {[EnumUtils.id]: "ICMS_UF_ORIGEM", [EnumUtils.display]: "1 Decendio"},
  SEGUNDO_DECENDIO = <any>   {[EnumUtils.id]: "ICMS_UF_DESTINO", [EnumUtils.display]: "2 Decendio"},
  TERCEIRO_DECENDIO = <any> {[EnumUtils.id]: "FCP", [EnumUtils.display]: "3 Decendio"},
}
