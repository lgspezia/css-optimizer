import { Component, Input, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { ItEnderecoComponent } from "../../../../core/components/domain/it-endereco.component";
import { FormComponent } from "../../../../core/crud/form-component";
import { ContextoService } from "../../../../core/services/contexto.service";
import { StringUtil } from "../../../../core/utils/string.util";
import { Contato } from "../utils/contato";
import { Endereco } from "../utils/endereco";

/**
 * Crud de outros endereços de entidade.
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidadeendereco",
  templateUrl: "entidade-endereco.form.component.html",
})
export class ItEntidadeEnderecoFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;
  @Input() public formEndereco$: BehaviorSubject<FormGroup>;

  public formContatoCobranca$: BehaviorSubject<FormGroup>;
  public formContatoEntrega$: BehaviorSubject<FormGroup>;
  public formEnderecoCobranca$: BehaviorSubject<FormGroup>;
  public formEnderecoEntrega$: BehaviorSubject<FormGroup>;

  public maskFone$: Observable<string>;

  @ViewChild("enderecoCobranca") private itEnderecoCobranca: ItEnderecoComponent;
  @ViewChild("enderecoEntrega") private itEnderecoEntrega: ItEnderecoComponent;

  constructor(private contexto: ContextoService) {
    super();

    this.formContatoCobranca$ = new BehaviorSubject(undefined);
    this.formContatoEntrega$ = new BehaviorSubject(undefined);
    this.formEnderecoCobranca$ = new BehaviorSubject(undefined);
    this.formEnderecoEntrega$ = new BehaviorSubject(undefined);

    this.maskFone$ = contexto.getPropriedade$(258)
      .map((p: string) => p === "true" ? "(9xx99) 00000-0000" : "(9xx99) 0000-000000000000000000000000000");
  }

  public ngOnInit(): void {
    this.addSubscription(this.getFormGroup("contatoCobranca", new Contato()).subscribe(this.formContatoCobranca$));
    this.addSubscription(this.getFormGroup("enderecoCobranca", new Endereco()).subscribe(this.formEnderecoCobranca$));
    this.addSubscription(this.getFormGroup("contatoEntrega", new Contato()).subscribe(this.formContatoEntrega$));
    this.addSubscription(this.getFormGroup("enderecoEntrega", new Endereco()).subscribe(this.formEnderecoEntrega$));

    /**
     * Validações.
     */
    this.addSubscription(this.getControl("nome", this.formContatoCobranca$)
      .merge(this.getControl("endereco", this.formEnderecoCobranca$),
        this.getControl("bairro", this.formEnderecoCobranca$),
        this.getControl("complemento", this.formEnderecoCobranca$))
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("numero", this.formEnderecoCobranca$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(6)])));

    this.addSubscription(this.getControl("nome", this.formContatoEntrega$)
      .merge(this.getControl("endereco", this.formEnderecoEntrega$),
        this.getControl("bairro", this.formEnderecoEntrega$),
        this.getControl("complemento", this.formEnderecoEntrega$))
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("numero", this.formEnderecoEntrega$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(6)])));

    /**
     * Atualiza o Estado de outros endereços quando alterado na geral.
     */
    this.addSubscription(this.getValueChanges("cep", this.formEndereco$)
      .merge(this.getControl("cep", this.formEndereco$)
        .map((c: AbstractControl) => c.value))
      .combineLatest(this.getControl("cep", this.formEndereco$),
        this.getControl("cep", this.formEnderecoCobranca$), this.getControl("cep", this.formEnderecoEntrega$),
        (cep: string, cepControl: AbstractControl, cepCobranca: AbstractControl, cepEntrega: AbstractControl) =>
          ({cep, cepControl, cepCobranca, cepEntrega}))
      .subscribe((wrapper: { cep: string, cepControl: AbstractControl, cepCobranca: AbstractControl, cepEntrega: AbstractControl }) => {
        if (!StringUtil.stringNullOrEmpty(wrapper.cep) && wrapper.cepControl.valid) {

          if (StringUtil.stringNullOrEmpty(wrapper.cepCobranca.value) ||
            (wrapper.cepCobranca.value.length === 8 && /^[0-9]{8}$/.test(wrapper.cepCobranca.value))) {
            wrapper.cepCobranca.setValue(wrapper.cep);
            this.itEnderecoCobranca.itCep.gerar();
          }

          if (StringUtil.stringNullOrEmpty(wrapper.cepEntrega.value) ||
            (wrapper.cepEntrega.value.length === 8 && /^[0-9]{8}$/.test(wrapper.cepEntrega.value))) {
            wrapper.cepEntrega.setValue(wrapper.cep);
            this.itEnderecoEntrega.itCep.gerar();
          }
        }
      }));
  }

}
