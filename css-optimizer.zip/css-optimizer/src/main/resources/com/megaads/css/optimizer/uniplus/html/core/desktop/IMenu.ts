/**
 * Dados de menu.
 *
 * @author Adriel.
 */
export interface IMenu {
    define: number;
    nameClass?: string;
    endpoint: string;
    permission: boolean;
    filho: IMenu[];
    icone: string;
    nomeItem: string;
}
