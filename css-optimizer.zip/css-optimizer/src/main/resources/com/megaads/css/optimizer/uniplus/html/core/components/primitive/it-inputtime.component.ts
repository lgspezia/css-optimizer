import { Component } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputtime",
    templateUrl: "it-inputtime.component.html",
})
export class ItInputTimeComponent extends BaseFormComponent { }
