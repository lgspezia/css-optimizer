import { Component, OnInit } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { GridCrud } from "../../../core/crud/grid.crud";
import { ContextoService } from "../../../core/services/contexto.service";
import { UnidadeMedida } from "./unidademedida";

/**
 * Unidades de medida.
 *
 * @author Osiel.
 */
@Component({
  templateUrl: "unidademedida.grid.crud.html",
})
export class UnidadeMedidaGridCrudComponent extends GridCrud<UnidadeMedida> implements OnInit {

  public sinonimo$: Observable<boolean>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService) {
    super(activatedRoute, formBuilder, new UnidadeMedida(), "unidades-medida");
  }

  public ngOnInit(): void {
    super.ngOnInit();

    this.sinonimo$ = this.contexto.isFuncionalidade$("SINONIMO_UNIDADE_MEDIDA")
      .combineLatest(this.isCreate$(), (f: boolean, c: boolean) => f && !c);
  }
}
