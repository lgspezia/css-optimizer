import { Component, Input } from "@angular/core";

import { Observable } from "rxjs/Observable";

@Component({
  selector: "it-button",
  template: `
    <button #button type="button" class="btn btn-{{type}} font-truman" [disabled]="disabled$ | async">
      &nbsp;&nbsp;<i class="fa fa-{{icon}} font-size-icons"></i>&nbsp;&nbsp;{{label.toUpperCase()}}&nbsp;&nbsp;
    </button>
  `,
})
export class ItButtonComponent {
  @Input() public label: string;
  @Input() public icon: string;
  @Input() public disabled$: Observable<boolean>;
  @Input() public type: string;
  @Input() public font: string;

  constructor() {
    this.disabled$ = Observable.of(false);
    this.type = "default";
  }
}
