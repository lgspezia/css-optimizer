import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { GridCrud } from "../../../core/crud/grid.crud";
import { uniqueAsyncValidator } from "../../../core/crud/validadores";
import { Regiao } from "./regiao";

@Component({
  templateUrl: "regiao.grid.crud.html",
})
export class RegiaoGridCrudComponent extends GridCrud<Regiao> {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Regiao(), "regioes");

    this.addValidators();
  }

  private addValidators(): void {
    this.addSubscription(this.getControl("codigo")
      .subscribe((codigo: AbstractControl) => {
        codigo.setValidators([Validators.required]);
        codigo.setAsyncValidators([uniqueAsyncValidator("regioes")]);
      }));

    this.disableWhenIsNotCreateMode("codigo");
  }

}
