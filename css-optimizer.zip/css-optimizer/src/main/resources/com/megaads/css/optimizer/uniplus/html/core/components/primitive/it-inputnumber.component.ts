import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { BaseFormComponent } from "./baseform.component";
import { ItControlMessagesComponent } from "./it-control-messages.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-inputnumber",
  templateUrl: "it-inputnumber.component.html",
})
export class ItInputNumberComponent extends BaseFormComponent implements OnInit {
  @Input() public min$: Observable<number>;
  @Input() public max$: Observable<number>;
  @Input() public decimais$: Observable<number>;

  @Output() eventBlur: EventEmitter<any>;

  public format$: Observable<String>;

  constructor() {
    super();
    this.decimais$ = Observable.of(2);
    this.eventBlur = new EventEmitter();
    this.min$ = Observable.of(0);
    this.max$ = Observable.of(999999999);
  }

  public ngOnInit(): void {
    this.format$ = this.decimais$.map((decimais) => `'n${decimais}'`);
  }

  /**
   * Evento Blur
   * @param event
   */
  public lostFocus(event) {
    this.eventBlur.emit(event);
  }
}
