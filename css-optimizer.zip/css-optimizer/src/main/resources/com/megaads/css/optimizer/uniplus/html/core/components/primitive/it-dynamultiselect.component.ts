import { Component, Input, OnInit, ViewChild } from "@angular/core";

import { WjMultiSelect } from "wijmo/wijmo.angular2.input";

import { HttpService } from "../../services/http.service";
import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-dynamultiselect",
  templateUrl: "it-dynamultiselect.component.html",
})
export class ItDynamultiselectComponent extends BaseFormComponent implements OnInit {
  @Input() public placeholder = "";
  @Input() public display: string;
  @Input() public url: string;

  @ViewChild(WjMultiSelect) private multiselect: WjMultiSelect;

  constructor(private httpService: HttpService) {
    super();
  }

  /**
   * Carrega os dados do servidor.
   */
  public ngOnInit() {
    this.httpService.get(this.url)
      .subscribe((resp) => this.multiselect.itemsSource = resp, (error) => super.handleError(error));
  }

  /**
   * Retorna array com os valores selecionados
   */
  public checkedItems(): any {
    return this.multiselect.checkedItems.map((item) => item.id);
  }

}
