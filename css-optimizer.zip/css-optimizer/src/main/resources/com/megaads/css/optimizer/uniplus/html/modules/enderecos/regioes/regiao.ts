import { AbstractPojo } from "../../../core/crud/pojo";

export class Regiao extends AbstractPojo {
    public nome = "";
    public valor = 0;
}
