import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TipoDocumentoFinanceiro } from "../../../modules/financeiros/tipos-documentos-financeiro/tipodocumentofinanceiro";

@Component({
  selector: "it-tipodocumentofinanceiro-integracao-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoDocumentoFinanceiroIntegracaoAutocompleteComponent extends ItAutocompleteComponent<TipoDocumentoFinanceiro> {

  constructor(httpService: HttpService) {
    super(httpService);
    this.display = "descricao";
    this.label = "Tipo de documento";
    this.url = "tipos-documentos-financeiro/filtrar-por-integracao";
    this.urlUpdate = "tipos-documentos-financeiro";
  }
}

