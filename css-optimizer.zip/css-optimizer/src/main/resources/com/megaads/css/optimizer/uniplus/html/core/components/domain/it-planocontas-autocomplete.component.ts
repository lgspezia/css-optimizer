import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { PlanoConta } from "../../../modules/reports/financeiro/planos-contas/plano-conta";

@Component({
    selector: "it-planocontas-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
// TODO OSIEL ESSE COMPONENTE PRECISA SER REFATORADO PARA TREEAUTOCOMPLETE
export class ItPlanoContasAutocompleteComponent extends ItAutocompleteComponent<PlanoConta> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "planos-contas";
        this.display = "nome";
        this.label = "Plano de contas";
    }

}
