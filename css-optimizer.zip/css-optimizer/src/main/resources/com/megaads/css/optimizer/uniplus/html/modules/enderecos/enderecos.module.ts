import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";

import { WjInputModule } from "wijmo/wijmo.angular2.input";

import { ComponentsModule } from "../../core/components/primitive/components.module";
import { CepGridCrudComponent } from "./estados/cidades/ceps/cep.grid.crud.component";
import { CidadeGridCrudComponent } from "./estados/cidades/cidade.grid.crud.component";
import { EstadoGridCrudComponent } from "./estados/estado.grid.crud.component";
import { PaisGridCrudComponent } from "./paises/pais.grid.crud.component";
import { RegiaoGridCrudComponent } from "./regioes/regiao.grid.crud.component";

const routes: Routes = [
  // Pais
  { path: "paises", component: PaisGridCrudComponent },
  // Estado
  { path: "estados", component: EstadoGridCrudComponent },
  // Cidade
  { path: "estados/:idEstado/cidades", component: CidadeGridCrudComponent },
  // Cep
  { path: "estados/:idEstado/cidades/:idCidade/ceps", component: CepGridCrudComponent },

    // Regiao
  { path: "regioes", component: RegiaoGridCrudComponent },
];

@NgModule({
  declarations: [PaisGridCrudComponent, EstadoGridCrudComponent, CidadeGridCrudComponent,
    CepGridCrudComponent, RegiaoGridCrudComponent],
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, ComponentsModule, ReactiveFormsModule, WjInputModule],
})
export class EnderecosModule { }
