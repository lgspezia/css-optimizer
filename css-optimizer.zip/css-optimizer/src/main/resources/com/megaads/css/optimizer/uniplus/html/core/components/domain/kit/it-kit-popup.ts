import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";
import { WjPopup } from "wijmo/wijmo.angular2.input";

import { ColumnDefinition } from "../../../crud/column-definition";
import { AbstractPojo } from "../../../crud/pojo";
import { HttpService } from "../../../services/http.service";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItTableComponent } from "../../primitive/it-table.component";

/**
 * TODO OSIEL FIXME QUANDO IMPLEMENTAR EDIÇÃO DE KIT CRIAR PARÂMETRO PARA EDITAR, POIS EM AJUSTE DE ESTOQUE ISSO NÃO PODE SER FEITO.
 *
 * Popup de exibição de produtos de kit.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-kit",
  templateUrl: "it-kit-popup.html",
})
export class ItKitPopupComponent extends BaseFormComponent implements OnInit {

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formNumeroSerie$: BehaviorSubject<FormGroup>;
  public title$: Observable<string>;

  private loadKit$: Subject<Kit>;

  @ViewChild(ItTableComponent) private itTableKit: ItTableComponent<Kit>;
  @ViewChild("popup") private popup: WjPopup;

  constructor(private httpService: HttpService) {
    super();
    this.loadKit$ = new Subject();
  }

  public ngOnInit(): void {

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("idProduto", "idProduto", DataType.Number, 0, null, false),
      new ColumnDefinition("idProdutoKit", "idProdutoKit", DataType.Number, 0, null, false),
      new ColumnDefinition("casasDecimaisUN", "casasDecimaisUN", DataType.Number, 0, null, false),
      new ColumnDefinition("codigoProduto", "Código", DataType.String, 120),
      new ColumnDefinition("descricaoProduto", "Descrição", DataType.String, "*"),
      new ColumnDefinition("unidadeProduto", "UN", DataType.String, 50),
      new ColumnDefinition("precoProduto", "Preço", DataType.Number, 100, "n2"),
      new ColumnDefinition("quantidade", "Quantidade", DataType.Number, 100, null, true, null, "casasDecimaisUN"),
      new ColumnDefinition("descontoProduto", "Desconto", DataType.Number, 100, "n2"),
      new ColumnDefinition("totalProduto", "Total", DataType.Number, 100, "n2"),
    ]);

    /**
     * Busca os valores existente em estoque no servidor.
     */
    this.addSubscription(this.loadKit$
      .switchMap((kitPai: Kit) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", kitPai.idprodutokit.toString());

        return this.httpService.get(`kits/filtrar-por-produto`, {search: params})
          .map((kitsFilhos: Kit[]) => ({qtd: kitPai.quantidade, kitsFilhos}));
      })
      .subscribe((obj: { qtd: number, kitsFilhos: Kit[] }) => {
        obj.kitsFilhos.forEach((kit) => {
          kit.quantidade = kit.quantidade * obj.qtd;
          kit.totalProduto = kit.quantidade * kit.precoProduto;
          kit.descontoProduto = 0;
        });

        this.itTableKit.updateItemsSource(obj.kitsFilhos);
        this.itTableKit.clearSelection();
        this.show();
      }));

    this.title$ = this.loadKit$.map((kitPai: Kit) => `${kitPai.codigoProduto} - ${kitPai.descricaoProduto}`);
  }

  /**
   * Seta o kit pai para iniciar o processo de busca.
   * @param {Kit} kitPai
   */
  public set kitPai(kitPai: Kit) {
    this.itTableKit.updateItemsSource([]);
    this.loadKit$.next(kitPai);
  }

  /**
   * Exibe a dialog. Quando fechada limpa o form.
   */
  private show(): void {
    this.popup.show(true);
  }
}

/**
 * TODO OSIEL FIXME MIGRAR CLASSE PARA CRUD DE KIT
 * Pojo dummy para auxilio.
 */
export class Kit extends AbstractPojo {
  public componente = "";
  public variacao = 0;
  public quantidade = 0;
  public idproduto = 0;
  public idprodutokit = 0;

  public codigoProduto = "";
  public descricaoProduto = "";
  public unidadeProduto = "";
  public precoProduto = 0;
  public descontoProduto = 0;
  public totalProduto = 0;
  public codigoProdutoKit = "";
  public casasDecimaisUN = 0;
}

