import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { AjusteEstoqueItem } from "./ajuste-estoque-item/ajuste-estoque-item";

/**
 * @author Osiel.
 */
export class AjusteEstoque extends AbstractPojo {

  public idFilial = 0;
  public idUsuario = 0;
  public idUsuarioEstorno = 0;
  public idLocalEstoqueOrigem = 0;
  public idLocalEstoqueDestino = 0;
  public idMotivo = 0;
  public idCentroCusto = 0;
  public idNotaFiscalControlePerda = 0;
  public ajusteFinalizado = false;
  public codigo = "";
  public data: Date = new Date();
  public dataEstorno: Date = new Date();
  public observacao = "";
  public status: StatusAjusteEstoque = StatusAjusteEstoque.PENDENTE[EnumUtils.id];
  public tipoMovimento: TipoAjusteEstoque = TipoAjusteEstoque.ENTRADA[EnumUtils.id];

  /*
   * ----------------- Transients ----------------
   */
  public agruparProdutos = false;
  public leitor = false;
  public nomeUsuario = "";
}

/**
 * Objeto facilitador para envio de dados de estoque.
 */
export class AjusteEstoqueWrapper {
  public ajusteEstoque: AjusteEstoque = new AjusteEstoque();
  public ajusteEstoqueItem: AjusteEstoqueItem = new AjusteEstoqueItem();
}

export enum TipoAjusteEstoque {
  LEVANTAMENTO = <any> {[EnumUtils.id]: "LEVANTAMENTO", [EnumUtils.display]: "Levantamento de estoque"},
  ENTRADA = <any> {[EnumUtils.id]: "ENTRADA", [EnumUtils.display]: "Entrada"},
  SAIDA = <any> {[EnumUtils.id]: "SAIDA", [EnumUtils.display]: "Saída"},
  TRANSFERENCIA_LOCAL_ESTOQUE = <any> {
    [EnumUtils.id]: "TRANSFERENCIA_LOCAL_ESTOQUE",
    [EnumUtils.display]: "Transferência de local de estoque",
  },
}

export enum StatusAjusteEstoque {
  FINALIZADO = <any> {[EnumUtils.id]: "FINALIZADO", [EnumUtils.display]: "Finalizado"},
  ESTORNADO = <any> {[EnumUtils.id]: "ESTORNADO", [EnumUtils.display]: "Estornado"},
  PENDENTE = <any> {[EnumUtils.id]: "PENDENTE", [EnumUtils.display]: "Pendente"},
}
