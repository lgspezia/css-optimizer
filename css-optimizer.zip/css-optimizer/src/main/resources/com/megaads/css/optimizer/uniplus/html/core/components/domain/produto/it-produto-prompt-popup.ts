import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";

import { DataType } from "wijmo/wijmo";

import { Subject } from "rxjs/Subject";

import { Produto } from "../../../../modules/produtos/produto";
import { ColumnDefinition } from "../../../crud/column-definition";
import { HttpService } from "../../../services/http.service";
import { ArrayUtil } from "../../../utils/array.util";
import { NumberUtil } from "../../../utils/number.util";
import { StringUtil } from "../../../utils/string.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItTableComponent } from "../../primitive/it-table.component";

/**
 * Prompt para busca de produtos através de parâmetros como Hierarquia e Família.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-produto-prompt-popup",
  templateUrl: "it-produto-prompt-popup.html",
})
export class ItProdutoPromptPopupComponent extends BaseFormComponent implements OnInit {
  @Input() public promptProduto: string;
  @Input() public produtosPesquisados$: BehaviorSubject<{ query?: string, produtos?: Produto[] }>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public form$: BehaviorSubject<FormGroup>;

  @ViewChild(ItTableComponent) private itTable: ItTableComponent<Produto>;
  private pesquisar$: Subject<{ value: string, idHierarquia: number, idFamilia: number }>;

  constructor(private formBuilder: FormBuilder, private httpService: HttpService) {
    super();
    this.columns$ = new BehaviorSubject(undefined);
    this.pesquisar$ = new Subject();
    this.produtosPesquisados$ = new BehaviorSubject({});
  }

  public ngOnInit(): void {
    /**
     * Inicializa um form dummy apenas para trabalhar com os componentes.
     * @type {BehaviorSubject<FormGroup>}
     */
    this.form$ = new BehaviorSubject(this.formBuilder
      .group({
        produto: "",
        idHierarquia: 0,
        idFamilia: 0,
      }));

    /**
     * Monta as colunas do prompt.
     */
    this.columns$.next([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idUnidadeMedida", "idUnidadeMedida", DataType.Number, 0, null, false),
      new ColumnDefinition("casasdecimais", "Casas decimais", DataType.String, 0, null, false),
      new ColumnDefinition("tipo", "Tipo", DataType.String, 0, null, false),
      new ColumnDefinition("codigo", "Código", DataType.Number, 100),
      new ColumnDefinition("referencia", "Referência", DataType.String, 100),
      new ColumnDefinition("ean", "Código de barras", DataType.String, 130),
      new ColumnDefinition("nome", "Nome", DataType.String, 300),
      new ColumnDefinition("unidademedida", "UN", DataType.String, 30),
      new ColumnDefinition("preco", "Preço", DataType.Number, 130, null, true, null, "casasdecimais"),
      new ColumnDefinition("observacao", "Observação", DataType.String, "*"),
    ]);

    /**
     * Carrega os dados do servidor utilizando os parâmetros definidos para o observable de parâmetros.
     */
    this.addSubscription(this.produtosPesquisados$
      .combineLatest(this.getControl("produto", this.form$),
        (pesquisa: { query: string, produtos: Produto[] }, control: AbstractControl) => ({pesquisa, control}))
      .subscribe((wrapper: { pesquisa: { query: string, produtos: Produto[] }, control: AbstractControl }) => {

        if (!StringUtil.stringNullOrEmpty(wrapper.pesquisa.query)) {
          wrapper.control.setValue(wrapper.pesquisa.query);
        }

        this.itTable.updateItemsSource(wrapper.pesquisa.produtos);
        this.itTable.clearSelection();
      }, (error) => this.handleError(error)));


    /**
     * Observa a alteração de parâmetros para a filtragem e executa a chamada para o Servidor.
     */
    this.addSubscription(this.pesquisar$
      .switchMap((wrapper: { value: string, idHierarquia: number, idFamilia: number }) => {

        const params: URLSearchParams = new URLSearchParams();
        params.set("prompt", this.promptProduto);
        params.set("query", wrapper.value);
        if (!NumberUtil.numberNullOrZero(wrapper.idHierarquia)) {
          params.set("idHierarquia", wrapper.idHierarquia.toString());
        }
        if (!NumberUtil.numberNullOrZero(wrapper.idFamilia)) {
          params.set("idFamilia", wrapper.idFamilia.toString());
        }
        return this.httpService.get(`produtos/filtro-prompt`, {search: params});
      })
      .subscribe((result: any) => {
        let produtos: Produto[] = [];
        if (ArrayUtil.isArray(result) && !ArrayUtil.nullOrEmpty(result)) {
          produtos = result;
        } else {
          produtos.push(result);
        }
        this.produtosPesquisados$.next({query: null, produtos: produtos});
      }));

    this.addObsProduto();
    this.addObsHierarquia();
    this.addObsFamilia();
  }

  /**
   * Limpa os parâmetros de consulta de hieraquia e familia.
   */
  public clearParams(): void {
    this.addSubscription(this.getControl("produto", this.form$)
      .combineLatest(this.getControl("idHierarquia", this.form$), this.getControl("idFamilia", this.form$),
        (produto: AbstractControl, hierarquia: AbstractControl, familia: AbstractControl) =>
          ({produto, hierarquia, familia}))
      .subscribe((wrapper: { produto: AbstractControl, hierarquia: AbstractControl, familia: AbstractControl }) => {
        wrapper.produto.setValue("");
        wrapper.hierarquia.setValue(0);
        wrapper.familia.setValue(0);
      }));
  }

  /**
   * Retorna o item selecionado.
   * @return {Produto}
   */
  public get selectedItem(): Produto {
    return this.itTable.selectedItem;
  }

  /**
   * Monitora o texto de pesquisa digitado para efetuar a busca. Pra isso combina com os outros componentes para passar
   * ambos os valores.
   */
  private addObsProduto(): void {
    this.addSubscription(this.getValueChanges("produto", this.form$)
    /**
     * Somente será pesquisado valores com no mínimo 3 caracteres.
     */
      .filter((value: string) => !StringUtil.stringNullOrEmpty(value) && value.length >= 3)
      .debounceTime(250)
      .distinctUntilChanged()
      .combineLatest(this.getControl("idHierarquia", this.form$), this.getControl("idFamilia", this.form$),
        (value: string, hierarquia: AbstractControl, familia: AbstractControl) =>
          ({value, idHierarquia: hierarquia.value, idFamilia: familia.value}))
      .subscribe((wrapper: { value: string, idHierarquia: number, idFamilia: number }) => this.pesquisar$.next(wrapper)));
  }

  /**
   * Monitora a alteração de grupo de produto para a filtragem correta dos produtos.
   * O filter por zero é realizado para prever quando é efetuado o clear no componente.
   */
  private addObsHierarquia(): void {
    this.addSubscription(this.getValueChanges("idHierarquia", this.form$)
      .filter((idHierarquia: number) => idHierarquia !== 0)
      .combineLatest(this.getControl("produto", this.form$), this.getControl("idFamilia", this.form$),
        (idHierarquia: number, produto: AbstractControl, familia: AbstractControl) =>
          ({value: produto.value, idHierarquia, idFamilia: familia.value}))
      .subscribe((wrapper: { value: string, idHierarquia: number, idFamilia: number }) => this.pesquisar$.next(wrapper)));
  }

  /**
   * Monitora a alteração de família para a filtragem correta dos produtos.
   * O filter por zero é realizado para prever quando é efetuado o clear no componente.
   */
  private addObsFamilia(): void {
    this.addSubscription(this.getValueChanges("idFamilia", this.form$)
      .filter((idFamilia: number) => idFamilia !== 0)
      .combineLatest(this.getControl("produto", this.form$), this.getControl("idHierarquia", this.form$),
        (idFamilia: number, produto: AbstractControl, hierarquia: AbstractControl) =>
          ({value: produto.value, idHierarquia: hierarquia.value, idFamilia}))
      .subscribe((wrapper: { value: string, idHierarquia: number, idFamilia: number }) => this.pesquisar$.next(wrapper)));
  }
}
