import { Component, OnInit } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Subject } from "rxjs/Subject";

import { FormComponent } from "../../../../core/crud/form-component";
import { AjusteEstoqueItem } from "../ajuste-estoque-item/ajuste-estoque-item";
import { StringUtil } from "../../../../core/utils/string.util";
import { TipoKit } from "../../../produtos/produto";

/**
 * Totais de ajuste.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-ajuste-estoque-total",
  templateUrl: "ajuste-estoque-total.form.component.html",
})
export class ItAjusteEstoqueTotalFormComponent extends FormComponent implements OnInit {

  public formTotal$: BehaviorSubject<FormGroup>;

  private itens$: Subject<AjusteEstoqueItem[]>;

  constructor(private formBuilder: FormBuilder) {
    super();
    this.itens$ = new Subject();
  }

  public ngOnInit(): void {
    this.formTotal$ = new BehaviorSubject(this.formBuilder.group(new TotalWrapper()));

    this.addSubscription(this.getControl("totalProduto", this.formTotal$)
      .merge(this.getControl("quantidadeTotal", this.formTotal$), this.getControl("quantidadeVariacao", this.formTotal$),
        this.getControl("quantidadeKit", this.formTotal$))
      .subscribe((control: AbstractControl) => control.disable()));

    this.addSubscription(this.itens$
      .withLatestFrom(this.getControl("totalProduto", this.formTotal$), this.getControl("quantidadeTotal", this.formTotal$),
        this.getControl("quantidadeVariacao", this.formTotal$), this.getControl("quantidadeKit", this.formTotal$),
        (itens: AjusteEstoqueItem[], total: AbstractControl, qtdTotal: AbstractControl, qtdVar: AbstractControl, qtdKit: AbstractControl) =>
          ({itens, total, qtdTotal, qtdVar, qtdKit}))
      .subscribe((obj: {
        itens: AjusteEstoqueItem[], total: AbstractControl, qtdTotal: AbstractControl, qtdVar: AbstractControl, qtdKit: AbstractControl,
      }) => {
        const idsProdutos: number[] = [];
        let quantidadeTotal = 0;
        let quantidadeVariacao = 0;
        let quantidadeKit = 0;

        obj.itens.forEach(item => {

          if (idsProdutos.indexOf(item.idProduto) === -1) {
            idsProdutos.push(item.idProduto);
          }
          quantidadeTotal = quantidadeTotal + item.quantidade;

          if (!StringUtil.stringNullOrEmpty(item.variacoes)) {
            quantidadeVariacao = quantidadeVariacao + item.quantidade;
          }

          if (item.tipoKit === TipoKit.KIT_PAI[`value`]) {
            quantidadeKit = quantidadeKit + item.quantidade;
          }
        });

        obj.total.setValue(idsProdutos.length);
        obj.qtdTotal.setValue(quantidadeTotal);
        obj.qtdVar.setValue(quantidadeVariacao);
        obj.qtdKit.setValue(quantidadeKit);
      }));
  }

  /**
   * Seta os itens
   * @param {AjusteEstoqueItem[]} itens
   */
  public set itensAjusteEstoque(itens: AjusteEstoqueItem[]) {
    this.itens$.next(itens);
  }
}

class TotalWrapper {
  public totalProduto = 0;
  public quantidadeTotal = 0;
  public quantidadeVariacao = 0;
  public quantidadeKit = 0;
}
