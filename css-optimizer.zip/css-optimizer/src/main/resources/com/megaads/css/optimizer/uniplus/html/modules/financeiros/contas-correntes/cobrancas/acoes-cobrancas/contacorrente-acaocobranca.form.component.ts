import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { enumConverter, EnumUtils } from "../../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../../core/models/dataitem";
import { ServerError } from "../../../../../core/models/server-error";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { IConfiguracaoBanco } from "../../contacorrente";
import { AcaoRetornoCobrancaEscritural, ContaCorrenteAcaoCobranca } from "./contacorrente-acaocobranca";

/**
 * Ações de cobrança.
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-contacorrente-acaocobranca",
  templateUrl: "contacorrente-acaocobranca.form.component.html",
})
export class ItContaCorrenteAcaoCobrancaFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;
  @Input() public configuracaoBanco$: BehaviorSubject<IConfiguracaoBanco>;
  @Input() public configuracaoCarteira$: BehaviorSubject<IConfiguracaoBanco>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formAcaoCobranca$: BehaviorSubject<FormGroup>;

  public acoes$: Observable<IDataItem[]>;
  public acoesRetorno$: Observable<IDataItem[]>;
  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<ContaCorrenteAcaoCobranca>;

  constructor(private formBuider: FormBuilder) {
    super();
    this.acoes$ = Observable.of([]);
    this.acoesRetorno$ = EnumUtils.getValues(AcaoRetornoCobrancaEscritural);
  }

  public ngOnInit(): void {
    this.formAcaoCobranca$ = new BehaviorSubject(this.formBuider.group(new ContaCorrenteAcaoCobranca()));

    this.addSubscription(this.getControl("codigoAcaoCobranca", this.formAcaoCobranca$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(2)])));

    this.addSubscription(this.getControl("descricaoAcaoCobranca", this.formAcaoCobranca$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required])));

    this.addSubscription(this.getControl("instrucaoCodificada", this.formAcaoCobranca$)
      .subscribe((c: AbstractControl) => {
        c.setValidators([Validators.maxLength(2)]);
        c.setAsyncValidators([acaoCobrancaAsyncValidate(this.itFormTable)]);
      }));


    /**
     * Quando o status dos componentes forem alterados, atualiza a validação.
     */
    this.addSubscription(this.getStatusChanges("codigoAcaoCobranca", this.formAcaoCobranca$)
      .merge(this.getStatusChanges("descricaoAcaoCobranca", this.formAcaoCobranca$))
      .combineLatest(this.getControl("instrucaoCodificada", this.formAcaoCobranca$),
        (status: any, instrucao: AbstractControl) => instrucao)
      .subscribe((instrucao: AbstractControl) => instrucao.updateValueAndValidity()));

    /**
     * Adiciona as ações de acordo com o banco.
     */
    this.addSubscription(this.configuracaoBanco$
      .filter((configuracao: IConfiguracaoBanco) => configuracao !== undefined)
      .combineLatest(this.getControl("descricaoAcaoCobranca", this.formAcaoCobranca$),
        (config: IConfiguracaoBanco, acao: AbstractControl) => ({config, acao}))
      .subscribe((wrapper: { config: IConfiguracaoBanco, acao: AbstractControl }) => this.loadActions(wrapper.config, wrapper.acao)));

    /**
     * Atualiza as informações de acordo com a carteira.
     */
    this.addSubscription(this.configuracaoCarteira$
      .filter((configuracao: IConfiguracaoBanco) => configuracao !== undefined)
      .subscribe((configuracao: IConfiguracaoBanco) => this.loadActions(configuracao)));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idContaCorrente", "idContaCorrente", DataType.Number, 0, null, false),
      new ColumnDefinition("codigoAcaoCobranca", "Código", DataType.String, "*"),
      new ColumnDefinition("descricaoAcaoCobranca", "Ação", DataType.String, "*"),
      new ColumnDefinition("instrucaoCodificada", "Instrução", DataType.String, "*"),
      new ColumnDefinition(
        "acaoProcessamentoRetorno",
        "Ação no retorno",
        DataType.String,
        "*",
        null,
        true,
        AcaoRetornoCobrancaEscritural,
        null,
        enumConverter,
      ),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idContaCorrente", id.toString());
        return {endpoint: "acoes-cobranca", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((acaoCobranca: ContaCorrenteAcaoCobranca) => {
          if (acaoCobranca.id) {
            acaoCobranca.id = NumberUtil.parseFloat(acaoCobranca.id.toString());
          }
          if (acaoCobranca.idContaCorrente) {
            acaoCobranca.idContaCorrente = NumberUtil.parseFloat(acaoCobranca.idContaCorrente.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((acaoCobranca: ContaCorrenteAcaoCobranca) =>
        acaoCobrancaAsyncValidator$(
          this.itFormTable,
          acaoCobranca.instrucaoCodificada,
          acaoCobranca.codigoAcaoCobranca,
          acaoCobranca.descricaoAcaoCobranca,
          acaoCobranca.id,
        )
          .combineLatest(this.afterGet$, (validate: { acaoValid: string }, idContaCorrente: number) =>
            ({acaoCobranca, validate, idContaCorrente})))
      .subscribe((obj: { acaoCobranca: ContaCorrenteAcaoCobranca, validate: { acaoValid: string }, idContaCorrente: number }) => {

        if (obj.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validate.acaoValid));
          return;
        }

        obj.acaoCobranca.idContaCorrente = obj.idContaCorrente;

        this.itFormTable.submit$.next(obj.acaoCobranca);
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new ContaCorrenteAcaoCobranca())));
  }

  /**
   * Carrega as opções de ações.
   * @param configuracao: IConfiguracaoBanco
   * @param acao: AbstractControl Somente quando carregar do banco.
   */
  private loadActions(configuracao: IConfiguracaoBanco, acao?: AbstractControl): void {
    const acoes: IDataItem[] = [];

    if (configuracao.acoesCobranca) {
      configuracao.acoesCobranca.forEach((a) => acoes.push({id: a.descricao, display: a.descricao}));
      if (acao) {
        acao.setValue(acoes[0].id);
      }
    }

    this.acoes$ = Observable.of(acoes);
  }
}

/**
 * Funçao de validaçao ação
 *
 * @param itFormTable: tFormTableComponent<ContaCorrenteAcaoCobranca>
 * @return {(control:FormControl)=>{filialValidate: string}}
 */
function acaoCobrancaAsyncValidate(itFormTable: ItFormTableComponent<ContaCorrenteAcaoCobranca>) {
  return (control: FormControl) => {
    return acaoCobrancaAsyncValidator$(itFormTable,
      control.value,
      control.parent.get("codigoAcaoCobranca").value,
      control.parent.get("descricaoAcaoCobranca").value,
      control.parent.get("id").value,
    );
  };
}

/**
 * Valida a existência da filial na table.
 *
 * @param instrucao: string
 * @param codigoAcao: string
 * @param descAcao: string
 * @param id: number
 * @param itTable: ItFormTableComponent<FormacaoPrecoProduto>
 * @return {{filialValidate: string}}
 */
function acaoCobrancaAsyncValidator$(itTable: ItFormTableComponent<ContaCorrenteAcaoCobranca>,
                                     instrucao: string, codigoAcao: string,
                                     descAcao: string, id: number): Observable<{ acaoValid: string }> {

  return itTable
    .afterLoadData$
    .map(() => {
      if (StringUtil.stringNullOrEmpty(codigoAcao)) {
        return {acaoValid: "WWW73 - Código não informado."};
      }
      if (StringUtil.stringNullOrEmpty(descAcao)) {
        return {acaoValid: "WWW74 - Ação não informada."};
      }

      return !itTable.sourceCollection
        .some((ccc: ContaCorrenteAcaoCobranca) => ccc.codigoAcaoCobranca === codigoAcao && ccc.descricaoAcaoCobranca === descAcao &&
        (StringUtil.stringNullOrEmpty(instrucao) || ccc.instrucaoCodificada === instrucao) &&
        (NumberUtil.numberNullOrZero(id) || NumberUtil.parseFloat(id.toString()) !== ccc.id)) ? null : {
        acaoValid: "FIN250 - Código " + codigoAcao + ", ação " +
        descAcao + (StringUtil.stringNullOrEmpty(instrucao) ? "" : " e instrução " + instrucao) + ", já foram adicionados."
      };

    }).first();
}
