import { Component, Input, OnInit } from "@angular/core";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { NumberUtil } from "../../utils/number.util";
import { BaseFormComponent } from "../primitive/baseform.component";

/**
 * Componente de seleção de cidade por Estado.
 *
 * @author Osiél.
 */
@Component({
  selector: "it-cidade-estado",
  templateUrl: "it-cidadeestado.component.html",
})
export class ItCidadeEstadoComponent extends BaseFormComponent implements OnInit {
  @Input() public controlEstado: string;
  @Input() public controlCidade: string;

  public paramsCidade$: Observable<URLSearchParams>;

  constructor() {
    super();
    this.controlEstado = "idEstado";
    this.controlCidade = "idCidade";
  }

  public ngOnInit(): void {
    this.paramsCidade$ = this.getValueChanges(this.controlEstado)
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEstado", id.toString());
        return params;
      });
  }

}
