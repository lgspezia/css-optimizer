import { Component, ViewChild } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItBandeiraAutocompleteComponent } from "../../../../core/components/domain/it-bandeira-autocomplete.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { IEditDetails } from "../../../../core/crud/edit-details";
import { FilterHelper, IFilter } from "../../../../core/crud/filter";
import { GridCrud } from "../../../../core/crud/grid.crud";
import { enumConverter, EnumUtils } from "../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../core/models/dataitem";
import { BandeiraCartao } from "../../bandeiras-cartoes/bandeira-cartao";
import { TipoCartaoManual } from "../administradora-cartao";
import { BandeiraRelacionada } from "./bandeira-relacionada";

/**
 * @author Luan  on 28/07/2017.
 */
@Component({
  templateUrl: "bandeira-relacionada.grid.crud.component.html",
})
export class BandeiraRelacionadaGridCrudComponent extends GridCrud<BandeiraRelacionada> {

  public filterAdm$: Observable<IFilter[]>;
  public tipoCartao$: Observable<IDataItem[]>;
  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public idAdministradora: string;

  @ViewChild(ItBandeiraAutocompleteComponent) private itBandeira: ItBandeiraAutocompleteComponent;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new BandeiraRelacionada(), "bandeiras-relacionadas");

    this.idAdministradora = this.getParam("idAdministradora");

    this.filterAdm$ = Observable.from([[FilterHelper.byId("idAdministradora", this.idAdministradora)]]);
    this.tipoCartao$ = EnumUtils.getValues(TipoCartaoManual);

    /**
     * Converte a enum para aparecer a descrição na grid
     * @type {BehaviorSubject<[ColumnDefinition]>}
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("manual", "Tipo cartão", DataType.String, "*", null, true, TipoCartaoManual, null, enumConverter),
    ]);

    /**
     * Seta o nome da bandeira para atualizar na grid
     */
    this.addSubscription(this.beforeSubmit$
      .subscribe((detail: IEditDetails<BandeiraRelacionada>) => {
        const bandeira: BandeiraCartao = this.itBandeira.selectedItem;
        if (bandeira) {
          detail.pojo.nomeBandeira = bandeira.nome;
        }
      }));
  }
}
