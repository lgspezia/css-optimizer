import { Component } from "@angular/core";
import { FormBuilder } from "@angular/forms";

import { Observable } from "rxjs/Observable";

import { ActivatedRoute } from "@angular/router";
import { ICustomizableColumn } from "../../../../core/crud/customizable-column";
import { FilterHelper, IFilter } from "../../../../core/crud/filter";
import { GridCrud, Modo } from "../../../../core/crud/grid.crud";
import { AdministradoraCartaoTaxa } from "./administradora-cartao-taxa";

/**
 * @author Luan  on 27/07/2017.
 */
@Component({
  templateUrl: "administradora-cartao-taxa.grid.crud.component.html",
})
export class AdministradoraCartaoTaxaGridCrudComponent extends GridCrud<AdministradoraCartaoTaxa> {

  public filterAdm$: Observable<IFilter[]>;
  public enableButton$: Observable<boolean>;
  public columns$: Observable<ICustomizableColumn[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new AdministradoraCartaoTaxa(), "administradoras-cartao-taxas");

    const idAdministradora = this.getParam("idAdministradora");

    this.filterAdm$ = Observable.from([[FilterHelper.byId("idAdministradora", idAdministradora)]]);

    this.enableButton$ = Observable.of(false);

    this.columns$ = Observable.of([
      {binding: "taxaCredito", format: "n2"},
      {binding: "taxaDebito", format: "n2"},
      ]);

    this.disableWhenIsNotCreateMode("numeroParcelas");
  }
}
