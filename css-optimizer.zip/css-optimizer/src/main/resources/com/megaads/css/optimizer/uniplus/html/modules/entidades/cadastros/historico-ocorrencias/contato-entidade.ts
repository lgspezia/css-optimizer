import { AbstractPojo } from "../../../../core/crud/pojo";

/**
 * Contato de entidade
 * Created by Osiel on 26/05/17.
 */
export class ContatoEntidade extends AbstractPojo {

    public idEntidade = 0;
    public idTipoHistoricoContato = 0;
    public idUsuario = 0;

    public dataHora: Date = new Date();
    public descricao = "";
    public tipoHistorico = "";
    public nomeUsuario = "";
}
