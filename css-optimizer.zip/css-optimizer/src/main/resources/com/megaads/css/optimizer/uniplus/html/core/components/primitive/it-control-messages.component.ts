import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";
import { StringUtil } from "../../utils/string.util";

@Component({
  selector: "it-control-messages",
  template: `
    <div class="field-error" *ngIf="errorMessage !== null">{{errorMessage}}</div>`,
})
export class ItControlMessagesComponent {
  @Input() protected control: FormControl;

  /**
   * Exibe o erro do componente quando clicado e inválido.
   * @returns {any}
   */
  public get errorMessage(): string {
    if (this.control && this.control.touched) {
      if (this.control.hasError("required")) {
        return "O campo deve ser preenchido";
      } else if (this.control.hasError("identificationRequired")) {
        return "O campo deve ser preenchido";
      } else if (this.control.hasError("minlength")) {
        return "Por favor preencha a quantidade mínima de caracteres.";
      } else if (this.control.hasError("maxlength")) {
        return "Quantidade máxima de caracteres atingida.";
      } else if (this.control.hasError("pattern")) {
        return "Caracteres inválidos.";
      }

      for (const propertyName in this.control.errors) {
        if (this.control.errors.hasOwnProperty(propertyName)) {
          return this.control.errors[propertyName];
        }
      }
    }
    return null;
  }

  /**
   * Retorna true quando houverem erros declarados no componente.
   * @returns {boolean}
   */
  public get errorFieldFilling(): boolean {
    return !StringUtil.stringNullOrEmpty(this.errorMessage);
  }
}
