import { AbstractPojo } from "../../../../../core/crud/pojo";

export class Cep extends AbstractPojo {
    public cep = "";
    public endereco = "";
    public bairro = "";
    public nomeCidade = "";
    public idCidade = 0;
    public idMunicipio = 0;
    public idEstado = 0;
    public estado = 0;
    public realizaEntrega = false;
    public codigoTaxaEntrega = 0;
}
