import { Component, Input } from "@angular/core";
import { FormControl } from "@angular/forms";

import { BaseFormComponent } from "./baseform.component";

@Component({
  selector: "it-mandatory-fields",
  template: `
    <label class="field-required"
           *ngIf="(controller?.errors?.required || controller?.errors?.identificationRequired || controller?.errors?.validateDifferentOf)">
      (Obrigatório)</label>
  `,
})
export class ItMandatoryFieldComponent extends BaseFormComponent {
  @Input() public controller: FormControl;
}
