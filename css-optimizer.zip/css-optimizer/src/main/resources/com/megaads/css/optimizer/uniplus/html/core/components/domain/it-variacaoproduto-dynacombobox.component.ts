import { Component, OnInit } from "@angular/core";

import { HttpService } from "../../services/http.service";

import { VariacaoDistribuidaWrapper } from "../../wrappers/VariacaoDistribuidaWrapper";
import { ItDynacomboboxParamsComponent } from "../primitive/it-dynacomboboxparams.component";

/**
 * Componente de variações de produto.
 * É necessário passar os parâmetros para a busca de dados. Ex:
 * { const params: URLSearchParams = new URLSearchParams();}
 * { params.set("idProduto", id.toString()); }
 * @author Osiel
 */
@Component({
  selector: "it-variacaoproduto-dynacombobox",
  templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItVariacaoProdutoDynacomboboxComponent extends ItDynacomboboxParamsComponent<VariacaoDistribuidaWrapper> implements OnInit {

  constructor(httpService: HttpService) {
    super(httpService);
    this.display = "descricao";
  }

  // public ngOnInit() {
  //   this.addSubscription(this.urlParams$
  //     .switchMap((url: URLSearchParams) => this.httpService.get(this.url, {search: url}))
  //     .subscribe((resp) => this.combobox.itemsSource = resp, (error: ServerError) => this.handleError(error)));
  // }
}
