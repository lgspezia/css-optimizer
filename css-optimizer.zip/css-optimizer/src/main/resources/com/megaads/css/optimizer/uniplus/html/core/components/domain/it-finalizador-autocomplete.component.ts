import { Component, OnInit } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { EntidadeFinalizador } from "../../../modules/entidades/cadastros/clientes/meios-pagamentos/entidade-finalizador";
import { Finalizador } from "../../../modules/cadastros/orfans/finalizador.model";

@Component({
  selector: "it-finalizador-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItFinalizadorAutocompleteComponent extends ItAutocompleteComponent<Finalizador> implements OnInit {

  constructor(httpService: HttpService) {
    super(httpService);

    this.display = "nome";
    this.label = "Meio de pagamento";
    this.url = "finalizadores";
  }

}
