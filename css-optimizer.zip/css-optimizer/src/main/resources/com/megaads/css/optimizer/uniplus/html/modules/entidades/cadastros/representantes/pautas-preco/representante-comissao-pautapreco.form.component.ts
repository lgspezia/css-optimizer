import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../../core/crud/form-component";
import { ContextoService } from "../../../../../core/services/contexto.service";

/**
 * Classe responsável pela aba pauta de entidade.
 *
 * @author Osiel
 */
@Component({
  selector: "it-representante-comissaopautapreco",
  templateUrl: "representante-comissao-pautapreco.form.component.html",
})
export class ItRepresentanteComissaoPautaPrecoFormComponent extends FormComponent implements OnInit {

  public pauta1$: Observable<boolean>;
  public pauta2$: Observable<boolean>;
  public pauta3$: Observable<boolean>;
  public pauta4$: Observable<boolean>;

  constructor(private contexto: ContextoService) {
    super();
  }

  public ngOnInit(): void {
    this.pauta1$ = this.contexto.getPropriedade$(6);
    this.pauta2$ = this.contexto.getPropriedade$(9);
    this.pauta3$ = this.contexto.getPropriedade$(12);
    this.pauta4$ = this.contexto.getPropriedade$(15);
  }
}
