import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Regiao } from "../../../modules/enderecos/regioes/regiao";

@Component({
    selector: "it-regiao-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItRegiaoAutocompleteComponent extends ItAutocompleteComponent<Regiao> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "regioes";
        this.display = "nome";
        this.label = "Região";
    }
}
