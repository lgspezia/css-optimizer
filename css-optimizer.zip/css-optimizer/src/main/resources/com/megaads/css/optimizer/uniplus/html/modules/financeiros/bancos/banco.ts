import { AbstractPojo } from "../../../core/crud/pojo";
/**
 * Created by luan on 24/05/17.
 */

export class Banco extends AbstractPojo {
    public nome = "";
}
