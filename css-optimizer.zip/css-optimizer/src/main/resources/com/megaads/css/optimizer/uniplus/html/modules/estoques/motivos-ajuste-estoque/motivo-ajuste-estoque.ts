import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";

/**
 * @author Osiel.
 */
export class MotivoAjusteEstoque extends AbstractPojo {

  public codigo = "";
  public descricao = "";
  public operacao: OperacaoMotivoAjusteEstoque = OperacaoMotivoAjusteEstoque.ENTRADA[EnumUtils.id];
  public movimentacao: MovimentacaoMotivoAjusteEstoque = MovimentacaoMotivoAjusteEstoque.SOMENTE_QUANTIDADE[EnumUtils.id];
  public valorizacao: ValorizacaoMotivoAjusteEstoque = ValorizacaoMotivoAjusteEstoque.NENHUM[EnumUtils.id];
  public baseCalculoCustoMedio = false;
  public centroCustoObrigatorio = false;
  public idPlanoContas = 0;
  public controlePerda = false;
  public idCfopControlePerda = 0;

}

export enum OperacaoMotivoAjusteEstoque {
  ENTRADA = <any> {[EnumUtils.id]: "ENTRADA", [EnumUtils.display]: "Entrada"},
  SAIDA = <any> {[EnumUtils.id]: "SAIDA", [EnumUtils.display]: "Saída"},
  TRANSFERENCIA = <any> {[EnumUtils.id]: "TRANSFERENCIA", [EnumUtils.display]: "Transferência"}
}

export enum MovimentacaoMotivoAjusteEstoque {
  SOMENTE_QUANTIDADE = <any> {[EnumUtils.id]: "SOMENTE_QUANTIDADE", [EnumUtils.display]: "Somente quantidade"},
  SOMENTE_VALOR = <any> {[EnumUtils.id]: "SOMENTE_VALOR", [EnumUtils.display]: "Somente valor"},
  QUANTIDADE_E_VALOR = <any> {[EnumUtils.id]: "QUANTIDADE_E_VALOR", [EnumUtils.display]: "Quantidade e valor"},
}

export enum ValorizacaoMotivoAjusteEstoque {
  NENHUM = <any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Nenhum"},
  PRECO_COMPRA = <any> {[EnumUtils.id]: "PRECO_COMPRA", [EnumUtils.display]: "Preço de compra"},
  CUSTO_COMPRA = <any> {[EnumUtils.id]: "CUSTO_COMPRA", [EnumUtils.display]: "Custo de compra"},
  CUSTO_MEDIO = <any> {[EnumUtils.id]: "CUSTO_MEDIO", [EnumUtils.display]: "Custo médio"},
  CUSTO_DIGITADO = <any> {[EnumUtils.id]: "CUSTO_DIGITADO", [EnumUtils.display]: "Custo digitado"},
}
