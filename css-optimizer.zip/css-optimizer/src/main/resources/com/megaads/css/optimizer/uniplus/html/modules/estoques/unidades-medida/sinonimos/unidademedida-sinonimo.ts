import { AbstractPojo } from "../../../../core/crud/pojo";

/**
 * @author Osiel.
 */
export class SinonimoUnidadeMedida extends AbstractPojo {

  public idUnidadeMedida = 0;
  public sinonimo = "";
}
