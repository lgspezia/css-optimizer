import { Component, Input } from "@angular/core";
import { Headers, RequestOptions } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { FileParams } from "../../models/file-params";
import { BaseFormComponent } from "../primitive/baseform.component";

/**
 * Componente de seleção de arquivo.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-inputfile",
  templateUrl: "it-inputfile.component.html",
})
export class ItInputFileComponent extends BaseFormComponent {
  @Input() condicao$: Observable<boolean>;
  @Input() typeFile: string;

  private file$: BehaviorSubject<FileParams>;

  constructor() {
    super();
    this.condicao$ = Observable.of(true);
    this.file$ = new BehaviorSubject(undefined);
  }

  /**
   * Monta os dados do arquivo e prepara para o envio ao servidor.
   * @param event
   */
  public fileChange(event): void {
    const files: FileList = event.target.files;
    if (files.length > 0) {
      const file: File = files.item(0);

      const formData: FormData = new FormData();
      formData.append("file", file, file.name);

      this.file$.next({data: formData, options: new RequestOptions({headers: new Headers()})});
    }
  }

  /**
   * Retorna os parâmetros para o endpoint.
   * @return {FileParams}
   */
  public get fileParams$(): BehaviorSubject<FileParams> {
    return this.file$;
  }
}
