import {  Component, Input } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputdate",
    templateUrl: "it-inputdate.component.html",
})
export class ItInputDateComponent extends BaseFormComponent {

    constructor() {
        super();
    }
}
