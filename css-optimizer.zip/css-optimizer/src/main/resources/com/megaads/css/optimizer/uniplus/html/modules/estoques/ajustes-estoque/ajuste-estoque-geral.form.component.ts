import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { applicationInjector } from "../../../app.module";
import { ItDynacomboboxParamsComponent } from "../../../core/components/primitive/it-dynacomboboxparams.component";
import { FormComponent } from "../../../core/crud/form-component";
import { identificationRequiredValidator, uniqueAsyncValidator } from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ContextoService } from "../../../core/services/contexto.service";
import { DateService } from "../../../core/services/date.service";
import { HttpService } from "../../../core/services/http.service";
import { ToasterService } from "../../../core/services/toaster.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { StringUtil } from "../../../core/utils/string.util";
import { Filial } from "../../cadastros/filiais/filial";
import { MotivoAjusteEstoque } from "../motivos-ajuste-estoque/motivo-ajuste-estoque";
import { AjusteEstoque, TipoAjusteEstoque } from "./ajuste-estoque";
import { ItAjusteEstoqueItemFormComponent } from "./ajuste-estoque-item/ajuste-estoque-item.form.component";

/**
 * Ajuste de estoque.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-ajusteestoque-geral",
  templateUrl: "ajuste-estoque-geral.form.component.html",
})
export class ItAjusteEstoqueGeralFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Subject<number>;

  public centroCusto$: Observable<boolean>;
  public exibirMotivo$: Observable<boolean>;
  public labelLocalEstoque$: Observable<string>;
  public motivoEstoque$: Observable<MotivoAjusteEstoque>;
  public submitAjuste$: Subject<AjusteEstoque>;
  public urlParamsMotivo$: Observable<URLSearchParams>;
  public tipoMovimento$: Observable<IDataItem[]>;
  public transferencia$: Observable<boolean>;
  public paramLocalEstoque$: Observable<URLSearchParams>;

  @ViewChild(ItDynacomboboxParamsComponent) private itMotivo: ItDynacomboboxParamsComponent<MotivoAjusteEstoque>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService,
              private http: HttpService, private toaster: ToasterService) {
    super();

    this.labelLocalEstoque$ = Observable.of("Local estoque");
    this.submitAjuste$ = new Subject();
    this.transferencia$ = Observable.of(true);

    this.tipoMovimento$ = EnumUtils.getValues(TipoAjusteEstoque)
      .combineLatest(this.contexto.isFuncionalidade$("LOCAL_ESTOQUE"),
        (values: IDataItem[], localEstoque: boolean) =>
          localEstoque ? values : values.filter((v) => v.id !== TipoAjusteEstoque.TRANSFERENCIA_LOCAL_ESTOQUE[EnumUtils.id]));
  }

  public ngOnInit(): void {
    this.addValidations();
    this.addBehaviors();
    this.addObsUpdateAjuste();

    this.loadAjustePendente();
  }

  /**
   * Ao executar o próximo passo, se possuir id o sistema deve salvar o registro em banco, pois pode ter sido alterado
   * o cabeçalho.
   * @param {ItAjusteEstoqueItemFormComponent} itAjusteEstoqueItem
   */
  public saveOnNext(itAjusteEstoqueItem: ItAjusteEstoqueItemFormComponent) {
    itAjusteEstoqueItem.itFormTable.invalidateFlexGrid();

    this.addSubscription(this.form$
      .filter((form: FormGroup) => form.get("id").disabled && !NumberUtil.numberNullOrZero(form.get("id").value) && form.enabled)
      .subscribe((form: FormGroup) => {
        const ajuste: AjusteEstoque = form.getRawValue();
        this.submitAjuste$.next(ajuste);
      }));
  }

  /**
   * Carrega o ajuste de estoque pendente de gravação.
   */
  private loadAjustePendente(): void {
    this.addSubscription(this.isCreate$()
      .filter((create: boolean) => create)
      .switchMap(() => this.http.get(`ajustes-estoque/filtrar-pendente`))
      .filter((ajuste: AjusteEstoque) => ajuste !== null && !NumberUtil.numberNullOrZero(ajuste.id))
      .combineLatest(this.form$, (ajuste: AjusteEstoque, form: FormGroup) => ({form, ajuste}))
      .subscribe((obj: { ajuste: AjusteEstoque, form: FormGroup }) => {
        obj.form.patchValue(obj.ajuste);
        this.disableForm(obj.form);
        this.afterGet$.next(obj.ajuste.id);
        this.toaster.pop("warning", "Ajuste de estoque pendente carregado para edição.");
      }));
  }

  /**
   * Observa se deve fazer o update do item.
   */
  private addObsUpdateAjuste(): void {
    this.addSubscription(this.submitAjuste$
      .switchMap((ajuste: AjusteEstoque) => this.http.put(`ajustes-estoque/update`, ajuste))
      .subscribe(() => this.toaster.pop("success", "Ajuste de estoque", "Alteração executada com sucesso!")));
  }

  /**
   * Validações
   */
  private addValidations(): void {
    this.addSubscription(this.getControl("codigo")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(20)]);
        control.setAsyncValidators([uniqueAsyncValidator("ajustes-estoque")]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("data")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, dateValidator])));

    this.addSubscription(this.getControl("idLocalEstoqueOrigem")
      .merge(this.getControl("idCentroCusto"),
        this.getControl("idMotivo"))
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("idLocalEstoqueDestino")
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator(), localEstoqueValidator])));
  }

  /**
   * Adiciona os comportamentos dos componentes.
   */
  private addBehaviors(): void {
    this.motivoEstoque$ = this.getValueChanges("idMotivo")
      .map((idMotivo: number) => !NumberUtil.numberNullOrZero(idMotivo) && this.itMotivo ? this.itMotivo.selectedItem : null)
      .startWith(null);

    /**
     * Determina se deve exibir o centro de custo.
     * @type {Observable<boolean>}
     */
    this.centroCusto$ = this.motivoEstoque$
      .combineLatest(this.contexto.isFuncionalidade$("CENTRO_CUSTO"),
        (motivo: MotivoAjusteEstoque, centro: boolean) => motivo !== null && motivo.centroCustoObrigatorio && centro)
      .startWith(false);

    this.addSubscription(this.centroCusto$
      .combineLatest(this.getControl("idCentroCusto"),
        (centro: boolean, control: AbstractControl) => ({centro, control}))
      .subscribe((wrapper: { centro: boolean, control: AbstractControl }) =>
        wrapper.centro ? wrapper.control.enable() : wrapper.control.disable()));

    /**
     * Componente só estará visível se for diferente de levantamento.
     * @type {Observable<boolean>}
     */
    this.exibirMotivo$ = this.getValueChanges("tipoMovimento")
      .map((tipoMovimento: string) => TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id] !== tipoMovimento)
      .startWith(true);

    this.addSubscription(this.exibirMotivo$
      .combineLatest(this.getControl("idMotivo"), this.getControl("tipoMovimento"),
        (exibir: boolean, motivo: AbstractControl, movimento: AbstractControl) => ({exibir, motivo, movimento}))
      .subscribe((wrapper: { exibir: boolean, motivo: AbstractControl, movimento: AbstractControl }) => {
        /**
         * Só deve habilitar ou desabilitar se o componente pai estiver habilitado.
         */
        if (wrapper.movimento.enabled) {
          if (wrapper.exibir) {
            wrapper.motivo.enable();
          } else {
            wrapper.motivo.disable();
            wrapper.motivo.setValue(0);
          }
        }
      }));

    /**
     * Parâmetros para a busca de motivos de estoque. Não deve buscar se for levantamento pois o componente não existe.
     * @type {Observable<URLSearchParams>}
     */
    this.urlParamsMotivo$ = this.getValueChanges("tipoMovimento")
      .startWith(TipoAjusteEstoque.ENTRADA[EnumUtils.id])
      .filter((tipoMovimento: string) => TipoAjusteEstoque.LEVANTAMENTO[EnumUtils.id] !== tipoMovimento)
      .map((tipoMovimento: string) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("tipoAjuste", tipoMovimento);

        return params;
      });

    /**
     * Parâmetro de filial para local de estoque.
     * @type {Observable<URLSearchParams>}
     */
    this.paramLocalEstoque$ = this.contexto.filial$
      .map((filial: Filial) => {
        const param: URLSearchParams = new URLSearchParams();
        param.set("idFilial", filial.id.toString());
        return param;
      });

    /**
     * Determina se habilita componente de tranferência de lote
     * @type {Observable<boolean>}
     */
    this.transferencia$ = this.getValueChanges("tipoMovimento")
      .map((tipo: string) => TipoAjusteEstoque.TRANSFERENCIA_LOCAL_ESTOQUE[EnumUtils.id] === tipo)
      .startWith(false);

    /**
     * Habilita/desabilita o campo.
     */
    this.addSubscription(this.transferencia$
      .combineLatest(this.getControl("idLocalEstoqueDestino"), this.isRead$(),
        (transferencia: boolean, control: AbstractControl, read: boolean) => ({transferencia, control, read}))
      .subscribe((wrapper: { transferencia: boolean, control: AbstractControl, read: boolean }) => {
        if (!wrapper.read) {
          wrapper.transferencia ? wrapper.control.enable() : wrapper.control.disable();
        }
      }));

    /**
     * Habilita/desabilita o campo.
     */
    this.addSubscription(this.contexto.isFuncionalidade$("LOCAL_ESTOQUE")
      .filter((local: boolean) => !local)
      .switchMap(() => this.getControl("idLocalEstoqueOrigem"))
      .subscribe((control: AbstractControl) => control.disable()));

    /**
     * Atualiza a validação.
     */
    this.addSubscription(this.getValueChanges("idLocalEstoqueOrigem")
      .combineLatest(this.transferencia$, (id: number, transf: boolean) => ({id, transf}))
      .filter((obj: { id: number, transf: boolean }) => !NumberUtil.numberNullOrZero(obj.id) && obj.transf)
      .switchMap(() => this.getControl("idLocalEstoqueDestino"))
      .subscribe((c: AbstractControl) => c.updateValueAndValidity()));
  }

  /**
   * Desabilita os compononentes do form (com exceção de observação).
   * Não deve emitir evento pois não pode atualizar os campos dynacombobox que existem na tela.
   * @param {FormGroup} form
   */
  public disableForm(form: FormGroup): void {
    Object.keys(form.controls)
      .filter((key: string) => key !== "observacao")
      .forEach((key: any) => form.get(key).disable({onlySelf: true, emitEvent: false}));
  }

}

/**
 * Não deve ser permitido data maior que data de hoje.
 * @param control: FormControl
 * @return {{validateDay: {valid: boolean}}}
 */
function dateValidator(control: FormControl) {
  const dateService = applicationInjector.get(DateService);

  const data: Date = StringUtil.isString(control.value) ? new Date(control.value) : control.value;
  if (dateService.withoutTime(data) > dateService.todayWithoutTime()) {
    return {validateDay: "EST20 - Não é possível realizar ajustes com data futura."};
  }

  return null;
}

/**
 * Em transferências os locais de estoques devem ser diferentes.
 * @param control: FormControl
 * @return {{validateLocal: {valid: boolean}}}
 */
function localEstoqueValidator(control: FormControl) {

  const idLocalOrigem: number = NumberUtil.parseFloat(control.parent.get("idLocalEstoqueOrigem").value);

  if (!NumberUtil.numberNullOrZero(idLocalOrigem) && idLocalOrigem === NumberUtil.parseFloat(control.value)) {
    return {validateLocal: "EST26 - O destino de estoque deve ser diferente da origem"};
  }

  return null;
}
