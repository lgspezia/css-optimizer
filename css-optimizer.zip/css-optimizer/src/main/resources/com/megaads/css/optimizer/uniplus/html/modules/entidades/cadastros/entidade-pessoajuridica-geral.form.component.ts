import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { AbstractControl, FormGroup, ValidatorFn, Validators } from "@angular/forms";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../core/crud/form-component";
import { TipoValidadorCpfCnpj } from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ContextoService } from "../../../core/services/contexto.service";
import { TipoContribuinte, TipoEnquadramentoEntidade } from "./entidade";
import { Contato } from "./utils/contato";

/**
 * Implementação de painel de pessoa juridica na aba geral de entidade.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-entidade-pessoajuridica",
  templateUrl: "entidade-pessoajuridica-geral.form.component.html",
})
export class ItEntidadePessoaJuridicaGeralFormComponent extends FormComponent implements OnInit, OnDestroy {
  @Input() public afterGet$: Observable<number>;
  @Input() public clienteFornecedor$: Observable<boolean>;
  @Input() public tipoContribuinte$: Observable<string>;
  @Input() public controlEstado$: Observable<AbstractControl>;

  public formContato$: BehaviorSubject<FormGroup>;

  public incentivoFiscal$: Observable<boolean>;
  public requiredCnpj$: Observable<boolean>;
  public maskFone$: Observable<string>;

  public cnpj$: Observable<TipoValidadorCpfCnpj>;
  public tiposContribuinte$: Observable<IDataItem[]>;
  public tiposEnquadramento$: Observable<IDataItem[]>;

  constructor(private contexto: ContextoService) {
    super();

    this.formContato$ = new BehaviorSubject(undefined);

    this.cnpj$ = Observable.of(TipoValidadorCpfCnpj.CNPJ);
    this.incentivoFiscal$ = contexto.isFuncionalidade$("INCENTIVO_FISCAL")
      .combineLatest(contexto.isFuncionalidade$("OPERACAO_FISCAL"), (i: boolean, o: boolean) => i || o);

    this.maskFone$ = contexto.getPropriedade$(258).map((p: string) => p === "true" ?
      "(9xx99) 00000-0000" : "(9xx99) 0000-000000000000000000000000000");

    this.tiposContribuinte$ = EnumUtils.getValues(TipoContribuinte);
    this.tiposEnquadramento$ = EnumUtils.getValues(TipoEnquadramentoEntidade);

    this.requiredCnpj$ = contexto.getPropriedade$(262).map((p: string) => p === "true");
  }

  public ngOnDestroy(): void {
    super.ngOnDestroy();

    this.formContato$.unsubscribe();
  }

  public ngOnInit(): void {
    this.addSubscription(this.getFormGroup("contato", new Contato()).subscribe(this.formContato$));

    this.addSubscription(this.getControl("razaoSocial")
      .combineLatest(this.contexto.getPropriedade$(262),
        (control: AbstractControl, razaoObrigatoria: string) => ({control, razaoObrigatoria}))
      .subscribe((wrapper: { control: AbstractControl, razaoObrigatoria: string }) => {
        const validators: ValidatorFn[] = [Validators.maxLength(60)];
        if (wrapper.razaoObrigatoria === "true") {
          validators.push(Validators.required);
        }
        wrapper.control.setValidators(validators);
      }));

    this.addSubscription(this.getControl("inscricaoMunicipal")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(20)])));

    this.addSubscription(this.getControl("nome", this.formContato$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

  }
}
