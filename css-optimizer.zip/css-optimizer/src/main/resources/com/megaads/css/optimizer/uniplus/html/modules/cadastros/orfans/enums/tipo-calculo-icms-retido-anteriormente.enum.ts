import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum TipoCalculoICMSRetidoAnteriormente {
  NENHUM = <any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Não efetuar nenhum cáculo", prefixo: 0},
  BUSCAR_ICMS_ST_COBRADO_ANTERIORMENTE = <any>   {
    [EnumUtils.id]: "BUSCAR_ICMS_ST_COBRADO_ANTERIORMENTE",
    [EnumUtils.display]: "Buscar valor de ICMS ST cobrado anteriormente",
    prefixo: 1
  },
  CALCULAR_ICMS_ST = <any> {
    [EnumUtils.id]: "CALCULAR_ICMS_ST",
    [EnumUtils.display]: "Calcular ICMS ST com as informações cadastradas",
    prefixo: 2
  },
}
