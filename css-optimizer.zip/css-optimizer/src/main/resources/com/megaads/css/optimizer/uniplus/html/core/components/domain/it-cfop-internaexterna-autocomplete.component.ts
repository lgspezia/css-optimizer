import { Component, Input, OnInit } from "@angular/core";

import { NaturezaOperacao } from "../../../modules/cadastros/orfans/natureza-operacao.model";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";

@Component({
  selector: "it-cfop-internaexterna-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItCfopInternaExternaAutocompleteComponent extends ItAutocompleteComponent<NaturezaOperacao> implements OnInit {
  @Input() public interna = true;
  @Input() public movimento: TipoMovimento;

  constructor(httpService: HttpService) {
    super(httpService);
    this.url = "naturezas-operacao/filtrar-tipo-estado";
    this.display = "descricao";
    this.urlUpdate = "naturezas-operacao";
  }

  public ngOnInit(): void {
    this.addParams("interna", this.interna ? "true" : "false");
    this.addParams("tipoMovimento", this.movimento.toString());

    super.ngOnInit();
  }
}

export enum TipoMovimento {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  SAIDA = <any> {
    display: "Saída",
    id: "SAIDA",
    inicioCFOPEstado: "5",
    inicioCFOPExterior: "7",
    inicioCFOPForaEstado: "6",
  },
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  ENTRADA = <any> {
    display: "Entrada",
    id: "ENTRADA",
    inicioCFOPEstado: "1",
    inicioCFOPExterior: "3",
    inicioCFOPForaEstado: "2",
  },
}
