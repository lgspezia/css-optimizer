import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../core/crud/form-component";
import { TipoValidadorCpfCnpj } from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { EstadoCivil, Sexo, TipoContribuinte } from "./entidade";
import { mountParamsCidade } from "./entidade-geral.form.component";
import { Endereco } from "./utils/endereco";

/**
 * Implementação de painel de pessoa física na aba geral de entidade.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-entidade-pessoafisica",
  templateUrl: "entidade-pessoafisica-geral.form.component.html",
})
export class ItEntidadePessoaFisicaGeralFormComponent extends FormComponent implements OnInit, OnDestroy {
  @Input() public afterGet$: Observable<number>;
  @Input() public tipoContribuinte$: Observable<string>;
  @Input() public controlEstado$: Observable<AbstractControl>;

  public formEnderecoTrabalho$: BehaviorSubject<FormGroup>;

  public requiredCpf$: Observable<boolean>;
  public estadoCivil$: Observable<IDataItem[]>;
  public sexo$: Observable<IDataItem[]>;
  public tiposContribuinte$: Observable<IDataItem[]>;

  public cpf$: Observable<TipoValidadorCpfCnpj>;
  public paramsCidadeNatural$: Observable<URLSearchParams>;

  constructor(private contexto: ContextoService) {
    super();

    this.formEnderecoTrabalho$ = new BehaviorSubject(undefined);

    this.cpf$ = Observable.of(TipoValidadorCpfCnpj.CPF);
    this.estadoCivil$ = EnumUtils.getValues(EstadoCivil);
    this.sexo$ = EnumUtils.getValues(Sexo);

    this.tiposContribuinte$ = EnumUtils.getValues(TipoContribuinte);
    this.requiredCpf$ = contexto.getPropriedade$(262).map((p: string) => p === "true");
  }

  public ngOnDestroy(): void {
    super.ngOnDestroy();

    this.formEnderecoTrabalho$.unsubscribe();
  }

  public ngOnInit() {
    this.addSubscription(this.getFormGroup("enderecoTrabalho", new Endereco()).subscribe(this.formEnderecoTrabalho$));

    this.addSubscription(this.getControl("rg")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(20)])));

    this.addSubscription(this.getControl("conjuge")
      .merge(this.getControl("pai"), this.getControl("mae"),
        this.getControl("profissao"), this.getControl("localTrabalho"))
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("endereco", this.formEnderecoTrabalho$)
      .merge(this.getControl("bairro", this.formEnderecoTrabalho$),
        this.getControl("complemento", this.formEnderecoTrabalho$))
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("numero", this.formEnderecoTrabalho$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(6)])));

    this.addBehaviors();
  }

  /**
   * Adiciona os comportamentos de cada control.
   */
  private addBehaviors(): void {

    /**
     * Load cidade natural.
     */
    this.paramsCidadeNatural$ = this.getValueChanges("idEstadoNatural")
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .map((id: number) => mountParamsCidade(id));
  }
}
