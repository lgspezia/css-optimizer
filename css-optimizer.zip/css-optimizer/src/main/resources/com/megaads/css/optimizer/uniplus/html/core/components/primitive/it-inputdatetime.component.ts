import { Component } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputdatetime",
    templateUrl: "it-inputdatetime.component.html",
})
export class ItInputDateTimeComponent extends BaseFormComponent {}
