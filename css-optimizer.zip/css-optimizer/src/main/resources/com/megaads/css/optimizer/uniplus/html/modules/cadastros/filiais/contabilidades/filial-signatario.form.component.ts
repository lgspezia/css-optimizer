import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItFormTableComponent } from "../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { FormComponent } from "../../../../core/crud/form-component";
import { IParamsData } from "../../../../core/crud/param-data";
import { enumValueValidator } from "../../../../core/crud/validadores";
import { enumConverter, EnumUtils } from "../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../core/models/dataitem";
import { ServerError } from "../../../../core/models/server-error";
import { NumberUtil } from "../../../../core/utils/number.util";
import { StringUtil } from "../../../../core/utils/string.util";
import { IdentificacaoSignatario, Signatario } from "./filial-signatario";

/**
 * @author Luan  on 26/06/2017.
 */
@Component({
  selector: "it-filial-signatario",
  templateUrl: "filial-signatario.form.component.html",
})
export class ItFilialSignatarioFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formSignatario$: BehaviorSubject<FormGroup>;
  public params$: Observable<IParamsData>;
  public tipoIdentificacao$: Observable<IDataItem[]>;
  public isSef$: Observable<boolean>;
  public required$: Observable<boolean>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<Signatario>;

  constructor(private formBuilder: FormBuilder) {
    super();
    /**
     *  Cria a lista de informação para o combo, removendo o item CONTADOR
     */
    this.tipoIdentificacao$ = EnumUtils.getValues(IdentificacaoSignatario, EnumUtils.display, false)
      .map((valores: IDataItem[]) => valores.filter((valor: IDataItem) => valor.id !== IdentificacaoSignatario.CONTADOR[EnumUtils.id]));

    this.required$ = Observable.of(true);
  }

  public ngOnInit(): void {
    /**
     * Cria o formGroup de Signatario
     */
    this.formSignatario$ = new BehaviorSubject(this.formBuilder.group(new Signatario()));

    this.addSubscription(this.getControl("nome", this.formSignatario$).subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required, Validators.maxLength(50)])));

    this.addSubscription(this.getControl("identificacaoSignatario", this.formSignatario$).subscribe((control: AbstractControl) =>
    control.setValidators([enumValueValidator(IdentificacaoSignatario, IdentificacaoSignatario.UNDEFINED)])));

    /**
     * Cria as colunas da table
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "ID", DataType.Number, 0, null, false),
      new ColumnDefinition("idFilial", "idFilial", DataType.Number, 0, null, false),
      new ColumnDefinition("nome", "Nome", DataType.String, "*", null, true),
      new ColumnDefinition("cpf", "CPF", DataType.String, 300, null, true),
      new ColumnDefinition("identificacaoSignatario", "Tipo", DataType.String, "*", null,
        true, IdentificacaoSignatario, null, enumConverter)
    ]);

    /**
     * Cria o parametro de consulta no servidor
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idFilial", id.toString());
        return {endpoint: "signatarios", search: params};
      });

    /**
     * Troca o valor que vem do banco de dados por um numerico, para poder trabalhar com o campo de inteiro
     */
    this.addSubscription(
      this.afterGet$.combineLatest(
        this.getControl("numeroOrdemLivro", this.form$), this.getControl("auxNumeroOrdemLivro", this.form$),
        (id: number, numOrdemLivro: AbstractControl, auxNumOrdemLivro: AbstractControl) =>
          ({numOrdemLivro, auxNumOrdemLivro}))
        .subscribe((wrapper: { numOrdemLivro: AbstractControl, auxNumOrdemLivro: AbstractControl }) =>
          wrapper.auxNumOrdemLivro.setValue(NumberUtil.parseInt(wrapper.numOrdemLivro.value))));

    /**
     * Ao clicar em incluir, cria um novo objeto.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new Signatario())));

    /**
     * Grava o objeto na tabela e no banco
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .combineLatest(this.afterGet$, (obj: Signatario, id: number) => ({obj, id}))
      .subscribe((wrapper: { obj: Signatario, id: number }) => {
        wrapper.obj.idFilial = wrapper.id;
        if (StringUtil.stringNullOrEmpty(wrapper.obj.nome)) {
          this.itFormTable.handleError(new ServerError(null, "WWW61", "Campo Nome não informado"));
          return;
        }
        if (StringUtil.stringNullOrEmpty(wrapper.obj.cpf)) {
          this.itFormTable.handleError(new ServerError(null, "WWW62", "Campo Cpf não informado"));
          return;
        }
        if (wrapper.obj.identificacaoSignatario === IdentificacaoSignatario.UNDEFINED[EnumUtils.id]) {
          this.itFormTable.handleError(new ServerError(null, "WWW63", "Campo Tipo não selecionado"));
          return;
        }
        this.itFormTable.submit$.next(wrapper.obj);
      }));

  }
}
