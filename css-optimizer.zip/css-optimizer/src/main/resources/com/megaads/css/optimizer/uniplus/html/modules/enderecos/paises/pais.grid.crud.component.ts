import { Component, OnInit } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { GridCrud } from "../../../core/crud/grid.crud";
import { Pais } from "./pais";

@Component({
  templateUrl: "pais.grid.crud.html",
})
export class PaisGridCrudComponent extends GridCrud<Pais> implements OnInit {

  public max$: Observable<number>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Pais(), "paises");

    this.max$ = Observable.of(999);

    this.addSubscription(this.getControl("codigoIbge")
      .merge(this.getControl("nome"))
      .subscribe((ab: AbstractControl) => ab.setValidators([Validators.required])));
  }

}
