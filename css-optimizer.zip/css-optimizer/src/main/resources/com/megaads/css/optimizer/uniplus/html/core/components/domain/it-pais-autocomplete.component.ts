import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Pais } from "../../../modules/enderecos/paises/pais";

@Component({
    selector: "it-pais-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItPaisAutoCompleteComponent extends ItAutocompleteComponent<Pais> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "nome";
        this.label = "País";
        this.url = "paises";
    }

}
