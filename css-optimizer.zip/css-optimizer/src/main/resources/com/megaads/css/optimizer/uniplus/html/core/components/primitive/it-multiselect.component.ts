import { Component, Input, ViewChild } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { WjMultiSelect } from "wijmo/wijmo.angular2.input";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-multiselect",
    templateUrl: "it-multiselect.component.html",
})
export class ItMultiselectComponent extends BaseFormComponent {
  @Input() public placeholder = "";
  @Input() public itens$: Observable<any>;

    @ViewChild(WjMultiSelect) private multiselect: WjMultiSelect;

    /**
     * Retorna array com os valores selecionados
     */
    public checkedItems(): any {
        return this.multiselect.checkedItems.map((item) => item.id);
    }
}
