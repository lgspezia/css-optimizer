import { Component } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { ItInputNumberComponent } from "../primitive/it-inputnumber.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-fatorconversao",
    templateUrl: "../primitive/it-inputnumber.component.html",
})
export class ItFatorConversaoInputNumberComponent extends ItInputNumberComponent {

    constructor() {
        super();
        this.decimais$ = Observable.of(6);
    }
}
