import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItTipoDocumentoFinanceiroIntegracaoAutocompleteComponent } from "./it-tipodocumentofinanceiro-integracao-autocomplete.component";

@Component({
  selector: "it-tipodocumentofinanceiro-integracaopagar-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoDocumentoFinanceiroIntegracaoPagarAutocompleteComponent
  extends ItTipoDocumentoFinanceiroIntegracaoAutocompleteComponent {

  constructor(httpService: HttpService) {
    super(httpService);
    this.addParams("integracao", "PAGAR");
  }
}

