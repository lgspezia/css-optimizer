import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-inputnumber-percentage",
  templateUrl: "it-inputnumber.component.html",
})
export class ItInputNumberPercentageComponent extends BaseFormComponent implements OnInit {
  @Input() public min$: Observable<number>;
  @Input() public max$: Observable<number>;
  @Input() public decimais$: Observable<number>;

  @Output() eventBlur: EventEmitter<any>;

  public format$: Observable<String>;

  constructor() {
    super();
    this.min$ = Observable.of(0);
    this.max$ = Observable.of(999999999);
    this.decimais$ = Observable.of(2);
    this.eventBlur = new EventEmitter();
  }

  public ngOnInit(): void {
    this.format$ = this.decimais$.map((decimais) => `'p${decimais}'`);
  }

  /**
   * Evento Blur
   * @param event
   */
  public lostFocus(event) {
    this.eventBlur.emit(event);
  }
}
