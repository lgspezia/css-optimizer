import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";

import { PdfViewerComponent } from "ng2-pdf-viewer";
import { WjGridModule } from "wijmo/wijmo.angular2.grid";
import { WjInputModule } from "wijmo/wijmo.angular2.input";

import { ItInputExtraConfigComponent } from "../domain/extras/it-inputextra-config.component";
import { ItInputExtraComponent } from "../domain/extras/it-inputextra.component";
import { ItAjusteApuracaoIcmsAutoCompleteComponent } from "../domain/it-ajuste-apuracao-icms-autocomplete.component";
import { ItAjusteDocumentoFiscalAutoCompleteComponent } from "../domain/it-ajuste-documento-fiscal-autocomplete.component";
import { ItBancoAutocompleteComponent } from "../domain/it-banco-autocomplete.component";
import { ItBandeiraAutocompleteComponent } from "../domain/it-bandeira-autocomplete.component";
import { ItCaptacaoAutocompleteComponent } from "../domain/it-captacao-autocomplete.component";
import { ItCasasDecimaisComboboxComponent } from "../domain/it-casasdecimais-combobox.component";
import { ItCepInputCodeComponent } from "../domain/it-cep-inputcode.component";
import { ItCestAutocompleteComponent } from "../domain/it-cest-autocomplete.component";
import { ItCfopInternaExternaAutocompleteComponent } from "../domain/it-cfop-internaexterna-autocomplete.component";
import { ItCidadeDynacomboboxComponent } from "../domain/it-cidade-dynacombobox.component";
import { ItCidadeEstadoComponent } from "../domain/it-cidadeestado.component";
import { ItClienteAutocompleteComponent } from "../domain/it-cliente-autocomplete.component";
import { ItClienteTecnicoAutocompleteComponent } from "../domain/it-clientetecnico-autocomplete.component";
import { ItComissaoInputNumberComponent } from "../domain/it-comissao-inputnumber.component";
import { ItCompradorAutocompleteComponent } from "../domain/it-comprador-autocomplete.component";
import { ItCondicaoPagamentoAutocompleteComponent } from "../domain/it-condicaopagamento-autocomplete.component";
import { ItContribuicaoPrevidenciariaAutocompleteComponent } from "../domain/it-contribuicaoprevidenciaria-autocomplete.component";
import { ItContribuicaoSocialApuradaAutocompleteComponent } from "../domain/it-contribuicaosocialapurada-autocomplete.component";
import { ItCpfCnpjInputMaskComponent } from "../domain/it-cpfcnpj-inputmask.component";
import { ItCreditoEstimuloAutoCompleteComponent } from "../domain/it-credito-estimulo-autocomplete.component";
import { ItEanProdutoInputCodeComponent } from "../domain/it-eanproduto-inputcode.component";
import { ItEmailInputTextComponent } from "../domain/it-email-inputtext.component";
import { ItEmpresaAutoCompleteComponent } from "../domain/it-empresa-autocomplete.component";
import { ItEmpresaDynalistboxComponent } from "../domain/it-empresa-dynalistbox.component";
import { ItEnderecoComponent } from "../domain/it-endereco.component";
import { ItEnquadramentoIpiAutocompleteComponent } from "../domain/it-enquadramentoipi-autocomplete.component";
import { ItEntidadeAutocompleteComponent } from "../domain/it-entidade-autocomplete.component";
import { ItEstadoDynacomboboxComponent } from "../domain/it-estado-dynacombobox.component";
import { ItFabricanteAutocompleteComponent } from "../domain/it-fabricante-autocomplete.component";
import { ItFamiliaProdutoAutocompleteComponent } from "../domain/it-familiaproduto-autocomplete.component";
import { ItFatorConversaoInputNumberComponent } from "../domain/it-fatorconversao-inputnumber.component";
import { ItFilialDynaComboboxComponent } from "../domain/it-filial-dynacombobox.component";
import { ItFinalizadorAutocompleteComponent } from "../domain/it-finalizador-autocomplete.component";
import { ItFornecedorAutocompleteComponent } from "../domain/it-fornecedor-autocomplete.component";
import { ItFornecedorClienteAutocompleteComponent } from "../domain/it-fornecedorcliente-autocomplete.component";
import { ItGradeAutoCompleteComponent } from "../domain/it-grade-autocomplete.component";
import { ItGrupoProdutoAutocompleteComponent } from "../domain/it-grupoproduto-autocomplete.component";
import { ItIatComboboxComponent } from "../domain/it-iat-combobox.component";
import { ItIncentivoFiscalDynacomboboxComponent } from "../domain/it-incentivofiscal-dynacombobox.component";
import { ItInputFileComponent } from "../domain/it-inputfile.component";
import { ItInscricaoEstadualInputTextComponent } from "../domain/it-inscricaoestadual-inputtext.component";
import { ItLocalEstoqueDynaComboboxComponent } from "../domain/it-local-estoque-dynacombobox.component";
import { ItModeloImpressaoAutocompleteComponent } from "../domain/it-modelo-impressao-autocomplete.component";
import { ItNcmAutocompleteComponent } from "../domain/it-ncm-autocomplete.component";
import { ItObservacaoLancamentoFiscalAutoCompleteComponent } from "../domain/it-observacao-lancamanto-fiscal-autocomplete.component";
import { ItOperacaoFiscalAutocompleteComponent } from "../domain/it-operacaofiscal-autocomplete.component";
import { ItPaisAutoCompleteComponent } from "../domain/it-pais-autocomplete.component";
import { ItPautaPrecoDynacomboboxComponent } from "../domain/it-pautapreco-dynacombobox.component";
import { ItPautaPrecoDynalistboxComponent } from "../domain/it-pautapreco-dynalistbox.component";
import { ItPeriodoDateComponent } from "../domain/it-periododate.component";
import { ItPisCofinsFormComponent } from "../domain/it-piscofins.form.component";
import { ItPlanoContasAutocompleteComponent } from "../domain/it-planocontas-autocomplete.component";
import { ItPlanoContasDynalistboxComponent } from "../domain/it-planocontas-dynalistbox.component";
import { ItProdutoAutoCompleteComponent } from "../domain/it-produto-autocomplete.component";
import { ItReceitaSemContribuicaoAutocompleteComponent } from "../domain/it-receitasemcontribuicao-autocomplete.component";
import { ItReferenciaProdutoInputTextComponent } from "../domain/it-referenciaproduto-inputtext.component";
import { ItRegiaoAutocompleteComponent } from "../domain/it-regiao-autocomplete.component";
import { ItRepresentanteAutocompleteComponent } from "../domain/it-representante-autocomplete.component";
import { ItRotaAutocompleteComponent } from "../domain/it-rota-autocomplete.component";
import { ItSpedContribuicaoComponent } from "../domain/it-sped-contribuicao.component";
import { ItSwitchComponent } from "../domain/it-switch.component";
import { ItTabelaMVAAutocompleteComponent } from "../domain/it-tabelamva-autocomplete.component";
import { ItTabelaPagamentoAutocompleteComponent } from "../domain/it-tabelapagamento-autocomplete.component";
import { ItTabelaPrecoPainelAutocompleteComponent } from "../domain/it-tabelaprecopainel-autocomplete.component";
import { ItTipoComissaoAutocompleteComponent } from "../domain/it-tipocomissao-autocomplete.component";
import { ItTipoCreditoAutocompleteComponent } from "../domain/it-tipocredito-autocomplete.component";
import { ItTipoCustoComboboxComponent } from "../domain/it-tipocusto-combobox.component";
import {
  ItTipoDocumentoFinanceiroIntegracaoAutocompleteComponent,
} from "../domain/it-tipodocumentofinanceiro-integracao-autocomplete.component";
import {
  ItTipoDocumentoFinanceiroIntegracaoPagarAutocompleteComponent,
} from "../domain/it-tipodocumentofinanceiro-integracao-pagar-autocomplete.component";
import {
  ItTipoDocumentoFinanceiroIntegracaoReceberAutocompleteComponent,
} from "../domain/it-tipodocumentofinanceiro-integracao-receber-autocomplete.component";
import { ItTipoDocumentoFinanceiroReceberAutocompleteComponent } from "../domain/it-tipodocumentofinanceiro-receber-autocomplete.component";
import { ItTipoEntidadeOperacaoFiscalAutocompleteComponent } from "../domain/it-tipoentidadeoperacaofiscal-autocomplete.component";
import { ItTipoHistoricoContatoAutoCompleteComponent } from "../domain/it-tipohistoricocontato-autocomplete.component";
import { ItTransportadoraAutocompleteComponent } from "../domain/it-transportadora-autocomplete.component";
import { ItTributacaoComboboxComponent } from "../domain/it-tributacao-combobox.component";
import { ItTributacaoEspecialAutocompleteComponent } from "../domain/it-tributacaoespecial-autocomplete.component";
import { ItUnidadeMedidaAutocompleteComponent } from "../domain/it-unidademedida-autocomplete.component";
import { ItUsuarioAutocompleteComponent } from "../domain/it-usuario-autocomplete.component";
import { ItVariacaoProdutoDynacomboboxComponent } from "../domain/it-variacaoproduto-dynacombobox.component";
import { ItKitPopupComponent } from "../domain/kit/it-kit-popup";
import { ItProdutoItemComponent } from "../domain/produto/it-produto-item.component";
import { ItProdutoLoteComponent } from "../domain/produto/it-produto-lote.component";
import { ItProdutoNumeroSerieComponent } from "../domain/produto/it-produto-numero-serie.component";
import { ItProdutoPromptPopupComponent } from "../domain/produto/it-produto-prompt-popup";
import { ItProdutoPromptComponent } from "../domain/produto/it-produto-prompt.component";
import { ItProdutoVariacaoComponent } from "../domain/produto/it-produto-variacao.component";
import { ItAutocompleteComponent } from "./it-autocomplete.component";
import { ItButtonComponent } from "./it-button.component";
import { ItCheckboxComponent } from "./it-checkbox.component";
import { ItComboboxComponent } from "./it-combobox.component";
import { ItComponent } from "./it-component.component";
import { ItControlMessagesComponent } from "./it-control-messages.component";
import { ItCustomCrudComponent } from "./it-customcrud.component";
import { ItDivComponent } from "./it-div.component";
import { ItDynacomboboxComponent } from "./it-dynacombobox.component";
import { ItDynacomboboxParamsComponent } from "./it-dynacomboboxparams.component";
import { ItDynalistboxComponent } from "./it-dynalistbox.component";
import { ItDynamultiselectComponent } from "./it-dynamultiselect.component";
import { ItFlowContainerComponent } from "./it-flowcontainer.component";
import { ItFooterComponent } from "./it-footer.component";
import { ItFormComponent } from "./it-form.component";
import { ItFormTableComponent } from "./it-formtable.component";
import { ItGridComponent } from "./it-grid.component";
import { ItGridBarComponent } from "./it-gridbar.component";
import { ItGridFormComponent } from "./it-gridform.component";
import { ItInputAreaNoborderComponent } from "./it-inputarea-noborder.component";
import { ItInputAreaComponent } from "./it-inputarea.component";
import { ItInputCodeComponent } from "./it-inputcode.component";
import { ItInputColorComponent } from "./it-inputcolor.component";
import { ItInputDateComponent } from "./it-inputdate.component";
import { ItInputDateTimeComponent } from "./it-inputdatetime.component";
import { ItInputIntComponent } from "./it-inputint.component";
import { ItInputMaskComponent } from "./it-inputmask.component";
import { ItInputNumberComponent } from "./it-inputnumber.component";
import { ItInputNumberPercentageComponent } from "./it-inputnumberpercentage.component";
import { ItInputPasswordComponent } from "./it-inputpassword.component";
import { ItInputTextComponent } from "./it-inputtext.component";
import { ItInputTimeComponent } from "./it-inputtime.component";
import { ItListboxComponent } from "./it-listbox.component";
import { ItMandatoryFieldComponent } from "./it-mandatory-fields.component";
import { ItMultiselectComponent } from "./it-multiselect.component";
import { ItPanelComponent } from "./it-panel.component";
import { ItRadioComponent } from "./it-radio.component";
import { ItReportComponent } from "./it-report.component";
import { ItRowComponent } from "./it-row.component";
import { ItSearchBoxComponent } from "./it-searchbox.component";
import { ItSearchButtonComponent } from "./it-searchbutton.component";
import { ItSplitButtonComponent } from "./it-splitbutton.component";
import { ItStepComponent } from "./it-step.component";
import { ItTabComponent } from "./it-tab.component";
import { ItTableComponent } from "./it-table.component";
import { ItTabPaneContentComponent } from "./it-tabpane-content";
import { ItTabsComponent } from "./it-tabs.component";
import { ItUiSwitchComponent } from "./it-ui-switch-controlvalue.component";

@NgModule({
  declarations: [ItInputTextComponent, ItInputDateComponent, ItInputDateTimeComponent, ItCheckboxComponent,
    ItUiSwitchComponent, ItSwitchComponent, ItRowComponent, ItGridComponent, ItGridBarComponent, ItButtonComponent, ItComponent,
    ItSearchBoxComponent, ItFormComponent, ItAutocompleteComponent, ItInputIntComponent, ItInputNumberComponent,
    ItInputNumberPercentageComponent, ItInputTimeComponent, ItInputMaskComponent, ItRadioComponent, ItTabComponent,
    ItTabsComponent, ItDynacomboboxComponent, ItComboboxComponent, ItInputCodeComponent, ItListboxComponent,
    ItDynalistboxComponent, ItSplitButtonComponent, ItInputColorComponent, ItMultiselectComponent,
    ItDynamultiselectComponent, ItInputAreaComponent, ItInputAreaNoborderComponent, ItInputPasswordComponent, ItDivComponent,
    ItPanelComponent, ItPautaPrecoDynacomboboxComponent, ItReportComponent, PdfViewerComponent,
    ItClienteAutocompleteComponent, ItClienteTecnicoAutocompleteComponent, ItFabricanteAutocompleteComponent,
    ItFornecedorAutocompleteComponent, ItFornecedorClienteAutocompleteComponent,
    ItRepresentanteAutocompleteComponent, ItTransportadoraAutocompleteComponent, ItPeriodoDateComponent,
    ItProdutoAutoCompleteComponent, ItGrupoProdutoAutocompleteComponent, ItFamiliaProdutoAutocompleteComponent,
    ItGradeAutoCompleteComponent, ItTipoCustoComboboxComponent, ItEanProdutoInputCodeComponent,
    ItReferenciaProdutoInputTextComponent, ItUnidadeMedidaAutocompleteComponent, ItPlanoContasAutocompleteComponent,
    ItComissaoInputNumberComponent, ItTributacaoEspecialAutocompleteComponent, ItCompradorAutocompleteComponent,
    ItNcmAutocompleteComponent, ItTabelaPagamentoAutocompleteComponent, ItTabelaPrecoPainelAutocompleteComponent,
    ItControlMessagesComponent, ItTabelaMVAAutocompleteComponent, ItCestAutocompleteComponent,
    ItEnquadramentoIpiAutocompleteComponent, ItContribuicaoPrevidenciariaAutocompleteComponent,
    ItTipoCreditoAutocompleteComponent, ItContribuicaoSocialApuradaAutocompleteComponent,
    ItReceitaSemContribuicaoAutocompleteComponent, ItCfopInternaExternaAutocompleteComponent, ItInputExtraComponent,
    ItInputExtraConfigComponent, ItTableComponent, ItFormTableComponent, ItFlowContainerComponent, ItStepComponent,
    ItCasasDecimaisComboboxComponent, ItTabPaneContentComponent, ItFatorConversaoInputNumberComponent, ItGridFormComponent,
    ItVariacaoProdutoDynacomboboxComponent, ItFilialDynaComboboxComponent, ItEmpresaDynalistboxComponent,
    ItPlanoContasDynalistboxComponent, ItEstadoDynacomboboxComponent, ItIncentivoFiscalDynacomboboxComponent,
    ItTipoEntidadeOperacaoFiscalAutocompleteComponent, ItCepInputCodeComponent, ItPaisAutoCompleteComponent,
    ItCidadeDynacomboboxComponent, ItRegiaoAutocompleteComponent, ItUsuarioAutocompleteComponent,
    ItCaptacaoAutocompleteComponent, ItEmailInputTextComponent, ItTipoComissaoAutocompleteComponent,
    ItCpfCnpjInputMaskComponent, ItInscricaoEstadualInputTextComponent, ItRotaAutocompleteComponent,
    ItTipoHistoricoContatoAutoCompleteComponent, ItEntidadeAutocompleteComponent, ItOperacaoFiscalAutocompleteComponent,
    ItCondicaoPagamentoAutocompleteComponent, ItTipoDocumentoFinanceiroReceberAutocompleteComponent, ItFinalizadorAutocompleteComponent,
    ItAjusteApuracaoIcmsAutoCompleteComponent, ItAjusteDocumentoFiscalAutoCompleteComponent, ItMandatoryFieldComponent,
    ItObservacaoLancamentoFiscalAutoCompleteComponent, ItCreditoEstimuloAutoCompleteComponent, ItEnderecoComponent,
    ItTipoDocumentoFinanceiroIntegracaoPagarAutocompleteComponent, ItTipoDocumentoFinanceiroIntegracaoReceberAutocompleteComponent,
    ItEmpresaAutoCompleteComponent, ItBancoAutocompleteComponent, ItTipoDocumentoFinanceiroIntegracaoAutocompleteComponent,
    ItLocalEstoqueDynaComboboxComponent, ItModeloImpressaoAutocompleteComponent, ItPautaPrecoDynalistboxComponent,
    ItSearchButtonComponent, ItBandeiraAutocompleteComponent, ItDynacomboboxParamsComponent, ItProdutoPromptComponent,
    ItProdutoPromptPopupComponent, ItProdutoItemComponent, ItProdutoLoteComponent, ItProdutoNumeroSerieComponent,
    ItTributacaoComboboxComponent, ItIatComboboxComponent, ItPisCofinsFormComponent, ItSpedContribuicaoComponent,
    ItProdutoVariacaoComponent, ItKitPopupComponent, ItCustomCrudComponent, ItCidadeEstadoComponent, ItFooterComponent,
    ItInputFileComponent,
  ],
  exports: [ItInputTextComponent, ItInputDateComponent, ItInputDateTimeComponent, ItCheckboxComponent,
    ItUiSwitchComponent, ItSwitchComponent, ItRowComponent, ItGridComponent, ItGridBarComponent,
    ItButtonComponent, ItComponent, ItSearchBoxComponent, ItFormComponent, ItAutocompleteComponent,
    ItInputIntComponent, ItInputNumberComponent, ItInputNumberPercentageComponent,
    ItInputTimeComponent, ItInputMaskComponent, ItRadioComponent, ItTabComponent, ItTabsComponent,
    ItDynacomboboxComponent, ItComboboxComponent, ItInputCodeComponent, ItListboxComponent, ItDynalistboxComponent,
    ItSplitButtonComponent, ItInputColorComponent, ItMultiselectComponent, ItDynamultiselectComponent,
    ItInputAreaComponent, ItInputAreaNoborderComponent, ItInputPasswordComponent, ItDivComponent, ItPanelComponent,
    ItPautaPrecoDynacomboboxComponent, ItReportComponent, PdfViewerComponent, ItClienteAutocompleteComponent,
    ItClienteTecnicoAutocompleteComponent, ItFabricanteAutocompleteComponent, ItFornecedorAutocompleteComponent,
    ItFornecedorClienteAutocompleteComponent, ItRepresentanteAutocompleteComponent,
    ItTransportadoraAutocompleteComponent, ItPeriodoDateComponent, ItProdutoAutoCompleteComponent,
    ItGrupoProdutoAutocompleteComponent, ItFamiliaProdutoAutocompleteComponent, ItGradeAutoCompleteComponent,
    ItTipoCustoComboboxComponent, ItEanProdutoInputCodeComponent, ItReferenciaProdutoInputTextComponent,
    ItUnidadeMedidaAutocompleteComponent, ItPlanoContasAutocompleteComponent, ItComissaoInputNumberComponent,
    ItTributacaoEspecialAutocompleteComponent, ItCompradorAutocompleteComponent,
    ItNcmAutocompleteComponent, ItTabelaPagamentoAutocompleteComponent, ItTabelaPrecoPainelAutocompleteComponent,
    ItControlMessagesComponent, ItTabelaMVAAutocompleteComponent, ItCestAutocompleteComponent,
    ItEnquadramentoIpiAutocompleteComponent, ItContribuicaoPrevidenciariaAutocompleteComponent,
    ItTipoCreditoAutocompleteComponent, ItContribuicaoSocialApuradaAutocompleteComponent,
    ItReceitaSemContribuicaoAutocompleteComponent, ItCfopInternaExternaAutocompleteComponent,
    ItInputExtraComponent, ItInputExtraConfigComponent, ItTableComponent, ItFormTableComponent, ItFlowContainerComponent,
    ItStepComponent, ItCasasDecimaisComboboxComponent, ItTabPaneContentComponent, ItFatorConversaoInputNumberComponent,
    ItGridFormComponent, ItVariacaoProdutoDynacomboboxComponent, ItFilialDynaComboboxComponent,
    ItEmpresaDynalistboxComponent, ItPlanoContasDynalistboxComponent, ItEstadoDynacomboboxComponent, ItIncentivoFiscalDynacomboboxComponent,
    ItTipoEntidadeOperacaoFiscalAutocompleteComponent, ItCepInputCodeComponent, ItPaisAutoCompleteComponent,
    ItCidadeDynacomboboxComponent, ItRegiaoAutocompleteComponent, ItUsuarioAutocompleteComponent,
    ItCaptacaoAutocompleteComponent, ItEmailInputTextComponent, ItTipoComissaoAutocompleteComponent,
    ItCpfCnpjInputMaskComponent, ItInscricaoEstadualInputTextComponent, ItOperacaoFiscalAutocompleteComponent,
    ItTipoHistoricoContatoAutoCompleteComponent, ItEntidadeAutocompleteComponent, ItRotaAutocompleteComponent,
    ItCondicaoPagamentoAutocompleteComponent, ItTipoDocumentoFinanceiroReceberAutocompleteComponent, ItFinalizadorAutocompleteComponent,
    ItAjusteDocumentoFiscalAutoCompleteComponent, ItAjusteApuracaoIcmsAutoCompleteComponent, ItMandatoryFieldComponent,
    ItObservacaoLancamentoFiscalAutoCompleteComponent, ItCreditoEstimuloAutoCompleteComponent, ItEnderecoComponent,
    ItTipoDocumentoFinanceiroIntegracaoPagarAutocompleteComponent, ItTipoDocumentoFinanceiroIntegracaoReceberAutocompleteComponent,
    ItEmpresaAutoCompleteComponent, ItBancoAutocompleteComponent, ItTipoDocumentoFinanceiroIntegracaoAutocompleteComponent,
    ItLocalEstoqueDynaComboboxComponent, ItModeloImpressaoAutocompleteComponent, ItPautaPrecoDynalistboxComponent,
    ItSearchButtonComponent, ItBandeiraAutocompleteComponent, ItDynacomboboxParamsComponent, ItProdutoPromptComponent,
    ItProdutoPromptPopupComponent, ItProdutoItemComponent, ItProdutoLoteComponent, ItProdutoNumeroSerieComponent,
    ItTributacaoComboboxComponent, ItIatComboboxComponent, ItPisCofinsFormComponent, ItSpedContribuicaoComponent,
    ItProdutoVariacaoComponent, ItKitPopupComponent, ItCustomCrudComponent, ItCidadeEstadoComponent, ItFooterComponent,
    ItInputFileComponent,
  ],
  imports: [CommonModule, ReactiveFormsModule, WjInputModule, WjGridModule],
})
export class ComponentsModule {
}
