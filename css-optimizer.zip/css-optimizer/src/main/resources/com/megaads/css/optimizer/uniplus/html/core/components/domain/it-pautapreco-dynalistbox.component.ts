import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItDynalistboxComponent } from "../primitive/it-dynalistbox.component";

/**
 * Componente de seleção de múltiplas pautas de preço.
 * @author Osiel.
 */
@Component({
  selector: "it-pautapreco-dynalistbox",
  templateUrl: "../primitive/it-dynalistbox.component.html",
})
export class ItPautaPrecoDynalistboxComponent extends ItDynalistboxComponent {

  constructor(httpService: HttpService) {
    super(httpService);
    this.label = "Pautas de preço";
    this.display = "nome";
    this.checkedMemberPath = "selecionado";
    this.height = "115px";
    this.url = "pautas-preco/lista-ativas";
  }
}
