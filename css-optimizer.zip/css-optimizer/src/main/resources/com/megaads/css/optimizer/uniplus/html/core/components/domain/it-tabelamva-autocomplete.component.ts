import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TabelaMVA } from "../../../modules/notas-fiscais/tabelas-mva/tabelamva";

@Component({
    selector: "it-tabelamva-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTabelaMVAAutocompleteComponent extends ItAutocompleteComponent<TabelaMVA> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "tabelas-mva";
        this.display = "descricao";
    }
}
