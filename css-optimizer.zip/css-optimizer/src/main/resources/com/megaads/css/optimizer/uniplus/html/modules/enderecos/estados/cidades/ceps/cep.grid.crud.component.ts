import { Component } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { IEditDetails } from "../../../../../core/crud/edit-details";
import { FilterHelper, IFilter } from "../../../../../core/crud/filter";
import { GridCrud, Modo } from "../../../../../core/crud/grid.crud";
import { uniqueAsyncValidator } from "../../../../../core/crud/validadores";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { Cidade } from "../cidade";
import { Cep } from "./cep";

/**
 * TODO OSIEL IMPLEMENTAR OPÇÔES DE UNICHEF
 */
@Component({
  templateUrl: "cep.grid.crud.html",
})
export class CepGridCrudComponent extends GridCrud<Cep> {

  public filterCidade$: Observable<IFilter[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Cep(), "ceps");

    const idCidade = this.getParam("idCidade");
    const params: URLSearchParams = new URLSearchParams();
    params.set("id", idCidade);

    /**
     * Filter de grid.
     */
    this.filterCidade$ = Observable.from([[FilterHelper.byId("idCidade", idCidade)]]);

    /**
     * Valdiações.
     */
    this.addSubscription(this.getControl("cep")
      .subscribe((codigo) => {
        codigo.setValidators([Validators.required, Validators.pattern("[0-9]{8}$")]);
        codigo.setAsyncValidators([uniqueAsyncValidator("ceps")]);
      }));
    this.disableWhenIsNotCreateMode("cep");

    /**
     * Adiciona as informações de cidade.
     */
    this.addSubscription(
      this.beforeSubmit$
        .subscribe((detail: IEditDetails<Cep>) => {
          if (detail.modo === Modo.UPDATE) {
            detail.pojo.nomeCidade = detail.original.nomeCidade;
          } else if (detail.modo === Modo.CREATE) {
            detail.pojo.idCidade = NumberUtil.parseFloat(idCidade);
          }
        }));

    /**
     * Quando a ação for Create deve fazer uma requisição para o endpoint de cidades
     * e para ajustar a informação na tabela a ser exibida para o usuário.
     */
    this.addSubscription(
      this.beforeSubmit$
        .filter((detail: IEditDetails<Cep>) => detail.modo === Modo.CREATE)
        .switchMap((detail: IEditDetails<Cep>) => this.httpService.get("cidades", {search: params})
          .map((cidades: Cidade[]) => ({detail, cidades})))
        .subscribe(({detail, cidades}) => {
          detail.pojo.nomeCidade = cidades[0].nome;
        }));

  }

}
