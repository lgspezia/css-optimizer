import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Cest } from "../../../modules/notas-fiscais/cests/cest";

@Component({
    selector: "it-cest-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItCestAutocompleteComponent extends ItAutocompleteComponent<Cest> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "cests";
        this.display = "descricao";
        this.label = "Cest";
    }
}
