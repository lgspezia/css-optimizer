import { Component, Input } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputpassword",
    templateUrl: "it-inputpassword.component.html",
})
export class ItInputPasswordComponent extends BaseFormComponent {
  @Input() public placeholder = "";
  @Input() public len = 40;
}
