import { Component } from "@angular/core";
import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { BandeiraCartao } from "../../../modules/financeiros/bandeiras-cartoes/bandeira-cartao";

/**
 * @author Luan  on 28/07/2017.
 */
@Component({
  selector: "it-bandeira-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItBandeiraAutocompleteComponent extends ItAutocompleteComponent<BandeiraCartao> {

  constructor(httpService: HttpService) {
    super(httpService);
    this.url = "bandeiras-cartoes";
    this.display = "nome";
    this.label = "Bandeira";
  }
}
