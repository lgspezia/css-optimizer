import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItDynacomboboxComponent } from "../primitive/it-dynacombobox.component";
import { IncentivoFiscal } from "../../../modules/notas-fiscais/incentivos-fiscais/incentivo-fiscal";

@Component({
    selector: "it-incentivofiscal-dynacombobox",
    templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItIncentivoFiscalDynacomboboxComponent extends ItDynacomboboxComponent<IncentivoFiscal> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.insertNullOption = true;
        this.url = "incentivos-fiscais";
        this.display = "nome";
        this.label = "Zona Franca/ALC";
    }
}
