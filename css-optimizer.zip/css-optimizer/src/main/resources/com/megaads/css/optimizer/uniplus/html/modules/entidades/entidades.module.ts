import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";

import { WjInputModule } from "wijmo/wijmo.angular2.input";

import { ComponentsModule } from "../../core/components/primitive/components.module";
import { ItEntidadeCartaoClienteFormComponent } from "./cadastros/clientes/cartoes-cliente/entidade-cartaocliente.form.component";
import { ClienteGridCrudComponent } from "./cadastros/clientes/cliente.grid.crud.component";
import { ItEntidadeDependenteFormComponent } from "./cadastros/clientes/dependentes/entidade-dependente.form.component";
import {
  ItEntidadeHistoricoBloqueioFormComponent,
} from "./cadastros/clientes/historico-bloqueios/entidade-historicobloqueio.form.component";
import { ItEntidadeHistoricoEntregaFormComponent } from "./cadastros/clientes/historico-entregas/entidade-historicoentrega.form.component";
import { ItEntidadeSPCHistoricoFormComponent } from "./cadastros/clientes/historicos-spc/entidade-spchistorico.form.component";
import {
  ItEntidadeLimiteCreditoHistoricoFormComponent,
} from "./cadastros/clientes/limites-credito-historico/entidade-limitecredito-historico.form.component";
import {
  ItEntidadeLimiteCreditoFormComponent,
} from "./cadastros/clientes/limites-credito-historico/limites-credito/entidade-limitecredito.form.component";
import {
  ItEntidadeLimiteCreditoFormaFormComponent,
} from "./cadastros/clientes/limites-credito-historico/limites-forma-pgmto/entidade-limitecredito-forma-pgmto.form.component";
import { ItEntidadeFinalizadorFormComponent } from "./cadastros/clientes/meios-pagamentos/entidade-finalizador.form.component";
import { ItEntidadeUnidadeCteFormComponent } from "./cadastros/clientes/unidades-medida-cte/entidade-unidade-cte.form.component";
import { CompradorGridCrudComponent } from "./cadastros/compradores/comprador.grid.crud.component";
import { ItEntidadeGeralFormComponent } from "./cadastros/entidade-geral.form.component";
import { ItEntidadePessoaFisicaGeralFormComponent } from "./cadastros/entidade-pessoafisica-geral.form.component";
import { ItEntidadePessoaJuridicaGeralFormComponent } from "./cadastros/entidade-pessoajuridica-geral.form.component";
import { FabricanteGridCrudComponent } from "./cadastros/fabricantes/fabricante.grid.crud.component";
import { FornecedorGridCrudComponent } from "./cadastros/fornecedores/fornecedor.grid.crud.component";
import { ItEntidadeHistoricoOcorrenciaFormComponent } from "./cadastros/historico-ocorrencias/entidade-historicoocorrencia.form.component";
import { MotoristaGridCrudComponent } from "./cadastros/motoristas/motorista.grid.crud.component";
import { ItEntidadeInformacaoAdicionalFormComponent } from "./cadastros/outras-informacoes/entidade-informacao-adicional.form.component";
import {
  ItEntidadePreferenciaObservacaoComponent,
} from "./cadastros/outras-informacoes/preferencias-observacoes/entidade-preferencia-observacao.form.component";
import { ItEntidadeEnderecoFormComponent } from "./cadastros/outros-enderecos/entidade-endereco.form.component";
import { PortadorGridCrudComponent } from "./cadastros/portadores/portador.grid.crud.component";
import {
  ItRepresentanteComissaoPautaPrecoFormComponent,
} from "./cadastros/representantes/pautas-preco/representante-comissao-pautapreco.form.component";
import { RepresentanteGridCrudComponent } from "./cadastros/representantes/representante.grid.crud.component";
import { TecnicoGridCrudComponent } from "./cadastros/tecnicos/tecnico.grid.crud.component";
import { TransportadoraGridCrudComponent } from "./cadastros/transportadoras/transportadora.grid.crud.component";
import {
  ConfiguracaoCartaoFidelidadeCustomCrudComponent,
} from "./configuracoes-cartao-fidelidade/configuracao-cartao-fidelidade.custom.crud.component";
import { TipoHistoricoContatoGridCrudComponent } from "./tipos-historico-contato/tipo-historico-contato.grid.crud.component";

const routes: Routes = [
  {path: "configuracoes-cartao-fidelidade", component: ConfiguracaoCartaoFidelidadeCustomCrudComponent},
  {path: "clientes", component: ClienteGridCrudComponent},
  {path: "compradores", component: CompradorGridCrudComponent},
  {path: "fabricantes", component: FabricanteGridCrudComponent},
  {path: "fornecedores", component: FornecedorGridCrudComponent},
  {path: "motoristas", component: MotoristaGridCrudComponent},
  {path: "portadores", component: PortadorGridCrudComponent},
  {path: "transportadoras", component: TransportadoraGridCrudComponent},
  {path: "tecnicos", component: TecnicoGridCrudComponent},
  {path: "representantes", component: RepresentanteGridCrudComponent},
  {path: "tipos-historico-contato", component: TipoHistoricoContatoGridCrudComponent},
];

@NgModule({
  declarations: [ItEntidadeGeralFormComponent,
    ItEntidadePessoaFisicaGeralFormComponent, ItEntidadePessoaJuridicaGeralFormComponent,
    ItEntidadeEnderecoFormComponent, ItEntidadeHistoricoOcorrenciaFormComponent, ItEntidadeHistoricoEntregaFormComponent,
    ItEntidadeDependenteFormComponent, ItEntidadeInformacaoAdicionalFormComponent, ItEntidadePreferenciaObservacaoComponent,
    ItEntidadeSPCHistoricoFormComponent, ItEntidadeFinalizadorFormComponent, ItEntidadeUnidadeCteFormComponent,
    ItEntidadeHistoricoBloqueioFormComponent, ItEntidadeCartaoClienteFormComponent, ItEntidadeLimiteCreditoHistoricoFormComponent,
    ItEntidadeLimiteCreditoFormComponent, ItEntidadeLimiteCreditoFormaFormComponent, ItRepresentanteComissaoPautaPrecoFormComponent,

    ClienteGridCrudComponent, CompradorGridCrudComponent, FabricanteGridCrudComponent, FornecedorGridCrudComponent,
    MotoristaGridCrudComponent, PortadorGridCrudComponent, TransportadoraGridCrudComponent, TecnicoGridCrudComponent,
    RepresentanteGridCrudComponent, ConfiguracaoCartaoFidelidadeCustomCrudComponent, TipoHistoricoContatoGridCrudComponent,
  ],
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, ComponentsModule, ReactiveFormsModule, WjInputModule],
})
export class EntidadesModule {
}
