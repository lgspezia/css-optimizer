import { AbstractPojo } from "../../../../../core/crud/pojo";
import { EnumUtils } from "../../../../../core/enuns/enumutil";

/**
 * Cartão de cliente.
 *
 * Created by Osiel on 26/05/17.
 */
export class CartaoCliente extends AbstractPojo {

  public idEntidade = 0;
  public dataEmissao: Date = new Date();
  public cartao = "";
  public status: StatusCartaoCliente = StatusCartaoCliente.ATIVO[EnumUtils.id];
  public senhaCartao = "";

  // Apenas para repetição.
  public senhaCartao1 = "";
  public cadastrarSenha = false;

}

export enum StatusCartaoCliente {
  BLOQUEADO = <any> {[EnumUtils.id]: "BLOQUEADO", [EnumUtils.display]: "Bloqueado"},
  ATIVO = <any> {[EnumUtils.id]: "ATIVO", [EnumUtils.display]: "Ativo"},
  INATIVO = <any> {[EnumUtils.id]: "INATIVO", [EnumUtils.display]: "Inativo"},
}
