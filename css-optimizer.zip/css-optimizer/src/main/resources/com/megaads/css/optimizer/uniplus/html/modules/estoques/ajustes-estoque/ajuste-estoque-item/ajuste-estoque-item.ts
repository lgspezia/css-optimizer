import { AbstractPojo } from "../../../../core/crud/pojo";
import { EnumUtils } from "../../../../core/enuns/enumutil";
import { TipoKit } from "../../../produtos/produto";

/**
 * @author Osiel.
 */
export class AjusteEstoqueItem extends AbstractPojo {

  public idInventarioEstoque = 0;
  public idProduto = 0;
  public idUnidadeMedida = 0;
  public idProdutoKit = 0;
  public idLote = 0;
  public idCentroCusto = 0;
  public quantidade = 0;
  public variacoes = "";
  public numerosSerie = "";
  public lotes = "";
  public lote = "";
  public dataLote: Date = new Date();
  public tipoKit: number = TipoKit.SEM_KIT[`value`];
  public preco = 0;
  public total = 0;
  public listaNumeroSeries: string[] = null;
  public fatorConversaoEmbalagem = 1;
  public centroCusto = "";
  public mapLote: any[] = null;

  // transient
  public idEmbalagem = 0;
  public codigoProduto = "";
  public descricaoProduto = "";
  public unidadeMedida = "";
  public casasDecimaisUN = 0;
  public casasDecimaisCusto = 6;

}
