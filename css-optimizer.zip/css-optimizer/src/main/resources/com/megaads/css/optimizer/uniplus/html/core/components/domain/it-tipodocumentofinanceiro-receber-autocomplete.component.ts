import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TipoUsoTipoDocumentoFinanceiro } from "../../../modules/financeiros/tipos-documentos-financeiro/tipodocumentofinanceiro";

@Component({
  selector: "it-tipodocumentofinanceiro-receber-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTipoDocumentoFinanceiroReceberAutocompleteComponent extends ItAutocompleteComponent<TipoUsoTipoDocumentoFinanceiro> {

  constructor(httpService: HttpService) {
    super(httpService);
    this.display = "descricao";
    this.label = "Tipo de documento";
    this.url = "tipos-documentos-financeiro/filtrar-documentos-a-receber";
  }
}
