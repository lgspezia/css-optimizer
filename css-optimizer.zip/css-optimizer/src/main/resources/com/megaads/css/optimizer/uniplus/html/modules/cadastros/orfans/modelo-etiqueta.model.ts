import { AbstractPojo } from "../../../core/crud/pojo";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class ModeloEtiqueta extends AbstractPojo {
  descricao = "";
  // tipoLayout: LayoutEtiqueta;
  alturaPagina = 0;
  larguraPagina = 0;
  alturaEtiqueta = 0;
  larguraEtiqueta = 0;
  margemSuperior = 0;
  margemInferior = 0;
  margemDireita = 0;
  margemEsquerda = 0;
  // tipoCodigoBarra: TipoCodigoBarra;
  numeroColunas = 0;
  espacoEntreColunas = 0;
  // jrxmlCompilado: byte[];
  scriptEtiqueta = "";
  scriptInicializacao = "";
  scriptFinalizacao = "";
  gerarEmPdf: boolean;
  // campos: ModeloEtiquetaCampo[];
}
