import { AbstractPojo } from "../../../../../core/crud/pojo";
import { EnumUtils } from "../../../../../core/enuns/enumutil";

/**
 * Created by osiel on 26/05/17.
 */
export class EntidadeDependente extends AbstractPojo {

    public idEntidade = 0;
    public idDependente = 0;
    public codigoDependente = "";
    public nomeDependente = "";
    public limiteCredito = 0;
    public grauParentesco: GrauParentesco = GrauParentesco.NENHUM[EnumUtils.id];
}

export enum GrauParentesco {
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  //noinspection JSNonASCIINames,JSNonASCIINames
  NENHUM = < any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Nenhum"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    AVÔ = < any> {[EnumUtils.id]: "AVÔ", [EnumUtils.display]: "Avô"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    AVÓ = < any> {[EnumUtils.id]: "AVÓ", [EnumUtils.display]: "Avó"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    CUNHADA = < any> {[EnumUtils.id]: "CUNHADA", [EnumUtils.display]: "Cunhada"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    CUNHADO = < any> {[EnumUtils.id]: "CUNHADO", [EnumUtils.display]: "Cunhado"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    FILHA = < any> {[EnumUtils.id]: "FILHA", [EnumUtils.display]: "Filha"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    FILHO = < any> {[EnumUtils.id]: "FILHO", [EnumUtils.display]: "Filho"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    GENRO = < any> {[EnumUtils.id]: "GENRO", [EnumUtils.display]: "Genro"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    IRMA = < any> {[EnumUtils.id]: "IRMA", [EnumUtils.display]: "Irmã"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    IRMAO = < any> {[EnumUtils.id]: "IRMAO", [EnumUtils.display]: "Irmão"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    NETA = < any> {[EnumUtils.id]: "NETA", [EnumUtils.display]: "Neta"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    NETO = < any> {[EnumUtils.id]: "NETO", [EnumUtils.display]: "Neto"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    NORA = < any> {[EnumUtils.id]: "NORA", [EnumUtils.display]: "Nora"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    MADRASTA = < any> {[EnumUtils.id]: "MADRASTA", [EnumUtils.display]: "Madrasta"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    MAE = < any> {[EnumUtils.id]: "MAE", [EnumUtils.display]: "Mãe"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    PADRASTO = < any> {[EnumUtils.id]: "PADRASTO", [EnumUtils.display]: "Padrasto"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    PAI = < any> {[EnumUtils.id]: "PAI", [EnumUtils.display]: "Pai"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    SOBRINHA = < any> {[EnumUtils.id]: "SOBRINHA", [EnumUtils.display]: "Sobrinha"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    SOBRINHO = < any> {[EnumUtils.id]: "SOBRINHO", [EnumUtils.display]: "Sobrinho"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    SOGRA = < any> {[EnumUtils.id]: "SOGRA", [EnumUtils.display]: "Sogra"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    SOGRO = < any> {[EnumUtils.id]: "SOGRO", [EnumUtils.display]: "Sogro"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    TIO = < any> {[EnumUtils.id]: "TIO", [EnumUtils.display]: "Tio"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    TIA = < any> {[EnumUtils.id]: "TIA", [EnumUtils.display]: "Tia"},
        // tslint:disable-next-line:no-angle-bracket-type-assertion
    CONJUGE = < any> {[EnumUtils.id]: "CONJUGE", [EnumUtils.display]: "Cônjuge"},
}
