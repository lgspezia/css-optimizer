import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { WjAutoComplete } from "wijmo/wijmo.angular2.input";

import { Modo } from "../../crud/grid.crud";
import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";
import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-autocomplete",
  templateUrl: "it-autocomplete.component.html",
})
export class ItAutocompleteComponent<C extends any> extends BaseFormComponent implements OnInit {
  @Input() public placeholder = "";
  @Input() public display: string;
  @Input() public url: string;
  @Input() public afterGet$: Observable<number>;

  /**
   * Quando é endpoint personalizado, é necessário setar a url de busca por id.
   */
  public urlUpdate: string;
  public getData = this.getDataFunc.bind(this);
  public selectedObject: any = {};

  @ViewChild(WjAutoComplete) private autocomplete: WjAutoComplete;

  private cache: any = {};
  private params: URLSearchParams = new URLSearchParams();

  constructor(protected httpService: HttpService) {
    super();
  }

  public ngOnInit(): void {
    if (this.afterGet$) {
      this.addSubscription(this.afterGet$
        .withLatestFrom(this.getControl(),
          (id: number, control: AbstractControl) => control)
        .switchMap((control: AbstractControl) => {

          /**
           * Como o valor é setado em um momento anterior (patchvalue),
           * o valuechanges não irá funcionar, sendo assim utiliza-se o valor do objeto.
           */
          const value = control.value;

          /**
           * O autocomplete por ter idenfificador de id oi de string.
           * Se o valor estiver definido e não possuir valor selecionado, é sinal de que
           * devemos buscar o objeto do banco.
           */
          if (((NumberUtil.isNumber(value) && !NumberUtil.numberNullOrZero(value)) ||
            StringUtil.isString(value) && !StringUtil.stringNullOrEmpty(value)) &&
            this.autocomplete.selectedItem === null) {

            /**
             * Verifica se tem em cache usando o id.
             */
            const self = this;
            const result = self.cache[value];
            if (result) {
              return Observable.of(result);
            }

            /**
             * Busca no servidor.
             */
            this.params = new URLSearchParams();
            this.addParams("id", value);
            return this.httpService.get(this.urlUpdate ? this.urlUpdate : this.url, {search: this.params});
          } else {
            /**
             * Nesse caso não existe valor selecionado, assim busca os valores defaults.
             */
            this.params.set("limit", "6");
            return this.httpService.get(this.url, {search: this.params});
          }
        }).combineLatest(this.getControl(), (resp: any, control: AbstractControl) => ({resp, control}))
        .subscribe(({resp, control}: { resp: any, control: AbstractControl }) => {
          const self = this;
          const result = self.cache[control.value];

          /**
           * Verifica se veio do cache.
           */
          if (result) {
            this.autocomplete.itemsSource = result;
          } else if (resp.length === 1 && !NumberUtil.numberNullOrZero(control.value)) {
            /**
             * Se o length é zero buscou por id.
             */
            this.params = new URLSearchParams();
            self.cache[control.value] = resp;
            this.autocomplete.itemsSource = resp;
            this.selectedObject = resp[0];
          } else {
            /**
             * Buscou os registros setando um limit.
             */
            self.cache[control.value] = resp;
            this.autocomplete.itemsSource = resp;
            this.autocomplete.selectedItem = null;
          }

          /**
           * Como essa ação só deve ser executada uma vez já finalizo o observable.
           */
        }, (error: ServerError) => this.handleError(error)));
    }
  }

  /**
   * Eventer emitter do componente que indica seleção de item.
   * @return {EventEmitter<{}>}
   */
  public get selectedChangesPC$(): EventEmitter<{}> {
    return this.autocomplete.selectedValueChangePC;
  }

  /**
   * Retorna o objeto selecionado.
   * @return {any}
   */
  public get selectedItem(): C {
    return this.autocomplete.selectedItem;
  }

  /**
   * Adiciona parâmetros para a consulta.
   * @param param: string
   * @param value: string
   */
  public addParams(param: string, value) {
    this.params.set(param, value);
  }

  private getDataFunc(query, max, callback) {
    /**
     * O modo pode não estar definido no componente, neste caso deve carregar os dados normalmente.
     * Se o modo for diferente de inclusão e não possuir filtros, significa que essa chamada é
     * do componente, nesse caso não deve ser feito a chamada, pois o behavior a cima irá
     * tratar.
     */
    if (this.modo$) {
      this.addSubscription(this.modo$
        .filter((modo: Modo) => modo === undefined ||
        modo === Modo.CREATE || !StringUtil.stringNullOrEmpty(query))
        .subscribe(() => this.loadData(query, max, callback)));
    } else {
      this.loadData(query, max, callback);
    }
  }

  /**
   * Carrega os dados do servidor setando o limit padrão.
   * @param query
   * @param max
   * @param callback
   */
  private loadData(query, max, callback): void {
    /**
     * verifica se já tem valor definido ou precisa buscar lista senao primeiro busca no cache
     */
    const self = this;
    const result = self.cache[query];
    if (result) {
      callback(result);
      return;
    }

    /**
     * e então busca no servidor
     */
    this.params.set("query", query);
    this.params.set("limit", max);

    this.httpService.get(this.url, {search: this.params})
      .subscribe((resp) => {
        if (resp.length === 0) {
          self.cache[query] = null;
          callback(null);
        } else {
          self.cache[query] = resp;
          callback(resp);
        }
      }, (error) => {
        self.cache[query] = null;
        callback(null);
        this.handleError(error);
      });
  }
}
