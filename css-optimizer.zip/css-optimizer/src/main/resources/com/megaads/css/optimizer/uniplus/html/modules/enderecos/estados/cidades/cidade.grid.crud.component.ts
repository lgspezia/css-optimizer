import { Component } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { IEditDetails } from "../../../../core/crud/edit-details";
import { FilterHelper, IFilter } from "../../../../core/crud/filter";
import { GridCrud, Modo } from "../../../../core/crud/grid.crud";
import { uniqueAsyncValidator } from "../../../../core/crud/validadores";
import { NumberUtil } from "../../../../core/utils/number.util";
import { Estado } from "../estado";
import { Cidade } from "./cidade";

@Component({
  templateUrl: "cidade.grid.crud.html",
})
export class CidadeGridCrudComponent extends GridCrud<Cidade> {

  public filterEstado$: Observable<IFilter[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Cidade(), "cidades");

    const idEstado = this.getParam("idEstado");
    const params: URLSearchParams = new URLSearchParams();
    params.set("id", idEstado);

    /**
     * Filter
     */
    this.filterEstado$ = Observable.from([[FilterHelper.byId("idEstado", idEstado)]]);

    this.addValidators();

    /**
     * Atualiza as informações antes da gravação.
     */
    this.addSubscription(this.beforeSubmit$
      .subscribe((detail: IEditDetails<Cidade>) => {
        if (detail.modo === Modo.UPDATE) {
          detail.pojo.nomeEstado = detail.original.nomeEstado;
          detail.pojo.nomePais = detail.original.nomePais;
        } else if (detail.modo === Modo.CREATE) {
          detail.pojo.idEstado = NumberUtil.parseFloat(idEstado);
        }
      }));

    /**
     * Quando o usuário submeter o form em modo de criação é necessário
     * realizar uma requisição para atualizar as informações de estado e país.
     */
    this.addSubscription(this.beforeSubmit$
      .filter((detail: IEditDetails<Cidade>) => detail.modo === Modo.CREATE)
      .switchMap((detail: IEditDetails<Cidade>) => this.httpService.get("estados", {search: params})
        .map((estados: Estado[]) => ({detail, estados})))
      .subscribe(({detail, estados}) => {
        detail.pojo.nomeEstado = estados[0].nome;
        detail.pojo.nomePais = estados[0].nomePais;
      }));

  }

  /**
   * Navega até CEP.
   */
  public eventCeps() {
    super.goTo("ceps");
  }

  /**
   * Adiciona as validações.
   */
  private addValidators(): void {
    this.addSubscription(this.getControl("codigo")
      .subscribe((codigo) => {
        codigo.setValidators([Validators.required, Validators.pattern("[0-9]+")]);
        codigo.setAsyncValidators([uniqueAsyncValidator("cidades")]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("nome").subscribe((codigo) => codigo.setValidators([Validators.required])));
  }

}
