import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { isNullOrUndefined } from "util";

import { Embalagem, TipoEmbalagem } from "../../../../modules/produtos/embalagens/embalagem";
import { Produto } from "../../../../modules/produtos/produto";
import { AbstractPojo } from "../../../crud/pojo";
import { identificationRequiredValidator, valueDifferentOfValidator } from "../../../crud/validadores";
import { EnumUtils } from "../../../enuns/enumutil";
import { NumberUtil } from "../../../utils/number.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItDynacomboboxParamsComponent } from "../../primitive/it-dynacomboboxparams.component";
import { TipoMovimento } from "../it-cfop-internaexterna-autocomplete.component";
import { ItProdutoLoteComponent } from "./it-produto-lote.component";
import { ItProdutoNumeroSerieComponent } from "./it-produto-numero-serie.component";
import { ItProdutoPromptComponent } from "./it-produto-prompt.component";
import { ItProdutoVariacaoComponent } from "./it-produto-variacao.component";


/**
 * Componente para identificação de produtos (com variação, grade ou lote), quantidade, unidade de medida e preço.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-produto-item",
  templateUrl: "it-produto-item.component.html",
})
export class ItProdutoItemComponent extends BaseFormComponent implements OnInit {
  @Input() public idCrud$: Observable<number>;
  @Input() public initPojo: AbstractPojo;
  @Input() public informarLoteNumeroSerieGrade$: Observable<boolean>;
  @Input() public distribuirQtdGrade$: BehaviorSubject<boolean>;

  /**
   * Embalagem/UN
   */
  @Input() public controlEmbalagem: string;
  @Input() public afterGetItem$: Observable<number>;
  @Input() public controlUN: string;
  @Input() public disableEmbalagem$: Observable<boolean>;
  @Input() public forcarUNProduto$: Observable<boolean>;
  @Input() public tiposEmbalagem: String[];
  public decimaisQtd$: Observable<number>;
  public urlParamsEmbalagem$: Observable<URLSearchParams>;

  /**
   * Lote
   */
  @Input() public controlLoteDate: string;
  @Input() public controlLoteEntrada: string;
  @Input() public controlLoteSaida: string;
  @Input() public controlMapLote: string;
  @Input() public modoDistribuicaoLote$: Observable<boolean>;
  @Input() public resourceNameLote: string;
  @Input() public tipoMovimento$: Observable<TipoMovimento>;

  /**
   * Número série
   */
  @Input() public controlNumeroSerie: string;
  @Input() public validarNumeroSerie$: Observable<boolean>;

  /**
   * Variação
   */
  @Input() public controlVariacao: string;
  @Input() public idLocalEstoque$: Observable<number>;
  @Input() public variacaoString: boolean;
  @Input() public validarSaldoVariacao$: Observable<boolean>;
  public eventBlurGrade$: Observable<any>;

  /**
   * Preco
   */
  @Input() public controlPreco: string;
  @Input() public labelPreco$: Observable<string>;
  @Input() public disabledPreco$: Observable<boolean>;
  @Input() public exibirPreco$: Observable<boolean>;
  @Input() public decimaisPreco$: Observable<number>;
  @Input() public minValuePreco$: Observable<number>;

  /**
   * Preco Total
   */
  @Input() public controlPrecoTotal: string;
  @Input() public labelPrecoTotal$: Observable<string>;
  @Input() public disabledPrecoTotal$: Observable<boolean>;
  @Input() public exibirPrecoTotal$: Observable<boolean>;
  @Input() public decimaisPrecoTotal$: Observable<number>;
  @Input() public minValuePrecoTotal$: Observable<number>;

  /**
   * Produto
   */
  @Input() public controlProduto: string;
  @Input() public promptProduto: string;
  @Input() public resourceNameValidationSaldo: string;
  @Input() public reloadProduto$: Subject<boolean>;

  /**
   * Quantidade.
   */
  @Input() public allowNegativeNumbersQtd$: Observable<boolean>;
  @Input() public allowNumberZeroQtd$: Observable<boolean>;
  @Input() public controlQuantidade: string;
  @Input() public disabledQuantidade$: Observable<boolean>;
  @Input() public quantidadeEsperada$: BehaviorSubject<number>;
  public minQtd$: Observable<number>;
  public eventBlurQtd$: EventEmitter<any>;

  public preco$: Observable<boolean>;

  @ViewChild(ItProdutoPromptComponent) public itProduto: ItProdutoPromptComponent;
  @ViewChild(ItDynacomboboxParamsComponent) public itEmbalagem: ItDynacomboboxParamsComponent<Embalagem>;
  @ViewChild(ItProdutoLoteComponent) public itLote: ItProdutoLoteComponent;
  @ViewChild(ItProdutoNumeroSerieComponent) public itSerie: ItProdutoNumeroSerieComponent;
  @ViewChild(ItProdutoVariacaoComponent) public itVariacao: ItProdutoVariacaoComponent;

  private embalagem$: Subject<any>;

  constructor() {
    super();

    this.allowNegativeNumbersQtd$ = Observable.of(false);
    this.allowNumberZeroQtd$ = Observable.of(false);
    this.afterGetItem$ = Observable.of(null);
    this.controlEmbalagem = "idEmbalagem";
    this.controlLoteDate = "dataLote";
    this.controlLoteEntrada = "lote";
    this.controlLoteSaida = "idLote";
    this.controlMapLote = "mapLote";
    this.controlNumeroSerie = "numerosserie";
    this.controlPreco = "preco";
    this.controlPrecoTotal = "total";
    this.controlProduto = "idProduto";
    this.controlQuantidade = "quantidade";
    this.controlUN = "idUnidadeMedida";
    this.controlVariacao = "variacoes";
    this.decimaisQtd$ = Observable.of(0);
    this.decimaisPreco$ = Observable.of(2);
    this.decimaisPrecoTotal$ = Observable.of(2);
    this.disableEmbalagem$ = Observable.of(false);
    this.disabledPreco$ = Observable.of(false);
    this.disabledPrecoTotal$ = Observable.of(false);
    this.disabledQuantidade$ = Observable.of(false);
    this.distribuirQtdGrade$ = new BehaviorSubject(false);
    this.embalagem$ = new Subject();
    this.forcarUNProduto$ = Observable.of(false);
    this.exibirPreco$ = Observable.of(true);
    this.exibirPrecoTotal$ = Observable.of(true);
    this.eventBlurQtd$ = new EventEmitter();
    this.idLocalEstoque$ = Observable.of(null);
    this.informarLoteNumeroSerieGrade$ = Observable.of(true);
    this.labelPreco$ = Observable.of("Preço Unitário");
    this.labelPrecoTotal$ = Observable.of("Total");
    this.modoDistribuicaoLote$ = Observable.of(false);
    this.minValuePreco$ = Observable.of(0);
    this.minValuePrecoTotal$ = Observable.of(0);
    this.quantidadeEsperada$ = new BehaviorSubject(0);
    this.reloadProduto$ = new Subject();
    this.validarNumeroSerie$ = Observable.of(true);
    this.validarSaldoVariacao$ = Observable.of(true);
    this.tiposEmbalagem = [TipoEmbalagem.COMPRAVENDA[EnumUtils.id]];
    this.tipoMovimento$ = Observable.of(TipoMovimento.ENTRADA);
  }

  public ngOnInit(): void {
    this.preco$ = this.exibirPreco$
      .combineLatest(this.exibirPrecoTotal$, (p: boolean, t: boolean) => p || t);

    /**
     * Determina qual evento será utilizado.
     * @type {Observable<any>}
     */
    this.eventBlurGrade$ = this.distribuirQtdGrade$
      .switchMap((distribuir: boolean) => distribuir ? this.eventBlurQtd$ : this.itProduto.eventBlur$);

    /**
     * Se não for distribuir zera a quantidade.
     */
    this.addSubscription(this.distribuirQtdGrade$
      .filter((distribuir: boolean) => !distribuir)
      .subscribe(() => this.quantidadeEsperada$.next(0)));

    this.addSubscription(this.itProduto.produtoSelecionado$
      .withLatestFrom(this.distribuirQtdGrade$, (p: Produto, distribuir: boolean) => ({p, distribuir}))
      .filter((obj: { p: Produto, distribuir: boolean }) => obj.distribuir && obj.p.numeroSerie)
      .subscribe(() => this.quantidadeEsperada$.next(0)));

    this.addBehaviorsEmbalagem();
    this.addBehaviorsQtd();
    this.addBehaviorsPreco();
    this.addBehaviorsPrecoTotal();

    /**
     * Limpa os valores quando o produto for apagado.
     */
    this.getValueChanges(this.controlProduto)
      .filter((id: number) => NumberUtil.numberNullOrZero(id))
      .switchMap(() => this.getControl("produto", this.itProduto.formProduto$)
        .combineLatest(this.getControl("display", this.itProduto.formProduto$),
          (produtoPesquisa: AbstractControl, display: AbstractControl) => ({produtoPesquisa, display})))
      .subscribe((wrapper: { produtoPesquisa: AbstractControl, display: AbstractControl }) => {
        wrapper.produtoPesquisa.setValue("");
        wrapper.display.setValue("");
        this.itEmbalagem.clearItemsSource();
      });
  }

  /**
   * FIXME OSIEL Implementado apenas para variação, verificar a necessidade de implementar para numero de série.
   * Quando é necessário informar primeiro a quantidade para depois distribuir, será acionado esse evento.
   * Para isso verifica se vai distribuir e se a quantidade foi informada. Detroi o evento para não chamar
   * sozinho.
   */
  public blur(): void {
    this.distribuirQtdGrade$
      .combineLatest(this.itProduto.produtoSelecionado$, this.getValue(this.controlQuantidade),
        (distribuir: boolean, produto: Produto, quantidade: number) => ({distribuir, produto, quantidade}))
      .subscribe((obj: { distribuir: boolean, produto: Produto, quantidade: number }) => {
        if (obj.distribuir && obj.produto.possuiVariacao) {
          if (!NumberUtil.numberNullOrZero(obj.quantidade)) {
            this.quantidadeEsperada$.next(obj.quantidade);
            this.eventBlurQtd$.next();
          }
        } else {
          this.quantidadeEsperada$.next(0);
        }
      }).unsubscribe();
  }

  /**
   * Retorna o produto atual.
   * @return {Observable<Produto>}
   */
  public get produtoSelecionado$(): Observable<Produto> {
    return this.itProduto.produtoSelecionado$;
  }

  /**
   * Adiciona o validador e comportamento do componente de unidade de medida.
   */
  private addBehaviorsEmbalagem(): void {
    /**
     * Validador de UN
     */
    this.addSubscription(this.getControl(this.controlEmbalagem)
      .subscribe((embalagem: AbstractControl) => embalagem.setValidators([identificationRequiredValidator()])));

    /**
     * Recarrega a embalagem/unidade de medida a cada alteração de produto.
     * @type {Observable<URLSearchParams>}
     */
    this.urlParamsEmbalagem$ = this.itProduto.produtoSelecionado$
      .map((produto: Produto) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", produto.id.toString());
        params.set("tipos", this.tiposEmbalagem.join(","));
        return params;
      });

    /**
     * Desabilita a UN quando definido via parâmetro ou quando possuir apenas 1 item, o que significa que não tem embalagem.
     * @type {Observable<boolean>}
     */
    this.addSubscription(this.disableEmbalagem$
      .combineLatest(this.itProduto.produtoSelecionado$, this.urlParamsEmbalagem$, this.itEmbalagem.selectedItemChangePC,
        (disable: boolean, produto: Produto, params: URLSearchParams, change: any) =>
          disable || this.itEmbalagem.combobox.itemsSource.length <= 1)
      .startWith(true)
      .combineLatest(this.getControl(this.controlEmbalagem),
        (disable: boolean, control: AbstractControl) => ({disable, control}))
      .subscribe((obj: { disable: boolean, control: AbstractControl }) => obj.disable ? obj.control.disable() : obj.control.enable()));

    /**
     * Se não possuir embalagem ou se forçar a unidade do produto seta -1, pois ao invés de usar id de embalagem
     * será usado de unidade de medida conforme implementação do retaguarda.
     * Somente deve ser chamado uma vez quando o componente é carregado, por isso foi usado o afterLoad$.
     */
    this.addSubscription(this.itEmbalagem.afterLoad$
      .withLatestFrom(this.itProduto.produtoSelecionado$, this.getControl(this.controlEmbalagem), this.forcarUNProduto$,
        (change: any, produto: Produto, embalagem: AbstractControl, forcarUN: boolean) =>
          ({produto, embalagem, forcarUN}))
      .subscribe((wrapper: { produto: Produto, embalagem: AbstractControl, forcarUN: boolean }) =>
        wrapper.embalagem.setValue((wrapper.produto.embalagem && !wrapper.forcarUN) ? wrapper.produto.embalagem.id : -1)));


    /**
     * Atualiza a unidade de medida quando determinado a embalagem.
     */
    this.addSubscription(this.getValueChanges(this.controlEmbalagem)
      .withLatestFrom(this.itProduto.produtoSelecionado$, this.getControl(this.controlUN),
        (idEmbalagem: number, produto: Produto, unidade: AbstractControl) => ({unidade, produto}))
      .subscribe((wrapper: { unidade: AbstractControl, produto: Produto }) => {
        const embalagem: Embalagem = this.itEmbalagem.selectedItem;
        if (embalagem && !NumberUtil.numberNullOrZero(embalagem.id) && embalagem.id !== -1) {
          wrapper.unidade.setValue(embalagem.idUnidadeMedida);
        } else {
          wrapper.unidade.setValue(wrapper.produto.idUnidadeMedida);
        }
      }));

  }

  /**
   * Adiciona os comportamentos de quantidade.
   */
  private addBehaviorsQtd(): void {
    /**
     * Mínimo permitido.
     * @type {Observable<[any , any , any]> | Observable<any[]>}
     */
    this.minQtd$ = this.allowNumberZeroQtd$
      .combineLatest(this.allowNegativeNumbersQtd$,
        (allowZero: boolean, allowNegative) => allowNegative ? -999999999 : allowZero ? 0 : 0.000001);

    /**
     * Determina as decimais.
     * @type {Observable<number>}
     */
    this.decimaisQtd$ = this.getValueChanges(this.controlEmbalagem)
      .filter((idEmbalagem: number) => (!NumberUtil.numberNullOrZero(idEmbalagem) && !isNullOrUndefined(this.itEmbalagem.selectedItem)))
      .map(() => this.itEmbalagem.selectedItem.casasDecimais)
      .startWith(0);

    /**
     * Desabilita a quantidade.
     */
    this.addSubscription(this.disabledQuantidade$
      .combineLatest(this.getControl(this.controlQuantidade),
        (disable: boolean, control: AbstractControl) => ({disable, control}))
      .subscribe((wrapper: { disable: boolean, control: AbstractControl }) =>
        wrapper.disable ? wrapper.control.disable() : wrapper.control.enable()));

    /**
     * Adiciona o validador se não permite zero.
     */
    this.addSubscription(this.allowNumberZeroQtd$
      .combineLatest(this.allowNegativeNumbersQtd$, this.getControl(this.controlQuantidade),
        (allowZero: boolean, allowNegative: boolean, control: AbstractControl) => ({allowZero, allowNegative, control}))
      .subscribe((wrapper: { allowZero: boolean, allowNegative: boolean, control: AbstractControl }) => {
        wrapper.control.clearValidators();
        if (!wrapper.allowZero && !wrapper.allowNegative) {
          wrapper.control.setValidators([valueDifferentOfValidator(0)]);
        }
        wrapper.control.updateValueAndValidity();
      }));
  }

  /**
   * Preço.
   */
  private addBehaviorsPreco(): void {
    /**
     * Desabilita a quantidade.
     */
    this.addSubscription(this.disabledPreco$
      .combineLatest(this.exibirPreco$, this.getControl(this.controlPreco),
        (disable: boolean, exibirPreco: boolean, control: AbstractControl) =>
          ({disable: disable || !exibirPreco, control}))
      .subscribe((wrapper: { disable: boolean, control: AbstractControl }) =>
        wrapper.disable ? wrapper.control.disable() : wrapper.control.enable()));
  }

  /**
   * Total.
   */
  private addBehaviorsPrecoTotal(): void {
    /**
     * Desabilita a quantidade.
     */
    this.addSubscription(this.disabledPrecoTotal$
      .combineLatest(this.exibirPrecoTotal$, this.getControl(this.controlPrecoTotal),
        (disable: boolean, exibirPreco: boolean, control: AbstractControl) =>
          ({disable: disable || !exibirPreco, control}))
      .subscribe((wrapper: { disable: boolean, control: AbstractControl }) =>
        wrapper.disable ? wrapper.control.disable() : wrapper.control.enable()));
  }
}
