import { Component, ElementRef, Input, OnDestroy, OnInit } from "@angular/core";

import { Subscription } from "rxjs/Subscription";
import { SpinnerService } from "../services/spinner.service";
import { Observable } from "rxjs/Observable";

declare const Spinner: any;

/**
 * Spinner ver https://github.com/seanlmcgill/ng2spin
 */
@Component({
  selector: "it-spinner",
  templateUrl: "./spinner.component.html",
})
export class SpinnerComponent implements OnInit, OnDestroy {

  private spinner: any;
  public show = false;
  private element: any = null;
  private subscription: Subscription = null;

  @Input() private lines = 12; // The number of lines to draw
  @Input() private length = 20; // The length of each line
  @Input() private width = 12; // The line thickness
  @Input() private radius = 50; // The radius of the inner circle
  @Input() private scale = 1.0; // Scales overall size of the spinner
  @Input() private corners = 1; // Corner roundness (0..1)
  @Input() private color = "#fff"; // #rgb or #rrggbb or array of colors
  @Input() private opacity = 0.25; // Opacity of the lines
  @Input() private rotate = 0; // The rotation offset
  @Input() private direction = 1; // 1: clockwise, -1: counterclockwise
  @Input() private speed = 0.8; // Rounds per second
  @Input() private trail = 60; // Afterglow percentage
  @Input() private fps = 20; // Frames per second when using setTimeout() as a fallback for CSS
  @Input() private className = "spinner"; // The CSS class to assign to the spinner
  @Input() private top = "50%"; // Top position relative to parent
  @Input() private left = "50%"; // Left position relative to parent
  @Input() private shadow = true; // Whether to render a shadow
  @Input() private hwaccel = true; // Whether to use hardware acceleration
  @Input() private position = "absolute"; // Element positioning

  constructor(private spinnerElement: ElementRef,
              private spinnerService: SpinnerService) {
    this.element = spinnerElement.nativeElement;
  }

  public ngOnInit() {
    this.initSpinner();
    this.createServiceSubscription();
  }

  public ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  public startSpinner() {
    this.show = true;
    this.spinner.spin(this.element.firstChild);
  }

  public stopSpinner() {
    this.show = false;
    this.spinner.stop();
  }

  private initSpinner() {
    const options = {
      className: this.className,
      color: this.color,
      corners: this.corners,
      direction: this.direction,
      fps: this.fps,
      hwaccel: this.hwaccel,
      left: this.left,
      length: this.length,
      lines: this.lines,
      opacity: this.opacity,
      position: this.position,
      radius: this.radius,
      rotate: this.rotate,
      scale: this.scale,
      shadow: this.shadow,
      speed: this.speed,
      top: this.top,
      trail: this.trail,
      width: this.width,
      zIndex: 2e9, // Artificially high z-index to keep on top
    };
    this.spinner = new Spinner(options);
  }

  private createServiceSubscription() {
    this.subscription = this.spinnerService.spinnerObservable$
      .switchMap((show: boolean) => show ? Observable.of(show).debounceTime(1000) : Observable.of(show))
      .subscribe((show) => {
        if (show) {
          this.startSpinner();
        } else {
          this.stopSpinner();
        }
      });
  }
}
