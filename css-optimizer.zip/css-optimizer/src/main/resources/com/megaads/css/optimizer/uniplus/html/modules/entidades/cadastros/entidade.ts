import { FormBuilder, FormGroup } from "@angular/forms";

import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumSimNao, EnumUtils } from "../../../core/enuns/enumutil";
import { ConfiguracaoCartaoFidelidade } from "../configuracoes-cartao-fidelidade/configuracao-cartao-fidelidade";
import { PaiDependente } from "./clientes/dependentes/pai-dependente";
import { Contato } from "./utils/contato";
import { Endereco } from "./utils/endereco";

/**
 * Pojo Entidade
 * Created by Osiel S. Mello on 16/05/2017.
 */
export class Entidade extends AbstractPojo {
  public cliente = 0;
  public fornecedor = 0;
  public transportadora = 0;
  public representante = 0;
  public tecnico = 0;
  public comprador = 0;
  public fabricante = 0;
  public motorista = 0;
  public portador = 0;
  public entregador = 0;
  public idIncentivofiscal = 0;
  // TODO OSIEL DATA
  public dataCadastro: Date = new Date();
  public nome = "";
  public razaoSocial = "";
  public tipoPessoa: TipoPessoa = TipoPessoa.FISICA[EnumUtils.id];
  public tipoContribuinte: TipoContribuinte = TipoContribuinte.NAO_CONTRIBUINTE[EnumUtils.id];
  public cnpjCpf = "";
  public inscricaoEstadual = "";
  public inscricaoSuframa = "";
  public inscricaoMunicipal = "";
  public rg = "";
  public telefone = "";
  public celular = "";
  public fax = "";
  public email = "";
  public emailComprador = "";
  public site = "";
  public emailFaturamento = "";
  public emailFaturamentoCopia = "";
  public emailFinanceiro = "";
  public emailTecnico = "";
  public emailCotacao = "";
  public limiteCredito = 0;
  public renda = 0;
  public creditoRestrito = 0;
  public creditoRestritoOriginal = 0;
  public imagem: any = null;
  public caminhoImagem = "";
  public idRepresentante = 0;
  public idRepresentante2 = 0;
  public idRepresentante3 = 0;
  public idTabelaPreco = 0;
  public idCondicaoPagamento = 0;
  public idPlanoContas = 0;
  public comissao = 0;
  public comissaoAVista = 0;
  public comissaoAPrazo = 0;
  public comissaoQuitacao = 0;
  public valorLimiteDesconto = 0;
  public transmiteLimiteDescontoNeg = false;
  public extra1 = "";
  public extra2 = "";
  public extra3 = "";
  public extra4 = "";
  public extra5 = "";
  public extra6 = "";
  public extra7 = "";
  public extra8 = "";
  public extra9 = "";
  public extra10 = "";
  public extra11 = "";
  public extra12 = "";
  public extra13 = "";
  public extra14 = "";
  public extra15 = "";
  public extra16 = "";
  public observacao = "";
  public nascimento: Date = new Date();
  public idCidadeNatural = 0;
  public idEstadoNatural = 0;
  public estadoCivil: EstadoCivil = EstadoCivil.NAO_IDENTIFICADO[EnumUtils.id];
  public sexo: Sexo = Sexo.INDEFINIDO[EnumUtils.id];
  public conjuge = "";
  public pai = "";
  public mae = "";
  public inativo = false;
  public profissao = "";
  public localTrabalho = "";
  public telefoneTrabalho = "";
  public placaVeiculo = "";
  public idEstadoVeiculo = 0;
  public veiculoProprio = false;
  public destacarIcmsSt = 0;
  public registroImportado = 0;
  public idUltimoTipoDocFinanceiro = 0;
  public pautaPreco = 0;
  public diaVencimento = 0;
  public diaLimite = 0;
  public tipoEnquadramento: TipoEnquadramentoEntidade = TipoEnquadramentoEntidade.NENHUM[EnumUtils.id];
  public idRegiao = 0;
  public limiteCreditoEspecial = 0;
  public validadeInicialCreditoEspecial: Date = new Date();
  public validadeFinalCreditoEspecial: Date = new Date();
  public liberarClienteComAtraso = false;
  public codigoApogeus = "";
  public rntrcTransportador = "";
  public idOperacaoFiscal = 0;
  public pertenceFilial = false;
  public idTransportadora = 0;
  public idTipoDocumentoFinanceiro = 0;
  public produtorRural = false;
  public idRota = 0;
  public idTipoEntidadeOpFiscal = 0;
  public cartaoFidelidade = false;
  public senhaCartaoFidelidade = "";

  // Transient
  public cadastrarSenha = false;
  public senhaCartao1 = "";
  public senhaCartao2 = "";

  // cadastro de motorista
  public numeroCnh = "";
  public categoriaCnh = "";
  public dataEmissaoCnh: Date = new Date();
  public dataValidadeCnh: Date = new Date();

  // panel historico
  public saldoAdiantamento = 0;
  public saldoPrePago = 0;

  // Dados da pauta de preco
  public comissaoPauta1 = 0;
  public comissaoPauta2 = 0;
  public comissaoPauta3 = 0;
  public comissaoPauta4 = 0;
  public comissaoAVistaPauta1 = 0;
  public comissaoAVistaPauta2 = 0;
  public comissaoAVistaPauta3 = 0;
  public comissaoAVistaPauta4 = 0;
  public comissaoAPrazoPauta1 = 0;
  public comissaoAPrazoPauta2 = 0;
  public comissaoAPrazoPauta3 = 0;
  public comissaoAPrazoPauta4 = 0;
  public comissaoQuitacaoPauta1 = 0;
  public comissaoQuitacaoPauta2 = 0;
  public comissaoQuitacaoPauta3 = 0;
  public comissaoQuitacaoPauta4 = 0;
  public idTipoComissao = 0;
  public tipoAvisoFinalizarOS: TipoAvisoFinalizacaoOS = TipoAvisoFinalizacaoOS.NENHUM[EnumUtils.id];

  // NFS-e
  public tipoTomadorServico: TipoTomadorServico = TipoTomadorServico.NENHUM[EnumUtils.id];
  // Gnio poliamazon
  public codigoUser = "";
  public idUsuarioVendedor = 0;
  public codigoECommerce = "";
  public leadTimeCompra = 0;
  public idFilialCadastro = 0;
  public idUsuarioInclusao = 0;
  public dataHoraInclusao: Date;
  public idUsuarioAlteracao = 0;
  public dataHoraAlteracao: Date;
  public codigoCaptacao = 0;
  public informacaoPdv = "";
  public trote = false;
  public troteObs = "";
  public registradoSpc: EnumSimNao = EnumSimNao.NAO[EnumUtils.id];

  /**
   * Utilizado apenas na alteração de entidade na inclusão de licenças
   */
  public naoValidarQuantidadeRegistros = false;
  public cidade = "";
  public estado = "";

  public endereco: FormGroup = new FormBuilder().group(new Endereco());
  public contato: FormGroup = new FormBuilder().group(new Contato());
  public enderecoEntrega: FormGroup = new FormBuilder().group(new Endereco());
  public contatoEntrega: FormGroup = new FormBuilder().group(new Contato());
  public enderecoCobranca: FormGroup = new FormBuilder().group(new Endereco());
  public contatoCobranca: FormGroup = new FormBuilder().group(new Contato());
  public enderecoTrabalho: FormGroup = new FormBuilder().group(new Endereco());

  // CONFIGURAÇÕES ADD
  public configuracoesAdicionaisEntidade: ConfiguracaoCartaoFidelidade = new ConfiguracaoCartaoFidelidade();

  // Campos transientes para grid
  public nomeEstado = "";
  public nomeCidade = "";
}

export interface ConfiguracoesAdicionaisEntidade {
  paiDependente: PaiDependente;
  cartaoFidelidade: ConfiguracaoCartaoFidelidade;
}

export enum TipoPessoa  {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  FISICA = <any> {[EnumUtils.id]: "FISICA", [EnumUtils.display]: "Física"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  JURIDICA = <any> {[EnumUtils.id]: "JURIDICA", [EnumUtils.display]: "Jurídica"},
}

export enum TipoContribuinte  {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  CONTRIBUINTE_ICMS = <any> {
    [EnumUtils.id]: "CONTRIBUINTE_ICMS",
    [EnumUtils.display]: "Contribuinte ICMS",
    consumidorFinal: false,
    ieObrigatoria: true,
    possuiIEPF: true,
    possuiIEPJ: true,
  },
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  CONTRIBUINTE_ISENTO = <any> {
    [EnumUtils.id]: "CONTRIBUINTE_ISENTO",
    [EnumUtils.display]: "Contribuinte Isento",
    consumidorFinal: false,
    ieObrigatoria: false,
    possuiIEPF: false,
    possuiIEPJ: false,
  },
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  NAO_CONTRIBUINTE = <any> {
    [EnumUtils.id]: "NAO_CONTRIBUINTE",
    [EnumUtils.display]: "Não contribuinte",
    consumidorFinal: true,
    ieObrigatoria: false,
    possuiIEPF: false,
    possuiIEPJ: true,
  },
}

export enum EstadoCivil  {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  CASADO = <any> {[EnumUtils.id]: "CASADO", [EnumUtils.display]: "Casado(a)"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  SOLTEIRO = <any> {[EnumUtils.id]: "SOLTEIRO", [EnumUtils.display]: "Solteiro(a)"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  DIVORCIADO = <any> {[EnumUtils.id]: "DIVORCIADO", [EnumUtils.display]: "Divorciado(a)"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  DESQUITADO = <any> {[EnumUtils.id]: "DESQUITADO", [EnumUtils.display]: "Desquitado(a)"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  VIUVO = <any> {[EnumUtils.id]: "VIUVO", [EnumUtils.display]: "Viúvo(a)"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  AMASIADO = <any> {[EnumUtils.id]: "AMASIADO", [EnumUtils.display]: "Amasiado(a)"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  NAO_IDENTIFICADO = <any> {[EnumUtils.id]: "NAO_IDENTIFICADO", [EnumUtils.display]: "Não identificado"},
}

export enum Sexo  {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  INDEFINIDO = <any> {[EnumUtils.id]: "INDEFINIDO", [EnumUtils.display]: "Indefinido"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  MASCULINO = <any> {[EnumUtils.id]: "MASCULINO", [EnumUtils.display]: "Feminino"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  FEMININO = <any> {[EnumUtils.id]: "FEMININO", [EnumUtils.display]: "Masculino"},
}

export enum TipoEnquadramentoEntidade {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  NENHUM = <any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Nenhum"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  LUCROREAL = <any> {[EnumUtils.id]: "LUCROREAL", [EnumUtils.display]: "Lucro real"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  LUCROPRESUMIDO = <any> {[EnumUtils.id]: "LUCROPRESUMIDO", [EnumUtils.display]: "Lucro presumido"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  SIMPLESNACIONAL = <any> {[EnumUtils.id]: "SIMPLESNACIONAL", [EnumUtils.display]: "Simples nacional"},
}

export enum TipoAvisoFinalizacaoOS {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  NENHUM = <any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Nenhum"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  EMAIL = <any> {[EnumUtils.id]: "EMAIL", [EnumUtils.display]: "E-mail"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  SMS = <any> {[EnumUtils.id]: "SMS", [EnumUtils.display]: "SMS"},
}

export enum TipoTomadorServico  {
  // tslint:disable-next-line:no-angle-bracket-type-assertion
  NENHUM = <any> {[EnumUtils.id]: EnumUtils.undefined, [EnumUtils.display]: "Nenhum"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  UTROS = <any> {[EnumUtils.id]: "UTROS", [EnumUtils.display]: "Outros"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  SUS = <any> {[EnumUtils.id]: "SUS", [EnumUtils.display]: "SUS"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  ORGAO_PODER_EXECUTIVO = <any> {
    [EnumUtils.id]: "ORGAO_PODER_EXECUTIVO", [EnumUtils.display]: "Órgão do poder executivo",
  },
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  BANCO = <any> {[EnumUtils.id]: "BANCO", [EnumUtils.display]: "Banco"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  COMERCIO_INDUSTRIA = <any> {[EnumUtils.id]: "COMERCIO_INDUSTRIA", [EnumUtils.display]: "Comércio / Indústria"},
    // tslint:disable-next-line:no-angle-bracket-type-assertion
  PODER_LEGISLATIVO_JUDICIARIO = <any> {
    [EnumUtils.id]: "PODER_LEGISLATIVO_JUDICIARIO", [EnumUtils.display]: "Poder Legislativo / Judiciário",
  },
}

export enum TipoEntidade {
  TODOS = <any> {[EnumUtils.id]: "TODOS", [EnumUtils.display]: "Todos", extra: "", url: ""},
  CLIENTE = <any> {[EnumUtils.id]: "CLIENTE", [EnumUtils.display]: "Clientes", extra: "cad_cliente", url: "clientes"},
  FORNECEDOR = <any> {
    [EnumUtils.id]: "FORNECEDOR",
    [EnumUtils.display]: "Fornecedores",
    extra: "cad_fornecedor",
    url: "fornecedores",
  },
  TRANSPORTADORA = <any> {
    [EnumUtils.id]: "TRANSPORTADORA",
    [EnumUtils.display]: "Transportadoras",
    extra: "cad_transportadora",
    url: "transportadoras",
  },
  REPRESENTANTE = <any> {
    [EnumUtils.id]: "REPRESENTANTE",
    [EnumUtils.display]: "Vendedores",
    extra: "cad_representante",
    url: "representantes",
  },
  TECNICO = <any> {[EnumUtils.id]: "TECNICO", [EnumUtils.display]: "Técnicos", extra: "cad_tecnico", url: "tecnicos"},
  COMPRADOR = <any> {
    [EnumUtils.id]: "COMPRADOR",
    [EnumUtils.display]: "Compradores",
    extra: "cad_comprador",
    url: "compradores",
  },
  FABRICANTE = <any> {
    [EnumUtils.id]: "FABRICANTE",
    [EnumUtils.display]: "Fabricantes",
    extra: "cad_fabricante",
    url: "fabricantes",
  },
  MOTORISTA = <any> {
    [EnumUtils.id]: "MOTORISTA",
    [EnumUtils.display]: "Motoristas",
    extra: "cad_motorista",
    url: "motoristas",
  },
  GARCOM = <any> {[EnumUtils.id]: "GARCOM", [EnumUtils.display]: "Garçons", extra: "cad_garcom", url: "garcons"},
  PORTADOR = <any> {
    [EnumUtils.id]: "PORTADOR",
    [EnumUtils.display]: "Portadores",
    extra: "cad_portador",
    url: "portadores",
  },
  ENTREGADOR = <any> {
    [EnumUtils.id]: "ENTREGADOR",
    [EnumUtils.display]: "Entregadores",
    extra: "cad_entregador",
    url: "entregadores",
  },
}
