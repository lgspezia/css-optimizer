import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, FormControl, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { applicationInjector } from "../../../app.module";
import { TipoContribuinte } from "../../../modules/entidades/cadastros/entidade";
import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { StringUtil } from "../../utils/string.util";
import { ItInputTextComponent } from "../primitive/it-inputtext.component";

/**
 * Componente de Inscrição Estadual
 * Created by Osiel S. Mello on 19/05/2017.
 */
@Component({
  selector: "it-inscricaoestadual-inputtext",
  templateUrl: "../primitive/it-inputtext.component.html",
})
export class ItInscricaoEstadualInputTextComponent extends ItInputTextComponent implements OnInit {
  @Input() public permitirIsento: boolean;
  @Input() public pessoaFisica: boolean;
  @Input() public tipoContribuinte$: Observable<string>;

  /**
   * Em alguns casos podemos ter estado dentro de form de endereço ou outro form.
   */
  @Input() public controlEstado$: Observable<AbstractControl>;

  constructor() {
    super();
    this.len = 20;
    this.label = "Insc Estadual";
    this.permitirIsento = false;
    this.pessoaFisica = true;

    this.controlEstado$ = null;
  }

  public ngOnInit(): void {
    if (this.tipoContribuinte$) {
      this.addSubscription(this.tipoContribuinte$
        .combineLatest(this.getControl(), (tipo: string, control: AbstractControl) => ({tipo, control}))
        .subscribe((wrapper: { tipo: string, control: AbstractControl }) => {
          const constante: any = TipoContribuinte[wrapper.tipo];

          if (constante[`ieObrigatoria`]) {
            wrapper.control.setValidators([Validators.required, Validators.maxLength(this.len)]);
          } else {
            wrapper.control.setValidators([Validators.maxLength(this.len)]);
          }
          wrapper.control.setAsyncValidators([validarIE(this.permitirIsento, `entidades/validar-ie`, this.controlEstado$)]);

          if (!constante[`${this.pessoaFisica ? "possuiIEPF" : "possuiIEPJ"}`]) {
            wrapper.control.setValue("");
            wrapper.control.disable();
          } else {
            wrapper.control.enable();
          }
        }));
    }

    /**
     * Caso o campo esteja desabilitado, seta vazio como valor, para seguir a validaçãoa acima.
     */
    this.addSubscription(this.getValueChanges()
      .filter((value: string) => !StringUtil.stringNullOrEmpty(value))
      .combineLatest(this.getControl(), (value: string, control: AbstractControl) => control)
      .filter((control: AbstractControl) => control.disabled)
      .subscribe((control: AbstractControl) => control.setValue("")));
  }

}

/**
 * Validador de IE.
 * @param permitirIsento: boolean
 * @param endPoint: string
 * * @param controlEstado$: Observable<AbstractControl> Não é obrigatório informar esse campo. Só utilizado em subforms.
 * @return {(formControl:FormControl)=>any}
 */
export function validarIE(permitirIsento: boolean, endPoint: string, controlEstado$?: Observable<AbstractControl>) {
  return (formControl: FormControl) => {

    const params: URLSearchParams = new URLSearchParams();
    params.set("value", formControl.value.toString());
    params.set("permitirIsento", permitirIsento.toString());

    const controlCodigo: AbstractControl = formControl.parent.get("codigo");
    params.set("codigo", controlCodigo ? controlCodigo.value : null);

    if (controlEstado$) {
      return controlEstado$
        .switchMap((control: AbstractControl) => {

          if (StringUtil.stringNullOrEmpty(formControl.value)) {
            return Observable.of(null);
          }
          params.set("idEstado", control.value);

          return applicationInjector.get(HttpService).get(endPoint, {search: params})
            .map(() => null)
            .catch((error: ServerError) => Observable.of({ieValidator: `${error.codigo} - ${error.mensagem}`}));
        }).first();
    } else {
      return new Observable((observer) => {
        if (StringUtil.stringNullOrEmpty(formControl.value)) {
          observer.next(null);
          return;
        }

        const estado: AbstractControl = formControl.parent.get("idEstado");
        params.set("idEstado", estado.value);

        applicationInjector.get(HttpService).get(endPoint, {search: params})
          .subscribe(() => observer.next(null),
            (error: ServerError) => observer.next({ieValidator: `${error.codigo} - ${error.mensagem}`}));

      }).first();
    }
  };
}
