import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { ItFormTableComponent } from "../../../core/components/primitive/it-formtable.component";
import { ICellEditTable } from "../../../core/crud/cell-edit-table";
import { ColumnDefinition } from "../../../core/crud/column-definition";
import { FormComponent } from "../../../core/crud/form-component";
import { Modo } from "../../../core/crud/grid.crud";
import { IParamsData } from "../../../core/crud/param-data";
import { uniqueAsyncValidator } from "../../../core/crud/validadores";
import { ServerError } from "../../../core/models/server-error";
import { NumberUtil } from "../../../core/utils/number.util";
import { StringUtil } from "../../../core/utils/string.util";
import { Grade, GradeValorWrapper } from "./grade";
import { GradeValor } from "./grade-valor";

/**
 * Grades
 *
 * @author Osiel.
 */
@Component({
  selector: "it-grade",
  templateUrl: "grade.form.component.html",
})
export class ItGradeFormComponent extends FormComponent implements OnInit {
  private static LIMITE_GRADE = 99;

  @Input() public afterGet$: Observable<number>;
  @Input() public cancelVisible$: Observable<boolean>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;

  public formValor$: BehaviorSubject<FormGroup>;

  public params$: Observable<IParamsData>;

  private submitItem$: Subject<GradeValorWrapper>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<GradeValor>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super();
    this.submitItem$ = new Subject();
  }

  public ngOnInit(): void {
    this.formValor$ = new BehaviorSubject(new FormBuilder().group(new GradeValor()));

    /**
     * Ao incluir o primeiro item em modo de criação o botão cancelar deve ser oculto.
     * @type {Observable<boolean>}
     */
    this.cancelVisible$ = this.isCreate$()
      .combineLatest(this.itFormTable.afterSubmit$, (create: boolean, after: GradeValor) => !create)
      .startWith(true);

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idGradeValor", "idGradeValor", DataType.Number, 0, null, false),
      new ColumnDefinition("ordem", "ordem", DataType.Number, 0, null, false),
      new ColumnDefinition("valor", "Valor", DataType.String, "*"),
      new ColumnDefinition("inativo", "Inativo", DataType.Boolean, 100, null, true, null, null, null, true),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idGrade", id.toString());
        return {endpoint: "grades/buscar-valores", search: params};
      });

    /**
     * Inicializa a table quando em modo de inclusao.
     */
    this.addSubscription(this.isCreate$()
      .filter((create: boolean) => create)
      .subscribe(() => this.itFormTable.updateItemsSource(null)));

    /*
     * -------------------------------------------------------------------------------------------------------------------------------------
     * Validators                                                                                                                    |
     * -------------------------------------------------------------------------------------------------------------------------------------
     */
    this.addSubscription(this.getControl("codigo")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(20)]);
        control.setAsyncValidators([uniqueAsyncValidator("grades")]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("descricao")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(100)]);
        control.setAsyncValidators([valueValidate(this.itFormTable, this.modo$)]);
      }));

    this.addSubscription(this.getControl("valor", this.formValor$)
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(60)]);
        control.setAsyncValidators([gradeValorAsyncValidate(this.itFormTable)]);
      }));


    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo. Push dos valores para grade.
     */
    this.addSubscription(this.itFormTable.afterLoadData$
      .combineLatest(this.getControl("valores"),
        (after, valores: AbstractControl) => valores)
      .subscribe((valores: AbstractControl) => {

        const valoresGrade: GradeValor[] = [];
        this.itFormTable.sourceCollection.forEach((grade: GradeValor) => {
          if (grade.id) {
            grade.id = NumberUtil.parseFloat(grade.id.toString());
          }
          if (grade.idGrade) {
            grade.idGrade = NumberUtil.parseFloat(grade.idGrade.toString());
          }

          valoresGrade.push(grade);
        });
        valores.setValue(valoresGrade);
      }));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((gradeValor: GradeValor) => gradeValorAsyncValidator$(this.itFormTable, gradeValor.valor, gradeValor.id)
        .combineLatest(this.form$, (validate: { gradeValid: string }, formGrade: FormGroup) =>
          ({gradeValor, validate, formGrade})))
      .subscribe((obj: { gradeValor: GradeValor, validate: { gradeValid: string }, formGrade: FormGroup }) => {

        if (obj.formGrade.get("codigo").invalid || StringUtil.stringNullOrEmpty(obj.formGrade.get("descricao").value)) {
          this.itFormTable.handleError({
            status: null,
            codigo: "WWW90",
            mensagem: "Existem campos inválidos. Por favor verifique!",
          });
          return;
        }

        if (obj.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validate.gradeValid));
          return;
        }

        const grade: Grade = obj.formGrade.value;

        if (NumberUtil.numberNullOrZero(grade.id)) {

          if (this.itFormTable.sourceCollection.length + 1 > ItGradeFormComponent.LIMITE_GRADE) {
            this.itFormTable.handleError({
              status: null,
              codigo: "PRD103",
              mensagem: "O limite definido para a grade é de 99 x 99. Não é possível adicionar novos valores.",
            });
            return;
          }

          const gradeWrapper: GradeValorWrapper = new GradeValorWrapper();
          gradeWrapper.gradeValor.valor = obj.gradeValor.valor;
          gradeWrapper.grade = grade;

          this.submitItem$.next(gradeWrapper);
        } else {
          obj.gradeValor.idGrade = grade.id;
          this.itFormTable.submit$.next(obj.gradeValor);
        }

      }, (error) => this.itFormTable.handleError(new ServerError(null, "WWW91", "Não foi possível executar a ação"))));

    /**
     * Post de cabeçalho e item.
     */
    this.addSubscription(this.submitItem$
      .switchMap((grade: GradeValorWrapper) => {
        this.itFormTable.spinnerService.show();
        return this.itFormTable.httpService.post(`grades/incluir`, grade)
          .combineLatest(this.getControl("id"), this.getControl("codigo"),
            (resp: { id: number, idItem: number }, controlId: AbstractControl, codigo: AbstractControl) =>
              ({resp, grade, controlId, codigo}));
      })
      .subscribe((wrapper: {
        resp: { id: number, idItem: number }, grade: GradeValorWrapper, controlId: AbstractControl, codigo: AbstractControl,
      }) => {

        wrapper.grade.gradeValor.id = wrapper.resp.idItem;
        wrapper.grade.gradeValor.idGrade = wrapper.resp.id;
        this.itFormTable.push(wrapper.grade.gradeValor);
        this.itFormTable.spinnerService.hide();
        this.itFormTable.success("A inclusão foi feita com sucesso");
        this.itFormTable.afterSubmit$.next(wrapper.grade.gradeValor);
        this.itFormTable.clear$.next();

        wrapper.controlId.setValue(wrapper.resp.id);
        wrapper.codigo.disable();
      }, (error: ServerError) => {
        this.itFormTable.spinnerService.hide();
        this.itFormTable.clear$.next();
        this.itFormTable.handleError(error);
      }));

    /**
     * Atualiza os valores a serem passados via parâmetro.
     */
    this.addSubscription(this.itFormTable.afterSubmit$
      .combineLatest(this.getControl("valores"), this.getControl("descricao"),
        (grade: GradeValor, valores: AbstractControl, descricao: AbstractControl) => ({valores, descricao}))
      .subscribe((wrapper: { valores: AbstractControl, descricao: AbstractControl }) => {

        const valores: GradeValor[] = [];
        this.itFormTable.sourceCollection.forEach((valor: GradeValor) => valores.push(valor));
        wrapper.valores.setValue(valores);
        wrapper.descricao.updateValueAndValidity();
      }));

    /**
     * Limpa o form.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new GradeValor())));

    /**
     * Observable para ação de edição de checkboxs.
     */
    this.addSubscription(this.itFormTable.edit$()
      .switchMap((edit: ICellEditTable<GradeValor>) => {
        this.itFormTable.spinnerService.show();
        return this.itFormTable.put(`valores-grades`, edit.pojo)
          .map(() => ({edit, error: null}))
          .catch((error: ServerError) => Observable.of({edit, error}));
      })
      .subscribe((wrapper: { edit: ICellEditTable<GradeValor>, error: ServerError }) => {
        if (wrapper.error) {
          this.itFormTable.handleError(wrapper.error);
          wrapper.edit.pojo.inativo = wrapper.edit.oldValue;
        } else {
          this.itFormTable.success(`Registro ${wrapper.edit.pojo.inativo ? "inativado" : "ativado"}.`);
        }
        this.itFormTable.clearChanges();
        this.itFormTable.spinnerService.hide();
      }));
  }

}

/**
 * Só deve estar válido se possuir valores na table.
 * @param {ItFormTableComponent<GradeValor>} itFormTable
 * @param modo$: Observable<Modo>
 * @return {() => Observable<{invalidValues: string}>}
 */
function valueValidate(itFormTable: ItFormTableComponent<GradeValor>, modo$: Observable<Modo>) {
  return () => {
    return itFormTable
      .afterLoadData$
      .startWith(true)
      .combineLatest(modo$, (after, modo: Modo) =>
        itFormTable.sourceCollection.length === 0 && modo === Modo.CREATE ?
          {invalidValues: "WWW94 - Por favor informe os valores da grade."} : null)
      .first();
  };
}

/**
 * Funçao de validaçao de valor.
 *
 * @param itFormTable: tFormTableComponent<GradeValor>
 * @return {(control:FormControl)=>{gradeValid: string}}
 */
function gradeValorAsyncValidate(itFormTable: ItFormTableComponent<GradeValor>) {
  return (control: FormControl) => {
    return gradeValorAsyncValidator$(itFormTable,
      control.value,
      control.parent.get("id").value,
    );
  };
}

/**
 * Valida a existência de valor na table.
 *
 * @param valor: string
 * @param id: number
 * @param itTable: ItFormTableComponent<GradeValor>
 * @return {{gradeValid: string}}
 */
function gradeValorAsyncValidator$(itTable: ItFormTableComponent<GradeValor>,
                                   valor: string, id: number): Observable<{ gradeValid: string }> {
  return itTable
    .afterLoadData$
    .startWith(true)
    .map(() => {
      const registroExiste: boolean = itTable.sourceCollection
        .some((grade: GradeValor) => grade.valor.trim().toUpperCase() === valor.trim().toUpperCase() &&
          (NumberUtil.numberNullOrZero(id) || NumberUtil.parseFloat(id.toString()) !== grade.id));

      return registroExiste ? {gradeValid: `PRD218 - O valor ${valor} já existe. Verifique!`} : null;
    }).first();
}
