import { Component, EventEmitter, forwardRef, HostListener, Input, OnInit, Output } from "@angular/core";
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";

import { BehaviorSubject } from "rxjs/BehaviorSubject";

import { BaseFormComponent } from "./baseform.component";

const UI_SWITCH_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => ItUiSwitchComponent),
  multi: true
};

@Component({
  selector: "it-ui-switch",
  templateUrl: "it-ui-switch-controlvalue.component.html",
  providers: [UI_SWITCH_CONTROL_VALUE_ACCESSOR]
})
export class ItUiSwitchComponent extends BaseFormComponent implements ControlValueAccessor, OnInit {
  @Input() public size: string;
  @Input() public color = "#6f9508";
  @Input() public defaultBgColor = "#fff";
  @Input() public switchColor = "#fff";
  @Input() public switchOffColor: string;
  @Input() public conditionOn: string;
  @Input() public conditionOff: string;
  @Input() public col: number;
  @Input() public conditionInit: boolean;
  @Input() public disableSwitch: boolean;

  @Output() public change = new EventEmitter<boolean>();

  public label$: BehaviorSubject<string>;
  private _checked: boolean;
  private _unchecked: boolean;
  private _reverse: boolean;
  private defaultBoColor = "#0041A0";

  constructor() {
    super();
    this.conditionInit = true;
    this.col = 3;
    this.size = "medium";
    this.switchOffColor = "";
  }

  public ngOnInit(): void {
    /**
     * Seta o default inicial.
     * @type {BehaviorSubject}
     */
    this.label$ = new BehaviorSubject(this.conditionInit ? this.conditionOn : this.conditionOff);
    this.checked = this.conditionInit;

    /**
     * Determina o label de acordo com o valor setado.
     */
    this.change.subscribe((on) => this.label$.next(on ? this.conditionOn : this.conditionOff));
  }

  @Input()
  public set checked(v: boolean) {
    this._checked = v !== false;
  }

  public get checked(): boolean {
    return this._checked;
  }

  @Input()
  public set unchecked(v: boolean) {
    this._unchecked = v !== false;
  };

  public get unchecked(): boolean {
    return this._unchecked;
  }

  @Input()
  public set reverse(v: boolean) {
    this._reverse = v !== false;
  };

  public get reverse(): boolean {
    return this._reverse;
  }

  public getColor(flag?: string): string {
    if (flag === "borderColor") {
      return this.defaultBoColor;
    }
    if (flag === "switchColor") {
      if (this.reverse) {
        return !this.checked ? this.switchColor : this.switchOffColor || this.switchColor;
      }
      return this.checked ? this.switchColor : this.switchOffColor || this.switchColor;
    }
    if (this.reverse) {
      return !this.checked ? this.color : this.defaultBgColor;
    }
    return this.checked ? this.color : this.defaultBgColor;
  }

  @HostListener("click")
  public onToggle(): void {
    if (this.unchecked || this.disableSwitch) {
      return;
    }
    this.checked = !this.checked;
    this.change.emit(this.checked);
    this.onChangeCallback(this.checked);
    this.onTouchedCallback(this.checked);
  }

  public writeValue(obj: any): void {
    if (obj !== this.checked) {
      this.checked = !!obj;
      this.change.emit(this.checked);
    }
  }

  public registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }

  public registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }

  private onTouchedCallback = (v: any) => { };
  private onChangeCallback = (v: any) => { };

}
