import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { AjusteDocumentoFiscal } from "../../../modules/speds/ajustes-documento-fiscal/ajuste-documento-fiscal";
/**
 * @author Luan  on 08/06/2017.
 */
@Component({
  selector: "it-ajuste-documento-fiscal-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItAjusteDocumentoFiscalAutoCompleteComponent extends ItAutocompleteComponent<AjusteDocumentoFiscal> {

  // TODO-LUAN Fazer um template par o autoComplete carregar uma grid de informações
  constructor(httpService: HttpService) {
    super(httpService);

    this.url = "ajustes-documento-fiscal";
    this.display = "codigo";
    this.label = "Ajuste documento fiscal";
  }
}
