import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { WjPopup } from "wijmo/wijmo.angular2.input";

import { Produto } from "../../../../modules/produtos/produto";
import { AbstractPojo } from "../../../crud/pojo";
import { EnumSimNao, EnumUtils } from "../../../enuns/enumutil";
import { HttpService } from "../../../services/http.service";
import { ArrayUtil } from "../../../utils/array.util";
import { NumberUtil } from "../../../utils/number.util";
import { StringUtil } from "../../../utils/string.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItProdutoPromptPopupComponent } from "./it-produto-prompt-popup";


/**
 * TODO OSIEL NÂO ESTA FUNCIONANDO QUANDO SELECIONADO DE PROMPT GRADE NUMERO SERIE E LOTE
 * Componente de pesquisa de produtos (Prompt).
 *
 * @author Osiel.
 */
@Component({
  selector: "it-produto-prompt",
  templateUrl: "it-produto-prompt.component.html",
})
export class ItProdutoPromptComponent extends BaseFormComponent implements OnInit {
  @Input() public promptProduto: string;
  @Input() public initPojo: AbstractPojo;
  @Input() public reloadProduto$: Subject<boolean>;

  public formProduto$: BehaviorSubject<FormGroup>;
  public produtosPesquisados$: BehaviorSubject<{ query?: string, produtos?: Produto[] }>;
  public eventBlur$: EventEmitter<any>;

  @ViewChild(WjPopup) private popup: WjPopup;
  @ViewChild(ItProdutoPromptPopupComponent) private promptPesquisa: ItProdutoPromptPopupComponent;
  private _produtoSelecionado$: BehaviorSubject<Produto>;

  constructor(private formBuilder: FormBuilder, private httpService: HttpService) {
    super();
    this.eventBlur$ = new EventEmitter();
    this.produtosPesquisados$ = new BehaviorSubject({});
    this._produtoSelecionado$ = new BehaviorSubject(undefined);
    this.reloadProduto$ = new Subject();
  }

  /**
   * Inicializa as propriedades do form.
   */
  public ngOnInit(): void {
    this.formProduto$ = new BehaviorSubject(this.formBuilder
      .group({
        produto: "",
        pesquisar: "",
        display: "",
      }));

    this.addSubscription(this.getControl("produto", this.formProduto$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required])));
    this.addSubscription(this.getControl("display", this.formProduto$)
      .subscribe((c: AbstractControl) => c.disable()));

    /**
     * Marca o componente interno como touched mas sempre validar.
     */
    this.addSubscription(this.getValueChanges("produto", this.formProduto$)
      .switchMap(() => this.getControl())
      .filter((c: AbstractControl) => !c.touched)
      .subscribe((c: AbstractControl) => c.markAsTouched()));

    /**
     * Desabilita o componente quando o form principal for deabilitado.
     */
    this.addSubscription(this.form$
      .filter((form: FormGroup) => form.disabled)
      .switchMap((form: FormGroup) => this.formProduto$)
      .subscribe((form: FormGroup) => form.disable()));

    /**
     * Quando limpar o componente de pesquisa, é necessário limpar também o valor anterior.
     */
    this.addSubscription(this.getValueChanges("produto", this.formProduto$)
      .filter((value: string) => StringUtil.stringNullOrEmpty(value))
      .subscribe((v) => this._produtoSelecionado$.next(undefined)));

    /**
     * Quando o produto, é necessário limpar também o valor anterior.
     */
    this.addSubscription(this.getValueChanges()
      .filter((value: number) => NumberUtil.numberNullOrZero(value))
      .subscribe(() => this._produtoSelecionado$.next(undefined)));

    this.addSubscription(this.reloadProduto$
      .withLatestFrom(this.getValueChanges(), (reload: boolean, id: number) => id)
      .filter((id: number) => !NumberUtil.numberNullOrZero(id))
      .switchMap((id: number) => this.httpService.get(`produtos/${id}`)
        .combineLatest(this.getControl("produto", this.formProduto$), this.getControl("display", this.formProduto$),
          (produto: Produto, control: AbstractControl, display: AbstractControl) => ({produto, control, display})))
      .subscribe((obj: { produto: Produto, control: AbstractControl, display: AbstractControl }) => {
        obj.control.setValue(obj.produto.codigo);
        obj.display.setValue(obj.produto.nome);
        this._produtoSelecionado$.next(obj.produto);
      }));

  }

  public filtrar(prompt: boolean): void {

    /**
     * Limpa os parâmetros anteriores.
     */
    this.promptPesquisa.clearParams();

    this.clear();

    /**
     * Realiza a busca do produto, se for encontrado mais de um registro ou for chamada de prompt, deve ser aberto a
     * dialog com os resultados.
     *
     * Deve levar em consideração a troca de parâmetros do produto, caso contrário não irá pesquisar novamente.
     */
    this.addSubscription(this.formProduto$
      .filter((form: FormGroup) => form.enabled)
      .switchMap(() => this.getControl("produto", this.formProduto$))
      .withLatestFrom(this._produtoSelecionado$, (control: AbstractControl, produto: Produto) => ({control, produto}))
      .filter((obj: { control: AbstractControl, produto: Produto }) => obj.control.valid || prompt)
      .switchMap((obj: { control: AbstractControl, produto: Produto }) => {

        if (!obj.produto || obj.produto.codigo.toUpperCase() !== obj.control.value.toUpperCase()) {

          const params: URLSearchParams = new URLSearchParams();
          params.set("prompt", this.promptProduto);
          params.set("query", obj.control.value);

          return this.httpService.get(`produtos/filtro-prompt`, {search: params})
            .combineLatest(this.getControl("display", this.formProduto$), this.getControl(),
              (result: Produto[] | Produto, display: AbstractControl, idProduto: AbstractControl) =>
                ({control: obj.control, display, idProduto, result, filtrou: true}));
        }
        return Observable.of({filtrou: prompt});
      })
      .subscribe((wrapper: {
        control?: AbstractControl, display?: AbstractControl, idProduto?: AbstractControl, result?: any, filtrou: boolean,
      }) => {

        if (wrapper.filtrou) {
          /**
           * Se foi retornado mais de um valor ou não achou nada (lenght === 0), abre o prompt.
           */
          if (wrapper.result) {
            if (ArrayUtil.isArray(wrapper.result) && !ArrayUtil.nullOrEmpty(wrapper.result) || wrapper.result.length === 0) {
              this.produtosPesquisados$.next({query: wrapper.control.value, produtos: wrapper.result});
              wrapper.display.setValue("");
              this.popup.show(true);
              this._produtoSelecionado$.next(undefined);
              this.form$.getValue().reset(this.initPojo);

            } else {
              const produto: Produto = wrapper.result;
              if (prompt) {
                this.produtosPesquisados$.next({query: wrapper.control.value, produtos: [produto]});
                this.popup.show(true);
              } else {
                wrapper.idProduto.setValue(produto.id);
                wrapper.control.setValue(produto.codigo);
                wrapper.display.setValue(produto.nome);
                this._produtoSelecionado$.next(produto);

                /**
                 * Utilizado para abrir dialog de variação, lote ou número de série, mesmo que o componente não tenha sido alterado.
                 */
                this.eventBlur$.next();
              }
            }
          }
        } else {

          /**
           * Utilizado para abrir dialog de variação, lote ou número de série, mesmo que o componente não tenha sido alterado.
           */
          this.eventBlur$.next();
        }
      }));

  }

  /**
   * Após clicar em "Selecionar" esse método é executado, se for digitado um valor válido, seta para o componente.
   * É necessário verificar se o produto possui grade ativa no banco.
   */
  public submitPrompt() {
    const produtoPesquisado: Produto = this.promptPesquisa.selectedItem;
    if (produtoPesquisado) {

      const params: URLSearchParams = new URLSearchParams();
      params.set("idProduto", produtoPesquisado.id.toString());

      this.addSubscription(this.httpService.get(`variacoes/variacao-ativa`, {search: params})
        .combineLatest(this.getControl("produto", this.formProduto$), this.getControl("display", this.formProduto$),
          this.getControl(),
          (possuiVariacao: boolean, produto: AbstractControl, display: AbstractControl, idProduto: AbstractControl) =>
            ({produto, display, idProduto, possuiVariacao}))
        .subscribe((wrapper: {
          produto: AbstractControl, display: AbstractControl, idProduto: AbstractControl, possuiVariacao: boolean,
        }) => {
          produtoPesquisado.possuiVariacao = wrapper.possuiVariacao;

          if (StringUtil.isString(produtoPesquisado.numeroSerie)) {
            produtoPesquisado.numeroSerie = EnumSimNao.SIM[EnumUtils.id] === produtoPesquisado.numeroSerie;
          }
          if (StringUtil.isString(produtoPesquisado.possuiLote)) {
            produtoPesquisado.possuiLote = EnumSimNao.SIM[EnumUtils.id] === produtoPesquisado.possuiLote;
          }

          this._produtoSelecionado$.next(produtoPesquisado);
          wrapper.idProduto.setValue(produtoPesquisado.id);
          wrapper.produto.setValue(produtoPesquisado.codigo);
          wrapper.display.setValue(produtoPesquisado.nome);
          this.popup.hide();
        }));
    }
  }

  /**
   * Retorna o produto do componente.
   * @return {Observable<Produto>}
   */
  public get produtoSelecionado$(): Observable<Produto> {
    return this._produtoSelecionado$
      .filter((produto: Produto) => produto !== undefined && !NumberUtil.numberNullOrZero(produto.id));
  }

  /**
   * Limpa o form de item.
   */
  public clear(): void {
    this.addSubscription(this.getControl("produto", this.formProduto$)
      .filter((produto: AbstractControl) => StringUtil.stringNullOrEmpty(produto.value))
      .switchMap(() => this.form$)
      .subscribe((form: FormGroup) => form.reset(this.initPojo)));
  }
}
