import { AbstractPojo } from "../../../../core/crud/pojo";

export class Cidade extends AbstractPojo {
    public nome = "";
    public nomePais = "";
    public nomeEstado = "";
    public idEstado: number = null;
    public codigoIBGE = 0;
}
