import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { Observable } from "rxjs/Observable";

import { ItInputNumberComponent } from "../primitive/it-inputnumber.component";

@Component({
  selector: "it-comissao-inputnumber",
  templateUrl: "it-comissao-inputnumber.component.html",
})
export class ItComissaoInputNumberComponent extends ItInputNumberComponent implements OnInit {
  @Input() public comissao: string;
  @Input() public comissaoAVista: string;
  @Input() public comissaoAPrazo: string;
  @Input() public comissaoQuitacao: string;
  @Input() public disabled$: Observable<boolean>;

  public disabledComissao$: Observable<boolean>;

  constructor() {
    super();
    this.disabled$ = Observable.of(false);
  }

  public ngOnInit(): void {
    /**
     * Desabilita os componentes quando o primeiro observable for true ou o valor de comissão for maior que zero.
     * @type {Observable<boolean>}
     */
    this.addSubscription(this.disabled$
      .combineLatest(this.isDeleteOrRead$, this.getControl(this.comissao), this.getControl(this.comissaoQuitacao),
        (disable: boolean, deleteOrRead: boolean, comissao: AbstractControl, comissaoQuitacao: AbstractControl) =>
          ({disable: disable || deleteOrRead, comissao, comissaoQuitacao}))
      .subscribe((obj: { disable: boolean, comissao: AbstractControl, comissaoQuitacao: AbstractControl }) => {
        if (obj.disable) {
          obj.comissao.disable();
          obj.comissaoQuitacao.disable();
        } else {
          obj.comissao.enable();
          obj.comissaoQuitacao.enable();
        }
      }));

    /**
     * Desabilita os componentes quando o primeiro observable for true ou o valor de comissão for maior que zero.
     * @type {Observable<boolean>}
     */
    this.addSubscription(this.disabled$
      .combineLatest(this.getValueChanges(this.comissao)
          .merge(this.getControl(this.comissao)
            .map((control: AbstractControl) => control.value)),
        (x: boolean, comissao: number) => x || comissao > 0)
      .combineLatest(this.isDeleteOrRead$, this.getControl(this.comissaoAVista), this.getControl(this.comissaoAPrazo),
        (disable: boolean, deleteOrRead: boolean, comissao: AbstractControl, prazo: AbstractControl) =>
          ({disable: disable || deleteOrRead, comissao, prazo}))
      .subscribe((obj: { disable: boolean, comissao: AbstractControl, prazo: AbstractControl }) => {
        if (obj.disable) {
          obj.comissao.disable();
          obj.prazo.disable();
        } else {
          obj.comissao.enable();
          obj.prazo.enable();
        }
      }));

    /**
     * Combino os observables para setar valor para o outros componentes.
     */
    this.addSubscription(this.getValueChanges(this.comissao)
      .combineLatest(this.getControl(this.comissaoAVista), this.getControl(this.comissaoAPrazo),
        (comissao: number, aVista: AbstractControl, aPrazo: AbstractControl) => ({comissao, aVista, aPrazo}))
      .subscribe(({comissao, aVista, aPrazo}: { comissao: number, aVista: AbstractControl, aPrazo: AbstractControl }) => {
        if (comissao > 0) {
          aVista.setValue(0);
          aPrazo.setValue(0);
        }
      }));
  }
}
