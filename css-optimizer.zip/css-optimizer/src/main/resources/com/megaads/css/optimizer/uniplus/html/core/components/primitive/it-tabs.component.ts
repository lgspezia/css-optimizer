import { AfterContentInit, Component, ContentChildren, forwardRef, HostBinding, QueryList } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { ItTabComponent } from "./it-tab.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-tabs",
  template: `
    <ul class="nav nav-tabs font-truman-12">
      <li *ngFor="let tab of tabs" [ngClass]="{active:tab.selected}">
        <a [href]="''" (click)="select(tab)" onclick="return false;"
           *ngIf="tab.isAtivo$ | async">{{tab.title}}</a>
      </li>
    </ul>
    <div class="tab-content">
      <ng-content></ng-content>
    </div>
  `,
})
export class ItTabsComponent implements AfterContentInit {
  @HostBinding("class.tabbable") public clazz = true;

  @ContentChildren(forwardRef(() => ItTabComponent)) public tabs: QueryList<ItTabComponent>;

  /**
   * Seta a primeira tab como selecionada.
   */
  public ngAfterContentInit(): void {

    /**
     * Cria um observable com o array de tab.
     * Mapeia a tab criando um novo observable combinando com o observable de validação de ativo.
     * Esse observable vai retornar a própria tab ou null se estiver inativa.
     * Na sequência faz um flatMap para mapear os observables dentro deles.
     * Por fim, pega o primeiro item e seta a seleção.
     */
    Observable.from(this.tabs.toArray())
      .map((tab: ItTabComponent) => Observable.of(tab)
        .combineLatest(tab.isAtivo$, (tabIn: ItTabComponent, ativo: boolean) => ativo ? tabIn : null))
      .flatMap((obs: Observable<ItTabComponent>) => obs)
      .first((tab) => tab !== null)
      .subscribe((tab: ItTabComponent) => this.select(tab))
      .unsubscribe();
  }

  /**
   * Seleciona a tab.
   * @param tab: ItTabComponent
   */
  public select(tab: ItTabComponent) {
    this.tabs.forEach((t) => t.selected = false);
    tab.invalidateFlexGrid();
    tab.selected = true;
  }
}
