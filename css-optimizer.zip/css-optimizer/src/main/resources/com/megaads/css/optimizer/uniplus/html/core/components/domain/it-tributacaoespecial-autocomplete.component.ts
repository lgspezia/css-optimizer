import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { NaturezaOperacao } from "../../../modules/cadastros/orfans/natureza-operacao.model";

@Component({
    selector: "it-tributacaoespecial-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTributacaoEspecialAutocompleteComponent extends ItAutocompleteComponent<NaturezaOperacao> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "naturezas-operacao/filtrar-tributacao-especial";
        this.label = "Tributação especial";
        this.display = "descricao";
    }
}
