import { Component, Input } from "@angular/core";

@Component({
  selector: "it-customcrud",
  templateUrl: "it-customcrud.component.html",
})
export class ItCustomCrudComponent {
  @Input() title: string;
}
