import { Component, Input, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { ContextoService } from "../../services/contexto.service";

/**
 * Painel com as seguintes caracteristicas:
 * - exibição de título
 * - visibilidade de acordo com modulo/funcionalidade
 * - largura configurável
 */
@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush, // valid
    selector: "it-panel",
  templateUrl: "it-panel.component.html",
})
export class ItPanelComponent implements OnInit {
    @Input() public title: string;
    @Input() public modulo: string;
    @Input() public funcionalidade: string;
    @Input() public licenca: string;
    @Input() public condicao$: Observable<boolean>;
    @Input() public col = 12;

    public isAtivo$: Observable<boolean> = Observable.of(true);

    constructor(private contextoService: ContextoService) { }

    /**
     * Se for definido condição, não irá validar modulo, funcionalidade e licença.
     */
    public ngOnInit(): void {
        if (this.modulo || this.funcionalidade || this.licenca) {
            this.isAtivo$ = this.contextoService
                .isAtivo$(this.modulo, this.funcionalidade, this.licenca)
                .first((ativo) => ativo);
        } else if (this.condicao$) {
            this.isAtivo$ = this.condicao$.map((ativo) => ativo);
        }
    }
}
