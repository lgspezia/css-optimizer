import { Component, EventEmitter, Input, ViewChild } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { WjComboBox } from "wijmo/wijmo.angular2.input";

import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-combobox",
  templateUrl: "it-combobox.component.html",
})
export class ItComboboxComponent<T extends any> extends BaseFormComponent {
  @Input() public itens$: Observable<any>;
  @Input() public display: string;

  @ViewChild(WjComboBox) public combobox: WjComboBox;

  constructor() {
    super();
    this.display = "display";
  }

  /**
   * Event emitter se seleção de item.
   * @return {EventEmitter<{}>}
   */
  public get selectedChangePC$(): EventEmitter<{}> {
    return this.combobox.selectedValueChangePC;
  }

  /**
   * Retorna o objeto selecionado.
   * @return {T}
   */
  public get selectedItem(): T {
    return this.combobox.selectedItem;
  }
}
