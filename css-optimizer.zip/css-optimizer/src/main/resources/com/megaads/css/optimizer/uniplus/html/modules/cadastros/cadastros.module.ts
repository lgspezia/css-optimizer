import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";

import { WjInputModule } from "wijmo/wijmo.angular2.input";

import { ComponentsModule } from "../../core/components/primitive/components.module";
import { EmpresaGridCrudComponent } from "./empresas/empresa.grid.crud.component";
import { ItFilialAvancadoFormComponent } from "./filiais/avancados/filial-avancado.form.component";
import { ItFilialCidadeCPOMFomComponent } from "./filiais/cidades/filial-cidade-cpom.form.component";
import { ItFilialSignatarioFormComponent } from "./filiais/contabilidades/filial-signatario.form.component";
import { ItFilialDadoContadorFormComponent } from "./filiais/dados-contador/filial-dado-contador.form.component";
import { ItFilialDiaFormComponent } from "./filiais/dias/filial-dia.form.component";
import { ItFilialGeralFormComponent } from "./filiais/filial-geral.form.component";
import { FilialGridCrudComponent } from "./filiais/filial.grid.crud.component";
import {
  ItFilialInscricaoEstadualSubstitutoFormComponent,
} from "./filiais/incricoes-estaduais-substitutos/filial-inscricao-estadual-substituto.form.component";
import { ItUsuarioGeralFormComponent } from "./usuarios/usuario-geral.form.component";
import { UsuarioGridCrudComponent } from "./usuarios/usuario.grid.crud.component";
import { ItUsuarioAssinaturaFormComponent } from "./usuarios/usuarios-assinatura/usuario-assinatura.form.component";
import { ItUsuarioPreferenciaFormComponent } from "./usuarios/usuarios-preferencias/usuario-preferencia.form.component";
import { ItUsuarioUnichefFormComponent } from "./usuarios/usuarios-unichef/usuario-unichef.form.component";

/**
 * @author Luan  on 12/06/2017.
 */

const routes: Routes = [
  {path: "empresas", component: EmpresaGridCrudComponent},
  {path: "filiais", component: FilialGridCrudComponent},
  {path: "usuarios", component: UsuarioGridCrudComponent}
];

@NgModule({
  declarations: [EmpresaGridCrudComponent, FilialGridCrudComponent, ItFilialGeralFormComponent, ItFilialAvancadoFormComponent,
    ItFilialDadoContadorFormComponent, ItFilialInscricaoEstadualSubstitutoFormComponent, ItFilialSignatarioFormComponent
    , ItFilialDiaFormComponent, ItFilialCidadeCPOMFomComponent, UsuarioGridCrudComponent, ItUsuarioGeralFormComponent
    , ItUsuarioPreferenciaFormComponent, ItUsuarioAssinaturaFormComponent, ItUsuarioUnichefFormComponent],
  exports: [RouterModule],
  imports: [RouterModule.forChild(routes), CommonModule, ComponentsModule, ReactiveFormsModule, WjInputModule],
})
export class CadastrosModule {
}
