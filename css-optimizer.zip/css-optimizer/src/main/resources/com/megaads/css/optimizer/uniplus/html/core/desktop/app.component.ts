import { Component, OnInit } from "@angular/core";

import { AutenticacaoService } from "../services/autenticacao.service";
import { ContextoService } from "../services/contexto.service";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-app",
  templateUrl: "app.component.html",
})
export class AppComponent implements OnInit {

  constructor(private autenticacaoService: AutenticacaoService, private contextoService: ContextoService) {
  }

  public ngOnInit(): void {
    if (this.autenticacaoService.isLogado()) {
      const usuario = this.autenticacaoService.getUsuario();
      this.contextoService.save(usuario.usuario, usuario.filial, usuario.licencas, usuario.modulos, usuario.funcionalidades,
        usuario.propriedades, usuario.menusAtivos, usuario.authorities, usuario.notificacoes, usuario.dadosLicenca);
    }
  }

  public get logado(): boolean {
    return this.autenticacaoService.isLogado();
  }
}
