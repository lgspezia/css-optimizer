import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { CustomCrud } from "../../../core/crud/custom.crud";
import { valueDifferentOfValidator } from "../../../core/crud/validadores";
import { NumberUtil } from "../../../core/utils/number.util";
import { ConfiguracaoCartaoFidelidade } from "./configuracao-cartao-fidelidade";

@Component({
  templateUrl: "configuracao-cartao-fidelidade.custom.crud.html",
})
export class ConfiguracaoCartaoFidelidadeCustomCrudComponent extends CustomCrud<ConfiguracaoCartaoFidelidade> {

  constructor(protected activedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activedRoute, formBuilder, new ConfiguracaoCartaoFidelidade(), "configuracoes-cartao-fidelidade");

    this.addValidators();
    this.addBehaviors();

    /**
     * Quando ZERO não irá gravar a configuração.
     */
    this.addSubscription(this.beforeSubmit$
      .subscribe((configuracao: ConfiguracaoCartaoFidelidade) => {
        if (NumberUtil.numberNullOrZero(configuracao.id)) {
          configuracao.id = null;
        }
      }));
  }

  private addValidators(): void {
    this.addSubscription(this.getControl("prefixoNumeroCartao")
      .subscribe((prefixo) => prefixo.setValidators([Validators.required, Validators.maxLength(6)])));

    this.addSubscription(this.getControl("proximoNumeroCartao")
      .subscribe((numero) => numero.setValidators([Validators.required, Validators.maxLength(10)])));

    this.addSubscription(this.getControl("tamanhoDigitoVerificador")
      .subscribe((digito) => digito.setValidators([Validators.required, Validators.maxLength(1)])));

    this.addSubscription(this.getControl("tamanhoNumeroCartao")
      .subscribe((tamanho) => tamanho.setValidators([valueDifferentOfValidator([11, 14])])));
  }

  /**
   * Desabilita os componentes quando necessário.
   */
  private addBehaviors(): void {

    this.addSubscription(this.getValueChanges("usarPrecoDiferenciado")
      .startWith(false)
      .combineLatest(this.getControl("pautaPreco"),
        (preco: boolean, pauta: AbstractControl) => ({preco, pauta}))
      .subscribe((obj: { preco: boolean, pauta: AbstractControl }) => obj.preco ? obj.pauta.enable() : obj.pauta.disable()));

    this.addSubscription(this.getValueChanges("geraNumeracaoCartao")
      .startWith(false)
      .combineLatest(this.getControl("tamanhoNumeroCartao"), this.getControl("prefixoNumeroCartao"),
        this.getControl("tamanhoDigitoVerificador"), this.getControl("proximoNumeroCartao"),
        (gerar: boolean, numero: AbstractControl, prefixo: AbstractControl, digito: AbstractControl, proximoNum: AbstractControl) =>
          ({disable: !gerar, numero, prefixo, digito, proximoNum}))
      .subscribe((obj: {
        disable: boolean, numero: AbstractControl, prefixo: AbstractControl, digito: AbstractControl, proximoNum: AbstractControl,
      }) => {
        if (obj.disable) {
          obj.numero.disable();
          obj.prefixo.disable();
          obj.digito.disable();
          obj.proximoNum.disable();
        } else {
          obj.numero.enable();
          obj.prefixo.enable();
          obj.digito.enable();
          obj.proximoNum.enable();
        }
      }));
  }

}
