import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum FinalidadeEmissaoNfe {

  NORMAL = <any>       {
    [EnumUtils.id]: "NORMAL",
    [EnumUtils.display]: "1 - NF-E NORMAL",
    integer: 1,
    possuiMovimentacaoFisicaC170: true
  },
  COMPLEMENTAR = <any> {
    [EnumUtils.id]: "COMPLEMENTAR",
    [EnumUtils.display]: "2 - NF-E COMPLEMENTAR",
    integer: 2,
    possuiMovimentacaoFisicaC170: false
  },
  AJUSTE = <any>       {
    [EnumUtils.id]: "AJUSTE",
    [EnumUtils.display]: "3 - NF-E DE AJUSTE",
    integer: 3,
    possuiMovimentacaoFisicaC170: false
  },
  DEVOLUCAO = <any>    {
    [EnumUtils.id]: "DEVOLUCAO",
    [EnumUtils.display]: "4 - DEVOLUÇÃO DE MERCADORIA",
    integer: 4,
    possuiMovimentacaoFisicaC170: true
  },
}
