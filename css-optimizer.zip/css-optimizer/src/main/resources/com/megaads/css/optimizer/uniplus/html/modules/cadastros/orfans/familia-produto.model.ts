import { Hierarquia } from "./hierarquia.model";

export class FamiliaProduto extends Hierarquia {
  qtdDiasCompra = 0;
}
