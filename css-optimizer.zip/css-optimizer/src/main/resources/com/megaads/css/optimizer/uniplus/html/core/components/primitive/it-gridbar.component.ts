import { Component, EventEmitter, Input, Output } from "@angular/core";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { Modo } from "../../crud/grid.crud";

@Component({
  selector: "it-gridbar",
  templateUrl: "it-gridbar.component.html",
})
export class ItGridBarComponent {
  @Input() public enableReturn = false;
  @Input() public eventAction$: Subject<Modo>;
  @Input() public formEditing$: Observable<boolean>;
  @Input() public allowCreate$: Observable<boolean>;
  @Input() public allowDelete$: Observable<boolean>;
  @Input() public allowRead$: Observable<boolean>;
  @Input() public allowUpdate$: Observable<boolean>;

  @Output() public onSearch: EventEmitter<string> = new EventEmitter<string>();
  @Output() public onReturn: EventEmitter<any> = new EventEmitter();

  public eventCreate(): void {
    this.eventAction$.next(Modo.CREATE);
  }

  public eventUpdate(): void {
    this.eventAction$.next(Modo.UPDATE);
  }

  public eventRead(): void {
    this.eventAction$.next(Modo.READ);
  }

  public eventDelete(): void {
    this.eventAction$.next(Modo.DELETE);
  }

  public eventReturn(): void {
    this.onReturn.emit(null);
  }

  /**
   * Reemite o evento
   */
  public eventSearch(pesquisar: string): void {
    this.onSearch.emit(pesquisar);
  }
}
