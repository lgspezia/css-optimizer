import { Component } from "@angular/core";

import { TipoEntidade } from "../../../modules/entidades/cadastros/entidade";
import { EnumUtils } from "../../enuns/enumutil";
import { HttpService } from "../../services/http.service";
import { ItEntidadeAutocompleteComponent } from "./it-entidade-autocomplete.component";

@Component({
  selector: "it-cliente-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
/**
 * Componente de representante, se necessário pode ser passado parâmetros como
 * ItEntidadeAutocompleteComponent#filtrarFilial ou ItEntidadeAutocompleteComponent#exibirInativos.
 * <p>
 * Para mais detalhes consultar ItEntidadeAutocompleteComponent.
 *
 * @Author Osiel.
 */
export class ItClienteAutocompleteComponent extends ItEntidadeAutocompleteComponent {

  constructor(httpService: HttpService) {
    super(httpService);
    this.label = "Cliente";
    this.tipos = [TipoEntidade.CLIENTE[EnumUtils.id]];
    this.urlUpdate = "clientes";
    this.configParams();
  }

}
