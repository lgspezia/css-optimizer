import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { WjListBox } from "wijmo/wijmo.angular2.input";

import { HttpService } from "../../services/http.service";
import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-dynalistbox",
  templateUrl: "it-dynalistbox.component.html",
})
export class ItDynalistboxComponent extends BaseFormComponent implements OnInit {
  @ViewChild(WjListBox) public listbox: WjListBox;

  @Input() public height = "";
  @Input() public display: string;
  @Input() public url: string;
  @Input() public checkedMemberPath: string;
  @Input() public urlParams$: Observable<URLSearchParams>;

  private afterLoad$: Subject<any>;

  constructor(private httpService: HttpService) {
    super();
    this.afterLoad$ = new Subject();
  }

  public ngOnInit(): void {
    if (this.urlParams$) {
      this.addSubscription(this.urlParams$
        .switchMap((url: URLSearchParams) => url ? this.httpService.get(this.url, {search: url}) : Observable.of(url))
        .subscribe((resp) => {
            resp ? this.listbox.itemsSource = resp : this.listbox.itemsSource = null;
            this.afterLoad$.next(this.listbox.itemsSource);
          },
          (error) => this.handleError(error)));
    } else {
      this.httpService.get(this.url)
        .subscribe((resp) => {
          this.listbox.itemsSource = resp;
          this.afterLoad$.next(this.listbox.itemsSource);
        }, (error) => this.handleError(error));
    }
  }

  /**
   * Atualiza o componente.
   */
  public refresh(): void {
    this.listbox.refresh();
  }

  /**
   * Retorna array com os valores selecionados
   */
  public checkedItems(): number[] {
    return this.listbox.checkedItems.map((item) => item.id);
  }

  /**
   * Ação disparada quando os dados do componente são carregados.
   * @return {Observable<any>} retorna o valor de {@link WjListBox.itemsSource}
   */
  public get afterLoadSource$(): Observable<any> {
    return this.afterLoad$.asObservable();
  }
}
