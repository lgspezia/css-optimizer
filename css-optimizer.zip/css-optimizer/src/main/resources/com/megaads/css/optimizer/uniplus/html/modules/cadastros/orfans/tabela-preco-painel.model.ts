import { AbstractPojo } from "../../../core/crud/pojo";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class TabelaPrecoPainel extends AbstractPojo {
  descricao = "";
  // imagens: TabelaPrecoPainelImagem[];
}
