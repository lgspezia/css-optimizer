import { Component, Input } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Entidade } from "../../../modules/entidades/cadastros/entidade";

/**
 * Classe base para componente de autocomplete de entidade, deve ser passado os parâmetros para filtros.
 *
 * @Author Osiel.
 */
@Component({
  selector: "it-entidade-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItEntidadeAutocompleteComponent extends ItAutocompleteComponent<Entidade> {
  @Input() public filtrarFilial = false;
  @Input() public exibirInativos = false;

  protected tipos: String[];

  constructor(httpService: HttpService) {
    super(httpService);
    this.url = "entidades/por-tipo";
    this.urlUpdate = "entidades";
    this.display = "nome";
  }

  protected configParams(): void {
    this.url = "entidades/por-tipo";
    this.display = "nome";
    this.addParams("filial", this.filtrarFilial);
    this.addParams("inativo", this.exibirInativos);
    this.addParams("tipoEntidade", this.tipos);
  }
}
