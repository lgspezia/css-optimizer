import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItEstadoDynacomboboxComponent } from "../../../../core/components/domain/it-estado-dynacombobox.component";
import { validarIE } from "../../../../core/components/domain/it-inscricaoestadual-inputtext.component";
import { ItFormTableComponent } from "../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { FormComponent } from "../../../../core/crud/form-component";
import { IParamsData } from "../../../../core/crud/param-data";
import { identificationRequiredValidator } from "../../../../core/crud/validadores";
import { ServerError } from "../../../../core/models/server-error";
import { NumberUtil } from "../../../../core/utils/number.util";
import { StringUtil } from "../../../../core/utils/string.util";
import { InscricaoEstadualContribuinteSubstituto } from "./filial-inscricao-estadual-substituto";

/**
 * @author Luan  on 26/06/2017.
 */
@Component({
  selector: "it-filial-inscricao-estadual-substituto",
  templateUrl: "filial-inscricao-estadual-substituto.form.component.html",
})
export class ItFilialInscricaoEstadualSubstitutoFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formInscricaoSubstituto$: BehaviorSubject<FormGroup>;
  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) public itFormTable: ItFormTableComponent<InscricaoEstadualContribuinteSubstituto>;
  @ViewChild(ItEstadoDynacomboboxComponent) private itEstado: ItEstadoDynacomboboxComponent;

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  public ngOnInit(): void {
    /**
     * Cria o novo formGroup de InscricaoEstadualContribuinteSubstituto
     */
    this.formInscricaoSubstituto$ = new BehaviorSubject(this.formBuilder.group(new InscricaoEstadualContribuinteSubstituto()));

    this.addSubscription(this.getControl("idEstado", this.formInscricaoSubstituto$)
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("inscricaoEstadual", this.formInscricaoSubstituto$)
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required]);
        control.setAsyncValidators([validarIE(true, `filiais/validar-ie`)]);
      }));

    /**
     * Cria as colunas da tabela
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "ID", DataType.Number, 0, null, false),
      new ColumnDefinition("idFilial", "idFilial", DataType.Number, 0, null, false),
      new ColumnDefinition("idEstado", "idEstado", DataType.Number, 0, null, false),
      new ColumnDefinition("estado", "Estado", DataType.String, "*", null, true),
      new ColumnDefinition("inscricaoEstadual", "Inscrição estadual", DataType.String, "*", null, true),
    ]);

    /**
     * Passo os dados necessários para carregar os dados do endPoint.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idFilial", id.toString());
        return {endpoint: "inscricoes-estaduais-substituto", search: params};
      });

    /**
     * Quando clicar em incluir, lima os campos criando um novo objeto
     */
    this.addSubscription(this.itFormTable.afterReset$
      .subscribe((form: FormGroup) => form.reset(new InscricaoEstadualContribuinteSubstituto())));

    /**
     * Ação feita ao incluir os dados da tabela.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .combineLatest(this.afterGet$, (obj: InscricaoEstadualContribuinteSubstituto, id: number) => ({obj, id}))
      .subscribe((wrapper: { obj: InscricaoEstadualContribuinteSubstituto, id: number }) => {
        wrapper.obj.idFilial = wrapper.id;
        if (NumberUtil.numberNullOrZero(wrapper.obj.idEstado)) {
          this.itFormTable.handleError(new ServerError(null, "WWW66", "Campo Estado não informado"));
          return;
        }
        if (StringUtil.stringNullOrEmpty(wrapper.obj.inscricaoEstadual)) {
          this.itFormTable.handleError(new ServerError(null, "WWW68", "Campo Inscrição estadual não informada"));
          return;
        }
        wrapper.obj.estado = this.itEstado.selectedItem.codigo;
        this.itFormTable.submit$.next(wrapper.obj);
      }));
  }
}
