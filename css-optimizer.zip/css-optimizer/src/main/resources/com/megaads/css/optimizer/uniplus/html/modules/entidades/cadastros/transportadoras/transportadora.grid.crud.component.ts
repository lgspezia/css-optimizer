import { Component } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { ContextoService } from "../../../../core/services/contexto.service";
import { TipoEntidade } from "../entidade";
import { EntidadeGridCrudComponent } from "../entidade.grid.crud.component";

/**
 * Cadastro de Transportadora.
 *
 * Created by Osiel S. Mello on 16/05/2017.
 */
@Component({
  templateUrl: "../entidade.grid.crud.html",
})
export class TransportadoraGridCrudComponent extends EntidadeGridCrudComponent {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, protected contexto: ContextoService) {
    super(activatedRoute, formBuilder, contexto);
    this.tipoEntidade = TipoEntidade.TRANSPORTADORA;
  }

}
