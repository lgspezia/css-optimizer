import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, Validators } from "@angular/forms";

import { Observable } from "rxjs/Observable";

import { ItEnderecoComponent } from "../../../core/components/domain/it-endereco.component";
import { validarIE } from "../../../core/components/domain/it-inscricaoestadual-inputtext.component";
import { FormComponent } from "../../../core/crud/form-component";
import { identificationRequiredValidator, TipoValidadorCpfCnpj } from "../../../core/crud/validadores";
import { IDadosLicenca } from "../../../core/desktop/dados-licenca";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil, REGEX_NUMBER } from "../../../core/utils/number.util";
import {
  InativoFilial,
  IndicadorFilial,
  RegimeEspecialTributacao,
  TipoContribuinte,
  TipoEnquadramentoFilial
} from "./filial";

/**
 * @author Luan  on 19/06/2017.
 */
@Component({
  selector: "it-filial-geral",
  templateUrl: "filial-geral.form.component.html"
})
export class ItFilialGeralFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public tipoEnquadramento$: Observable<IDataItem[]>;
  public tipoContribuinte$: Observable<IDataItem[]>;
  public regimeEspecialTributacao$: Observable<IDataItem[]>;
  public indicadorFilial$: Observable<IDataItem[]>;
  public required$: Observable<boolean>;
  public habilitaInsentivoFiscal$: Observable<boolean>;
  public habilitaSuframa$: Observable<boolean>;
  public cnpj$: Observable<TipoValidadorCpfCnpj>;
  public visibleInativoFilial$: Observable<boolean>;
  public disableEstado$: Observable<boolean>;

  @ViewChild(ItEnderecoComponent) public itEndereco: ItEnderecoComponent;

  constructor(public contexto: ContextoService) {
    super();

    this.cnpj$ = Observable.of(TipoValidadorCpfCnpj.CNPJ);
    this.required$ = Observable.of(true);
    this.carregarEnuns();
  }

  public ngOnInit(): void {

    /**
     * Verifica se habilita insentivo fiscal
     */
    this.habilitaInsentivoFiscal$ = this.contexto.isFuncionalidade$("INCENTIVO_FISCAL, OPERACAO_FISCAL");
    /**
     * Se não habilita o insentivo fiscal, habilita o suftama
     */
    this.habilitaSuframa$ = this.habilitaInsentivoFiscal$.map((habilita: boolean) => !habilita);

    /**
     * Só habilita o campo inativo se tiver mais de 1 filial
     */
    this.visibleInativoFilial$ = this.contexto.dadosLicenca$
      .map((dadosLicenca: IDadosLicenca) => dadosLicenca.quantidadeFiliais > 1);

    this.addValidators();

    this.addBehavior();

  }

  /**
   * Carre as informações das Enuns dentro de seus combo
   */
  private carregarEnuns(): void {
    this.tipoEnquadramento$ = EnumUtils.getValues(TipoEnquadramentoFilial, EnumUtils.display, false);
    this.tipoContribuinte$ = EnumUtils.getValues(TipoContribuinte, EnumUtils.display, false);
    this.regimeEspecialTributacao$ = EnumUtils.getValuesNullOption(RegimeEspecialTributacao);
    this.indicadorFilial$ = EnumUtils.getValues(IndicadorFilial, EnumUtils.display, false);
  }

  /**
   * Adiciona validadores sync e Async para os componentes
   */
  private addValidators(): void {
    this.addSubscription(this.getControl("codigo").subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required, Validators.maxLength(4), Validators.pattern(REGEX_NUMBER)])));

    this.addSubscription(this.getControl("tipoEnquadramento").subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("idEmpresa").subscribe((control: AbstractControl) =>
      control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("razaoSocial").merge(this.getControl("nome"))
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(60)])));

    this.addSubscription(this.getControl("idEstado").merge(this.getControl("idCidade"))
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("endereco").merge(this.getControl("bairro"))
      .merge(this.getControl("responsavel"))
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(50)])));

    this.addSubscription(this.getControl("numero")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(6)])));

    this.addSubscription(this.getControl("complemento")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("telefone")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(16)])));

    this.addSubscription(this.getControl("inscricaoEstadual")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(17)]);
        control.setAsyncValidators([validarIE(true, `filiais/validar-ie`)]);
      }));

    this.addSubscription(this.getControl("cnae")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(7)])));

  }

  /**
   * Adiciona os comportamentos para os componentes
   */
  private addBehavior(): void {

    /**
     *  Limpa o combo de idFilialCdm quando marcado checkBox cdm
     */
    this.addSubscription(
      this.getValueChanges("cdm")
        .combineLatest(this.isDeleteOrRead$, this.getControl("idFilialCdm"),
          (cdm: boolean, deleteOrRead: boolean, control: AbstractControl) =>
            ({disable: cdm || deleteOrRead, control}))
        .subscribe((obj: { disable: boolean, control: AbstractControl }) => {
          if (obj.disable) {
            obj.control.setValue(0);
            obj.control.disable();
          } else {
            obj.control.enable();
          }
        }));

    /**
     * Como o campo inativo na base pode ter 3 valores diferentes(0, 1 ou 2), é usado uma variavel auxiliar
     * para marcar ou desmarcar o combo em tela, sendo que só vair ser true quando retornar SIM || INATIVO_POR_LICENCA
     */
    this.addSubscription(this.afterGet$
      .combineLatest(this.getControl("inativoView"), this.getControl("inativo"),
        (id: number, inativoView: AbstractControl, inativo: AbstractControl) => ({inativoView, inativo}))
      .subscribe((wrapper: { inativoView: AbstractControl, inativo: AbstractControl }) => {
        wrapper.inativoView.setValue(wrapper.inativo.value === InativoFilial.SIM[EnumUtils.id]
          || wrapper.inativo.value === InativoFilial.INATIVO_POR_LICENCA[EnumUtils.id]);
      }));

    const isDemonstracao$: Observable<boolean> = this.contexto.dadosLicenca$
      .map((dadosLicena: IDadosLicenca) => dadosLicena.isDemonstracao);

    /**
     * Quando alterado o estado, carrega o estado selecionado para variavel "estado"
     */
    this.addSubscription(this.getValueChanges("idEstado")
      .combineLatest(this.getControl("estado"),
        (idEstado: number, control: AbstractControl) => ({idEstado, control}))
      .subscribe((wrapper: { idEstado: number, control: AbstractControl }) => {
        if (!NumberUtil.numberNullOrZero(wrapper.idEstado) && this.itEndereco.itEstado.selectedItem) {
          wrapper.control.setValue(this.itEndereco.itEstado.selectedItem.codigo);
        }
      }));

    /**
     * Quando alterado a cidade, carrega a cidade selecionada para variavel "cidade"
     */
    this.addSubscription(this.getValueChanges("idCidade")
      .combineLatest(this.getControl("cidade"),
        (idCidade: number, control: AbstractControl) => ({idCidade, control}))
      .subscribe((wrapper: { idCidade: number, control: AbstractControl }) => {
        if (!NumberUtil.numberNullOrZero(wrapper.idCidade) && this.itEndereco.itCidade.selectedItem) {
          wrapper.control.setValue(this.itEndereco.itCidade.selectedItem.nome);
        }
      }));

    /**
     * quando muda o estado, valida a IE novamente
     */
    this.addSubscription(this.getValueChanges("idEstado")
      .combineLatest(this.getControl("inscricaoEstadual"), (estado: number, ie: AbstractControl) => ie)
      .subscribe((ie: AbstractControl) => ie.updateValueAndValidity()));

    /**
     * Habilita o campo razão social se for inclusão ou estiver em Demonstração
     */
    this.addSubscription(this.isCreate$()
      .combineLatest(isDemonstracao$, this.getControl("razaoSocial"),
        (c: boolean, d: boolean, control: AbstractControl) => ({habilitar: c || d, control}))
      .subscribe((wrapper: { habilitar: boolean, control: AbstractControl }) => {
        if (wrapper.habilitar) {
          wrapper.control.enable();
        } else {
          wrapper.control.disable();
        }
      }));

    /**
     * Desabilita o campo estado na alteração.
     */
    this.disableEstado$ = this.isUpdate$();

    this.disableWhenIsNotCreateMode("codigo");
    this.disableWhenIsNotCreateMode("cnpj");

  }
}
