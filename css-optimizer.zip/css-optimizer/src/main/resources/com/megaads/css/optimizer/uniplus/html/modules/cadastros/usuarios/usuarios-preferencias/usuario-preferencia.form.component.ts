import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";
import { EnumUtils } from "../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../core/models/dataitem";
import { ContextoService } from "../../../../core/services/contexto.service";
import { TipoAcesso } from "../usuario";
import { ApresentacaoSaldoEstoque, PreferenciaUsuario } from "./usuario-preferencia";

/**
 * @author Luan  on 20/07/2017.
 */
@Component({
  selector: "it-preferencia-usuario",
  templateUrl: "usuario-preferencia.form.component.html",
})
export class ItUsuarioPreferenciaFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public formPrefUsuario$: BehaviorSubject<FormGroup>;
  public tipoAcesso$: Observable<IDataItem[]>;
  public habilitaTipoAceso$: Observable<boolean>;
  public tipoApresentacaoSaldoEstoque$: Observable<IDataItem[]>;

  public isEnterpriseOrExpedicao$: Observable<boolean>;
  public isOSOrDemo: Observable<boolean>;
  public habilitaBrinde$: Observable<boolean>;
  public habilitaManipularData$: Observable<boolean>;

  constructor(private contexto: ContextoService) {
    super();

    this.formPrefUsuario$ = new BehaviorSubject(undefined);

    this.tipoAcesso$ = EnumUtils.getValues(TipoAcesso, EnumUtils.display, false);
    this.tipoApresentacaoSaldoEstoque$ = EnumUtils.getValues(ApresentacaoSaldoEstoque, EnumUtils.display, false);
    this.habilitaTipoAceso$ = contexto.isFuncionalidade$("TIPO_ACESSO");
    this.isEnterpriseOrExpedicao$ = this.contexto.isEnterprise$()
      .combineLatest(this.contexto.isModulo$("EXPEDICAO"), (isEnterprose, isExpedicao) => isEnterprose || isExpedicao);
    this.habilitaBrinde$ = this.contexto.isFuncionalidade$("BRINDE").map((isBrinde: boolean) => isBrinde);
    this.habilitaManipularData$ = this.contexto.isFuncionalidade$("MANIPULAR_DATAS_ENTRADA_BAIXA_FINANCEIRO")
      .map((isManipular: boolean) => isManipular);
  }

  public ngOnInit() {

    this.addSubscription(this.getFormGroup("preferenciaUsuario", new PreferenciaUsuario())
      .subscribe(this.formPrefUsuario$));

    this.addSubscription(this.getControl("emailPadrao", this.formPrefUsuario$)
      .merge(this.getControl("servidorSmtp", this.formPrefUsuario$))
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(256)])));

    this.addSubscription(this.getControl("usuarioServidorSmtp", this.formPrefUsuario$)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("senhaServidorSmtp", this.formPrefUsuario$)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(30)])));

    this.addSubscription(this.getControl("portaImpressoraEtiqueta", this.formPrefUsuario$)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(50)])));
  }

}
