import { EnumUtils } from "../../../../core/enuns/enumutil";
import { TipoAcaoFinanceiro } from "../../../financeiros/tipos-documentos-financeiro/tipodocumentofinanceiro";
import { TipoFinanceiro } from "./tipo-financeiro.enum";

export enum TipoIntegracaoFinanceiro {
  NENHUM = <any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Nenhum", tipoFinanceiro: null, tipoAcao: null},
  RECEBER = <any> {
    [EnumUtils.id]: "RECEBER",
    [EnumUtils.display]: "Contas a receber",
    tipoFinanceiro: TipoFinanceiro.RECEBER[EnumUtils.id],
    tipoAcao: TipoAcaoFinanceiro.RECEBER[EnumUtils.id]
  },
  PAGAR = <any> {
    [EnumUtils.id]: "PAGAR",
    [EnumUtils.display]: "Contas a pagar",
    tipoFinanceiro: TipoFinanceiro.PAGAR[EnumUtils.id],
    tipoAcao: TipoAcaoFinanceiro.PAGAR[EnumUtils.id]
  },
}
