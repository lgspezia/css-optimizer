import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { enumConverter, EnumSimNao, EnumUtils } from "../../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../../core/models/dataitem";
import { ServerError } from "../../../../../core/models/server-error";
import { ContextoService } from "../../../../../core/services/contexto.service";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { Usuario } from "../../../../cadastros/usuarios/usuario";
import { EntidadeSPCHistorico, TipoOperacaoSPC } from "./entidade-spchistorico";

/**
 * SPC
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-spchistorico",
  templateUrl: "entidade-spchistorico.form.component.html",
})
export class ItEntidadeSPCHistoricoFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formSPC$: BehaviorSubject<FormGroup>;

  public simNao$: Observable<IDataItem[]>;
  public operacao$: Observable<IDataItem[]>;
  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<EntidadeSPCHistorico>;

  constructor(private formBuider: FormBuilder, private contexto: ContextoService) {
    super();

    this.simNao$ = EnumUtils.getValues(EnumSimNao);
    this.operacao$ = EnumUtils.getValues(TipoOperacaoSPC);
  }

  public ngOnInit(): void {
    this.formSPC$ = new BehaviorSubject(this.formBuider.group(new EntidadeSPCHistorico()));

    this.addSubscription(this.getControl("dataOperacao", this.formSPC$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required])));

    this.addSubscription(this.getValueChanges("registradoSpc")
      .merge(this.afterGet$
        .combineLatest(this.getControl("registradoSpc"), (id: number, c: AbstractControl) => c.value))
      .combineLatest(this.getControl("tipoOperacaoSPC", this.formSPC$),
        (spc: string, tipo: AbstractControl) => ({spc, tipo}))
      .subscribe((wrapper: { spc: string, tipo: AbstractControl }) => {
        if (StringUtil.stringNullOrEmpty(wrapper.spc) || EnumSimNao[wrapper.spc][EnumUtils.id] === EnumSimNao.NAO[EnumUtils.id]) {
          wrapper.tipo.setValue(TipoOperacaoSPC.ICLUSAO[EnumUtils.id]);
        } else {
          wrapper.tipo.setValue(TipoOperacaoSPC.EXCLUSAO[EnumUtils.id]);
        }
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idEntidade", "idEntidade", DataType.Number, 0, null, false),
      new ColumnDefinition("idusuarioalteracao", "idusuarioalteracao", DataType.Number, 0, null, false),
      new ColumnDefinition("tipoOperacaoSPC", "Operação", DataType.String, "*", null, true, TipoOperacaoSPC, null, enumConverter),
      new ColumnDefinition("dataOperacao", "Data operação", DataType.Date, 170, "dd/MM/yyyy HH:mm"),
      new ColumnDefinition("usuarioalteracao", "Usuário", DataType.String, "*"),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEntidade", id.toString());
        return {endpoint: "historicos-spc", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$.subscribe(() =>
        this.itFormTable.sourceCollection.forEach((spc: EntidadeSPCHistorico) => {
          if (spc.id) {
            spc.id = NumberUtil.parseFloat(spc.id.toString());
          }
          if (spc.idEntidade) {
            spc.idEntidade = NumberUtil.parseFloat(spc.idEntidade.toString());
          }
          if (spc.idusuarioalteracao) {
            spc.idusuarioalteracao = NumberUtil.parseFloat(spc.idusuarioalteracao.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .combineLatest(this.afterGet$, this.contexto.usuario$, this.getControl("registradoSpc"),
        (spc: EntidadeSPCHistorico, idEntidade: number, usuario: Usuario, registroSpc: AbstractControl) =>
          ({spc, idEntidade, usuario, registroSpc}))
      .subscribe((wrapper: { spc: EntidadeSPCHistorico, idEntidade: number, usuario: Usuario, registroSpc: AbstractControl }) => {
        wrapper.spc.idEntidade = wrapper.idEntidade;
        wrapper.spc.idusuarioalteracao = wrapper.usuario.id;
        wrapper.spc.usuarioalteracao = wrapper.usuario.nome;

        this.itFormTable.submit$.next(wrapper.spc);

        if (TipoOperacaoSPC[wrapper.spc.tipoOperacaoSPC][EnumUtils.id] === TipoOperacaoSPC.ICLUSAO[EnumUtils.id]) {
          wrapper.registroSpc.setValue(EnumSimNao.SIM[EnumUtils.id]);
        } else {
          wrapper.registroSpc.setValue(EnumSimNao.NAO[EnumUtils.id]);
        }
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$
      .combineLatest(this.getControl("registradoSpc"), (form: FormGroup, spc: AbstractControl) => ({form, spc}))
      .subscribe((wrapper: { form: FormGroup, spc: AbstractControl }) => {
        const historico: EntidadeSPCHistorico = new EntidadeSPCHistorico();
        if (StringUtil.stringNullOrEmpty(wrapper.spc.value) ||
          EnumSimNao[wrapper.spc.value][EnumUtils.id] === EnumSimNao.NAO[EnumUtils.id]) {
          historico.tipoOperacaoSPC = TipoOperacaoSPC.ICLUSAO[EnumUtils.id];
        } else {
          historico.tipoOperacaoSPC = TipoOperacaoSPC.EXCLUSAO[EnumUtils.id];
        }
        wrapper.form.reset(historico);
      }));

    /**
     * Desabilita os componentes
     */
    this.addSubscription(this.getControl("registradoSpc")
      .combineLatest(this.getControl("tipoOperacaoSPC", this.formSPC$),
        (registrado: AbstractControl, tipo: AbstractControl) => ({registrado, tipo}))
      .subscribe((obj: { registrado: AbstractControl, tipo: AbstractControl }) => {
        obj.registrado.disable();
        obj.tipo.disable();
      }));
  }

}
