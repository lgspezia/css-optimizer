import { Component, Input, OnInit } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";

/**
 * @author Luan  on 27/06/2017.
 */
@Component({
  selector: "it-filial-dia",
  templateUrl: "filial-dia.form.component.html",
})
export class ItFilialDiaFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  constructor() {
    super();
  }

  public ngOnInit(): void {}
}
