import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { enumConverter, EnumUtils } from "../../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../../core/models/dataitem";
import { ServerError } from "../../../../../core/models/server-error";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { EntidadeTipoUnidadeMedida, TipoUnidadeMedida } from "./entidade-unidade-cte";

/**
 * Unidades de CTEs
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-unidade-cte",
  templateUrl: "entidade-unidade-cte.form.component.html",
})
export class ItEntidadeUnidadeCteFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formUnidadeCte$: BehaviorSubject<FormGroup>;

  public tiposUnidade$: Observable<IDataItem[]>;
  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<EntidadeTipoUnidadeMedida>;

  constructor(private formBuider: FormBuilder) {
    super();

    this.tiposUnidade$ = EnumUtils.getValues(TipoUnidadeMedida);
  }

  public ngOnInit(): void {
    this.formUnidadeCte$ = new BehaviorSubject(this.formBuider.group(new EntidadeTipoUnidadeMedida()));

    this.addSubscription(this.getControl("codigo", this.formUnidadeCte$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(6)])));

    this.addSubscription(this.getControl("tipoUnidade", this.formUnidadeCte$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required])));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idEntidade", "idEntidade", DataType.Number, 0, null, false),
      new ColumnDefinition("codigo", "Código unidade Nf-e", DataType.String, "*"),
      new ColumnDefinition("tipoUnidade", "Unidade Ct-e", DataType.String, "*", null, true, TipoUnidadeMedida, null, enumConverter),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEntidade", id.toString());
        return {endpoint: "tipos-unidade-entidade", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable.afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((unidade: EntidadeTipoUnidadeMedida) => {
          if (unidade.id) {
            unidade.id = NumberUtil.parseFloat(unidade.id.toString());
          }
          if (unidade.idEntidade) {
            unidade.idEntidade = NumberUtil.parseFloat(unidade.idEntidade.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .combineLatest(this.afterGet$,
        (unidade: EntidadeTipoUnidadeMedida, idEntidade: number) => ({unidade, idEntidade}))
      .subscribe((wrapper: { unidade: EntidadeTipoUnidadeMedida, idEntidade: number }) => {

        wrapper.unidade.idEntidade = wrapper.idEntidade;
        this.itFormTable.submit$.next(wrapper.unidade);
      }, (error) => this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$
      .subscribe((form: FormGroup) => form.reset(new EntidadeTipoUnidadeMedida())));
  }

}
