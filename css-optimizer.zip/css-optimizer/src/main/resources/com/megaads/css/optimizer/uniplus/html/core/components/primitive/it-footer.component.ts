import { Component, Input, OnInit } from "@angular/core";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { FormComponent } from "../../crud/form-component";
import { Modo } from "../../crud/grid.crud";
import { AutenticacaoService } from "../../services/autenticacao.service";
import { ContextoService } from "../../services/contexto.service";

@Component({
  selector: "it-footer",
  templateUrl: "it-footer.component.html",
})
export class ItFooterComponent {
  @Input() title: string;

}
