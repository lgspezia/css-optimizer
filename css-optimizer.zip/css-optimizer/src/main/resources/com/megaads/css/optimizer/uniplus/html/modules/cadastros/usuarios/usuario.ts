import { FormBuilder, FormGroup } from "@angular/forms";

import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { PreferenciaUsuario } from "./usuarios-preferencias/usuario-preferencia";

/**
 * @author Luan  on 17/07/2017.
 */
export class Usuario extends AbstractPojo {

  public nome = "";
  public inativo = 0;
  public inativoAux = false;
  public senha = "";
  public chave = "";
  public supervisor = 0;
  public supervisorAux = false;
  public percentualDesconto = 0;
  public validade = new Date;
  public codEntidade = "";
  public centroLucro = "";
  public alteraSenhaProximoLogin = false;
  public idPerfil = 0;
  public administrador = false;
  public percentualDescontoPerfil = 0;
  public valorDescontoPerfil = 0;
  public valorDesconto = 0;
  public percentualDescontoRecebimento = 0;
  public cartaoMagnetico = "";
  public idFilialTrabalho = 0;
  public idLocalEstoqueTrabalho = 0;
  public idSetor = 0;
  public idEntidade = 0;
  public tipoAcesso = TipoAcesso.USUARIO[EnumUtils.id];
  public valorLimiteCredito = 0;
  public email = "";
  public accesstoken = "";
  public refreshtoken = "";
  public assinatura = "";
  public dispositivo = "";
  public celular = "";
  public arquivoImagemEmail = "";

  public liberDesExQtFilial = 0;
  public liberaVendaOffline = 0;
  public pautaPreco = 0;

  public permiteMesa = false;
  public permiteComanda = false;
  public permiteBalcao = false;
  public permiteDelivery = false;
  public permiteEntrega = false;
  public permiteProducao = false;

  public preferenciaUsuario: FormGroup = new FormBuilder().group(new PreferenciaUsuario());

  // Variavel auxiliar para carregar nome da grid
  public nomePerfil = "";
}

export enum TipoAcesso {

  USUARIO = <any> {[EnumUtils.id]: "USUARIO", [EnumUtils.display]: "Usuário"},
  CLIENTE = <any> {[EnumUtils.id]: "CLIENTE", [EnumUtils.display]: "Cliente"},
}
