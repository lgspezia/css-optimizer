import { Component, Input } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../../core/crud/form-component";
import { ContextoService } from "../../../../../core/services/contexto.service";

/**
 * Limites de créditos de clientes.
 *
 * Created by Osiel on 22/06/17.
 */
@Component({
  selector: "it-entidade-limitecreditohistorico",
  templateUrl: "entidade-limitecredito-historico.form.component.html",
})
export class ItEntidadeLimiteCreditoHistoricoFormComponent extends FormComponent {
  @Input() public afterGet$: Observable<number>;

  public meioPagamento$: Observable<boolean>;

  constructor(private contexto: ContextoService) {
    super();

    this.meioPagamento$ = contexto.isFuncionalidade$("LIMITE_CREDITO_FORMA_PGMTO");
  }
}
