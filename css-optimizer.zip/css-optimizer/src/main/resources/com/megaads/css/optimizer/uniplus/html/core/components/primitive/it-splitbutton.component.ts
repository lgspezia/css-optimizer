import { Component, EventEmitter, Input, Output } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { IDataItem } from "../../models/dataitem";

@Component({
    selector: "it-splitbutton",
    template: `
        <wj-menu #menu [header]="label">
            <div *ngFor="let item of itens$ | async">
                <wj-menu-item [cmd]="menuCommand" [cmdParam]="item.id">
                    <i class="fa fa-{{item.icon}}"></i> {{item.display}}
                </wj-menu-item>
            </div>
        </wj-menu>
  `,
})
export class ItSplitButtonComponent {
  @Input() public label: string;
  @Input() public itens$: Observable<IDataItem[]>;

  @Output() public onSelect: EventEmitter<any> = new EventEmitter();

  public menuCommand = {
        executeCommand: (arg) => {
            this.onSelect.emit(arg);
        },
    };
}
