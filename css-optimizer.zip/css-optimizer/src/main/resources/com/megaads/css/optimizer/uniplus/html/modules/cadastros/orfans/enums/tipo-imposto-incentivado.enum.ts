import { EnumUtils } from "../../../../core/enuns/enumutil";
import { CstICMS, CstPisCofins } from "../../../produtos/produto";

export enum TipoImpostoIncentivado {
  ICMS = <any> {[EnumUtils.id]: "ICMS", [EnumUtils.display]: "ICMS", classeEnum: CstICMS},
  PIS = <any> {[EnumUtils.id]: "PIS", [EnumUtils.display]: "PIS", classeEnum: CstPisCofins},
  COFINS = <any> {[EnumUtils.id]: "COFINS", [EnumUtils.display]: "COFINS", classeEnum: CstPisCofins},
}
