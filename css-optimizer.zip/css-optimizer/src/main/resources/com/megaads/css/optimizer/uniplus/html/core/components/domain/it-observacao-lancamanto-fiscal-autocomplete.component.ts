import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { ObservacaoLancamentoFiscal } from "../../../modules/speds/observacoes-lancamentos-fiscais/observacao-lancamento-fiscal";

/**
 * @author Luan  on 08/06/2017.
 */

@Component({
  selector: "it-observacao-lancamento-fiscal-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItObservacaoLancamentoFiscalAutoCompleteComponent extends ItAutocompleteComponent<ObservacaoLancamentoFiscal> {

  constructor(httpService: HttpService) {
    super(httpService);

    this.url = "observacoes-lancamentos-fiscais";
    this.display = "descricao";
    this.label = "Observação complementar";
  }
}
