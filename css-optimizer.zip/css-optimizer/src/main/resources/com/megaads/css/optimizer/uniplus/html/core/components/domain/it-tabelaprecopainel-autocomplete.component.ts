import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { TabelaPrecoPainel } from "../../../modules/cadastros/orfans/tabela-preco-painel.model";

@Component({
    selector: "it-tabelaprecopainel-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItTabelaPrecoPainelAutocompleteComponent extends ItAutocompleteComponent<TabelaPrecoPainel> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "tabelas-preco-painel";
        this.label = "Tabela de preço do painel";
        this.display = "descricao";
    }
}
