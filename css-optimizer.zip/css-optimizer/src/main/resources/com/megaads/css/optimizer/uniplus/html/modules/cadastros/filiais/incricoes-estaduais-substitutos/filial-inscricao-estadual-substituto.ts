import { AbstractPojo } from "../../../../core/crud/pojo";
/**
 * @author Luan  on 26/06/2017.
 */

export class InscricaoEstadualContribuinteSubstituto extends AbstractPojo {
  public idFilial = 0;
  public idEstado = 0;
  public inscricaoEstadual = "";

  // auxiliar
  public estado = "";
}
