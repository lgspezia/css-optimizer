import { Component, Input, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { ContextoService } from "../../services/contexto.service";
import { BaseFormComponent } from "../primitive/baseform.component";

/**
 * @author Luan  on 11/08/2017.
 */
@Component({
  selector: "it-sped-contribuicao",
  templateUrl: "it-sped-contribuicao.component.html",
})
export class ItSpedContribuicaoComponent extends BaseFormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;
  @Input() public enablePrevidencia: boolean;
  @Input() public enableEntradaCredito: boolean;

  public contribuicaoSocialApurada$: Observable<boolean>;
  public contribuicaoSocialDiferentePisCofins$: Observable<boolean>;
  public semContribuicaoSocial$: Observable<boolean>;
  public spedFiscal$: Observable<boolean>;

  constructor(private contexto: ContextoService) {
    super();

    this.enablePrevidencia = true;
    this.enableEntradaCredito = true;
  }


  public ngOnInit(): void {

    this.contribuicaoSocialApurada$ = this.contexto.getPropriedade$(504).map((prop) => prop === "true");
    this.contribuicaoSocialDiferentePisCofins$ = this.contexto.getPropriedade$(253).map((prop) => prop === "true");
    this.semContribuicaoSocial$ = this.contribuicaoSocialDiferentePisCofins$.map((value) => !value);
    this.spedFiscal$ = this.contexto.getPropriedade$(166).map((prop) => prop === "true");

  }
}
