import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum TipoValorGnre {
  ICMSST = <any> {[EnumUtils.id]: "ICMSST", [EnumUtils.display]: "Valor do ICMS ST"},
  TOTAL_NOTA = <any>   {[EnumUtils.id]: "TOTAL_NOTA", [EnumUtils.display]: "Valor total da nota"},
  TOTAL_BRUTO_NOTA = <any> {[EnumUtils.id]: "TOTAL_BRUTO_NOTA", [EnumUtils.display]: "Valor total bruto da nota"},
  ICMS_UF_ORIGEM = <any> {[EnumUtils.id]: "ICMS_UF_ORIGEM", [EnumUtils.display]: "Valor do ICMS da UF de origem"},
  ICMS_UF_DESTINO = <any>   {[EnumUtils.id]: "ICMS_UF_DESTINO", [EnumUtils.display]: "Valor do ICMS da UF de destino"},
  FCP = <any> {[EnumUtils.id]: "FCP", [EnumUtils.display]: "Valor do Fundo de Combate a Pobreza"},
  ICMSST_NAO_DESTACADO_ORIGEM = <any> {
    [EnumUtils.id]: "ICMSST_NAO_DESTACADO_ORIGEM",
    [EnumUtils.display]: "Valor do ICMS ST não destacado na origem"
  },
}
