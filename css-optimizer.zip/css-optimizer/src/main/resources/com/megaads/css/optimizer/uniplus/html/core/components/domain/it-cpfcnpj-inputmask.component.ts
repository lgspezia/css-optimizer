import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, FormControl, ValidatorFn } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { Observable } from "rxjs/Observable";

import { applicationInjector } from "../../../app.module";
import { cpfCnpjValidator, requiredMaskValidator, TipoValidadorCpfCnpj } from "../../crud/validadores";
import { ContextoService } from "../../services/contexto.service";
import { HttpService } from "../../services/http.service";
import { ItInputMaskComponent } from "../primitive/it-inputmask.component";

/**
 * Componente de CPF CNPJ
 *
 * Created by Osiel S. Mello on 19/05/2017.
 */
@Component({
  selector: "it-cpfcnpj-inputmask",
  templateUrl: "../primitive/it-inputmask.component.html",
})
export class ItCpfCnpjInputMaskComponent extends ItInputMaskComponent implements OnInit {
  @Input() public tipoComponent$: Observable<TipoValidadorCpfCnpj>;
  @Input() public required$: Observable<boolean>;
  @Input() public validarDuplicado: boolean;
  @Input() public urlValidacaoDuplicado: string;


  constructor() {
    super();
    this.tipoComponent$ = Observable.of(TipoValidadorCpfCnpj.CPF);
    this.validarDuplicado = false;
    this.required$ = Observable.of(false);
  }

  public ngOnInit(): void {
    this.addSubscription(this.tipoComponent$
      .combineLatest(this.required$, this.getControl(),
        (tipo: TipoValidadorCpfCnpj, required: boolean, control: AbstractControl) => ({tipo, required, control}))
      .subscribe((wrapper: { tipo: TipoValidadorCpfCnpj, required: boolean, control: AbstractControl }) => {

        this.mask = wrapper.tipo === TipoValidadorCpfCnpj.CPF ? "999,999,999-99" : "99,999,999/9999-99";
        this.label = wrapper.tipo === TipoValidadorCpfCnpj.CPF ? "CPF" : "CNPJ";

        const validadores: ValidatorFn[] = [];
        if (wrapper.required) {
          validadores.push(requiredMaskValidator(TipoValidadorCpfCnpj.CPF ? "___.___.___-__" : "__.___.___/____-__"));
        }

        validadores.push(cpfCnpjValidator(wrapper.tipo));
        wrapper.control.setValidators(validadores);

        if (this.validarDuplicado) {
          wrapper.control.setAsyncValidators([validarCpfCnpjDuplicado(this.urlValidacaoDuplicado, wrapper.tipo)]);
        }
      }));
  }

}

/**
 * Validador de CPF CNPJ duplicado.
 * @param url: string
 * @param tipo: TipoValidadorCpfCnpj
 * @return {(formControl:FormControl)=>any}
 */
function validarCpfCnpjDuplicado(url: string, tipo: TipoValidadorCpfCnpj) {
  return (formControl: FormControl) => {

    return applicationInjector.get(ContextoService).getPropriedade$(42)
      .switchMap((permitirDuplicado: string) => {
        if (permitirDuplicado !== "false") {
          return Observable.of(null);
        }
        const params: URLSearchParams = new URLSearchParams();
        params.set("value", formControl.value.toString());

        const codigo: AbstractControl = formControl.parent.get("codigo");
        params.set("codigo", codigo ? codigo.value : null);

        return applicationInjector.get(HttpService)
          .get(url, {search: params})
          .map((resp: boolean) => !resp ? null :
            {
              cpfCnpjDuplicado: tipo === TipoValidadorCpfCnpj.CPF ?
                "WWW69- Esse CPF já foi cadastrado." : "WWW70 - Esse CNPJ já foi cadastrado.",
            });

      }).first();

  };
}

