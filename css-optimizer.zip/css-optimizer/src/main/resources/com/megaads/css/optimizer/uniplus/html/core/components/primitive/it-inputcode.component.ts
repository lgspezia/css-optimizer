import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";

import { ServerError } from "../../models/server-error";
import { HttpService } from "../../services/http.service";
import { StringUtil } from "../../utils/string.util";
import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-inputcode",
  templateUrl: "it-inputcode.component.html",
})
export class ItInputCodeComponent extends BaseFormComponent implements OnInit {
  @Input() public placeholder = "";
  @Input() public len = 6;
  @Input() public url: string;
  @Input() public exibirBotao$: Observable<boolean>;
  @Input() public endPoint: string;

  @Output() public gerar$: EventEmitter<any>;
  public icon: string;
  private urlParams: URLSearchParams;

  constructor(protected httpService: HttpService) {
    super();
    this.exibirBotao$ = Observable.of(true);
    this.gerar$ = new EventEmitter();
    this.urlParams = new URLSearchParams();
    this.icon = "cog";
  }

  public ngOnInit(): void {
    if (!this.endPoint) {
      this.endPoint = `${this.url}/last-valid-code`;
    }

    /**
     * Quando o botão de geração é acionado combina com o control e filtra para saber se possui valor,
     * somente será gerado se não possuir valor, na sequência utiliza o http para fazer a requisição
     * e combina com o control para setar o valor.
     */
    this.addSubscription(this.gerar$
      .withLatestFrom(this.getControl(), (gerar: any, control: AbstractControl) => control)
      .filter((control: AbstractControl) => StringUtil.stringNullOrEmpty(control.value))
      .switchMap((control: AbstractControl) => this.httpService.get(this.endPoint, {search: this.urlParams})
        .map((resp: string) => ({resp, control})),
      )
      .subscribe(({resp, control}: { resp: string, control: AbstractControl }) => control.setValue(resp),
        (error: ServerError) => this.handleError(error)));

  }

  /**
   * Adiciona os parâmetros necessários para o endpoint.
   * @param param: string
   * @param value: any
   */
  public addParams(param: string, value: any) {
    this.urlParams.set(param, value);
  }

  /**
   * Retorna os parâmetros de consulta adicionados.
   * @return {URLSearchParams}
   */
  public get params(): URLSearchParams {
    return this.urlParams;
  }

  /**
   * Executa a chamada para o endpoint.
   */
  public gerar(): void {
    this.gerar$.next();
  }

}
