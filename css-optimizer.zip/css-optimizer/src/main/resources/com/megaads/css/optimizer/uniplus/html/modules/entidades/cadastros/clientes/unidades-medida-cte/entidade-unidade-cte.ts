import { AbstractPojo } from "../../../../../core/crud/pojo";
import { EnumUtils } from "../../../../../core/enuns/enumutil";

/**
 * Unidade de medida de CTE
 *
 * Created by Osiel on 26/05/17.
 */
export class EntidadeTipoUnidadeMedida extends AbstractPojo {

  public idEntidade = 0;
  public codigo = "";
  public tipoUnidade: TipoUnidadeMedida = TipoUnidadeMedida.UNIDADE[EnumUtils.id];
}

export enum TipoUnidadeMedida {
  M3 = <any> {[EnumUtils.id]: "M3", [EnumUtils.display]: "M3"},
  KG = <any> {[EnumUtils.id]: "KG", [EnumUtils.display]: "KG"},
  TON = <any> {[EnumUtils.id]: "TON", [EnumUtils.display]: "TON"},
  UNIDADE = <any> {[EnumUtils.id]: "UNIDADE", [EnumUtils.display]: "UNIDADE"},
  LITROS = <any> {[EnumUtils.id]: "LITROS", [EnumUtils.display]: "LITROS"},
  MMBTU = <any> {[EnumUtils.id]: "MMBTU", [EnumUtils.display]: "MMBTU"},
}
