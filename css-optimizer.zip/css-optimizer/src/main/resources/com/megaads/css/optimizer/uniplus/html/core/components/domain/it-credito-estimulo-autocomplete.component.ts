import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { CreditoEstimulo } from "../../../modules/speds/creditos-estimulo/credito-estimulo";

/**
 * @author Luan  on 09/06/2017.
 */

@Component({
  selector: "it-credito-estimulo-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItCreditoEstimuloAutoCompleteComponent extends ItAutocompleteComponent<CreditoEstimulo> {

  constructor(httpService: HttpService) {
    super(httpService);

    this.url = "creditos-estimulo";
    this.label = "Crédito de estímulo";
    this.display = "descricao";
  }
}
