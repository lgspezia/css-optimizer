import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";
import { WjPopup } from "wijmo/wijmo.angular2.input";

import { applicationInjector } from "../../../../app.module";
import { ProdutoNumeroSerie } from "../../../../modules/produtos/numeros-serie/produto-numero-serie";
import { Produto } from "../../../../modules/produtos/produto";
import { ColumnDefinition } from "../../../crud/column-definition";
import { AbstractPojo } from "../../../crud/pojo";
import { EnumUtils } from "../../../enuns/enumutil";
import { ServerError } from "../../../models/server-error";
import { HttpService } from "../../../services/http.service";
import { ArrayUtil } from "../../../utils/array.util";
import { NumberUtil } from "../../../utils/number.util";
import { StringUtil } from "../../../utils/string.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItFormTableComponent } from "../../primitive/it-formtable.component";
import { ItTableComponent } from "../../primitive/it-table.component";
import { TipoMovimento } from "../it-cfop-internaexterna-autocomplete.component";

/**
 *
 * Cadastramentos de números de série.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-produto-numero-serie",
  templateUrl: "it-produto-numero-serie.component.html",
})
export class ItProdutoNumeroSerieComponent extends BaseFormComponent implements OnInit {
  @Input() public controlNumeroSerie: string;
  @Input() public controlProduto: string;
  @Input() public eventBlur$: EventEmitter<any>;
  @Input() public idCrud$: Observable<number>;
  @Input() public informarNumeroSerie$: Observable<boolean>;
  @Input() public produto$: Observable<Produto>;
  @Input() public quantidadeEsperada$: Observable<number>;
  @Input() public resourceNameValidationSaldo: string;
  @Input() public tipoMovimento$: Observable<TipoMovimento>;
  @Input() public validarNumeroSerie$: Observable<boolean>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public columnsSearch$: BehaviorSubject<ColumnDefinition[]>;
  public title$: Observable<string>;
  public formItem$: BehaviorSubject<FormGroup>;
  public formNumeroSerie$: BehaviorSubject<FormGroup>;
  public search$: Subject<boolean>;
  public searchVisible$: Observable<boolean>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<NumeroSerie>;
  @ViewChild(ItTableComponent) private itTableSearch: ItTableComponent<NumeroSerie>;
  @ViewChild(WjPopup) private popup: WjPopup;

  constructor(private formBuilder: FormBuilder) {
    super();
    this.informarNumeroSerie$ = Observable.of(true);
    this.quantidadeEsperada$ = Observable.of(null);
    this.search$ = new Subject();
  }

  public ngOnInit(): void {
    /**
     * Inicializa um form dummy apenas para trabalhar com os componentes.
     * @type {BehaviorSubject<FormGroup>}
     */
    this.formNumeroSerie$ = new BehaviorSubject(this.formBuilder.group({numerosSerie: []}));

    /**
     * Form de itens.
     * @type {BehaviorSubject<FormGroup>}
     */
    this.formItem$ = new BehaviorSubject(new FormBuilder().group(new NumeroSerie()));

    this.searchVisible$ = this.tipoMovimento$
      .map((tipoMovimento: TipoMovimento) => tipoMovimento[EnumUtils.id] === TipoMovimento.SAIDA[EnumUtils.id]);

    /**
     * Exibe o popup se possui Números de série ou limpa os dados para evitar lixo em produto errado.
     */
    this.addSubscription(this.eventBlur$
      .withLatestFrom(this.produto$, this.getControl(this.controlNumeroSerie), this.informarNumeroSerie$,
        (event: any, produto: Produto, numeros: AbstractControl, informar: boolean) => ({produto, numeros, informar}))
      .subscribe((wrapper: { produto: Produto, numeros: AbstractControl, informar: boolean }) => {
        if (wrapper.produto.numeroSerie && wrapper.informar) {
          this.search$.next(false);

          const numerosSerie: NumeroSerie[] = [];

          if (!ArrayUtil.nullOrEmpty(wrapper.numeros.value)) {
            wrapper.numeros.value.forEach((numero: string) => {
              const num: NumeroSerie = new NumeroSerie();
              num.numeroSerie = numero;
              numerosSerie.push(num);
            });
          }

          this.itFormTable.updateItemsSource(numerosSerie);

          this.show();
        } else {
          wrapper.numeros.setValue(null);
        }
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([new ColumnDefinition("numeroSerie", "Número de série", DataType.String, "*")]);

    this.columnsSearch$ = new BehaviorSubject([
      new ColumnDefinition("selecionado", " ", DataType.Boolean, 40, null, true, null, null, null, true),
      new ColumnDefinition("numeroSerie", "Número de série", DataType.String, "*"),
    ]);

    /**
     * Titulo do popup.
     * @type {Observable<any> | Observable<string>}
     */
    this.title$ = this.search$
      .startWith(false)
      .combineLatest(this.produto$
          .map((produto: Produto) => produto.nome.toUpperCase()),
        (search: boolean, descricao: string) => search ? `Selecione o(s) número(s) de série` : `Números de série de ${descricao}`);

    /**
     * Busca os valores existente em estoque no servidor.
     */
    this.addSubscription(this.search$
      .filter((search: boolean) => search)
      .withLatestFrom(this.produto$, (search: boolean, produto: Produto) => produto)
      .switchMap((produto: Produto) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", produto.id.toString());

        return this.itFormTable.httpService.get(`numeros-serie/filtrar-por-produto-estoque`, {search: params});
      })
      .subscribe((numerosServidor: ProdutoNumeroSerie[]) => {
        const itensExistentes = this.itFormTable.sourceCollection;
        const numerosSerie: NumeroSerie[] = [];

        /**
         * Filtra os itens que já estão na lista.
         */
        if (!ArrayUtil.nullOrEmpty(itensExistentes)) {
          numerosServidor = numerosServidor
            .filter((numero: ProdutoNumeroSerie) => !itensExistentes
              .some((n: NumeroSerie) => n.numeroSerie.trim().toUpperCase() === numero.numeroserie.trim().toUpperCase()));
        }

        numerosServidor.forEach((num: ProdutoNumeroSerie) => {
          const numero: NumeroSerie = new NumeroSerie();
          numero.numeroSerie = num.numeroserie;
          numerosSerie.push(numero);
        });

        this.itTableSearch.updateItemsSource(numerosSerie);
        this.itTableSearch.clearSelection();
      })
    );

    /**
     * Validações.
     */
    this.addSubscription(this.validarNumeroSerie$
      .combineLatest(this.getControl("numeroSerie", this.formItem$), this.tipoMovimento$,
        (validar: boolean, control: AbstractControl, tipoMovimento: TipoMovimento) =>
          ({validar, control, tipoMovimento}))
      .subscribe((wrapper: { validar: boolean, control: AbstractControl, tipoMovimento: TipoMovimento }) => {

        wrapper.control.clearValidators();
        wrapper.control.clearAsyncValidators();
        wrapper.control.setValidators([Validators.required]);

        wrapper.control.setAsyncValidators([numeroSerieAsyncValidator(this.itFormTable,
          this.produto$, this.idCrud$, this.getControl("id"), wrapper.tipoMovimento, this.resourceNameValidationSaldo, wrapper.validar)]);
      }));

    /**
     * Adiciona o item na table.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .withLatestFrom(this.tipoMovimento$, this.validarNumeroSerie$,
        (numeroSerie: NumeroSerie, tipoMovimento: TipoMovimento, validar) => ({numeroSerie, tipoMovimento, validar}))
      .switchMap((wrapper: { numeroSerie: NumeroSerie, tipoMovimento: TipoMovimento, validar: boolean }) =>
        numeroSerieAsyncValidate$(this.itFormTable, this.produto$, this.idCrud$, this.getControl("id"),
          wrapper.tipoMovimento, this.resourceNameValidationSaldo, wrapper.numeroSerie.numeroSerie, wrapper.validar)
          .map((validate: { numValidate: string }) => ({numeroSerie: wrapper.numeroSerie, validate})))
      .subscribe((wrapper: { numeroSerie: NumeroSerie, validate: { numValidate: string } }) => {

        /**
         * Se não passou na validação, exibe a mensagem e retorna.
         */
        if (wrapper.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(wrapper.validate.numValidate));
          return;
        }

        this.itFormTable.push(wrapper.numeroSerie);
        this.itFormTable.success("A inclusão foi feita com sucesso");

        this.itFormTable.clear$.next();
      }));

    /**
     * Exclusão
     */
    this.addSubscription(this.itFormTable.delete$
      .subscribe((numeroSerie: NumeroSerie) => {
        this.itFormTable.deletePojo(numeroSerie);
        this.itFormTable.success("Exclusão realizada com sucesso");
      }));

    /**
     * Limpa o componente para informar um novo número de série.
     */
    this.addSubscription(this.itFormTable.afterReset$
      .switchMap(() => this.getControl("numeroSerie", this.formItem$))
      .subscribe((control: AbstractControl) => control.setValue("")));
  }

  /**
   * Retorna as informações de quantidade.
   * @return {Observable<string>}
   */
  public get informacaoQuantidade$(): Observable<string> {
    return this.quantidadeEsperada$
      .filter((qtd: number) => !NumberUtil.numberNullOrZero(qtd))
      .map((qtd: number) => `Quantidade esperada ${qtd} - Quantidade informada ${this.itFormTable.sourceCollection.length}`);
  }

  /**
   * Exibe a dialog. Quando fechada limpa o form.
   */
  public show(): void {
    this.popup.show(true, () => this.itFormTable.clear$.next());
  }

  /**
   * Carrega os números de séries selecionados para a table.
   */
  public loadNumbers(): void {
    this.itTableSearch.sourceCollection.filter((num: NumeroSerie) => num.selecionado)
      .forEach((num: NumeroSerie) => {
        const existe: boolean = this.itFormTable
          .sourceCollection
          .some((numero: NumeroSerie) => numero.numeroSerie.trim().toUpperCase() === num.numeroSerie.trim().toUpperCase());

        if (existe) {
          this.itFormTable.handleError({
            status: null,
            codigo: "VND18",
            mensagem: `Número de série ${num.numeroSerie} já digitado.`,
          });
          return;
        }

        this.itFormTable.push(num);
      });

    this.search$.next(false);
  }

  /**
   * Submit.
   */
  public submit(): void {
    this.quantidadeEsperada$
      .combineLatest(this.getControl(this.controlNumeroSerie),
        (qtd: number, control: AbstractControl) => ({qtd, control}))
      .subscribe((wrapper: { qtd: number, control: AbstractControl }) => {
        const numerosSerie: NumeroSerie[] = this.itFormTable.sourceCollection;
        if (ArrayUtil.nullOrEmpty(numerosSerie)) {
          this.itFormTable.handleError({
            status: null,
            codigo: "VND19",
            mensagem: "Por favor informe os números de série"
          });
          return;
        }
        if (!NumberUtil.numberNullOrZero(wrapper.qtd) && wrapper.qtd !== numerosSerie.length) {
          this.itFormTable.handleError({
            status: null,
            codigo: "VND20",
            mensagem: `É necessário informar ${wrapper.qtd} número(s) de série. Por favor verifique.`
          });
          return;
        }

        const listaString: string[] = [];
        numerosSerie.forEach((num: NumeroSerie) => listaString.push(num.numeroSerie));

        wrapper.control.setValue(listaString);
        this.popup.hide(true);
      }).unsubscribe();
  }
}

/**
 * Pojo dummy para auxilio.
 */
export class NumeroSerie extends AbstractPojo {
  public selecionado = false;
  public numeroSerie = "";
}

/**
 * Validador para número de série.
 * @param {ItFormTableComponent<NumeroSerie>} itFormTable
 * @param {Observable<Produto>} produto$
 * @param {Observable<number>} idCrud$
 * @param {Observable<AbstractControl>} idItem$
 * @param {TipoMovimento} tipoMovimento
 * @param {string} resourceNameValidationSaldo
 * @param {boolean} validarNumeroSerie determina se irá validar o saldo no servidor.
 * @return {(form: FormControl) => Observable<any>}
 */
function numeroSerieAsyncValidator(itFormTable: ItFormTableComponent<NumeroSerie>, produto$: Observable<Produto>,
                                   idCrud$: Observable<number>, idItem$: Observable<AbstractControl>,
                                   tipoMovimento: TipoMovimento, resourceNameValidationSaldo: string, validarNumeroSerie: boolean) {
  return (form: FormControl) => {
    return numeroSerieAsyncValidate$(
      itFormTable, produto$, idCrud$, idItem$, tipoMovimento, resourceNameValidationSaldo, form.value, validarNumeroSerie,
    );
  };
}

/**
 * Valida se o número de série já existe na table e o saldo informado.
 * @param {ItFormTableComponent<NumeroSerie>} itFormTable
 * @param {Observable<Produto>} produto$
 * @param {Observable<number>} idCrud$
 * @param {Observable<AbstractControl>} idItem$
 * @param {TipoMovimento} tipoMovimento
 * @param {string} resourceNameValidationSaldo
 * @param {string} numeroSerie
 * @param {boolean} validarNumeroSerie determina se irá validar no servidor.
 * @return {Observable<any>}
 */
function numeroSerieAsyncValidate$(itFormTable: ItFormTableComponent<NumeroSerie>, produto$: Observable<Produto>,
                                   idCrud$: Observable<number>, idItem$: Observable<AbstractControl>,
                                   tipoMovimento: TipoMovimento, resourceNameValidationSaldo: string,
                                   numeroSerie: string, validarNumeroSerie: boolean): Observable<{ numValidate: string }> {

  const http: HttpService = applicationInjector.get(HttpService);

  return idItem$
    .combineLatest(idCrud$, produto$,
      (idItem: AbstractControl, id: number, produto: Produto) =>
        ({produto, id, idItem: idItem.value}))
    .switchMap((wrapper: { produto: Produto, id: number, idItem: number }) => {

      const existe: boolean = itFormTable
        .sourceCollection
        .some((numero: NumeroSerie) => numero.numeroSerie.trim().toUpperCase() === numeroSerie.trim().toUpperCase());

      if (existe) {
        return Observable.of({numValidate: "VND18 - Número de série já digitado."});
      } else if (validarNumeroSerie) {

        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", wrapper.produto.id.toString());
        if (wrapper.id) {
          params.set("idCrud", wrapper.id.toString());
        }
        if (wrapper.idItem) {
          params.set("idItemAtual", wrapper.idItem.toString());
        }
        params.set("tipoMovimento", tipoMovimento[EnumUtils.id]);
        params.set("numeroSerie", numeroSerie);
        params.set("resourceName", resourceNameValidationSaldo);

        return http.get(`produtos/validar-numero-serie`, {search: params})
          .map(() => null)
          .catch((error: ServerError) => Observable.of({numValidate: `${error.codigo} - ${error.mensagem}`}));
      }
      return Observable.of(null);
    })
    .first();

}
