import { ChangeDetectionStrategy, Component, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { ContextoService } from "../services/contexto.service";
import { IMenu } from "./IMenu";

@Component({
    changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-menuvertical",
    templateUrl: "menuvertical.component.html",
})
export class MenuVerticalComponent implements OnInit {
    public menu$: Observable<IMenu[]>;

    constructor(private contextoService: ContextoService) {
    }

    public ngOnInit(): void {
        this.menu$ = this.contextoService.menusAtivos$;
    }
}
