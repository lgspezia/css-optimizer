import { AbstractPojo } from "../../../core/crud/pojo";
import { MotivoDesoneracaoIcms } from "./enums/motivo-desoneracao-icms.enum";
import { MotivoDesoneracaoPisCofins } from "./enums/motivo-desoneracao-pis-cofins.enum";
import { TipoImpostoIncentivado } from "./enums/tipo-imposto-incentivado.enum";

export class NaturezaOperacaoIncentivoImposto extends AbstractPojo {
  public idNaturezaOperacao = 0;
  public tipoImposto: TipoImpostoIncentivado;
  public idIncentivoFiscal = 0;
  public idEstado = 0;
  public cst = "";
  public motivoDesoneracaoIcms: MotivoDesoneracaoIcms;
  public motivoDesoneracaoPisCofins: MotivoDesoneracaoPisCofins;
  public descricaoIncentivoFiscal = "";
  public ufEstado = "";
}
