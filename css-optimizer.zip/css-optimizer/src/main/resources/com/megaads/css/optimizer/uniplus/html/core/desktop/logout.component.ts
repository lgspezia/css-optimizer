import { Component, OnInit } from "@angular/core";

import { AutenticacaoService } from "../services/autenticacao.service";
import { SpinnerService } from "../services/spinner.service";
/**
 * Componente de Login
 */
@Component({
    template: "",
})
export class LogoutComponent implements OnInit {

    constructor(private autenticacaoService: AutenticacaoService, private spinService: SpinnerService) { };

    public ngOnInit(): void {
        this.spinService.show();
        this.autenticacaoService.doLogout();
    }
}
