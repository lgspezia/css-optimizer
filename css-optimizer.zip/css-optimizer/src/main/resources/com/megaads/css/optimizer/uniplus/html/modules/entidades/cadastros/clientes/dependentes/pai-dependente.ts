/**
 * Representação de pai de dependente.
 *
 * Created by Osiel on 28/05/17.
 */
export class PaiDependente {
  public pai = "";
  public limite = 0;
}
