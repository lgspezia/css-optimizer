import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";
/**
 * Created by luan on 31/05/17.
 */
export class BandeiraCartao extends AbstractPojo {
  public nome = "";
  public tipoBandeira: TipoBandeiraNFE = TipoBandeiraNFE.UNDEFINED[EnumUtils.id];
}

export enum TipoBandeiraNFE {

  UNDEFINED = <any> {[EnumUtils.id]: "UNDEFINED", [EnumUtils.display]: "-- selecione --"},
  VISA = <any> {[EnumUtils.id]: "VISA", [EnumUtils.display]: "Visa"},
  MASTERCARD = <any> {[EnumUtils.id]: "MASTERCARD", [EnumUtils.display]: "Mastercard"},
  AMERICAN_EXPRESS = <any> {[EnumUtils.id]: "AMERICAN_EXPRESS", [EnumUtils.display]: "American Express"},
  SOROCRED = <any> {[EnumUtils.id]: "SOROCRED", [EnumUtils.display]: "Sorocred"},
  OUTROS = <any> {[EnumUtils.id]: "OUTROS", [EnumUtils.display]: "Outros"},
}
