import { AbstractPojo } from "../../../../../../core/crud/pojo";

/**
 * Representação de limite de crédito por forma de PGMTO.
 *
 * Created by Osiel on 22/06/17.
 */
export class LimiteCreditoFormaPgmto extends AbstractPojo {

  public idCliente = 0;
  public idFormaPgmto = 0;
  public dataInclusao: Date = new Date();
  public idUsuarioResponsavel = 0;
  public valorLimiteCredito = 0;
  public valorLimiteCreditoEspecial = 0;
  public liberacaoEspecial = false;
  public dataLiberacaoEspecialInicial: Date = new Date;
  public dataLiberacaoEspecialFinal: Date = new Date();

  // Transientes
  public idFormaPgmtoEspecial = 0;
  public formaPgmto = "";
  public creditoDisponivel = 0;
  public divida = 0;
  public dividaDependentes = 0;
  public dividaPai = 0;
  public valorLimiteCreditoPai = 0;

}
