import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../../core/crud/form-component";
import { maxNumberValidator } from "../../../../../core/crud/validadores";
import { EnumUtils } from "../../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../../core/models/dataitem";
import { ContextoService } from "../../../../../core/services/contexto.service";
import { TipoAvisoFinalizacaoOS } from "../../entidade";

/**
 * Preferências e outras observações de entidade.
 *
 * Created by Osiel on 01/06/17.
 */
@Component({
  selector: "it-entidade-preferenciaobservacao",
  templateUrl: "entidade-preferencia-observacao.form.component.html",
})
export class ItEntidadePreferenciaObservacaoComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;
  @Input() public cliente$: Observable<boolean>;

  public preferenciaEntidade$: Observable<boolean>;

  public tiposAvisoOS$: Observable<IDataItem[]>;

  constructor(private contexto: ContextoService) {
    super();
    this.tiposAvisoOS$ = EnumUtils.getValues(TipoAvisoFinalizacaoOS);
  }

  public ngOnInit(): void {
    this.preferenciaEntidade$ = this.cliente$
      .combineLatest(this.contexto.isFuncionalidade$("PREFERENCIA_ENTIDADE"), (c: boolean, f: boolean) => c && f);

    this.addSubscription(this.getControl("diaVencimento")
      .merge(this.getControl("diaVencimento"))
      .subscribe((c: AbstractControl) => c.setValidators([maxNumberValidator(31)])));
  }
}
