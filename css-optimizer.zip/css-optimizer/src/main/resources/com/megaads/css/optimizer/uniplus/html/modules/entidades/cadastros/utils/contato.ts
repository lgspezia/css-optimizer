/**
 * Pojo de Contato.
 *
 * Created by Osiel S. Mello on 16/05/2017.
 */
export class Contato {
    public nome = "";
    public telefone = "";
    public celular = "";
    public fax = "";
    public email = "";
    public dataNascimento: Date = new Date();
}
