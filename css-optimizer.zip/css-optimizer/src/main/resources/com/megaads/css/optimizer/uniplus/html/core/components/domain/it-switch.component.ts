import { Component, Input } from "@angular/core";

import { BaseFormComponent } from "../primitive/baseform.component";

/**
 * Componente de Switch.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-switch",
  templateUrl: "it-switch.component.html",
})
export class ItSwitchComponent extends BaseFormComponent {
  @Input() public size: string;
  @Input() public color = "#6f9508";
  @Input() public defaultBgColor = "#fff";
  @Input() public switchColor = "#fff";
  @Input() public switchOffColor: string;
  @Input() public conditionOn: string;
  @Input() public conditionOff: string;
  @Input() public conditionInit: boolean;

  constructor() {
    super();
    this.conditionInit = false;
  }
}
