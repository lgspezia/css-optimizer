import { Component, Input } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputint",
    templateUrl: "it-inputint.component.html",
})
export class ItInputIntComponent extends BaseFormComponent {
  @Input() public min$: Observable<number>;
  @Input() public max$: Observable<number>;

    constructor() {
        super();
        this.min$  = Observable.of(0);
        this.max$ = Observable.of(999999999);
    }
}
