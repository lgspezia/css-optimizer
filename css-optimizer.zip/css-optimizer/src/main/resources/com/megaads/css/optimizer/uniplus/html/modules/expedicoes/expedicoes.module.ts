import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";

import { WjInputModule } from "wijmo/wijmo.angular2.input";

import { ComponentsModule } from "../../core/components/primitive/components.module";
import { RotaGridCrudComponent } from "./rotas/rota.grid.crud.component";

const routes: Routes = [
    {path: "rotas", component: RotaGridCrudComponent},
];

@NgModule({
    declarations: [RotaGridCrudComponent],
    exports: [RouterModule],
    imports: [RouterModule.forChild(routes), CommonModule, ComponentsModule, ReactiveFormsModule, WjInputModule],
})
export class ExpedicoesModule {
}
