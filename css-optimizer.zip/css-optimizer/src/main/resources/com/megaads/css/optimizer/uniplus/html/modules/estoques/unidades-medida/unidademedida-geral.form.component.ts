import { Component, OnInit } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../core/crud/form-component";
import { maxNumberValidator, uniqueAsyncValidator } from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { TipoValorUnidadeMedida } from "./unidademedida";

/**
 * Unidades de medida.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-unidademedida-geral",
  templateUrl: "unidademedida-geral.form.html",
})
export class ItUnidadeMedidaGeralFormComponent extends FormComponent implements OnInit {

  public max$: Observable<number>;
  public tipo$: Observable<IDataItem[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super();

    this.max$ = Observable.of(6);
    this.tipo$ = EnumUtils.getValues(TipoValorUnidadeMedida);
  }

  public ngOnInit(): void {
    this.addSubscription(this.getControl("codigo")
      .subscribe((c: AbstractControl) => {
        c.setValidators([Validators.required, Validators.maxLength(6)]);
        c.setAsyncValidators([uniqueAsyncValidator("unidades-medida")]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("nome")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(50)])));

    this.addSubscription(this.getControl("casasdecimais")
      .subscribe((c: AbstractControl) => c.setValidators([maxNumberValidator(6)])));
  }

}
