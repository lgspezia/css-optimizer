import { Component, EventEmitter, ViewChild } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { WjPopup } from "wijmo/wijmo.angular2.input";

import { ICustomizableColumn } from "../../../core/crud/customizable-column";
import { IEditDetails } from "../../../core/crud/edit-details";
import { GridCrud, Modo } from "../../../core/crud/grid.crud";
import { enumConverter, EnumUtils } from "../../../core/enuns/enumutil";
import { ServerError } from "../../../core/models/server-error";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { Usuario } from "../../cadastros/usuarios/usuario";
import { AjusteEstoque, StatusAjusteEstoque, TipoAjusteEstoque } from "./ajuste-estoque";


/**
 * Ajuste de estoque.
 *
 * @author Osiel.
 */
@Component({
  templateUrl: "ajuste-estoque.grid.crud.html",
})
export class AjusteEstoqueGridCrudComponent extends GridCrud<AjusteEstoque> {

  public cancel$: Observable<boolean>;
  public customizableColumns$: Observable<ICustomizableColumn[]>;
  public enableEdit$: Observable<boolean>;
  public textDialog$: Observable<string>;
  public onCancelRevert$: EventEmitter<boolean>;

  @ViewChild("popup") private popup: WjPopup;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService) {
    super(activatedRoute, formBuilder, new AjusteEstoque(), "ajustes-estoque");

    this.enableEdit$ = Observable.of(false);
    this.onCancelRevert$ = new EventEmitter();

    /**
     * Conversores para as enuns
     * @type {Observable<ICustomizableColumn[]>}
     */
    this.customizableColumns$ = Observable.of([
      {binding: "tipoMovimento", enumClass: TipoAjusteEstoque, converter: enumConverter},
      {binding: "status", enumClass: StatusAjusteEstoque, converter: enumConverter},
    ]);

    this.cancel$ = this.onCancelRevert$
      .startWith(true);

    this.textDialog$ = this.cancel$
      .map((cancel: boolean) => cancel ? "O registro já foi gravado e será excluído." :
        "Todas as alterações no estoque feitas por este documento serão revertidas.");

    /**
     * Monitora a ação de cancelamento, se já possui id  e for inclusão irá excluir o ajuste.
     */
    this.addSubscription(this.onCancelRevert$
      .withLatestFrom(this.modo$, this.getValueChanges("id").startWith(0),
        (cancel: boolean, modo: Modo, id: number) => ({cancel, id, modo}))
      .subscribe((obj: { cancel: boolean, id: number, modo: Modo }) => {
        if (!NumberUtil.numberNullOrZero(obj.id) && obj.modo === Modo.CREATE || !obj.cancel) {
          this.popup.show(true);
        } else if (obj.cancel) {
          this.onCancel();
        }
      }));

    /**
     * Seta os dados do usuário antes de enviar o objeto.
     */
    this.addSubscription(this.beforeSubmit$
      .combineLatest(this.contexto.usuario$,
        (details: IEditDetails<AjusteEstoque>, usuario: Usuario) => ({details, usuario}))
      .subscribe((obj: { details: IEditDetails<AjusteEstoque>, usuario: Usuario }) => {
        obj.details.pojo.status = StatusAjusteEstoque.FINALIZADO[EnumUtils.id];
        obj.details.pojo.idUsuario = obj.usuario.id;
        obj.details.pojo.nomeUsuario = obj.usuario.nome;
      }));
  }

  /**
   * Como o ajuste de estoque já foi gravado em banco, é necessário excluir.
   */
  public deleteDocument(): void {
    this.popup.hide();
    this.spinnerService.show();
    this.getValue("id")
      .switchMap((id: number) => this.httpService.delete(`ajustes-estoque`, id)
        .map(() => id))
      .subscribe((id: number) => {

        /**
         * Exclui o registro se existir.
         */
        const ajuste: AjusteEstoque = this.getById(id);
        if (ajuste) {
          ajuste.id = NumberUtil.parseFloat(ajuste.id.toString());
          this.deleteItemGrid(ajuste);
        }

        this.toasterService.popSuccess("O registro foi excluído!");
        this.spinnerService.hide();
        this.onCancel();
      });
  }

  /**
   * Inicia a etapa de estorno.
   */
  public onRevert(): void {
    const ajuste: AjusteEstoque = this.selectedItemGrid;
    if (ajuste) {
      if (ajuste.status === StatusAjusteEstoque.ESTORNADO[EnumUtils.id]) {
        this.toasterService.popWarning("O registro já esta estornado.");
        return;
      }
      this.onCancelRevert$.emit(false);
    }
  }

  /**
   * Reverte o ajuste selecionado.
   */
  public revertDocument(): void {
    const ajuste: AjusteEstoque = this.selectedItemGrid;
    if (ajuste) {
      this.spinnerService.show();
      const params: URLSearchParams = new URLSearchParams();
      params.set("id", ajuste.id.toString());

      this.addSubscription(this.httpService.get(`${this.endpoint}/estornar`, {search: params})
        .map((estornou: boolean) => ({
          estornou,
          type: `${estornou ? "success" : "warning"}`,
          codigo: `${estornou ? "EST35" : "EST36"}`,
          mensagem: `${estornou ? "O estorno foi realizado." : "Não foi possível estornar o documento."}`
        }))
        .catch((error: ServerError) => Observable.of({
          estornou: false,
          type: "error",
          codigo: error.codigo,
          mensagem: error.mensagem
        }))
        .subscribe((obj: { estornou: boolean, type: string, codigo: string, mensagem: string }) => {

          if (obj.estornou) {
            /**
             * Atualiza o objeto
             */
            ajuste.status = StatusAjusteEstoque.ESTORNADO[EnumUtils.id];
            this.updateItemGrid(ajuste);
          }

          this.popup.hide();
          this.spinnerService.hide();
          this.toasterService.pop(obj.type, "Resultado", `${obj.codigo} - ${obj.mensagem}`);
        }));
    }
  }

  /**
   * Gera a nota fiscal de controle de perda.
   */
  public gerarNotaFiscalPerda(): void {
    const ajuste: AjusteEstoque = this.selectedItemGrid;
    if (ajuste) {

      if (ajuste.status !== StatusAjusteEstoque.FINALIZADO[EnumUtils.id]) {
        this.toasterService.popWarning("EST34 - Só é possível gerar nota fiscal de controle de perdas para documentos finalizados.");
        return;
      }

      this.spinnerService.show();
      const params: URLSearchParams = new URLSearchParams();
      params.set("id", ajuste.id.toString());

      this.addSubscription(this.httpService
        .get(`${this.endpoint}/gerar-nf-controle-perdas`, {search: params})
        .map((mensagem: string) => ({sucesso: true, mensagem}))
        .catch((error: ServerError) => Observable.of({sucesso: false, mensagem: `${error.codigo} - ${error.mensagem}`}))
        .subscribe((obj: { sucesso: boolean, mensagem: string }) => {
          this.popup.hide();
          this.spinnerService.hide();
          this.toasterService.pop(obj.sucesso ? "success" : "warning", "Nota fiscal de controle de perda", obj.mensagem);
        }));
    }
  }

}
