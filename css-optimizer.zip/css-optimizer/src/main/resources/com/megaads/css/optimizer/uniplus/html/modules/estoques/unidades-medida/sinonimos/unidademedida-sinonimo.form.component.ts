import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { applicationInjector } from "../../../../app.module";
import { ItFormTableComponent } from "../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { FormComponent } from "../../../../core/crud/form-component";
import { IParamsData } from "../../../../core/crud/param-data";
import { ServerError } from "../../../../core/models/server-error";
import { HttpService } from "../../../../core/services/http.service";
import { NumberUtil } from "../../../../core/utils/number.util";
import { StringUtil } from "../../../../core/utils/string.util";
import { SinonimoUnidadeMedida } from "./unidademedida-sinonimo";


/**
 * Sinonimos
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-unidademedida-sinonimo",
  templateUrl: "unidademedida-sinonimo.form.component.html",
})
export class ItUnidadeMedidaSinonimoFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formSinonimo$: BehaviorSubject<FormGroup>;

  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<SinonimoUnidadeMedida>;

  constructor(private formBuider: FormBuilder) {
    super();
  }

  public ngOnInit(): void {
    this.formSinonimo$ = new BehaviorSubject(this.formBuider.group(new SinonimoUnidadeMedida()));

    this.addSubscription(this.getControl("sinonimo", this.formSinonimo$)
      .subscribe((c: AbstractControl) => {
        c.setValidators([Validators.required, Validators.maxLength(6)]);
        c.setAsyncValidators([sinonimoAsyncValidate(this.itFormTable)]);
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idUnidadeMedida", "idUnidadeMedida", DataType.Number, 0, null, false),
      new ColumnDefinition("sinonimo", "Sinônimo", DataType.String, "*"),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idUnidadeMedida", id.toString());
        return {endpoint: "sinonimos-unidades-medida", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((sinonimo: SinonimoUnidadeMedida) => {
          if (sinonimo.id) {
            sinonimo.id = NumberUtil.parseFloat(sinonimo.id.toString());
          }
          if (sinonimo.idUnidadeMedida) {
            sinonimo.idUnidadeMedida = NumberUtil.parseFloat(sinonimo.idUnidadeMedida.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((sinonimo: SinonimoUnidadeMedida) =>
        sinonimoAsyncValidator$(
          this.itFormTable,
          sinonimo.sinonimo,
          sinonimo.id,
        )
          .combineLatest(this.afterGet$, (validate: { sinonimoValid: string }, idUnidadeMedida: number) =>
            ({sinonimo, validate, idUnidadeMedida})))
      .subscribe((obj: { sinonimo: SinonimoUnidadeMedida, validate: { sinonimoValid: string }, idUnidadeMedida: number }) => {

        if (obj.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validate.sinonimoValid));
          return;
        }

        obj.sinonimo.idUnidadeMedida = obj.idUnidadeMedida;

        this.itFormTable.submit$.next(obj.sinonimo);
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new SinonimoUnidadeMedida())));
  }
}

/**
 * Funçao de validaçao ação
 *
 * @param itFormTable: tFormTableComponent<ContaCorrenteAcaoCobranca>
 * @return {(control:FormControl)=>{filialValidate: string}}
 */
function sinonimoAsyncValidate(itFormTable: ItFormTableComponent<SinonimoUnidadeMedida>) {
  return (control: FormControl) => {
    return sinonimoAsyncValidator$(itFormTable,
      control.value,
      control.parent.get("id").value,
    );
  };
}

/**
 * Valida a existência da filial na table.
 *
 * @param sinonimo: string
 * @param id: number
 * @param itTable: ItFormTableComponent<FormacaoPrecoProduto>
 * @return {{filialValidate: string}}
 */
function sinonimoAsyncValidator$(itTable: ItFormTableComponent<SinonimoUnidadeMedida>,
                                 sinonimo: string, id: number): Observable<{ sinonimoValid: string }> {

  const http: HttpService = applicationInjector.get(HttpService);

  return itTable
    .afterLoadData$
    .switchMap(() => {
      const registroExiste: boolean = itTable.sourceCollection
        .some((sin: SinonimoUnidadeMedida) => sin.sinonimo.toUpperCase() === sinonimo.toUpperCase() &&
        (NumberUtil.numberNullOrZero(id) || NumberUtil.parseFloat(id.toString()) !== sin.id));

      if (registroExiste) {
        return Observable.of({sinonimoValid: "PRD203 - O sinônimo já existe na lista. Verifique!"});
      } else {
        const params: URLSearchParams = new URLSearchParams();
        params.set("value", sinonimo);
        params.set("id", id.toString());

        return http.get(`sinonimos-unidades-medida/validar-sinonimo`, {search: params})
          .map(() => null)
          .catch((error: ServerError) => Observable.of({sinonimoValid: `${error.codigo} - ${error.mensagem}`}));
      }
    }).first();
}
