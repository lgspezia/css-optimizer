import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { GridCrud } from "../../../core/crud/grid.crud";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { REGEX_NUMBER } from "../../../core/utils/number.util";
import { Empresa, TipoContabilizacaoSped } from "./empresa";

/**
 * @author Luan  on 12/06/2017.
 */
@Component({
  templateUrl: "empresa.grid.crud.html",
})
export class EmpresaGridCrudComponent extends GridCrud<Empresa> {

  public tipoContabilizacao$: Observable<IDataItem[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Empresa(), "empresas");

    this.tipoContabilizacao$ = EnumUtils.getValuesNullOption(TipoContabilizacaoSped);

    this.addSubscription(this.getControl("codigo")
      .merge(this.getControl("razaoSocial"))
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("numeroOrdemLivro")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(50), Validators.pattern(REGEX_NUMBER)])));

    /**
     * Só habilita o componente de numeroOrdemLivro se for centralizada
     */
    this.addSubscription(this.getValueChanges("tipoContabilizacaoSped")
    /**
     * Combina a alteração do combo com o objeto que vai ser desabilitado,
     * Cria um novo objeto onde é passado o valor da enum e controle do campo que vai ser desabilitado
     */
      .combineLatest(this.getControl("numeroOrdemLivro"),
        (tipo: string, ordemLivro: AbstractControl) => ({tipo, ordemLivro}))
      .subscribe((wapper: { tipo: string, ordemLivro: AbstractControl }) => {
        if (wapper.tipo === TipoContabilizacaoSped.CENTRALIZADA[EnumUtils.id]) {
          wapper.ordemLivro.enable();
        } else {
          wapper.ordemLivro.disable();
          wapper.ordemLivro.setValue("");
        }
      }));
  }
}
