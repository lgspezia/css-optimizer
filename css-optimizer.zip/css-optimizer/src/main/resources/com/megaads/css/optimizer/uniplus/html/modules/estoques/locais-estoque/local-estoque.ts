import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";

/**
 * @author Luan  on 19/07/2017.
 */
export class LocalEstoque extends AbstractPojo {

  public descricao = "";
  public tipo = TipoLocalEstoque.LOJA[EnumUtils.id];
  public permiteRetirarMercadoria = false;
  public idFilial = 0;

}

export enum TipoLocalEstoque {

  LOJA = <any> {[EnumUtils.id]: "LOJA", [EnumUtils.display]: "Loja"},
  DEPOSITO = <any> {[EnumUtils.id]: "DEPOSITO", [EnumUtils.display]: "Depósito"},
  PROCESSO = <any> {[EnumUtils.id]: "PROCESSO", [EnumUtils.display]: "Processo"},
}
