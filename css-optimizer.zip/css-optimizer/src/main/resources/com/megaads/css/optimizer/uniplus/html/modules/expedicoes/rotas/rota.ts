import { AbstractPojo } from "../../../core/crud/pojo";

export class Rota extends AbstractPojo {
    public descricao = "";
}
