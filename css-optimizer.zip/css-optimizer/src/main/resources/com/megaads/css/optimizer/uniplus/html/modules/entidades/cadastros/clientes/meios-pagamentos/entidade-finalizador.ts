import { AbstractPojo } from "../../../../../core/crud/pojo";

/**
 * Finalizador de entidade
 *
 * Created by Osiel on 26/05/17.
 */
export class EntidadeFinalizador extends AbstractPojo {

  public idEntidade = 0;
  public idFinalizador = 0;
  public descricaoFinalizador = "";
}
