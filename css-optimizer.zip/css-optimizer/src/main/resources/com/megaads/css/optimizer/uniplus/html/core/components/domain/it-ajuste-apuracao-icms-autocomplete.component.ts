import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { AjusteApuracaoIcms } from "../../../modules/speds/ajustes-apuracao-icms/ajuste-apuracao-icms";

/**
 * @author Luan  on 08/06/2017.
 */

@Component({
  selector: "it-ajuste-apuracao-icms-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItAjusteApuracaoIcmsAutoCompleteComponent extends ItAutocompleteComponent<AjusteApuracaoIcms> {

  constructor(httpService: HttpService) {
    super(httpService);

    this.url = "ajustes-apuracao-icms";
    this.display = "codigo";
    this.label = "Ajuste do ICMS";
  }
}
