import { FormBuilder, FormGroup } from "@angular/forms";
import { AbstractPojo } from "../../../core/crud/pojo";

import { EnumUtils } from "../../../core/enuns/enumutil";
import { FilialContador } from "./dados-contador/filial-dado-contador";
/**
 * @author Luan  on 14/06/2017.
 */
export class Filial extends AbstractPojo {

  public idEmpresa = 0;
  public inativoView = false;
  public inativo = InativoFilial.NAO[EnumUtils.id];
  public nome = "";
  public razaoSocial = "";
  public endereco = "";
  public numero = "";
  public complemento = "";
  public bairro = "";
  public cep = "";
  public telefone = "";
  public cnpj = "";
  public inscricaoEstadual = "";
  public inscricaoEstadualST = "";
  public inscricaoMunicipal = "";
  public cnae = "";
  public codigoTributacaoMunicipio = "";
  public idEstado = 0;
  public estado = "";
  public idCidade = 0;
  public cidade = "";
  public tipoEnquadramento = TipoEnquadramentoFilial.SIMPLESNACIONAL[EnumUtils.id];
  public tipoContribuinteST = TipoContribuinte.NENHUM[EnumUtils.id];
  public regimeEspecialTributacao = EnumUtils.undefined;
  public idIncentivofiscal = 0;
  public suframa = "";
  public responsavel = "";
  public email = "";
  public site = "";
  public indicadorFilial = IndicadorFilial.MATRIZ[EnumUtils.id];
  public incentivadorCultural = false;
  public idEntidade = 0;
  public cdm = false;
  public idFilialCdm = 0;
  public vendaProgramada = false;
  public vendaEntregaFutura = false;

  public percentualCustoIndireto = 0;
  public registroNacionalTransportador = "";

  // Turno
  public primeiroTurnoHoraInicial = "";
  public primeiroTurnoHoraFinal = "";
  public segundoTurnoHoraInicial = "";
  public segundoTurnoHoraFinal = "";
  public terceiroTurnoHoraInicial = "";
  public terceiroTurnoHoraFinal = "";
  public quartoTurnoHoraInicial = "";
  public quartoTurnoHoraFinal = "";

  // Peps
  public usarPeps = false;
  public permitirBaixarLoteVencido = false;
  public tipoDataBaixaPEPS = TipoDataBaixaEstoquePEPS.UNDEFINED[EnumUtils.id];

  // MDF-e
  public tipoEmitenteManifesto = TipoEmitenteManifesto.NAO_PRESTADOR[EnumUtils.id];
  public tipoTransportador = TipoTransportador.UNDEFINED[EnumUtils.id];

  // Dados contador
  public contador: FormGroup = new FormBuilder().group(new FilialContador());

  // Contabilidade
  public numeroInscricaoJunta = "";
  public dataInscricaoJunta = new Date();
  public dataAbertura = new Date();
  public numeroOrdemLivro = "";
  public auxNumeroOrdemLivro = 0;

  // DIA
  public nomeResponsavelDIA = "";
  public foneResponsavelDIA = "";
  public emailResponsavelDIA = "";

}

export enum TipoEnquadramentoFilial {
  SIMPLESNACIONAL = <any> {[EnumUtils.id]: "SIMPLESNACIONAL", [EnumUtils.display]: "Simples nacional"},
  LUCROREAL = <any> {[EnumUtils.id]: "LUCROREAL", [EnumUtils.display]: "Lucro real"},
  LUCROPRESUMIDO = <any> {[EnumUtils.id]: "LUCROPRESUMIDO", [EnumUtils.display]: "Lucro presumido"},
}

export enum ModeloNfse {
  IPM = <any> {[EnumUtils.id]: "IPM", [EnumUtils.display]: "IPM"},
  SIMPLESG2KANACIONAL = <any> {[EnumUtils.id]: "G2KA", [EnumUtils.display]: "G2KA"},
  UNICO = <any> {[EnumUtils.id]: "UNICO", [EnumUtils.display]: "Único"},
}

export enum TipoContribuinte {
  NENHUM = <any> {[EnumUtils.id]: "NENHUM", [EnumUtils.display]: "Nenhum"},
  SUBSTITUIDO = <any> {[EnumUtils.id]: "SUBSTITUIDO", [EnumUtils.display]: "Substituído tributário"},
  SUBSTITUTO = <any> {[EnumUtils.id]: "SUBSTITUTO", [EnumUtils.display]: "Substituto tributário"},
}

export enum RegimeEspecialTributacao {
  MICROEMPRESA_MUNICIPAL = <any> {
    [EnumUtils.id]: "MICROEMPRESA_MUNICIPAL",
    [EnumUtils.display]: "Microempresa municipal"
  },
  ESTIMATIVA = <any> {[EnumUtils.id]: "ESTIMATIVA", [EnumUtils.display]: "Estimativa"},
  SOCIEDADE_PROFISSIONAIS = <any> {
    [EnumUtils.id]: "SOCIEDADE_PROFISSIONAIS",
    [EnumUtils.display]: "Sociedade de profissionais"
  },
  COOPERATIVA = <any> {[EnumUtils.id]: "COOPERATIVA", [EnumUtils.display]: "Cooperativa"},
  MEI = <any> {[EnumUtils.id]: "MEI", [EnumUtils.display]: "Microempresário Individual (MEI)"},
  ME_EPP = <any> {[EnumUtils.id]: "ME_EPP", [EnumUtils.display]: "Microempresário e Empresa de Pequeno Porte (ME EPP)"},
}

export enum IndicadorFilial {
  MATRIZ = <any> {[EnumUtils.id]: "MATRIZ", [EnumUtils.display]: "Matriz"},
  FILIAL = <any> {[EnumUtils.id]: "FILIAL", [EnumUtils.display]: "Filial"},
}

export enum InativoFilial {
  NAO = <any> {[EnumUtils.id]: "NAO", [EnumUtils.display]: "Não"},
  INATIVO_POR_LICENCA = <any> {[EnumUtils.id]: "INATIVO_POR_LICENCA", [EnumUtils.display]: "Inativo por licença"},
  SIM = <any> {[EnumUtils.id]: "SIM", [EnumUtils.display]: "Sim"},
}

export enum TipoDataBaixaEstoquePEPS {
  UNDEFINED = <any> {[EnumUtils.id]: "UNDEFINED", [EnumUtils.display]: "-- selecione --"},
  ENTRADA = <any> {[EnumUtils.id]: "ENTRADA", [EnumUtils.display]: "Entrada"},
  VENCIMENTO = <any> {[EnumUtils.id]: "VENCIMENTO", [EnumUtils.display]: "Vencimento"},
}

export enum TipoEmitenteManifesto {
  PRESTADOR = <any> {[EnumUtils.id]: "PRESTADOR", [EnumUtils.display]: "Prestador de serviço de transporte"},
  NAO_PRESTADOR = <any> {
    [EnumUtils.id]: "NAO_PRESTADOR",
    [EnumUtils.display]: "Não prestador de serviço de transporte (carga própria)"
  },
}

export enum TipoTransportador {
  UNDEFINED = <any> {[EnumUtils.id]: "UNDEFINED", [EnumUtils.display]: "-- selecione --"},
  ETC = <any> {[EnumUtils.id]: "ETC", [EnumUtils.display]: "ETC"},
  TAC = <any> {[EnumUtils.id]: "TAC", [EnumUtils.display]: "TAC"},
  CTC = <any> {[EnumUtils.id]: "CTC", [EnumUtils.display]: "CTC"},
}
