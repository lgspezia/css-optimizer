import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { BehaviorSubject } from "rxjs/BehaviorSubject";

import { PdfViewerComponent } from "ng2-pdf-viewer";
import { WjPopup } from "wijmo/wijmo.angular2.input";

@Component({
  selector: "it-report",
  // changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "it-report.component.html",
})
export class ItReportComponent {
  @ViewChild("popup") public popup: WjPopup;
  @ViewChild("form") public submit: ElementRef;
  @ViewChild("cancel") public cancel: ElementRef;

  @Input() public form$: BehaviorSubject<FormGroup>;
  @Input() public fileSrc: any;
  @Input() public page: number;
  @Input() public zoom: number;
  @Input() public originalSize: boolean;
  @Input() public showAll: boolean;
  @Input() public title: string;

  @Output() public onCancel: EventEmitter<any> = new EventEmitter();
  @ViewChild("myPdfViewer") public pdfViewer: PdfViewerComponent;

  public pdf: PDFDocumentProxy;

  constructor() {
    this.page = 1;
    this.zoom = 1.0;
    this.showAll = true;
  }

  /**
   * Get pdf information after it's loaded
   * @param pdf
   */
  public afterLoadComplete(pdf: PDFDocumentProxy) {
    this.pdf = pdf;
  }
}
