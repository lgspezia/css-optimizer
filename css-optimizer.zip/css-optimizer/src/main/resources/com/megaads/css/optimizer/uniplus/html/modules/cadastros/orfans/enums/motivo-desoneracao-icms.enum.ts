import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum MotivoDesoneracaoIcms {
  TAXI = <any> {
    [EnumUtils.id]: "TAXI",
    [EnumUtils.display]: "Taxi",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  PRODUTOR_AGROPECUARIO = <any> {
    [EnumUtils.id]: "PRODUTOR_AGROPECUARIO",
    [EnumUtils.display]: "Uso na agropecuária/Produtor Agropecuário",
    cst20: true,
    cst30: false,
    cst40_41_50: true,
    cst70: true,
    cst90: true
  },
  FROTITA_LOCADORA = <any> {
    [EnumUtils.id]: "FROTITA_LOCADORA",
    [EnumUtils.display]: "Frotista/Locadora",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  DIPLOMATICO = <any> {
    [EnumUtils.id]: "DIPLOMATICO",
    [EnumUtils.display]: "Diplomático/Consular",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  UTILITARIOS = <any> {
    [EnumUtils.id]: "UTILITARIOS",
    [EnumUtils.display]: "Utilitários e Motocicletas da Amazônia Ocidental e Áreas " +
    "de Livre Comércio (Resolução 714/88 e 790/94 – CONTRAN e suas alterações)",
    cst20: false,
    cst30: true,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  SUFRAMA = <any> {
    [EnumUtils.id]: "SUFRAMA",
    [EnumUtils.display]: "SUFRAMA",
    cst20: false,
    cst30: true,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  VENDA_ORGAO_PUBLICO = <any> {
    [EnumUtils.id]: "VENDA_ORGAO_PUBLICO",
    [EnumUtils.display]: "Venda a Órgão Público",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  OUTROS = <any> {
    [EnumUtils.id]: "OUTROS",
    [EnumUtils.display]: "Outros",
    cst20: true,
    cst30: true,
    cst40_41_50: true,
    cst70: true,
    cst90: true
  },
  DEFICIENTE_CONDUTOR = <any> {
    [EnumUtils.id]: "DEFICIENTE_CONDUTOR",
    [EnumUtils.display]: "Deficiente Condutor (Convênio ICMS 38/12)",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  DEFICIENTE_NAO_CONDUTOR = <any> {
    [EnumUtils.id]: "DEFICIENTE_NAO_CONDUTOR",
    [EnumUtils.display]: "Deficiente Não Condutor (Convênio ICMS 38/12)",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  },
  ORGAOS_DE_FOMENTO = <any> {
    [EnumUtils.id]: "ORGAOS_DE_FOMENTO",
    [EnumUtils.display]: "Órgão de fomento e desenvolvimento agropecuário.",
    cst20: false,
    cst30: false,
    cst40_41_50: true,
    cst70: false,
    cst90: false
  }
}
