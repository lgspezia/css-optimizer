/**
 * @author Luan  on 20/06/2017.
 */
export interface IDadosLicenca {
  quantidadeFiliais: number;
  isDemonstracao: boolean;
}
