import { Component, OnInit } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { IEditDetails } from "../../../core/crud/edit-details";
import { GridCrud } from "../../../core/crud/grid.crud";
import { IDadosLicenca } from "../../../core/desktop/dados-licenca";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { StringUtil } from "../../../core/utils/string.util";
import { Filial, InativoFilial, TipoDataBaixaEstoquePEPS, TipoTransportador } from "./filial";

/**
 * @author Luan  on 14/06/2017.
 */
@Component({
  templateUrl: "filial.grid.crud.html",
})
export class FilialGridCrudComponent extends GridCrud<Filial> implements OnInit {

  public enableCreate$: Observable<boolean>;

  public title$: Observable<string>;
  public isSef$: Observable<boolean>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService) {
    super(activatedRoute, formBuilder, new Filial(), "filiais");

    /**
     * Retorna o titulo da tab
     */
    this.title$ = contexto.isSef$().map((isSef) => isSef ? "SEF" : "Contabilidade");

    /**
     * Valida se é sef ou se tem o modulo de contabilidade ativo
     */
    this.isSef$ = this.contexto.isSef$().combineLatest(this.contexto.isModulo$("CONTABILIDADE"),
      (isSef: boolean, isContabilidade: boolean) => isSef || isContabilidade);

    /**
     * Ajusta algumas informações do pojo antes de enviar para gravação no servidor
     */
    this.addSubscription(this.beforeSubmit$
      .subscribe((detail: IEditDetails<Filial>) => {
        detail.pojo.inativo = detail.pojo.inativoView ? InativoFilial.SIM[EnumUtils.id] : InativoFilial.NAO[EnumUtils.id];
        detail.pojo.tipoTransportador =
          detail.pojo.tipoTransportador === TipoTransportador.UNDEFINED[EnumUtils.id] ? null : detail.pojo.tipoTransportador;
        detail.pojo.tipoDataBaixaPEPS =
          detail.pojo.tipoDataBaixaPEPS === TipoDataBaixaEstoquePEPS.UNDEFINED[EnumUtils.id] ? null : detail.pojo.tipoDataBaixaPEPS;
        detail.pojo.idFilialCdm = NumberUtil.numberNullOrZero(detail.pojo.idFilialCdm) ? null : detail.pojo.idFilialCdm;
        detail.pojo.numeroOrdemLivro = StringUtil.numberToString(detail.pojo.auxNumeroOrdemLivro);
      }));

  }

  public ngOnInit(): void {
    super.ngOnInit();

    /**
     * Só habilita o botao incluir se o numero de licenca de filial for mario do que a quantidade de filiais cadastrada
     */
    this.enableCreate$ = this.contexto.dadosLicenca$
      .combineLatest(this.afterGetLoadGrid$,
        (dl: IDadosLicenca, carregado: boolean) =>
          dl.quantidadeFiliais > this.sourceCollectionGrid.length);

    /**
     * Atualiza a filial do contexto após gravar o registro.
     */
    this.addSubscription(this.afterSave$
      .withLatestFrom(this.contexto.filial$, (filialAlterada: Filial, filialContexto: Filial) =>
        ({filialAlterada, filialContexto}))
      .filter((obj: { filialAlterada: Filial, filialContexto: Filial }) =>
        NumberUtil.parseFloat(obj.filialAlterada.id.toString()) === NumberUtil.parseFloat(obj.filialContexto.id.toString()))
      .subscribe((obj: { filialAlterada: Filial, filialContexto: Filial }) => this.contexto.filial = obj.filialAlterada));
  }
}
