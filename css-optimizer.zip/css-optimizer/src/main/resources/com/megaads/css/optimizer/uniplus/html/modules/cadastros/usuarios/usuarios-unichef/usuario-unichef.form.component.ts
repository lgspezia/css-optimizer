import { Component, Input } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";

/**
 * @author Luan  on 24/07/2017.
 */
@Component({
  selector: "it-usuario-unichef",
  templateUrl: "usuario-unichef.form.component.html"
})
export class ItUsuarioUnichefFormComponent extends FormComponent {

  @Input() public afterGet$: Observable<number>;

  constructor() {
    super();
  }
}
