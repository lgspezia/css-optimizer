import { Component, OnInit } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { applicationInjector } from "../../../app.module";
import { IEditDetails } from "../../../core/crud/edit-details";
import { GridCrud } from "../../../core/crud/grid.crud";
import {
  identificationRequiredValidator, uniqueAsyncValidator,
  valueDifferentOfValidator
} from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ServerError } from "../../../core/models/server-error";
import { ContextoService } from "../../../core/services/contexto.service";
import { HttpService } from "../../../core/services/http.service";
import { NumberUtil, REGEX_NUMBER } from "../../../core/utils/number.util";
import {
  MotivoAjusteEstoque, MovimentacaoMotivoAjusteEstoque,
  OperacaoMotivoAjusteEstoque, ValorizacaoMotivoAjusteEstoque
} from "./motivo-ajuste-estoque";

/**
 * Motivos de ajuste de estoque.
 *
 * @author Osiel.
 */
@Component({
  templateUrl: "motivo-ajuste-estoque.grid.crud.html",
})
export class MotivoAjusteEstoqueGridCrudComponent extends GridCrud<MotivoAjusteEstoque> implements OnInit {

  public exibirCentroCusto$: Observable<boolean>;
  public exibirControlePerda$: Observable<boolean>;
  public exibirCfop$: Observable<boolean>;
  public exibirPlanoContas$: Observable<boolean>;
  public enableEdit$: Observable<boolean>;
  public enableRead$: Observable<boolean>;
  public movimentar$: Observable<boolean>;
  public valorizar$: Observable<boolean>;

  public operacao$: Observable<IDataItem[]>;
  public movimentacao$: Observable<IDataItem[]>;
  public valorizacao$: Observable<IDataItem[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService) {
    super(activatedRoute, formBuilder, new MotivoAjusteEstoque(), "motivos-ajuste-estoque");

    this.operacao$ = EnumUtils.getValues(OperacaoMotivoAjusteEstoque)
      .combineLatest(contexto.isFuncionalidade$("LOCAL_ESTOQUE"),
        (values: IDataItem[], localEstoque: boolean) =>
          localEstoque ? values : values.filter((v: IDataItem) => v.id !== OperacaoMotivoAjusteEstoque.TRANSFERENCIA[EnumUtils.id]));

    this.movimentacao$ = EnumUtils.getValues(MovimentacaoMotivoAjusteEstoque);

    this.valorizacao$ = EnumUtils.getValues(ValorizacaoMotivoAjusteEstoque);

    this.addValidations();
    this.addBehaviors();
  }

  public ngOnInit(): void {
    super.ngOnInit();

    this.enableRead$ = this.currentChangedGrid$
      .map((m: MotivoAjusteEstoque) => m !== null);

    /**
     * Só deve ser permitido editar ou excluir se o código for maior que -1.
     * @type {Observable<boolean>}
     */
    this.enableEdit$ = this.currentChangedGrid$
      .map((m: MotivoAjusteEstoque) => NumberUtil.parseInt(m.codigo) > -1);
  }

  /**
   * Validations
   */
  private addValidations(): void {
    this.addSubscription(this.getControl("codigo")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.pattern(REGEX_NUMBER)]);
        control.setAsyncValidators([uniqueAsyncValidator("motivos-ajuste-estoque")]);
      }));
    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.getControl("descricao")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required, Validators.maxLength(55)])));

    this.addSubscription(this.getControl("operacao")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("idPlanoContas")
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("idCfopControlePerda")
      .subscribe((control: AbstractControl) => {
        control.setValidators([identificationRequiredValidator()]);
        control.setAsyncValidators([validarControlePerda]);
      }));

    this.addSubscription(this.getControl("valorizacao")
      .subscribe((control: AbstractControl) =>
        control.setValidators([valueDifferentOfValidator(ValorizacaoMotivoAjusteEstoque.NENHUM[EnumUtils.id])])));
  }

  /**
   * Behaviors
   */
  private addBehaviors(): void {
    this.movimentar$ = this.getValueChanges("baseCalculoCustoMedio")
      .merge(this.getControl("baseCalculoCustoMedio")
        .map((c: AbstractControl) => c.value));

    this.valorizar$ = this.movimentar$
      .combineLatest(this.getValueChanges("movimentacao")
          .merge(this.getControl("movimentacao")
            .map((c: AbstractControl) => c.value)),
        (m: boolean, tipo: string) => m && tipo === MovimentacaoMotivoAjusteEstoque.QUANTIDADE_E_VALOR[EnumUtils.id]);

    /**
     * Determina o valor inicial
     */
    this.addSubscription(this.valorizar$
      .combineLatest(this.getControl("valorizacao"), this.isDeleteOrRead$,
        (valorizar: boolean, control: AbstractControl, deleteOrRead: boolean) =>
          ({valorizar, control, deleteOrRead}))
      .subscribe((wrapper: { valorizar: boolean, control: AbstractControl, deleteOrRead: boolean }) => {
        if (!wrapper.deleteOrRead) {
          wrapper.valorizar ? wrapper.control.enable() : wrapper.control.disable();
        }
        wrapper.control.updateValueAndValidity();
      }));

    this.addSubscription(this.movimentar$
      .filter((movimentar: boolean) => !movimentar)
      .switchMap(() => this.getControl("movimentacao"))
      .subscribe((control: AbstractControl) => control.setValue(MovimentacaoMotivoAjusteEstoque.SOMENTE_QUANTIDADE[EnumUtils.id])));

    this.exibirControlePerda$ = this.getValueChanges("operacao")
      .merge(this.getControl("operacao")
        .map((c: AbstractControl) => c.value))
      .combineLatest(this.contexto.isFuncionalidade$("CONTROLE_PERDA"),
        (operacao: string, perda: boolean) => OperacaoMotivoAjusteEstoque.SAIDA[EnumUtils.id] === operacao && perda);

    this.exibirCentroCusto$ = this.movimentar$
      .combineLatest(this.getValueChanges("operacao")
          .merge(this.getControl("operacao")
            .map((c: AbstractControl) => c.value)), this.contexto.isFuncionalidade$("CENTRO_CUSTO"),
        (cm: boolean, operacao: string, centro: boolean) => !cm && OperacaoMotivoAjusteEstoque.SAIDA[EnumUtils.id] === operacao && centro);

    this.exibirPlanoContas$ = this.getValueChanges("centroCustoObrigatorio")
      .merge(this.getControl("centroCustoObrigatorio")
        .map((c: AbstractControl) => c.value))
      .startWith(false);

    this.addSubscription(this.exibirCentroCusto$
      .filter((exibir: boolean) => !exibir)
      .switchMap(() => this.getControl("centroCustoObrigatorio"))
      .subscribe((control: AbstractControl) => control.setValue(false)));

    /**
     * Desabilita o componente para invalidar as validações, se for exclusão ou visualização não deve habilitar.
     */
    this.addSubscription(this.exibirPlanoContas$
      .combineLatest(this.getControl("idPlanoContas"), this.isDeleteOrRead$,
        (exibir: boolean, plano: AbstractControl, deleteOrRead: boolean) => ({exibir: exibir && !deleteOrRead, plano}))
      .subscribe((wrapper: { exibir: boolean, plano: AbstractControl }) => {
        if (wrapper.exibir) {
          wrapper.plano.enable();
        } else {
          wrapper.plano.disable();
          wrapper.plano.setValue(0);
        }
      }));

    this.exibirCfop$ = this.getValueChanges("controlePerda")
      .merge(this.getControl("controlePerda")
        .map((c: AbstractControl) => c.value))
      .startWith(false);

    /**
     * Desabilita o componente para invalidar as validações, se for exclusão ou visualização não deve habilitar.
     */
    this.addSubscription(this.exibirCfop$
      .combineLatest(this.getControl("idCfopControlePerda"), this.isDeleteOrRead$,
        (exibir: boolean, cfop: AbstractControl, deleteOrRead: boolean) => ({exibir: exibir && !deleteOrRead, cfop}))
      .subscribe((wrapper: { exibir: boolean, cfop: AbstractControl }) => {
        if (wrapper.exibir) {
          wrapper.cfop.enable();
        } else {
          wrapper.cfop.disable();
          wrapper.cfop.setValue(0);
        }
      }));

    /**
     * Atribui a valorização para nenhum quando não selecionado as opções de custo médio.
     */
    this.addSubscription(this.beforeSubmit$
      .subscribe((detail: IEditDetails<MotivoAjusteEstoque>) => {
        if (!detail.pojo.baseCalculoCustoMedio ||
          detail.pojo.movimentacao !== MovimentacaoMotivoAjusteEstoque.QUANTIDADE_E_VALOR[EnumUtils.id]) {
          detail.pojo.valorizacao = ValorizacaoMotivoAjusteEstoque.NENHUM[EnumUtils.id];
        }
      }));
  }
}

/**
 * Valida a natureza de operação para o controle de perda.
 * @param {FormControl} control
 * @return {Observable<{cfopPerdaInvalida: string}>}
 */
function validarControlePerda(control: FormControl): Observable<{ cfopPerdaInvalida: string }> {
  const http: HttpService = applicationInjector.get(HttpService);
  const params: URLSearchParams = new URLSearchParams();
  params.set("idCfop", control.value);

  return http.get(`naturezas-operacao/validar-controle-perda`, {search: params})
    .map(() => null)
    .catch((error: ServerError) => Observable.of({cfopPerdaInvalida: `${error.codigo} - ${error.mensagem}`}))
    .first();
}
