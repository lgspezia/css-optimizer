import { Component, Input } from "@angular/core";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-searchbutton",
  template: `
    <div class='form-group col-sm-{{col}}'>
      <label></label>

      <button type="button" class="sqrbutton btn-primary font-truman">
        <i class="fa fa-search font-size-icons"></i>
      </button>

    </div>
  `,
})
export class ItSearchButtonComponent {
  @Input() public col = 3;
}
