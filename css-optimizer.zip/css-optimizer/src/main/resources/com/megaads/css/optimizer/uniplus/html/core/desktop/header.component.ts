import { Component, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { AutenticacaoService } from "../services/autenticacao.service";
import { ContextoService } from "../services/contexto.service";

/**
 * Header (cabeçalho)
 */
@Component({
    selector: "it-desktop-header",
    templateUrl: "header.component.html",
})
export class HeaderComponent implements OnInit {
  public status: { isopen: boolean } = {isopen: false};

  public nomeUsuario$: Observable<string>;

  constructor(private autenticacaoService: AutenticacaoService, private contexto: ContextoService) {
  }

  public ngOnInit(): void {
    this.nomeUsuario$ = this.contexto.usuario$.map((user: any) => user.nome);
  }

  /**
   * Logout do sistema.
   */
  public logout(): void {
    this.autenticacaoService.doLogout();
  }

  public toggled(open: boolean): void {
    console.log("Dropdown is now: ", open);
  }

  public toggleDropdown($event: MouseEvent): void {
    $event.preventDefault();
    $event.stopPropagation();
    this.status.isopen = !this.status.isopen;
  }
}
