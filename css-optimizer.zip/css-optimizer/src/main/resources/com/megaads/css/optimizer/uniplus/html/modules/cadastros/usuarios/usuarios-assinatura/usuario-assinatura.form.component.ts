import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, Validators } from "@angular/forms";

import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";

/**
 * @author Luan  on 24/07/2017.
 */
@Component({
  selector: "it-usuario-assinatura",
  templateUrl: "usuario-assinatura.form.component.html"
})
export class ItUsuarioAssinaturaFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  constructor() {
    super();
  }


  public ngOnInit(): void {
    this.addSubscription(this.getControl("assinatura")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(544)])));

    this.addSubscription(this.getControl("arquivoImagemEmail")
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(512)])));
  }
}
