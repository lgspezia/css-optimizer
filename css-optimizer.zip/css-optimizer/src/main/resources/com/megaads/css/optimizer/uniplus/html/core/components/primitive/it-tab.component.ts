import { AfterViewInit, Component, ContentChildren, forwardRef, HostBinding, Input, QueryList } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { AbstractPojo } from "../../crud/pojo";
import { ContextoService } from "../../services/contexto.service";
import { ItFormTableComponent } from "./it-formtable.component";
import { ItTableComponent } from "./it-table.component";

/**
 * Tab com as seguintes caracteristicas:
 * - título
 * - visibilidade de acordo com modulo/funcionalidade
 * - botão de fechar opcional (normalmente desabilitado)
 * - desabilitar/habilitar
 */
@Component({
  selector: "it-tab",
  template: `
    <ng-content></ng-content>`,
})
export class ItTabComponent implements AfterViewInit {
  @HostBinding("class.tab-pane") public addClass: boolean;
  @HostBinding("class.active") public selected: boolean;
  @Input() public condicao$: Observable<boolean>;
  @Input() public funcionalidade: string;
  @Input() public licenca: string;
  @Input() public modulo: string;
  @Input() public title: string;

  public isAtivo$: Observable<boolean>;

  @ContentChildren(forwardRef(() => ItFormTableComponent)) private formsTables: QueryList<ItFormTableComponent<AbstractPojo>>;
  @ContentChildren(forwardRef(() => ItTableComponent)) private tables: QueryList<ItTableComponent<AbstractPojo>>;

  private isClicked = false;

  constructor(private contextoService: ContextoService) {
    this.addClass = true;
    this.isAtivo$ = Observable.of(true);
    this.title = "";
  }

  /**
   * Se for definido condição, não irá validar modulo, funcionalidade e licença.
   */
  public ngAfterViewInit(): void {
    if (this.modulo || this.funcionalidade || this.licenca) {
      this.isAtivo$ = this.contextoService
        .isAtivo$(this.modulo, this.funcionalidade, this.licenca)
        .first((ativo) => ativo);
    } else if (this.condicao$) {
      this.isAtivo$ = this.condicao$.map((ativo) => ativo);
    }
  }

  /**
   * Determina se a tab foi clicada para renderizar os componentes internos.
   * Após isso a tab não deve ser refeita.
   * @return {boolean}
   */
  public get clicked(): boolean {
    if (!this.isClicked) {
      this.isClicked = this.selected;
    }
    return this.isClicked;
  }

  /**
   * Invalida o flexgrid para reposicionar a table e o scroll.
   */
  public invalidateFlexGrid() {
    if (this.formsTables) {
      for (const form of this.formsTables.toArray()) {
        form.invalidateFlexGrid();
      }
    }
    if (this.tables) {
      for (const table of this.tables.toArray()) {
        table.invalidateFlexGrid();
      }
    }
  }
}
