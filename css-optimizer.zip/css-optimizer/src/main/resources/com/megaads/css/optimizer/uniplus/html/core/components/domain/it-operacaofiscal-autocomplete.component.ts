import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { OperacaoFiscal } from "../../../modules/cadastros/orfans/operacao-fiscal.model";

@Component({
    selector: "it-operacaofiscal-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItOperacaoFiscalAutocompleteComponent extends ItAutocompleteComponent<OperacaoFiscal> {

    constructor(httpService: HttpService) {
        super(httpService);
      this.display = "nome";
      this.label = "Operação fiscal";
      this.url = "operacoes-fiscais";
    }
}
