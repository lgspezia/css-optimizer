import { Component, Input } from "@angular/core";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-component",
  template: `
    <div class="container-fluid-home container" ng-version="4.0.3">
      <h2>&nbsp;</h2>
      <ng-content></ng-content>
    </div>
  `,
})
export class ItComponent {
}
