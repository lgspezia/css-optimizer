import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItDynalistboxComponent } from "../primitive/it-dynalistbox.component";

/**
 * Componente de seleção de múltiplas empresas.
 * @author Leonardo 12/06/2017.
 */
@Component({
    selector: "it-planocontas-dynalistbox",
    templateUrl: "../primitive/it-dynalistbox.component.html",
})
export class ItPlanoContasDynalistboxComponent extends ItDynalistboxComponent {

    constructor(httpService: HttpService) {
        super(httpService);
        this.label = "Plano de contas (PC)";
        this.display = "nome";
        this.checkedMemberPath = "selecionado";
        this.height = "80px";
        this.url = "planos-contas/filtrar-plano-conta-sem-filhos";
    }
}
