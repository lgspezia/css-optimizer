import { Component } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-checkbox",
  templateUrl: "it-checkbox.component.html",
})
export class ItCheckboxComponent extends BaseFormComponent {
}
