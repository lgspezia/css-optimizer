import { Component, Input, OnDestroy, OnInit } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";
import { TipoValidadorCpfCnpj } from "../../../../core/crud/validadores";
import { Endereco } from "../../../entidades/cadastros/utils/endereco";
import { FilialContador } from "./filial-dado-contador";

/**
 * @author Luan  on 23/06/2017.
 */
@Component({
  selector: "it-filial-dado-contador",
  templateUrl: "filial-dado-contador.form.component.html",
})
export class ItFilialDadoContadorFormComponent extends FormComponent implements OnInit, OnDestroy {

  @Input() public afterGet$: Observable<number>;

  public formEnderecoContador$: BehaviorSubject<FormGroup>;
  public formFilialContador$: BehaviorSubject<FormGroup>;
  public tipoComponentCNPJ$: Observable<TipoValidadorCpfCnpj>;

  constructor() {
    super();
      this.formEnderecoContador$ = new BehaviorSubject(undefined);
      this.formFilialContador$ = new BehaviorSubject(undefined);
      this.tipoComponentCNPJ$ = Observable.of(TipoValidadorCpfCnpj.CNPJ);
  }

  public ngOnDestroy() {
    super.ngOnDestroy();
    this.formFilialContador$.unsubscribe();
    this.formEnderecoContador$.unsubscribe();
  }

  public ngOnInit() {

    /**
     * Cria os formGroup de contador e endereço
     */
    this.addSubscription(this.getFormGroup("contador", new FilialContador()).subscribe(this.formFilialContador$));
    this.addSubscription(this.getFormGroup("endereco", new Endereco(), this.formFilialContador$).subscribe(this.formEnderecoContador$));

    this.addSubscription(this.getControl("nome", this.formFilialContador$)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(50)])));

    this.addSubscription(this.getControl("crc", this.formFilialContador$)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(14)])));

    this.addSubscription(this.getControl("email", this.formFilialContador$)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(200)])));
  }
}
