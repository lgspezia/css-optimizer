import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItDynacomboboxComponent } from "../primitive/it-dynacombobox.component";
import { Estado } from "../../../modules/enderecos/estados/estado";

@Component({
    selector: "it-estado-dynacombobox",
    templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItEstadoDynacomboboxComponent extends ItDynacomboboxComponent<Estado> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.insertNullOption = true;
        this.url = "estados/filtrar-uf";
        this.display = "codigo";
        this.label = "UF";
    }

}
