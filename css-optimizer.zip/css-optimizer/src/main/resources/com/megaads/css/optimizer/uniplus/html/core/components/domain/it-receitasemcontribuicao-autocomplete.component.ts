import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { ReceitaSemContribuicao } from "../../../modules/speds/receitas-sem-contribuicao/receita-sem-contribuicao";

@Component({
    selector: "it-receitasemcontribuicao-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItReceitaSemContribuicaoAutocompleteComponent extends ItAutocompleteComponent<ReceitaSemContribuicao> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "receitas-sem-contribuicoes";
        this.display = "descricao";
        this.label = "Receita sem contribuição";
    }
}
