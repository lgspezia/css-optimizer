import { AbstractPojo } from "../../../core/crud/pojo";
import { GradeValor } from "./grade-valor";

/**
 * @author Osiel.
 */
export class Grade extends AbstractPojo {

  public descricao = "";

  /*
   * Usados virtualmente
   */
  public inativa = false;
  public idGradeLinha = 0;
  public idGradeColuna = 0;
  public valores: GradeValor[] = [];
}

/**
 * Facilitador para envio de cabeçalho e item.
 */
export class GradeValorWrapper extends AbstractPojo {
  public grade: Grade = new Grade();
  public gradeValor: GradeValor = new GradeValor();
}
