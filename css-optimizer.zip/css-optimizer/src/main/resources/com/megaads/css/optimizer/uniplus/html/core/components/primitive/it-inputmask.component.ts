import { Component, Input, OnInit, style, ViewChild } from "@angular/core";

import { WjInputMask } from "wijmo/wijmo.angular2.input";

import { BaseFormComponent } from "./baseform.component";
import { Subject } from "rxjs/Subject";

/**
 * Input com máscara
 *
 * Veja
 * http://wijmo.com/5/docs/topic/wijmo.input.InputMask.Class.html
 * para instruções para formatar a máscara
 */
@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-inputmask",
  templateUrl: "it-inputmask.component.html",
})
export class ItInputMaskComponent extends BaseFormComponent implements OnInit {
  @Input() public mask = "";

  public focus$: Subject<boolean>;

  @ViewChild(WjInputMask) private itMask: WjInputMask;

  constructor() {
    super();
    this.focus$ = new Subject();
  }

  public  ngOnInit(): void {
    this.itMask.gotFocus.addHandler(() => this.focus$.next(true));
    this.itMask.lostFocus.addHandler(() => this.focus$.next(false));
  }
}
