import { Component, Input, OnInit } from "@angular/core";

import { FormBuilder, FormGroup } from "@angular/forms";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputarea-noborder",
    templateUrl: "it-inputarea-noborder.component.html",
})
export class ItInputAreaNoborderComponent extends BaseFormComponent implements OnInit {
  @Input() public placeholder = "";
  @Input() public len = 120;
  @Input() public cols = 40;
  @Input() public rows = 3;
  @Input() public height = "";
  @Input() public content = "";
  @Input() public controle: string;
  @Input() public form$: BehaviorSubject<FormGroup>;
  public conteudo$: Observable<string>;

  constructor(private formBuilder: FormBuilder) {
    super();
  }

  public ngOnInit(): void {

  }
}
