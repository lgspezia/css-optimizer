import { Component, EventEmitter, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";
import { WjPopup } from "wijmo/wijmo.angular2.input";

import { applicationInjector } from "../../../../app.module";
import { Filial } from "../../../../modules/cadastros/filiais/filial";
import { Produto } from "../../../../modules/produtos/produto";
import { TipoVariacao, Variacao } from "../../../../modules/produtos/variacao";
import { ColumnDefinition } from "../../../crud/column-definition";
import { AbstractPojo } from "../../../crud/pojo";
import { identificationRequiredValidator, saldoValidator$, valueDifferentOfValidator } from "../../../crud/validadores";
import { EnumUtils } from "../../../enuns/enumutil";
import { ContextoService } from "../../../services/contexto.service";
import { HttpService } from "../../../services/http.service";
import { NumberUtil } from "../../../utils/number.util";
import { StringUtil } from "../../../utils/string.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { ItDynacomboboxParamsComponent } from "../../primitive/it-dynacomboboxparams.component";
import { ItFormTableComponent } from "../../primitive/it-formtable.component";
import { ItTableComponent } from "../../primitive/it-table.component";

/**
 * Distribuição de grade de produto.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-produto-variacao",
  templateUrl: "it-produto-variacao.component.html",
})
export class ItProdutoVariacaoComponent extends BaseFormComponent implements OnInit {
  @Input() public idLocalEstoque$: Observable<number>;
  @Input() public idFilial$: Observable<number>;
  @Input() public controlProduto: string;
  @Input() public controlVariacao: string;
  @Input() public eventBlur$: EventEmitter<any>;
  @Input() public idCrud$: Observable<number>;
  @Input() public informarGrade$: Observable<boolean>;
  @Input() public produto$: BehaviorSubject<Produto>;
  @Input() public quantidadeEsperada$: BehaviorSubject<number>;
  @Input() public resourceNameValidationSaldo: string;
  @Input() public validarSaldo$: Observable<boolean>;
  @Input() public variacaoString: boolean;

  public afterGetItem$: Observable<number>;
  public balance$: Subject<boolean>;
  public column$: Subject<string>;
  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public columnsBalance$: BehaviorSubject<ColumnDefinition[]>;
  public formItem$: BehaviorSubject<FormGroup>;
  public formVariacao$: BehaviorSubject<FormGroup>;
  public informacaoQuantidade$: Observable<string>;
  public minQtd$: Observable<number>;
  public row$: Subject<string>;
  public rowVisible$: Subject<boolean>;
  public title$: Observable<string>;
  public urlParamsLinha$: Observable<URLSearchParams>;
  public urlParamsColuna$: Observable<URLSearchParams>;
  public variacaoAlterada$: Subject<boolean>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<VariacaoDistribuida>;
  @ViewChild(ItTableComponent) private itTableBalance: ItTableComponent<SaldoVariacao>;
  @ViewChild(WjPopup) private popup: WjPopup;
  @ViewChild("linha") private itLinha: ItDynacomboboxParamsComponent<Variacao>;
  @ViewChild("coluna") private itColuna: ItDynacomboboxParamsComponent<Variacao>;

  private _quantidadeDistribuida$: Subject<number>;
  private variacoesAtuais = [];

  constructor(private formBuilder: FormBuilder, private contexto: ContextoService) {
    super();
    this.afterGetItem$ = Observable.of(null);
    this.balance$ = new Subject();
    this.column$ = new Subject();
    this.idFilial$ = contexto.filial$.map((filial: Filial) => filial.id);
    this.idLocalEstoque$ = Observable.of(null);
    this.informarGrade$ = Observable.of(true);
    this.minQtd$ = Observable.of(0);
    this.row$ = new Subject();
    this.rowVisible$ = new Subject();
    this.quantidadeEsperada$ = new BehaviorSubject(0);
    this._quantidadeDistribuida$ = new Subject();
    this.variacaoAlterada$ = new Subject();
  }

  public ngOnInit(): void {

    /**
     * Inicializa um form dummy apenas para trabalhar com os componentes.
     * @type {BehaviorSubject<FormGroup>}
     */
    this.formVariacao$ = new BehaviorSubject(this.formBuilder.group({variacao: []}));

    /**
     * Form de itens.
     * @type {BehaviorSubject<FormGroup>}
     */
    this.formItem$ = new BehaviorSubject(new FormBuilder().group(new VariacaoDistribuida()));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("descricao", "Variação", DataType.String, "*"),
      new ColumnDefinition("quantidade", "Quantidade", DataType.Number, "*"),
    ]);

    this.columnsBalance$ = new BehaviorSubject([
      new ColumnDefinition("variacao", "Variação", DataType.String, "*"),
      new ColumnDefinition("saldo", "Saldo", DataType.Number, "*"),
      new ColumnDefinition("saldoPrevisto", "Saldo previsto", DataType.Number, "*"),
    ]);

    /**
     * Combina com o evento clear para a cada mudança na table refazer a soma.
     * @type {Observable<string>}
     */
    this.informacaoQuantidade$ = this.quantidadeEsperada$
      .combineLatest(this.itFormTable.clear$.startWith(true), (qtd: number) => {
        if (!NumberUtil.numberNullOrZero(qtd)) {
          const qtdDistribuida: number = this.itFormTable.sourceCollection.map((v) => v.quantidade).reduce((a, b) => a + b, 0);
          return `Quantidade esperada ${qtd} - Quantidade informada ${qtdDistribuida}`;
        }
        return null;
      });

    this.addBehaviors();

    this.addObservableProduct();

    this.addBehaviorsBalance();

    this.addValidators();

    /**
     * Adiciona o item na table.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .withLatestFrom(this.validarSaldo$, (variacao: VariacaoDistribuida, validar: boolean) => ({variacao, validar}))
      .switchMap((obj: { variacao: VariacaoDistribuida, validar: boolean }) => variacaoAsyncValidate$(obj.validar, this.itFormTable,
        this.produto$, this.idCrud$, this.getControl("id"), this.idFilial$, this.idLocalEstoque$, this.itLinha, this.itColuna,
        this.resourceNameValidationSaldo, obj.variacao.id, obj.variacao.idGradeLinha, obj.variacao.idGradeColuna, obj.variacao.quantidade,
      )
        .combineLatest((validate: { saldoValidate: string }) => ({validate, variacaoDistribuida: obj.variacao})))
      .subscribe((wrapper: { validate: { saldoValidate: string }, variacaoDistribuida: VariacaoDistribuida }) => {
        /**
         * Se não passou na validação, exibe a mensagem e retorna.
         */
        if (wrapper.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(wrapper.validate.saldoValidate));
          return;
        }

        const linha = this.itLinha ? this.itLinha.selectedItem : null;
        const coluna = this.itColuna.selectedItem;

        wrapper.variacaoDistribuida.variacao = (((linha ? linha.ordem : 1) - 1) * 100) + coluna.ordem;
        wrapper.variacaoDistribuida.descricao = linha ? `${linha.descricao}/${coluna.descricao}` : coluna.descricao;

        /**
         * Inclusão ou alteração.
         */
        if (NumberUtil.numberNullOrZero(wrapper.variacaoDistribuida.id)) {
          this.itFormTable.push(wrapper.variacaoDistribuida, true);
          this.itFormTable.success("A inclusão foi feita com sucesso");
        } else {
          this.itFormTable.update(wrapper.variacaoDistribuida);
          this.itFormTable.success("Alteração realizada com sucesso");
        }

        this.itFormTable.clear$.next();
      }));

    /**
     * Exclusão
     */
    this.addSubscription(this.itFormTable.delete$
      .subscribe((variacao: VariacaoDistribuida) => {
        this.itFormTable.deletePojo(variacao);
        this.itFormTable.success("Exclusão realizada com sucesso");
      }));

    /**
     * Limpa o componente para informar um novo número de série.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new VariacaoDistribuida())));
  }

  /**
   * Submit.
   * Ao clicar em gravar distribui as quantidades de grade corretamente para o campo definido.
   */
  public submit(): void {
    this.quantidadeEsperada$
      .combineLatest(this.getControl(this.controlVariacao),
        (qtdEsperada: number, control: AbstractControl) => ({qtdEsperada, control}))
      .subscribe((wrapper: { qtdEsperada: number, control: AbstractControl }) => {

        const variacoes: VariacaoDistribuida[] = this.itFormTable.sourceCollection;
        const qtdDistribuida: number = variacoes.map((v) => v.quantidade).reduce((a, b) => a + b, 0);

        if (!NumberUtil.numberNullOrZero(wrapper.qtdEsperada) && wrapper.qtdEsperada !== qtdDistribuida) {
          this.itFormTable.handleError({
            status: null,
            codigo: "PRD212",
            mensagem: `A quantidade informada (${qtdDistribuida}) é diferente da quantidade esperada (${wrapper.qtdEsperada}).`
          });
          return;
        }

        /*
         * Se a variação não existir na lista atual é porque foi alterada.
         */
        const variacaoAlterada: boolean = variacoes.some((vd: VariacaoDistribuida) => this.variacoesAtuais.indexOf(vd.variacao) === -1);
        if (variacaoAlterada) {
          this.variacaoAlterada$.next(true);
        }

        this._quantidadeDistribuida$.next(qtdDistribuida);

        if (this.variacaoString) {
          /**
           * String no formato "201=10;202=5;"
           * @type {string}
           */
          const variacaoString: string = variacoes
            .map((v: VariacaoDistribuida) => `${v.variacao}=${v.quantidade};`)
            .reduce((a, b) => `${a}${b}`, "");

          wrapper.control.setValue(variacaoString);
        } else {
          /**
           * Formato de array * Ex: {3: 20}, {102: 10}
           */
          const map = {};
          variacoes.forEach((v: VariacaoDistribuida) => {
            const qtd = map[v.variacao];
            map[v.variacao] = qtd ? qtd + v.quantidade : v.quantidade;
          });
          wrapper.control.setValue(map);
        }

        this.popup.hide(true);
      }).unsubscribe();
  }

  /**
   * Sempre que for distribuída a quantidade, será determinado um novo valor na stream.
   * @return {Observable<number>}
   */
  public get quantidadeDistribuida$(): Observable<number> {
    return this._quantidadeDistribuida$.asObservable();
  }

  /**
   * Define os comportamentos dos componentes.
   */
  private addBehaviors(): void {
    const produtoVariacao$: Observable<Produto> = this.produto$
      .filter((produto: Produto) => produto.possuiVariacao);

    /**
     * Params de busca de variação.
     * @type {Observable<URLSearchParams>}
     */
    const params$: Observable<URLSearchParams> = produtoVariacao$.map((produto: Produto) => {
      const params: URLSearchParams = new URLSearchParams();
      params.set("idProduto", produto.id.toString());
      return params;
    });

    /**
     * Linhas
     * @type {Observable<URLSearchParams>}
     */
    this.urlParamsLinha$ = params$.map((params: URLSearchParams) => {
      params.set("tipoVariacao", TipoVariacao.TIPO_LINHA[EnumUtils.id]);
      return params;
    });

    /**
     * Colunas
     * @type {Observable<URLSearchParams>}
     */
    this.urlParamsColuna$ = params$.map((params: URLSearchParams) => {
      params.set("tipoVariacao", TipoVariacao.TIPO_COLUNA[EnumUtils.id]);
      return params;
    });

    /**
     * Define o nome de coluna e linha e se deve exibir a linha.
     */
    this.addSubscription(params$
      .switchMap((params: URLSearchParams) => this.itFormTable.httpService.get(`variacoes/informacoes-grade`, {search: params}))
      .subscribe((resp: { coluna: string, linha: string, exibirLinha: boolean }) => {
        this.column$.next(resp.coluna);
        this.row$.next(resp.linha);
        this.rowVisible$.next(resp.exibirLinha);
      }));

    /**
     * Titulo do popup.
     * @type {Observable<any> | Observable<string>}
     */
    this.title$ = this.balance$
      .startWith(false)
      .combineLatest(produtoVariacao$
          .map((produto: Produto) => produto.nome.toUpperCase()),
        (search: boolean, descricao: string) => search ? `Saldo do produto ${descricao}` : `Grade de ${descricao}`);
  }

  /**
   * Observa a mudança de produto, se não possuir variação, limpa os dados para não ficar lixo em memória.
   * Se possuir variação, realiza a transformação do valor do atributo (caso haja valor) e envia para o servidor para
   * retornar os valores convertidos corretamente.
   */
  private addObservableProduct(): void {
    this.addSubscription(this.eventBlur$
      .withLatestFrom(this.produto$, this.getControl(this.controlVariacao), this.informarGrade$,
        (event, produto: Produto, variacao: AbstractControl, informarGrade: boolean) =>
          ({produto, variacao, informarGrade}))
      .switchMap((wrapper: { produto: Produto, variacao: AbstractControl, informarGrade: boolean }) => {

        /*
         * Se for string deve vir no formato "1=20;101=10;"
         * Se for array deve vir como [[1, 20], [101, 10]]
         */
        const variacoesExistente = wrapper.variacao.value;
        this.variacoesAtuais = [];

        if (wrapper.produto.possuiVariacao && variacoesExistente && wrapper.informarGrade) {

          /**
           * Se não for string, mapeia os valores e converte.
           * @type {string}
           */
          const variacaoString = StringUtil.isString(variacoesExistente) ? variacoesExistente : Object.keys(variacoesExistente)
            .map((key) => `${key}=${variacoesExistente[key]};`).reduce((a, b) => `${a}${b}`);

          const params: URLSearchParams = new URLSearchParams();
          params.set("idProduto", wrapper.produto.id.toString());
          params.set("variacoes", variacaoString);

          return this.itFormTable.httpService.get(`variacoes/variacao-to-list`, {search: params})
            .map((variacoes: VariacaoDistribuida[]) => ({
              produto: wrapper.produto,
              control: wrapper.variacao,
              informarGrade: wrapper.informarGrade,
              variacoes,
              variacaoAtual: variacaoString,
            }));
        }

        /**
         * Se não possuir variação, apenas retorna os valores.
         */
        return Observable.of({
          produto: wrapper.produto,
          control: wrapper.variacao,
          informarGrade: wrapper.informarGrade
        });
      })
      .subscribe((wrapper: {
        produto: Produto, control: AbstractControl, informarGrade: boolean, variacoes?: VariacaoDistribuida[], variacaoAtual?: string,
      }) => {

        /**
         * Limpa os valores para evitar lixo em memória.
         */
        if (!wrapper.produto.possuiVariacao || !wrapper.informarGrade) {
          wrapper.control.setValue(null);
          this.variacoesAtuais = [];
        } else if (!StringUtil.stringNullOrEmpty(wrapper.produto.variacoesString)) {
          /**
           * Se a variação foi identificada no próprio componente.
           */
          wrapper.control.setValue(this.variacaoString ? wrapper.produto.variacoesString : wrapper.produto.variacoes);
        } else {
          let variacoes = [];

          /**
           * Carrega as variações já distribuídas.
           */
          if (wrapper.variacoes) {
            /*
             * Gera um id dummy apenas para controlar saldo em alteração.
             */
            wrapper.variacoes.forEach((v: VariacaoDistribuida, idx: number) => v.id = -Math.abs(idx + 1));

            variacoes = wrapper.variacoes;
            this.setVariacoesAtuais(wrapper.variacaoAtual);
          }

          this.itFormTable.updateItemsSource(variacoes);
          this.balance$.next(false);
          this.popup.show(true);
        }
      }));
  }

  /**
   * Comportamento de saldo de estoque.
   */
  private addBehaviorsBalance(): void {
    /**
     * Busca os valores existente em estoque no servidor e seta para a tabela.
     */
    this.addSubscription(this.balance$
      .filter((balance: boolean) => balance)
      .withLatestFrom(this.produto$, this.idFilial$, this.idLocalEstoque$,
        (balance: boolean, produto: Produto, idFilial: number, idLocalEstoque: number) =>
          ({produto, idFilial, idLocalEstoque}))
      .switchMap((wrapper: { produto: Produto, idFilial: number, idLocalEstoque: number }) => {
        this.itFormTable.spinnerService.show();
        const params: URLSearchParams = new URLSearchParams();
        params.set("idProduto", wrapper.produto.id.toString());
        params.set("idFilial", wrapper.idFilial.toString());
        if (wrapper.idLocalEstoque) {
          params.set("idLocalEstoque", wrapper.idLocalEstoque.toString());
        }

        return this.itFormTable.httpService.get(`variacoes/saldo`, {search: params});
      })
      .subscribe((mapResult: SaldoVariacao[]) => {
        this.itTableBalance.updateItemsSource(mapResult);
        this.itTableBalance.clearSelection();
        this.itFormTable.spinnerService.hide();
      }));
  }

  /**
   * Adiciona as validações dos campos.
   */
  private addValidators(): void {
    /**
     * Validações.
     */
    this.addSubscription(this.validarSaldo$
      .combineLatest(this.getControl("quantidade", this.formItem$),
        (validar: boolean, control: AbstractControl) => ({validar, control}))
      .subscribe((wrapper: { validar: boolean, control: AbstractControl }) => {
        wrapper.control.clearValidators();
        wrapper.control.setValidators([valueDifferentOfValidator(0)]);

        wrapper.control.setAsyncValidators([
          variacaoAsyncValidator(
            wrapper.validar,
            this.itFormTable,
            this.produto$,
            this.idCrud$,
            this.getControl("id"),
            this.idFilial$,
            this.idLocalEstoque$,
            this.itLinha,
            this.itColuna,
            this.resourceNameValidationSaldo,
          )]);
      }));

    /**
     * Adiciona validação em linha e coluna.
     */
    this.addSubscription(this.getControl("idGradeLinha", this.formItem$)
      .merge(this.getControl("idGradeColuna", this.formItem$))
      .subscribe((control: AbstractControl) => control.setValidators([identificationRequiredValidator()])));

    this.getValueChanges("idGradeLinha", this.formItem$)
      .merge(this.getValueChanges("idGradeColuna", this.formItem$), this.getValueChanges("id", this.formItem$))
      .switchMap(() => this.getControl("quantidade", this.formItem$))
      .subscribe((control: AbstractControl) => control.updateValueAndValidity());
  }

  /**
   * Atribui as variações carregadas.
   * @param variacoes
   */
  private setVariacoesAtuais(variacoes: string) {
    if (!StringUtil.stringNullOrEmpty(variacoes)) {
      const splitVariacoes = variacoes.split(";");
      for (const idx in splitVariacoes) {
        if (splitVariacoes.hasOwnProperty(idx)) {
          const variacaoSplit = splitVariacoes[idx].split("=");
          if (variacaoSplit.length === 2) {
            this.variacoesAtuais.push(NumberUtil.parseInt(variacaoSplit[0]));
          }
        }
      }
    }
  }

}

/**
 * Função para validação de saldo de estoque de grade.
 *
 * @param {boolean} validarSaldo
 * @param {ItFormTableComponent<VariacaoDistribuida>} itFormTable
 * @param {Observable<Produto>} produto$
 * @param {Observable<number>} idCrud$
 * @param {Observable<AbstractControl>} idItem$
 * @param {Observable<number>} idFilial$
 * @param {Observable<number>} idLocalEstoque$
 * @param {ItDynacomboboxParamsComponent} itLinha
 * @param {ItDynacomboboxParamsComponent} itColuna
 * @param {string} resourceNameValidationSaldo
 * @return {(form: FormControl) => Observable<{saldoValidate: string}>}
 */
function variacaoAsyncValidator(validarSaldo: boolean, itFormTable: ItFormTableComponent<VariacaoDistribuida>,
                                produto$: Observable<Produto>, idCrud$: Observable<number>, idItem$: Observable<AbstractControl>,
                                idFilial$: Observable<number>, idLocalEstoque$: Observable<number>,
                                itLinha: ItDynacomboboxParamsComponent<Variacao>, itColuna: ItDynacomboboxParamsComponent<Variacao>,
                                resourceNameValidationSaldo: string) {
  return (form: FormControl) => {

    const idVariacao: number = form.parent.get(`id`).value;
    const idGradeLinha: number = form.parent.get(`idGradeLinha`).value;

    let idGradeColuna: number = null;
    const coluna: AbstractControl = form.parent.get(`idGradeColuna`);
    if (coluna) {
      idGradeColuna = coluna.value;
    }

    return variacaoAsyncValidate$(validarSaldo, itFormTable, produto$, idCrud$, idItem$, idFilial$, idLocalEstoque$,
      itLinha, itColuna, resourceNameValidationSaldo, idVariacao, idGradeLinha, idGradeColuna, form.value);
  };
}

/**
 * Observable de validação de saldo de estoque para variação.
 *
 * @param {boolean} validarSaldo
 * @param {ItFormTableComponent<VariacaoDistribuida>} itFormTable
 * @param {Observable<Produto>} produto$
 * @param {Observable<number>} idCrud$
 * @param {Observable<AbstractControl>} idItem$
 * @param {Observable<number>} idFilial$
 * @param {Observable<number>} idLocalEstoque$
 * @param {ItDynacomboboxParamsComponent} itLinha
 * @param {ItDynacomboboxParamsComponent} itColuna
 * @param {string} resourceNameValidationSaldo
 * @param {number} idVariacao
 * @param {number} idGradeLinha
 * @param {number} idGradeColuna
 * @param {number} quantidade
 * @return {Observable<{saldoValidate: string}>}
 */
function variacaoAsyncValidate$(validarSaldo: boolean, itFormTable: ItFormTableComponent<VariacaoDistribuida>,
                                produto$: Observable<Produto>, idCrud$: Observable<number>, idItem$: Observable<AbstractControl>,
                                idFilial$: Observable<number>, idLocalEstoque$: Observable<number>,
                                itLinha: ItDynacomboboxParamsComponent<Variacao>, itColuna: ItDynacomboboxParamsComponent<Variacao>,
                                resourceNameValidationSaldo: string, idVariacao: number, idGradeLinha: number,
                                idGradeColuna: number, quantidade: number): Observable<{ saldoValidate: string }> {

  const http: HttpService = applicationInjector.get(HttpService);

  return idItem$
    .combineLatest(idCrud$, produto$, idFilial$, idLocalEstoque$,
      (idItem: AbstractControl, id: number, produto: Produto, idFilial: number, localEstoque: number) =>
        ({produto, id, idItem: idItem.value, idFilial, localEstoque}))
    .switchMap((wrapper: { produto: Produto, id: number, idItem: number, idFilial: number, localEstoque: number }) => {

      if (itLinha && NumberUtil.numberNullOrZero(idGradeLinha) || NumberUtil.numberNullOrZero(idGradeColuna)) {
        return Observable.of({saldoValidate: "WWW108 - Por favor informe todos os campos."});
      }

      if (!validarSaldo) {
        return Observable.of(null);
      }

      const variacao: number = (( (itLinha ? itLinha.selectedItem.ordem : 1) - 1) * 100) + itColuna.selectedItem.ordem;

      itFormTable.sourceCollection
        .forEach((variacaoDistribuida: VariacaoDistribuida) => {
          if (variacaoDistribuida.variacao === variacao) {
            quantidade = quantidade + variacaoDistribuida.quantidade;
          }
        });

      /**
       * Se for alteração subtrai a quantidade original.
       */
      if (!NumberUtil.numberNullOrZero(idVariacao)) {
        const variacaoAtual: VariacaoDistribuida = itFormTable.sourceCollection
          .find((v: VariacaoDistribuida) => v.id === idVariacao);

        quantidade = quantidade - variacaoAtual.quantidade;
      }

      return saldoValidator$(resourceNameValidationSaldo, wrapper.produto.id, quantidade, wrapper.id, wrapper.idItem,
        wrapper.idFilial, variacao, null, wrapper.localEstoque);

    }).first();
}


/**
 * Pojo dummy para auxilio.
 */
class VariacaoDistribuida extends AbstractPojo {
  public idGradeColuna = 0;
  public idGradeLinha = 0;
  public quantidade = 0;
  public variacao = 0;
  public descricao = "";
}

/**
 * Pojo dummy para auxilio.
 */
class SaldoVariacao extends AbstractPojo {
  public variacao = "";
  public saldo = 0;
  public saldoPrevisto = 0;
}
