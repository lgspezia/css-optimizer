import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { applicationInjector } from "../../../../../app.module";
import { ItClienteAutocompleteComponent } from "../../../../../core/components/domain/it-cliente-autocomplete.component";
import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { identificationRequiredValidator } from "../../../../../core/crud/validadores";
import { enumConverter, EnumUtils } from "../../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../../core/models/dataitem";
import { ServerError } from "../../../../../core/models/server-error";
import { ContextoService } from "../../../../../core/services/contexto.service";
import { HttpService } from "../../../../../core/services/http.service";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { ConfiguracoesAdicionaisEntidade } from "../../entidade";
import { EntidadeDependente, GrauParentesco } from "./entidadedependente";
import { PaiDependente } from "./pai-dependente";

/**
 * Dependentes
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-dependente",
  templateUrl: "entidade-dependente.form.component.html",
})
export class ItEntidadeDependenteFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formDependente$: BehaviorSubject<FormGroup>;
  public formPaiDependente$: BehaviorSubject<FormGroup>;

  public limiteCreditoPGMTODesativado$: Observable<boolean>;
  public parentescos$: Observable<IDataItem[]>;
  public params$: Observable<IParamsData>;

  public dependente$: BehaviorSubject<boolean>;
  public reloadDependente$: Subject<number>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<EntidadeDependente>;
  @ViewChild(ItClienteAutocompleteComponent) private itDependente: ItClienteAutocompleteComponent;

  private urlParams$: Observable<URLSearchParams>;

  constructor(private formBuider: FormBuilder, private contexto: ContextoService) {
    super();

    this.limiteCreditoPGMTODesativado$ = contexto.isFuncionalidade$("LIMITE_CREDITO_FORMA_PGMTO")
      .map((f: boolean) => !f);

    this.parentescos$ = EnumUtils.getValues(GrauParentesco);
    this.dependente$ = new BehaviorSubject(false);
    this.reloadDependente$ = new Subject();
  }

  public ngOnInit(): void {
    this.formDependente$ = new BehaviorSubject(this.formBuider.group(new EntidadeDependente()));
    this.formPaiDependente$ = new BehaviorSubject(this.formBuider.group(new PaiDependente()));

    /**
     * Validador de dependente.
     */
    this.addSubscription(this.getControl("idDependente", this.formDependente$)
      .subscribe((c: AbstractControl) => {
        c.setValidators([identificationRequiredValidator()]);
        c.setAsyncValidators([dependenteAsyncValidator(this.itFormTable, this.afterGet$)]);
      }));

    /**
     * Desabilita os componentes de dependentes de pai.
     */
    this.addSubscription(this.getControl("pai", this.formPaiDependente$)
      .merge(this.getControl("limite", this.formPaiDependente$))
      .subscribe((c: AbstractControl) => c.disable()));

    /**
     * Monta os parâmetros para consultas default.
     * @type {Observable<URLSearchParams>}
     */
    this.urlParams$ = this.afterGet$.map((id: number) => {
      const params: URLSearchParams = new URLSearchParams();
      params.set("idEntidade", id.toString());
      return params;
    });

    /**
     * Verifica se a entidade possui dependentes ou se é dependende de outra entidade.
     */
    this.addSubscription(this.getControl("configuracoesAdicionaisEntidade")
      .combineLatest(this.formPaiDependente$.asObservable(),
        (control: AbstractControl, form: FormGroup) => ({control, form}))
      .subscribe((config: { control: AbstractControl, form: FormGroup }) => {
        const configuracoes: ConfiguracoesAdicionaisEntidade = config.control.value;
        if (configuracoes.paiDependente) {
          config.form.patchValue(configuracoes.paiDependente);
        }

        this.dependente$.next(configuracoes.paiDependente !== null);
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idEntidade", "idEntidade", DataType.Number, 0, null, false),
      new ColumnDefinition("idDependente", "idDependente", DataType.Number, 0, null, false),
      new ColumnDefinition("codigoDependente", "Código", DataType.String, 100),
      new ColumnDefinition("nomeDependente", "Nome", DataType.String, "*"),
      new ColumnDefinition("limiteCredito", "Limite", DataType.Number, 150, "n2"),
      new ColumnDefinition(
        "grauParentesco", "Grau", DataType.Object, 150, null, true, GrauParentesco, null, enumConverter),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.urlParams$
      .map((params: URLSearchParams) => ({endpoint: "dependentes-entidade/buscar", search: params}));

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$.subscribe(() =>
        this.itFormTable.sourceCollection.forEach((dependente: EntidadeDependente) => {
          if (dependente.id) {
            dependente.id = NumberUtil.parseFloat(dependente.id.toString());
          }
          if (dependente.idEntidade) {
            dependente.idEntidade = NumberUtil.parseFloat(dependente.idEntidade.toString());
          }
          if (dependente.limiteCredito) {
            dependente.limiteCredito = NumberUtil.parseFloat(dependente.limiteCredito.toString());
          }
        })));

    /**
     * Após a alteração, recarrega os dados para o autocomplete.
     */
    this.addSubscription(this.itFormTable
      .afterLoadUpdate$
      .withLatestFrom(this.getControl("idDependente", this.formDependente$),
        (dependente: EntidadeDependente, idDependente: AbstractControl) => ({dependente, idDependente}))
      .subscribe((wrapper: { dependente: EntidadeDependente, idDependente: AbstractControl }) => {
        /**
         * Se não possuir item selecionado é porque não possui o objeto e deve ser
         * disparada uma requisição.
         */
        if (!this.itDependente.selectedItem) {
          if (!NumberUtil.numberNullOrZero(wrapper.dependente.idDependente)) {
            if (NumberUtil.numberNullOrZero(wrapper.idDependente.value)) {
              wrapper.idDependente.setValue(wrapper.dependente.idDependente);
            }
            this.reloadDependente$.next();
          }
        }
      }));

    /**
     * Submit. É necessário revalidar novamente o form, por isso existe o switchMap.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((dependente: EntidadeDependente) =>
        dependenteValidate$(this.itFormTable, dependente.idDependente, dependente.id, this.afterGet$)
          .combineLatest(this.afterGet$,
            (validate: { depValidate: string }, id: number) => ({validate, id, dependente})))
      .subscribe((wrapper: {
        validate: { depValidate: string }, id: number, dependente: EntidadeDependente,
      }) => {
        /**
         * Se não passou na validação, exibe a mensagem e retorna.
         */
        if (wrapper.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(wrapper.validate.depValidate));
          return;
        }

        wrapper.dependente.idEntidade = wrapper.id;
        if (this.itDependente.selectedItem) {
          wrapper.dependente.codigoDependente = this.itDependente.selectedItem.codigo;
          wrapper.dependente.nomeDependente = this.itDependente.selectedItem.nome;
        }

        this.itFormTable.submit$.next(wrapper.dependente);
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new EntidadeDependente())));
  }

}

/**
 * Validação assíncrona para dependentes.
 * @param itFormTable: ItFormTableComponent<EntidadeDependente>
 * @param afterGet$: Observable<number>
 * @return {(formControl:FormControl)=>Observable<{depValidate: string}>}
 */
function dependenteAsyncValidator(itFormTable: ItFormTableComponent<EntidadeDependente>,
                                  afterGet$: Observable<number>) {
  return (formControl: FormControl) => {
    return dependenteValidate$(
      itFormTable,
      NumberUtil.parseFloat(formControl.value),
      NumberUtil.parseFloat(formControl.parent.get("id").value),
      afterGet$,
    );
  };
}

/**
 * Observable para validação assíncrona de dependentes.
 * @param itFormTable: ItFormTableComponent<EntidadeDependente>
 * @param idDependente: number
 * @param id: number
 * @param afterGet$: Observable<number>
 * @return {Observable<{depValidate: string}>}
 */
function dependenteValidate$(itFormTable: ItFormTableComponent<EntidadeDependente>,
                             idDependente: number, id: number,
                             afterGet$: Observable<number>): Observable<{ depValidate: string }> {

  return afterGet$
    .switchMap((idEntidade: number) => {
      if (idDependente === idEntidade) {
        return Observable.of({depValidate: "ENT22 - Este cliente não pode ser dependente de si mesmo"});
      }

      const dependenteExistente: boolean = itFormTable
        .sourceCollection
        .some((d: EntidadeDependente) => d.idDependente === idDependente &&
        (NumberUtil.numberNullOrZero(id) || id !== d.id));

      if (dependenteExistente) {
        return Observable.of({depValidate: "ENT25 -Dependente já cadastrado"});
      }

      const http: HttpService = applicationInjector.get(HttpService);
      const params: URLSearchParams = new URLSearchParams();
      params.set("idEntidade", idDependente.toString());

      return http.get(`dependentes-entidade/existe-dependente`, {search: params})
        .map((existe: boolean) => !existe ? null :
          {depValidate: "ENT24 -Este cliente não pode ser um dependente por que já possui dependentes"});
    })
    .first();
}
