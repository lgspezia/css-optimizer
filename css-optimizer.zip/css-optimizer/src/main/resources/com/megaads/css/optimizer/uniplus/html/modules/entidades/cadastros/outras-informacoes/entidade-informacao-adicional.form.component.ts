import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl, Validators } from "@angular/forms";
import { Observable } from "rxjs/Observable";

import { FormComponent } from "../../../../core/crud/form-component";
import { EnumUtils } from "../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../core/models/dataitem";
import { ContextoService } from "../../../../core/services/contexto.service";
import { ModeloNfse } from "../../../cadastros/filiais/filial";
import { TipoEntidade, TipoTomadorServico } from "../entidade";

/**
 * Informações adicionais.
 *
 * Created by Osiel on 29/05/17.
 */
@Component({
  selector: "it-entidade-informacaoadicional",
  templateUrl: "entidade-informacao-adicional.form.component.html",
})
export class ItEntidadeInformacaoAdicionalFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;
  @Input() public tipoEntidade$: Observable<TipoEntidade>;

  public apogeus$: Observable<boolean>;
  public cliente$: Observable<boolean>;
  public expedicao$: Observable<boolean>;
  public fornecedor$: Observable<boolean>;
  public mvaEstado$: Observable<boolean>;
  public nfceUnico$: Observable<boolean>;
  public operacaoFiscal$: Observable<boolean>;

  public nomeTabela$: Observable<string>;

  public tiposTomadorServico$: Observable<IDataItem[]>;

  constructor(private contexto: ContextoService) {
    super();
    this.tiposTomadorServico$ = EnumUtils.getValues(TipoTomadorServico);
  }

  public ngOnInit(): void {
    this.nomeTabela$ = this.tipoEntidade$.map((tipo: TipoEntidade) => tipo[`extra`]);

    this.fornecedor$ = this.entidade$(TipoEntidade.FORNECEDOR);

    // FUNCIONALIDADE NÃO EXISTE MAIS
    // this.apogeus$ = this.entidade$(TipoEntidade.REPRESENTANTE)
    //   .combineLatest(this.contexto.isFuncionalidade$("APOGEUS"), (r: boolean, f: boolean) => r && f);

    this.cliente$ = this.entidade$(TipoEntidade.CLIENTE);

    this.expedicao$ = this.cliente$
      .combineLatest(this.contexto.isModulo$("EXPEDICAO"), (c: boolean, m: boolean) => c && m);

    this.nfceUnico$ = this.contexto.isLicenciado$("NF_SERVICO")
      .combineLatest(this.contexto.filial$, this.cliente$,
        (s: boolean, filial: any, c: boolean) => c && s && filial.parametroNFSE.modeloNfse === ModeloNfse.UNICO[EnumUtils.id]);

    this.mvaEstado$ = this.cliente$
      .combineLatest(this.fornecedor$, this.contexto.isFuncionalidade$("MVA_PAUTA_ESTADO"),
        (cli: boolean, fo: boolean, mva: boolean) => mva && (cli || fo));

    this.operacaoFiscal$ = this.cliente$
      .combineLatest(this.fornecedor$, this.contexto.isFuncionalidade$("OPERACAO_FISCAL"), this.contexto.getPropriedade$(372),
        (cli: boolean, fo: boolean, func: boolean, prop: string) => func && prop === "true" && (cli || fo));

    this.addSubscription(this.getControl("inscricaoSuframa")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(9)])));

    this.addSubscription(this.getControl("codigoUser")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.maxLength(4)])));

    this.addSubscription(this.getControl("dataCadastro")
      .subscribe((c: AbstractControl) => c.disable()));
  }

  /**
   * Retorna um novo observable de boolean atestando o valor passado.
   * @param tipo: TipoEntidade
   * @return {Observable<boolean>}
   */
  private entidade$(tipo: TipoEntidade): Observable<boolean> {
    return this.tipoEntidade$.map((t: TipoEntidade) => t[EnumUtils.id] === tipo[EnumUtils.id]);
  }
}
