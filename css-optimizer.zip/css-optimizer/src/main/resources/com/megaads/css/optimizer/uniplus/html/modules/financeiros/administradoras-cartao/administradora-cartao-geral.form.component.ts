import { Component, Input, OnInit } from "@angular/core";

import { Observable } from "rxjs/Observable";

import { AbstractControl, Validators } from "@angular/forms";
import { FormComponent } from "../../../core/crud/form-component";
import {
  cpfCnpjValidator, identificationRequiredValidator,
  TipoValidadorCpfCnpj
} from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ParcelamentoPosDebCred, TipoCartaoManual } from "./administradora-cartao";

/**
 * @author Luan  on 27/07/2017.
 */
@Component({
  selector: "it-administradora-cartao",
  templateUrl: "administradora-cartao-geral.form.component.html",
})
export class ItAdministradoraCartaoFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  public tipoManual$: Observable<IDataItem[]>;
  public tipoParcelamento$: Observable<IDataItem[]>;
  public tipoComponent$: Observable<TipoValidadorCpfCnpj>;

  constructor() {
    super();

    this.tipoManual$ = EnumUtils.getValues(TipoCartaoManual, EnumUtils.display, false);
    this.tipoParcelamento$ = EnumUtils.getValues(ParcelamentoPosDebCred, EnumUtils.display, false);
    this.tipoComponent$ = Observable.of(TipoValidadorCpfCnpj.CNPJ);

  }


  public ngOnInit(): void {

    this.addSubscription(this.getControl("codigo").subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required])));

    this.addSubscription(this.getControl("nome").subscribe((control: AbstractControl) =>
      control.setValidators([Validators.required, Validators.maxLength(50)])));

    this.addSubscription(this.getControl("idEntidade").subscribe((control: AbstractControl) =>
      control.setValidators([identificationRequiredValidator()])));

    this.addSubscription(this.getControl("cnpj").subscribe((control: AbstractControl) =>
      control.setValidators([cpfCnpjValidator(TipoValidadorCpfCnpj.CNPJ)])));

    this.disableWhenIsNotCreateMode("codigo");
  }
}
