import { EnumUtils } from "../../../../core/enuns/enumutil";
import { FinalidadeEmissaoNfe } from "./finalidade-emissao-nfe.enum";

export enum FinalidadeEmissaoNfeCFOP {
  NORMAL = <any>            {
    [EnumUtils.id]: "NORMAL",
    [EnumUtils.display]: "Normal",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.NORMAL,
    origem: 0
  },
  COMPLEMENTAR = <any>          {
    [EnumUtils.id]: "COMPLEMENTAR",
    display: "Complementar",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.COMPLEMENTAR,
    origem: 0
  },
  AJUSTE = <any>                {
    [EnumUtils.id]: "AJUSTE",
    display: "Ajuste",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.AJUSTE,
    origem: 0
  },
  AJUSTE_ITENS = <any>          {
    [EnumUtils.id]: "AJUSTE_ITENS",
    display: "Ajuste com itens",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.AJUSTE,
    origem: 0
  },
  DEVOLUCAO_VENDA = <any>       {
    [EnumUtils.id]: "DEVOLUCAO_VENDA",
    display: "Devolução de venda",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.DEVOLUCAO,
    origem: 3
  },
  DEVOLUCAO_COMPRA = <any>      {
    [EnumUtils.id]: "DEVOLUCAO_COMPRA",
    display: "Devolução de compra",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.DEVOLUCAO,
    origem: 0
  },
  IMPORTACAO_CUPOM = <any>      {
    [EnumUtils.id]: "IMPORTACAO_CUPOM",
    display: "Importação do PDV",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.NORMAL,
    origem: 1
  },
  TRANSFERENCIA_CREDITO_ICMS = <any> {
    [EnumUtils.id]: "TRANSFERENCIA_CREDITO_ICMS",
    display: "Transferência de crédito de ICMS",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.AJUSTE,
    origem: 0
  },
  CREDITO_ICMS = <any>{
    [EnumUtils.id]: "CREDITO_ICMS",
    display: "Crédito de ICMS",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.AJUSTE,
    origem: 0
  },
  TRANSFERENCIA_ENTRADA_MERCADORIA = <any> {
    [EnumUtils.id]: "TRANSFERENCIA_ENTRADA_MERCADORIA",
    display: "Entrada de transferência de mercadorias",
    finalidadeEmissaoNfe: FinalidadeEmissaoNfe.NORMAL,
    origem: 0
  },

}
