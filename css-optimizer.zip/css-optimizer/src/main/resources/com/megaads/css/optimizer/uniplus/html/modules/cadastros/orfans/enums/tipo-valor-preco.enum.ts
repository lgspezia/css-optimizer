import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum TipoValorPreco {
  PRECO = <any> {[EnumUtils.id]: "TRIBUTADO", [EnumUtils.display]: "Preço de venda", custo: false},
  CUSTO = <any> {[EnumUtils.id]: "ISENTO", [EnumUtils.display]: "Custo", custo: true},
  CUSTO_MEDIO = <any> {[EnumUtils.id]: "NAO_TRIBUTADO", [EnumUtils.display]: "Custo Médio", custo: true},
}
