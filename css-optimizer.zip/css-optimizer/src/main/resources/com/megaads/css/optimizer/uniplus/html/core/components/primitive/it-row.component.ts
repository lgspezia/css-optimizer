import { Component, ContentChildren, forwardRef, QueryList } from "@angular/core";

import { AbstractPojo } from "../../crud/pojo";
import { ItFormTableComponent } from "./it-formtable.component";
import { ItTableComponent } from "./it-table.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-row",
  template: `
    <div class="row">
        <ng-content></ng-content>
    </div>
  `,
})
export class ItRowComponent {
  @ContentChildren(forwardRef(() => ItFormTableComponent)) private formsTables: QueryList<ItFormTableComponent<AbstractPojo>>;
  @ContentChildren(forwardRef(() => ItTableComponent)) private tables: QueryList<ItTableComponent<AbstractPojo>>;

  /**
   * Invalida o flexgrid para reposicionar a table e o scroll.
   */
  public invalidateFlexGrid() {
    if (this.formsTables) {
      this.formsTables.forEach((form: ItFormTableComponent<AbstractPojo>) => form.invalidateFlexGrid());
    }
    if (this.tables) {
      this.tables.forEach((form: ItTableComponent<AbstractPojo>) => form.invalidateFlexGrid());
    }
  }
}
