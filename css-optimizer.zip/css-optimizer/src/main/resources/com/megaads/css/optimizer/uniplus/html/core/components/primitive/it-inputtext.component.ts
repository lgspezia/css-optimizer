import { Component, EventEmitter, Input, Output } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
  // changeDetection: ChangeDetectionStrategy.OnPush, // valid
  selector: "it-inputtext",
  templateUrl: "it-inputtext.component.html",
})
export class ItInputTextComponent extends BaseFormComponent {
  @Input() public placeholder = "";
  @Input() public len = 40;

  @Output() eventBlur: EventEmitter<any>;

  constructor() {
    super();
    this.eventBlur = new EventEmitter();
  }

  /**
   * Evento Blur
   * @param event
   */
  public blur(event) {
    this.eventBlur.emit(event);
  }
}
