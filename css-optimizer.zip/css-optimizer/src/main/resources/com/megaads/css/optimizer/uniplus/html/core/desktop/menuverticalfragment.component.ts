import { ChangeDetectionStrategy, Component, Input } from "@angular/core";
import { Router } from "@angular/router";

import { ToasterService } from "../services/toaster.service";
import { IMenu } from "./IMenu";

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-menuverticalfragment",
  templateUrl: "menuverticalfragment.component.html",
})
export class MenuVerticalFragmentComponent {

  @Input() public data: IMenu[] = [];

  constructor(private router: Router, private toaster: ToasterService) {
  }

  /**
   * Realiza uma navegação entre componentes
   * @param object
   */
  protected goTo(object: IMenu): void {
    this.router.navigate([object.endpoint])
      .catch((error) => {
        this.toaster.pop("warning", `Não foi possível acessar o caminho ${object.endpoint}`);
        throw new Error(error);
      });
  }
}
