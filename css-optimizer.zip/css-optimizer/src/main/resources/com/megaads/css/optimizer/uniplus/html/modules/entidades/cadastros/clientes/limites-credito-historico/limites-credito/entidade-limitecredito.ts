import { AbstractPojo } from "../../../../../../core/crud/pojo";

/**
 * Representação de historico de limite de crédito.
 *
 * Created by Osiel on 22/06/17.
 */
export class LimiteCreditoHistorico extends AbstractPojo {

  public idCliente = 0;
  public idFormaPgmto = 0;
  public idFormaPgmtoEspecial = 0;
  public dataInclusao: Date = new Date();
  public idUsuarioResponsavel = 0;
  public valorLimiteCredito = 0;
  public valorLimiteCreditoEspecial = 0;
  public liberacaoEspecial = false;
  public dataLiberacaoEspecialInicial: Date = new Date;
  public dataLiberacaoEspecialFinal: Date = new Date();
  public usuarioResponsavel = "";
  public formaPgmto = "";
  public formaPgmtoEspecial = "";

}
