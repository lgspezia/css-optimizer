import { Component, Input, OnInit } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { EnumUtils, TipoCalculoCusto } from "../../enuns/enumutil";
import { IDataItem } from "../../models/dataitem";
import { ItComboboxComponent } from "../primitive/it-combobox.component";

@Component({
  selector: "it-tipocusto-combobox",
  templateUrl: "../primitive/it-combobox.component.html",
})
export class ItTipoCustoComboboxComponent extends ItComboboxComponent<TipoCalculoCusto> implements OnInit {
  @Input() public isVenda$: Observable<boolean> = Observable.of(false);
  @Input() public tipoCustoFilter$: Observable<TipoCalculoCustoFilter> = Observable.of(null);

  private tiposCustoVenda$: Observable<IDataItem[]>;
  private tiposCusto$: Observable<IDataItem[]>;

  constructor() {
    super();
    this.label = "Calcular por";
    this.tiposCustoVenda$ = EnumUtils.getValues(TipoCalculoCusto, "displayVenda");
    this.tiposCusto$ = EnumUtils.getValues(TipoCalculoCusto);
  }

  /**
   * Combina os observables para filtrar os tipos de custo desejados.
   */
  public ngOnInit(): void {
    this.itens$ = this.isVenda$
      .combineLatest(this.tiposCustoVenda$, this.tiposCusto$, this.tipoCustoFilter$,
        (isVenda: boolean, vendas: IDataItem[], custos: IDataItem[], filter: TipoCalculoCustoFilter) => {
          const tiposCustos = isVenda ? vendas : custos;
          return filter === null ? tiposCustos :
            tiposCustos.filter((tipoCusto: IDataItem) => filterTipo(filter, tipoCusto));
        });
  }

}

/**
 * Filtra somente os itens que devem ser exibidos para a data de hoje.
 */
function filterTipo(tipoFilter: TipoCalculoCustoFilter, tipoCusto: IDataItem): boolean {
  if (tipoFilter === TipoCalculoCustoFilter.TODAY) {
    return tipoCusto.id === TipoCalculoCusto.CUSTO_ULTIMA_COMPRA_ATUAL[EnumUtils.id] ||
      tipoCusto.id === TipoCalculoCusto.CUSTO_MEDIO_ATUAL[EnumUtils.id];
  } else {
    return tipoCusto.id === TipoCalculoCusto.CUSTO_ULTIMA_COMPRA_DATA[EnumUtils.id] ||
      tipoCusto.id === TipoCalculoCusto.CUSTO_MEDIO_DATA[EnumUtils.id];
  }
}

export enum TipoCalculoCustoFilter {
  TODAY = 0, RETROACTIVE = 1,
}
