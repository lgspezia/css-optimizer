import { OnInit } from "@angular/core";
import { AbstractControl, FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";

import { isBoolean, isObject } from "util";
import { IEditDetails } from "../../../core/crud/edit-details";
import { GridCrud } from "../../../core/crud/grid.crud";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { ContextoService } from "../../../core/services/contexto.service";
import { StringUtil } from "../../../core/utils/string.util";
import { ModeloNfse } from "../../cadastros/filiais/filial";
import { ConfiguracoesAdicionaisEntidade, Entidade, TipoEntidade } from "./entidade";

/**
 * Classe base para GridGrud de entidade.
 *
 * Created by Osiel S. Mello on 16/05/2017.
 */
export class EntidadeGridCrudComponent extends GridCrud<Entidade> implements OnInit {

  public bloqueio$: Observable<boolean>;
  public cartaoCliente$: Observable<boolean>;
  public comissaoPauta$: Observable<boolean>;
  public dependente$: Observable<boolean>;
  public finalizador$: Observable<boolean>;
  public historico$: Observable<boolean>;
  public historicoEntrega$: Observable<boolean>;
  public limiteCredito$: Observable<boolean>;
  public outrasInformacoes$: Observable<boolean>;
  public spc$: Observable<boolean>;
  public unidadesCte$: Observable<boolean>;

  public title$: Observable<string>;

  public tipoEntidade$: Observable<TipoEntidade>;

  /**
   * Não será usado no template.
   */
  protected tipoEntidade: TipoEntidade;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, protected contexto: ContextoService) {
    super(activatedRoute, formBuilder, new Entidade(), "entidades");

    /**
     * Antes da gravação.
     */
    this.addSubscription(this.beforeSubmit$
      .subscribe((detail: IEditDetails<Entidade>) => {
        if (isBoolean(detail.pojo.cliente)) {
          detail.pojo.cliente = detail.pojo.cliente ? 1 : 0;
        }

        if (isBoolean(detail.pojo.fornecedor)) {
          detail.pojo.fornecedor = detail.pojo.fornecedor ? 1 : 0;
        }

        if (isBoolean(detail.pojo.transportadora)) {
          detail.pojo.transportadora = detail.pojo.transportadora ? 1 : 0;
        }

        if (isBoolean(detail.pojo.representante)) {
          detail.pojo.representante = detail.pojo.representante ? 1 : 0;
        }

        if (isBoolean(detail.pojo.tecnico)) {
          detail.pojo.tecnico = detail.pojo.tecnico ? 1 : 0;
        }

        if (isBoolean(detail.pojo.comprador)) {
          detail.pojo.comprador = detail.pojo.comprador ? 1 : 0;
        }

        if (isBoolean(detail.pojo.fabricante)) {
          detail.pojo.fabricante = detail.pojo.fabricante ? 1 : 0;
        }

        if (isBoolean(detail.pojo.motorista)) {
          detail.pojo.motorista = detail.pojo.motorista ? 1 : 0;
        }

        if (isBoolean(detail.pojo.portador)) {
          detail.pojo.portador = detail.pojo.portador ? 1 : 0;
        }

        if (isBoolean(detail.pojo.entregador)) {
          detail.pojo.entregador = detail.pojo.entregador ? 1 : 0;
        }

        if (!StringUtil.stringNullOrEmpty(detail.pojo.senhaCartao2)) {
          detail.pojo.senhaCartaoFidelidade = detail.pojo.senhaCartao2;
        }

        if (detail.pojo.idUsuarioVendedor === 0) {
          detail.pojo.idUsuarioVendedor = null;
        }

        detail.pojo.configuracoesAdicionaisEntidade = null;
      }));
  }

  public ngOnInit(): void {
    super.ngOnInit();

    this.endpoint = this.tipoEntidade[`url`];

    /**
     * Define o tipo como cliente e modo diferente de create.
     */
    const cliente$: Observable<boolean> = this.isCreate$()
      .map((create: boolean) => !create && this.tipoEntidade === TipoEntidade.CLIENTE);

    this.bloqueio$ = cliente$;

    this.cartaoCliente$ = this.contexto.isFuncionalidade$("CARTAO_FIDELIDADE")
      .combineLatest(cliente$, (cartao: boolean, c: boolean) => c && cartao);

    this.dependente$ = this.contexto.isFuncionalidade$("DEPENDENTES_ENTIDADE")
      .combineLatest(cliente$, (m: boolean, u: boolean) => m && u);

    this.historico$ = this.contexto.isFuncionalidade$("HISTORICO_OCORRENCIAS_ENTIDADE")
      .combineLatest(this.isCreate$(), (f: boolean, c: boolean) => f && !c);

    this.historicoEntrega$ = this.contexto.isModulo$("EXPEDICAO")
      .combineLatest(cliente$, (m: boolean, c: boolean) => m && c);

    this.limiteCredito$ = this.contexto.isFuncionalidade$("LIMITE_CREDITO")
      .combineLatest(cliente$, (limite: boolean, cliente: boolean) => limite && cliente);

    this.outrasInformacoes$ = this.contexto.isFuncionalidade$("OBSERVACOES_ENTIDADE")
      .combineLatest(this.contexto.isFuncionalidade$("EXTRA_COMPONENTES_ENTIDADE"), this.contexto.isFuncionalidade$("DADOS_TRIBUTARIOS"),
        this.contexto.isLicenciado$("NF_SERVICO"), this.contexto.filial$,
        (obs: boolean, extra: boolean, dadosTrib: boolean, servico: boolean, filial: any) =>
          (obs || extra ||
          (dadosTrib && (this.tipoEntidade === TipoEntidade.CLIENTE || this.tipoEntidade === TipoEntidade.FORNECEDOR)) ||
          (this.tipoEntidade === TipoEntidade.CLIENTE && servico && filial.parametroNFSE.modeloNfse === ModeloNfse.UNICO[EnumUtils.id]))
      );

    this.spc$ = cliente$;
    this.finalizador$ = cliente$;

    this.unidadesCte$ = cliente$
      .combineLatest(this.contexto.isModulo$("CTE"), (cliente: boolean, cte: boolean) => cliente && cte);

    this.tipoEntidade$ = Observable.of(this.tipoEntidade);
    this.title$ = Observable.of(this.tipoEntidade[EnumUtils.display]);

    /**
     * Verifica se ao menos uma preferencia de pauta esta habilita e  modulo e funcionalidade esta ativa.
     * @type {Observable<boolean>}
     */
    this.comissaoPauta$ = this.contexto.getPropriedade$(6)
      .combineLatest(this.contexto.getPropriedade$(9), this.contexto.getPropriedade$(12), this.contexto.getPropriedade$(15),
        (p1: string, p2: string, p3: string, p4: string) => p1 === "true" || p2 === "true" || p3 === "true" || p4 === "true")
      .combineLatest(this.contexto.isModulo$("COMISSAO"), this.contexto.isFuncionalidade$("PAUTA_PRECO"),
        (pauta: boolean, modulo: boolean, func: boolean) => pauta && modulo && func && this.tipoEntidade === TipoEntidade.REPRESENTANTE);

    /**
     * Converte as configurações de entidade em Objeto.
     */
    this.addSubscription(this.getValueChanges("configuracoesAdicionaisEntidade")
      .filter((configuracao: ConfiguracoesAdicionaisEntidade | String) => !isObject(configuracao))
      .combineLatest(this.getControl("configuracoesAdicionaisEntidade"),
        (configuracao: string, control: AbstractControl) => ({configuracao, control}))
      .subscribe((conf: { configuracao: string, control: AbstractControl }) => conf.control.setValue(JSON.parse(conf.configuracao))));
  }
}
