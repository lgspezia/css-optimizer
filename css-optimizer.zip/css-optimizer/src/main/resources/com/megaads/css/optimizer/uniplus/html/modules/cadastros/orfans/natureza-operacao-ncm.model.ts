import { AbstractPojo } from "../../../core/crud/pojo";
import { TipoRegistroNcm } from "../../notas-fiscais/ncms/ncm";

export class NaturezaOperacaoNcm extends AbstractPojo {
  public idNcm = 0;
  public idNaturezaOperacao = 0;
  public codigoNcm = "";
  public descricaoNcm = "";
  public tipoRegistroNcm: TipoRegistroNcm;
}
