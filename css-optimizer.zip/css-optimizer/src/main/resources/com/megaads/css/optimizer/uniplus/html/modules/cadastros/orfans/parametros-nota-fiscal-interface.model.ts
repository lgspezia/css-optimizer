import { AbstractPojo } from "../../../core/crud/pojo";
import { CodigoNaturezaOperacaoG2ka } from "./enums/codigo-natureza-operacao-g2ka.enum";
import { FinalidadeEmissaoNfeCFOP } from "./enums/finalidade-emissao-nfe-cfop.enum";
import { PresencaConsumidorNFE } from "./enums/presenca-consumidor-nfe.enum";
import { TipoCfopConsignacao } from "./enums/tipo-cfop-consignacao.enum";
import { TipoIntegracaoFinanceiro } from "./enums/tipo-integracao-financeiro.enum";
import { TipoValorPreco } from "./enums/tipo-valor-preco.enum";
import { GnreNaturezaOperacaoEstado } from "./gnre-natureza-operacao-estado.model";

/**
 * TODO Classes desse pacote não tem um cadastro ainda, mas são usados em outros pontos do sistema;
 * Essas classes devem ser refatoradas e colocadas em seu locais, quandos os respectivos cadastros estiverem feitos.
 */
export class ParametrosNotaFiscalInterface extends AbstractPojo {
  public idplanocontas = 0;
  public finalidadeEmissaoNfe: FinalidadeEmissaoNfeCFOP;
  public considerarProduto: boolean;
  public considerarServico: boolean;
  public digitarImpostosItemNotaSaida: boolean;
  public informarTotaisManualmente: boolean;
  public consignacao: TipoCfopConsignacao;
  public consideraDevolucaoVenda: boolean;
  public integracao: TipoIntegracaoFinanceiro;
  public habilitaBaseIpiItemNota: boolean;
  public habilitaBasePisCofinsItemNota: boolean;
  public idCondicaoPagamento = 0;
  public idtipodocumentofinanceiro = 0;
  public descricao = "";
  public adicionarPisCofinsInfComp: boolean;
  public somarPisOutrasDesp: boolean;
  public somarCofinsOutrasDesp: boolean;
  public somarSiscomexOutrasDesp: boolean;
  public somarDespAcesOutrasDesp: boolean;
  public somarIcmsOutrasDesp: boolean;
  public consideravenda: boolean;
  public naoConsideraTribEspecProduto: boolean;
  public permitirBaixarLoteVencido: boolean;
  public conferenciaNotaFiscal: boolean;
  public conferenciaPedido: boolean;
  public tipoValorPreco: TipoValorPreco;
  public consideraInscricaoEstadualSub: boolean;
  public codigoCfopServicoG2ka: CodigoNaturezaOperacaoG2ka;
  public listaNaturezaOperacaoEstado: GnreNaturezaOperacaoEstado[];
  public idObsLancFiscalCreditoIcms;
  public idAjusteDocFiscalCreditoIcms;
  public consumidorFinal: boolean;
  public presencaConsumidor: PresencaConsumidorNFE;
  public exigirDocumentoReferenciado: boolean;

}
