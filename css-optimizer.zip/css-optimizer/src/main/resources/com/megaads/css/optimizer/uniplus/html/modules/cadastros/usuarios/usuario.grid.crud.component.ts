import { Component, OnInit } from "@angular/core";
import { FormBuilder } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { ICustomizableColumn } from "../../../core/crud/customizable-column";
import { IEditDetails } from "../../../core/crud/edit-details";
import { GridCrud } from "../../../core/crud/grid.crud";
import { EnumSimNao, enumSimNaoConverter } from "../../../core/enuns/enumutil";
import { ContextoService } from "../../../core/services/contexto.service";
import { NumberUtil } from "../../../core/utils/number.util";
import { Filial } from "../filiais/filial";
import { Usuario } from "./usuario";

/**
 * @author Luan  on 17/07/2017.
 */
@Component({
  templateUrl: "usuario.grid.crud.html"
})
export class UsuarioGridCrudComponent extends GridCrud<Usuario> implements OnInit {

  public customizableColumns$: Observable<ICustomizableColumn[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService) {
    super(activatedRoute, formBuilder, new Usuario(), "usuarios");

    const coluns: ICustomizableColumn[] = [
      {binding: "supervisor", enumClass: EnumSimNao, converter: enumSimNaoConverter},
      {binding: "inativo", enumClass: EnumSimNao, converter: enumSimNaoConverter},
    ];

    this.customizableColumns$ = Observable.of(coluns);

    this.addSubscription(this.beforeSubmit$
      .subscribe((detail: IEditDetails<Usuario>) => {
        detail.pojo.inativo = detail.pojo.inativoAux ? 1 : 0;
        detail.pojo.supervisor = detail.pojo.supervisorAux ? 1 : 0;
      }));

  }

  public ngOnInit(): void {
    super.ngOnInit();

    const userFilter: Observable<{ usuario: Usuario, usuarioContexto: Usuario }> = this.afterSave$
      .withLatestFrom(this.contexto.usuario$, (usuario: Usuario, usuarioContexto: Usuario) =>
        ({usuario, usuarioContexto}))
      .filter((obj: { usuario: Usuario, usuarioContexto: Usuario }) =>
        NumberUtil.parseFloat(obj.usuario.id.toString()) === NumberUtil.parseFloat(obj.usuarioContexto.id.toString()));

    /**
     * Atualiza o usuário do contexto, desde que seja o mesmo usuário.
     */
    this.addSubscription(userFilter.map((obj: { usuario: Usuario, usuarioContexto: Usuario }) => obj.usuario)
      .subscribe((usuario: Usuario) => this.contexto.usuario = usuario));

    /**
     * Atualiza a filial do contexto, desde que seja o mesmo usuário.
     */
    this.addSubscription(userFilter.map((obj: { usuario: Usuario, usuarioContexto: Usuario }) => obj.usuario)
      .combineLatest(this.contexto.filial$, (usuario: Usuario, filial: Filial) => ({usuario, filial}))
      .filter((obj: { usuario: Usuario, filial: Filial }) =>
        NumberUtil.parseFloat(obj.usuario.idFilialTrabalho.toString()) !== NumberUtil.parseFloat(obj.filial.id.toString()))
      .switchMap((obj: { usuario: Usuario, filial: Filial }) => this.httpService.get(`filiais/${obj.usuario.idFilialTrabalho}`))
      .subscribe((filial: Filial) => this.contexto.filial = filial));
  }
}
