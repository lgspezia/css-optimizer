import { Component } from "@angular/core";

import { TipoEntidade } from "../../../modules/entidades/cadastros/entidade";
import { EnumUtils } from "../../enuns/enumutil";
import { HttpService } from "../../services/http.service";
import { ItEntidadeAutocompleteComponent } from "./it-entidade-autocomplete.component";

/**
 * Componente de representante, se necessário pode ser passado parâmetros como
 * ItEntidadeAutocompleteComponent#filtrarFilial ou ItEntidadeAutocompleteComponent#exibirInativos.
 * <p>
 * Para mais detalhes consultar ItEntidadeAutocompleteComponent.
 *
 * @Author Osiel.
 */
@Component({
  selector: "it-representante-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItRepresentanteAutocompleteComponent extends ItEntidadeAutocompleteComponent {

  constructor(httpService: HttpService) {
    super(httpService);
    this.label = "Vendedor";
    this.tipos = [TipoEntidade.REPRESENTANTE[EnumUtils.id]];
    this.urlUpdate = "representantes";
    this.configParams();
  }

}
