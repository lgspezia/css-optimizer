import { Component, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { ItAutocompleteComponent } from "../../../core/components/primitive/it-autocomplete.component";
import { IEditDetails } from "../../../core/crud/edit-details";
import { GridCrud } from "../../../core/crud/grid.crud";
import { identificationRequiredValidator, uniqueAsyncValidator } from "../../../core/crud/validadores";
import { Estado } from "./estado";

@Component({
  templateUrl: "estado.grid.crud.html",
})
export class EstadoGridCrudComponent extends GridCrud<Estado> {

  @ViewChild(ItAutocompleteComponent) private itPais: ItAutocompleteComponent<Estado>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Estado(), "estados");

    this.addValidators();
  }

  /**
   * Invoca o crud de cidades
   */
  public eventCidades(): void {
    super.goTo("cidades");
  }

  private addValidators(): void {

    this.addSubscription(this.getControl("codigo")
      .subscribe((codigo: AbstractControl) => {
        codigo.setValidators([Validators.required, Validators.maxLength(2), Validators.pattern("[A-Z]+")]);
        codigo.setAsyncValidators([uniqueAsyncValidator("estados")]);
      }));

    this.addSubscription(this.getControl("nome")
      .subscribe((nome: AbstractControl) => nome.setValidators([Validators.required])));

    this.addSubscription(this.getControl("idPais")
      .subscribe((idPais: AbstractControl) => idPais.setValidators([identificationRequiredValidator()])));

    this.disableWhenIsNotCreateMode("codigo");

    this.addSubscription(this.beforeSubmit$
      .subscribe((details: IEditDetails<Estado>) => details.pojo.nomePais = this.itPais.selectedItem.nome));

  }
}
