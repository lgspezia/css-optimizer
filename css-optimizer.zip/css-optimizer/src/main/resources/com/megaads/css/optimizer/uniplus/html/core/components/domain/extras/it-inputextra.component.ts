import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { WjPopup } from "wijmo/wijmo.angular2.input";

import { EnumUtils } from "../../../enuns/enumutil";
import { IDataItem } from "../../../models/dataitem";
import { HttpService } from "../../../services/http.service";
import { SpinnerService } from "../../../services/spinner.service";
import { NumberUtil } from "../../../utils/number.util";
import { StringUtil } from "../../../utils/string.util";
import { BaseFormComponent } from "../../primitive/baseform.component";
import { Extras, TipoCampoExtra } from "./extras";
import { ItInputExtraConfigComponent } from "./it-inputextra-config.component";

/**
 * TODO OSIEL VERIFICAR A QUESTÃO DE ALTERAÇÃO DE FORMATO PARA NÚMERO OU INTEIRO.
 *
 * Componente de campos extras para inserção em cruds. É necessário passar a tabela, control e label default.
 *
 * @author Osiel.
 */
@Component({
  selector: "it-inputextra",
  templateUrl: "it-inputextra.component.html",
})
export class ItInputExtraComponent extends BaseFormComponent implements OnInit {

  @Input() public table: string;

  public typeInt$: Observable<boolean>;
  public typeMask$: Observable<boolean>;
  public typeCheck$: Observable<boolean>;
  public typeCombo$: Observable<boolean>;
  public typeDate$: Observable<boolean>;
  public typeDateTime$: Observable<boolean>;
  public typeTextArea$: Observable<boolean>;
  public dec$: Observable<number>;
  public mask$: Observable<string>;
  public itens$: Observable<IDataItem[]>;

  public typeText$: Subject<boolean>;
  public typeNumber$: Subject<boolean>;

  public fieldTypeProperty;
  public fieldExtraProperty;
  public extraConfigServer: Extras = new Extras();
  public typeField: string = TipoCampoExtra.TEXTO[EnumUtils.id];

  @ViewChild("popup") private popup: WjPopup;
  @ViewChild("extraConfig") private extraConfig: ItInputExtraConfigComponent;

  private maxLength: number;
  private params: URLSearchParams;

  constructor(private httpService: HttpService, private spinner: SpinnerService) {

    super();

    this.dec$ = Observable.of(2);
    this.typeNumber$ = new Subject();
    this.typeText$ = new Subject();

    this.params = new URLSearchParams();
  }

  /**
   * Define os parâmetros iniciais.
   */
  public ngOnInit(): void {
    this.params.set("tabela", this.table);
    this.fieldTypeProperty = "tipo".concat(this.formatExtraName());
    this.fieldExtraProperty = "mascara".concat(this.formatExtraName());

    /**
     * TODO OSIEL MAXLENGTH NÂO FUNCIONA PARA NUMBER, VERIFCAR O QUE FAZER.
     * Adiciona os validadores para number e texto.
     */
    this.addSubscription(this.typeNumber$
      .filter((isNumber: boolean) => isNumber)
      .combineLatest(this.getControl(), (n: boolean, control: AbstractControl) => control)
      .subscribe((control: AbstractControl) => control.setValidators([Validators.maxLength(this.maxLength)])));

    /**
     * Adiciona as validações para o componente de texto.
     */
    this.addSubscription(this.typeText$
      .filter((texto: boolean) => texto)
      .combineLatest(this.getControl(), (n: boolean, control: AbstractControl) => control)
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.maxLength(this.maxLength)]);
        control.updateValueAndValidity();
      }));

    /**
     * Inicializa o componente.
     */
    this.addSubscription(this.camposExtras$().subscribe((extras: Extras) => this.updateValues(extras)));
  }

  /**
   * Chama a dialog para configuração do campo.
   */
  public configFieldPopup(): void {
    this.spinner.show();

    /**
     * Inicializa o componente novamente pois preciso das informações atualizadas,
     * caso tenha ocorrido alterações por outros usuários por exemplo.
     * Seta o valor para o form.
     */
    this.addSubscription(this.camposExtras$()
      .combineLatest(this.extraConfig.form$, (extras: Extras, form: FormGroup) => ({extras, form}))
      .subscribe(({extras, form}: { extras: Extras, form: FormGroup }) => {
        this.updateValues(extras);
        form.patchValue(this.extraConfigServer);
        this.spinner.hide();
        this.popup.show(true);
      }));
  }

  /**
   * Como pode ter a inclusão de um field e posteriomente a alteração, é necessário busca o pojo.
   * Para isso buscos a configuração da base e combino com o form para ter acesso aos dados,
   * é realizado um switchMap pois preciso de um novo observable de put ou post dependendo do id.
   * O retorno é combinado com o próprio pojo.
   */
  public onSubmit(): void {
    this.popup.hide(true);
    this.spinner.show();

    this.addSubscription(this.httpService.get("campos-extras/buscar-por-tabela", {search: this.params})
      .combineLatest(this.extraConfig.form$, ((campoExtra: Extras, form: FormGroup) => ({campoExtra, form})))
      .switchMap(({campoExtra, form}: { campoExtra: Extras, form: FormGroup }) => {
        const extra: Extras = form.value;

        if (NumberUtil.numberNullOrZero(campoExtra.id)) {
          return this.httpService.post("campos-extras", extra)
            .map((id) => ({id, extra}));
        } else {
          /**
           * Atribui os valores para alteração;
           */
          campoExtra[this.control] = extra[this.control];
          campoExtra[this.fieldTypeProperty] = extra[this.fieldTypeProperty];
          campoExtra[this.fieldExtraProperty] = extra[this.fieldExtraProperty];

          return this.httpService.put("campos-extras", campoExtra)
            .map((id) => ({id: null, extra}));
        }
      })
      .subscribe((wrapper: { id: number, extra: Extras }) => {
        /**
         * Se possui id definido é resultado de uma inclusão.
         */
        if (wrapper.id) {
          this.extraConfigServer.id = wrapper.id;
        }
        this.extraConfigServer = wrapper.extra;

        this.formatExtraFieldFromServer();
        this.addObservables();

        this.toaster.pop("success", "Sucesso", "Configuração gravada com sucesso");
        this.spinner.hide();
      }, (error) => {
        this.spinner.hide();
        this.toaster.pop("success", "Atenção", error);
      }));
  }

  /**
   * Inicializa os parâmetros.
   */
  private camposExtras$(): Observable<Extras> {
    return this.httpService.get("campos-extras/buscar-por-tabela", {search: this.params});
  }

  /**
   * Atualiza os valores do objeto em memória.
   * @param extras: Extras
   */
  private updateValues(extras: Extras): void {
    this.extraConfigServer = extras;

    if (StringUtil.stringNullOrEmpty(this.extraConfigServer[this.control])) {
      this.extraConfigServer.nometabela = this.table;
      this.extraConfigServer[this.fieldTypeProperty] = "TEXTO";
      this.extraConfigServer[this.control] = this.label;
    } else {
      this.formatExtraFieldFromServer();
    }
    this.addObservables();
  }

  /**
   * Adiciona os observadores.
   */
  private addObservables(): void {
    this.typeText$.next(this.typeField === TipoCampoExtra.TEXTO[EnumUtils.id]);
    this.typeNumber$.next(this.typeField === TipoCampoExtra.NUMERO[EnumUtils.id]);
    this.typeInt$ = Observable.of(this.typeField === TipoCampoExtra.INTEIRO[EnumUtils.id]);
    this.typeMask$ = Observable.of(this.typeField === TipoCampoExtra.MASCARA[EnumUtils.id]);
    this.typeCheck$ = Observable.of(this.typeField === TipoCampoExtra.CHECBOX[EnumUtils.id]);
    this.typeCombo$ = Observable.of(this.typeField === TipoCampoExtra.COMBO[EnumUtils.id]);
    this.typeDate$ = Observable.of(this.typeField === TipoCampoExtra.DATA[EnumUtils.id]);
    this.typeDateTime$ = Observable.of(this.typeField === TipoCampoExtra.DATA_HORA[EnumUtils.id]);
    this.typeTextArea$ = Observable.of(this.typeField === TipoCampoExtra.TEXTO_GRANDE[EnumUtils.id]);
  }

  /**
   * Formata os campos de acordo com a gravação.
   */
  private formatExtraFieldFromServer(): void {
    if (this.extraConfigServer[this.fieldTypeProperty]) {
      this.typeField = this.extraConfigServer[this.fieldTypeProperty];
    }

    if (!StringUtil.stringNullOrEmpty(this.extraConfigServer[this.control])) {
      this.label = this.extraConfigServer[this.control];
    }

    if (this.typeField === TipoCampoExtra.TEXTO[EnumUtils.id] &&
      !StringUtil.stringNullOrEmpty(this.extraConfigServer[this.fieldExtraProperty])) {
      this.maxLength = NumberUtil.parseInt(this.extraConfigServer[this.fieldExtraProperty]);
    }

    if (this.typeField === TipoCampoExtra.MASCARA[EnumUtils.id] &&
      !StringUtil.stringNullOrEmpty(this.extraConfigServer[this.fieldExtraProperty])) {
      this.mask$ = Observable.of(this.extraConfigServer[this.fieldExtraProperty]);
    }

    if (this.typeField === TipoCampoExtra.COMBO[EnumUtils.id] &&
      !StringUtil.stringNullOrEmpty(this.extraConfigServer[this.fieldExtraProperty])) {
      const additionalValues: IDataItem[] = [];
      additionalValues.push({id: "", display: " "});

      this.extraConfigServer[this.fieldExtraProperty]
        .split(";")
        .forEach((value) => additionalValues.push({id: value, display: value}));

      this.itens$ = Observable.of(additionalValues);
    }

    if (this.typeField === TipoCampoExtra.NUMERO[EnumUtils.id] &&
      !StringUtil.stringNullOrEmpty(this.extraConfigServer[this.fieldExtraProperty])) {

      const values: string[] = this.extraConfigServer[this.fieldExtraProperty].split(",");
      const dec: number = NumberUtil.parseInt(values[1]);

      this.maxLength = NumberUtil.parseInt(values[0]) - dec;
      this.dec$ = Observable.of(dec);
    }
  }

  /**
   * Função helper para formatar nome do campo. Necessário para acessar atributos
   * do objeto que vem do servidor.
   * @returns {string}
   */
  private formatExtraName(): string {
    return this.control.charAt(0).toUpperCase() + this.control.slice(1);
  }

}
