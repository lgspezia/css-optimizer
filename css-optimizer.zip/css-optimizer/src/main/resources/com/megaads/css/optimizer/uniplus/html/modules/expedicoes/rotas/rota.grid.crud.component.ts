import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { GridCrud } from "../../../core/crud/grid.crud";
import { uniqueAsyncValidator } from "../../../core/crud/validadores";
import { Rota } from "./rota";

@Component({
  templateUrl: "rota.grid.crud.component.html",
})
export class RotaGridCrudComponent extends GridCrud<Rota> {

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder) {
    super(activatedRoute, formBuilder, new Rota(), "rotas");

    this.addValidators();
  }

  private addValidators(): void {

    this.addSubscription(this.getControl("codigo")
      .subscribe((codigo: AbstractControl) => {
        codigo.setValidators([Validators.required, Validators.maxLength(20)]);
        codigo.setAsyncValidators([uniqueAsyncValidator("rotas")]);
      }));

    this.addSubscription(this.getControl("descricao")
      .subscribe((descricao: AbstractControl) => descricao.setValidators([Validators.required, Validators.maxLength(100)])));

    this.disableWhenIsNotCreateMode("codigo");
  }
}
