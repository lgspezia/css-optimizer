import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";
import { Observable } from "rxjs/Observable";
import { FormComponent } from "../../../../core/crud/form-component";

/**
 * @author Luan  on 28/07/2017.
 */
@Component({
  selector: "it-adm-cartao-mfe",
  templateUrl: "administradora-cartao-mfe.form.component.html",
})
export class ItAdministgradoraCartaoMfeFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;

  constructor() {
    super();

  }

  ngOnInit(): void {

    this.addSubscription(this.getControl("chaveRequisicao").subscribe((control: AbstractControl) =>
      control.disable()));
  }
}
