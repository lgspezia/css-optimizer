import {
  AfterContentInit, Component, ContentChildren, EventEmitter, forwardRef, Output,
  QueryList
} from "@angular/core";

import { ItStepComponent } from "./it-step.component";

/**
 * https://github.com/maiyaporn/angular2-wizard
 */
@Component({
  selector: "it-flowcontainer",
  templateUrl: "it-flowcontainer.component.html",
  styles: [
    ".card { height: 100%; }",
    ".card-header { background-color: #fff; padding: 0; font-size: 1.25rem; }",
    ".card-block { overflow-y: auto; overflow-x: hidden}",
    ".card-footer { background-color: #fff; border-top: 0 none; }",
    ".nav-item { padding: 1rem 0rem; border-bottom: 0.7rem solid #ccc; }",
    ".active { font-weight: bold; color: black; border-bottom-color: #1976D2 !important; }",
    ".enabled { cursor: pointer; border-bottom-color: rgb(88, 162, 234); }",
    ".disabled { color: #ccc; }",
    ".completed { cursor: default; }"
  ]
})
export class ItFlowContainerComponent implements AfterContentInit {
  @Output() public onStepChanged: EventEmitter<ItStepComponent> = new EventEmitter<ItStepComponent>();

  @ContentChildren(ItStepComponent) private wizardSteps: QueryList<ItStepComponent>;
  private _steps: Array<ItStepComponent> = [];

  // private _isCompleted: boolean;

  constructor() {
  }

  public ngAfterContentInit(): void {
    this.wizardSteps.forEach(step => this._steps.push(step));
    this.steps[0].isActive = true;
  }

  public get steps(): Array<ItStepComponent> {
    return this._steps.filter(step => !step.hidden);
  }

  // public get isCompleted(): boolean {
  //   return this._isCompleted;
  // }

  public get activeStep(): ItStepComponent {
    return this.steps.find(step => step.isActive);
  }

  public set activeStep(step: ItStepComponent) {
    if (step !== this.activeStep && !step.isDisabled) {
      this.activeStep.isActive = false;
      step.isActive = true;
      step.invalidateFlexGrid();
      this.onStepChanged.emit(step);
    }
  }

  public get activeStepIndex(): number {
    return this.steps.indexOf(this.activeStep);
  }

  public get hasNextStep(): boolean {
    return this.activeStepIndex < this.steps.length - 1;
  }

  public get hasPrevStep(): boolean {
    return this.activeStepIndex > 0;
  }

  // public goToStep(step: ItStepComponent): void {
  //   // if (!this.isCompleted) {
  //   this.activeStep = step;
  //   // }
  // }

  public next(): void {
    if (this.hasNextStep && this.activeStep.isValid) {
      const nextStep: ItStepComponent = this.steps[this.activeStepIndex + 1];
      this.activeStep.onNext.emit();
      nextStep.isDisabled = false;
      this.activeStep = nextStep;
    }
  }

  public previous(): void {
    if (this.hasPrevStep) {
      const prevStep: ItStepComponent = this.steps[this.activeStepIndex - 1];
      this.activeStep.onPrev.emit();
      prevStep.isDisabled = false;
      this.activeStep = prevStep;
    }
  }

  // public complete(): void {
  //   this.activeStep.onComplete.emit();
  //   this._isCompleted = true;
  // }

}
