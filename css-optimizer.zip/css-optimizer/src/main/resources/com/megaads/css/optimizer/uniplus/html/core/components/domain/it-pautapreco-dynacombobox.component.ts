import { Component, Input } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { PautaPrecoWrapper } from "../../wrappers/PautaPrecoWrapper";
import { ItDynacomboboxComponent } from "../primitive/it-dynacombobox.component";

@Component({
  selector: "it-pautapreco-dynacombobox",
  templateUrl: "../primitive/it-dynacombobox.component.html",
})
export class ItPautaPrecoDynacomboboxComponent extends ItDynacomboboxComponent<PautaPrecoWrapper> {
  @Input() public itemSemPauta: boolean;

  constructor(httpService: HttpService) {
    super(httpService);
    this.display = "descricao";
    this.url = "pautas-preco";
  }

  protected loadData(resp: PautaPrecoWrapper[]) {
    this.combobox.itemsSource = this.itemSemPauta ? resp : resp.filter((item) => item.id !== -1);
  }
}
