import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { HierarquiaGrupoProduto } from "../../../modules/cadastros/orfans/hierarquia-grupo-produto.model";

@Component({
    selector: "it-grupoproduto-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
// TODO OSIEL ESSE COMPONENTE PRECISA SER REFATORADO PARA TREEAUTOCOMPLETE
export class ItGrupoProdutoAutocompleteComponent extends ItAutocompleteComponent<HierarquiaGrupoProduto> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "grupos-produto";
        this.display = "nome";
        this.label = "Grupo de produto";
    }

}
