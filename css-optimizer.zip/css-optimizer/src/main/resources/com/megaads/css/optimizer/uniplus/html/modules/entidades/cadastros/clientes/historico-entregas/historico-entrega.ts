import { AbstractPojo } from "../../../../../core/crud/pojo";

/**
 * Histórico de entrega
 *
 * Created by Osiel on 26/05/17.
 */
export class HistoricoEntrega extends AbstractPojo {

    public data: Date = new Date();
    public numerodocumento = "";
    public descricaohistoricopadrao = "";
    public historicocomplementar = "";
}
