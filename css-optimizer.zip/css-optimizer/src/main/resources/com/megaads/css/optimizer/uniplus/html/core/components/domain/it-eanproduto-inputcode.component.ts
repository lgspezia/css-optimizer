import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { AbstractControl, Validators } from "@angular/forms";
import { Observable } from "rxjs/Observable";

import { codigoBarrasAsyncValidator, codigoBarrasValidator } from "../../crud/validadores";
import { ServerError } from "../../models/server-error";
import { ContextoService } from "../../services/contexto.service";
import { HttpService } from "../../services/http.service";
import { NumberUtil } from "../../utils/number.util";
import { StringUtil } from "../../utils/string.util";
import { ItInputCodeComponent } from "../primitive/it-inputcode.component";

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: "it-eanproduto-inputcode",
  templateUrl: "../primitive/it-inputcode.component.html",
})
export class ItEanProdutoInputCodeComponent extends ItInputCodeComponent implements OnInit {
  @Input() public validarProdutoAtual = false;
  @Input() public addValidators = true;
  @Input() public fieldCodigoProduto: string;

  @Output() public gerar$: EventEmitter<any>;

  constructor(private contexto: ContextoService, httpService: HttpService) {
    super(httpService);
    this.label = "Código de barras";
    this.len = 20;
    this.endPoint = "produtos/gerar-codigo-barras";
    this.gerar$ = new EventEmitter();
  }

  public ngOnInit(): void {
    this.exibirBotao$ = Observable.of(!StringUtil.stringNullOrEmpty(this.fieldCodigoProduto));

    /**
     * Upper case quando string
     */
    this.addSubscription(this.getValueChanges()
      .filter((value: any) => !NumberUtil.isNumber(value) && !StringUtil.stringNullOrEmpty(value))
      .combineLatest(this.getControl(), (value: any, control: AbstractControl) => ({value, control}))
      .debounceTime(200)
      .distinctUntilChanged()
      .subscribe(({value, control}: { value: any, control: AbstractControl }) => control.setValue(value.toUpperCase())));

    /**
     * Adiciona os validadores para o código de barras.
     */
    if (this.addValidators) {
      this.addSubscription(this.getControl()
        .combineLatest(this.contexto.getPropriedade$(487), this.contexto.getPropriedade$(89),
          (control: AbstractControl, pattern: string, validar: string) => ({control, validar, pattern}))
        .subscribe((validator: { control: AbstractControl, validar: string, pattern: string }) => {
          validator.control.setValidators(Validators.compose([
            Validators.pattern(validator.pattern), codigoBarrasValidator(validator.validar === "true"),
          ]));
          validator.control.setAsyncValidators(
            codigoBarrasAsyncValidator(this.validarProdutoAtual, this.fieldCodigoProduto));
        }));
    }

    /**
     * Só deve gerar o código de barras quando informar o código do produto.
     * Para isso ao clicar no botão filtra o valor do campo para não ficar gerando sempre, combina
     * com o control de produto e faz um switch com o endpoint e combina com o control para setar o valor.
     *
     */
    if (!StringUtil.stringNullOrEmpty(this.fieldCodigoProduto)) {
      this.addSubscription(this.gerar$
        .withLatestFrom(this.getControl(), (gerar: any, ean: AbstractControl) => ean)
        .filter((ean: AbstractControl) => StringUtil.stringNullOrEmpty(ean.value))
        .combineLatest(this.getControl(this.fieldCodigoProduto),
          (ean: AbstractControl, codigo: AbstractControl) => codigo)
        .switchMap((codigo: AbstractControl) => {
          this.addParams("codigoProduto", codigo.value);
          return this.httpService.get(this.endPoint, {search: this.params});
        })
        .combineLatest(this.getControl(), (resp: any, ean: AbstractControl) => ({resp, ean}))
        .subscribe(({resp, ean}: { resp: any, ean: AbstractControl }) => ean.setValue(resp),
          (error: ServerError) => super.handleError(error)));
    }
  }

}
