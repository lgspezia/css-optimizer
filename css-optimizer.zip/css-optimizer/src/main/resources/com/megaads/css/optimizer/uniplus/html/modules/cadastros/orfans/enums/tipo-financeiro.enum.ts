import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum TipoFinanceiro {
  RECEBER = <any> {[EnumUtils.id]: "RECEBER", [EnumUtils.display]: "Receber"},
  PAGAR = <any> {[EnumUtils.id]: "PAGAR", [EnumUtils.display]: "Pagar"},
}
