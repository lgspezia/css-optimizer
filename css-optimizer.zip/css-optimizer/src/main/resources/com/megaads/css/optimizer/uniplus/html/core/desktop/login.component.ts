import { Component, OnDestroy } from "@angular/core";

import { Subscription } from "rxjs/Subscription";

import { AbstractControl, FormBuilder } from "@angular/forms";
import { Observable } from "rxjs/Observable";
import { Observer } from "rxjs/Observer";
import { subscribeOn } from "rxjs/operator/subscribeOn";
import { AutenticacaoService } from "../services/autenticacao.service";
import { SpinnerService } from "../services/spinner.service";
import { ToasterService } from "../services/toaster.service";

/**
 * Componente de Login
 */
@Component({
  templateUrl: "login.component.html",
})
export class LoginComponent implements OnDestroy {
  public model: any = {};

  private subscription: Subscription;
  private validField: boolean;
  public validFieldObs$: Observable<boolean>;

  constructor(private autenticacaoService: AutenticacaoService,
              private toasterService: ToasterService,
              private spinService: SpinnerService,
              private formBuilder: FormBuilder) {

    this.validFieldObs$ = Observable.of(false);
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  // quando o usuário clicar no botão de login
  public onLogin(): void {
    this.spinService.show();

    this.subscription = this.autenticacaoService.login(this.model.usuario, this.model.senha)
      .subscribe(() => this.autenticacaoService.doLogin(this.model.usuario, this.spinService),
        (error) => {
          this.spinService.hide();
          this.trataErro(error);
          this.validFieldObs$ = Observable.of(true);
          this.validFieldObs$
            .subscribe((desabilitar: boolean) => !desabilitar);
        });
  }

  private trataErro(erro): void {
    if (erro.status === 401) {
      console.log("Senha ou usuário inválidos");
      this.toasterService.pop("error", "Falha na autenticação", "Senha ou usuário inválidos");
      this.validFieldObs$ = this.validFieldObs$.map((filtros: boolean) => !filtros);
    }
  }

  private validInputField (valido: boolean): boolean {
    this.validField = valido;
    console.log(this.validField);
    return this.validField;
  }

}
