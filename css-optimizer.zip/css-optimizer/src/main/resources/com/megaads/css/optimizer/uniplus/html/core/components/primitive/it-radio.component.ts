import { Component, Input } from "@angular/core";
import { Observable } from "rxjs/Observable";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-radio",
    templateUrl: "it-radio.component.html",
})
export class ItRadioComponent extends BaseFormComponent {
  @Input() public itens$: Observable<any>;
}
