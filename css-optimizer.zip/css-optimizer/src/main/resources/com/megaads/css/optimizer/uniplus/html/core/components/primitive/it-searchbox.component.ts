import { Component, ElementRef, EventEmitter, OnDestroy, OnInit, Output } from "@angular/core";

import { Observable } from "rxjs/Observable";
import { Subscription } from "rxjs/Subscription";

@Component({
    selector: "it-searchbox",
    template: `
    <div class="input-group">
        <span class="input-group-addon"><i class="icon icon-filtro-avancado-limpo lead"></i></span>
        <input type="text" class="form-control form-group-searchbox" placeholder="Pesquisar" autofocus>
    </div>
    `,
})
export class ItSearchBoxComponent implements OnInit, OnDestroy {
    @Output() public pesquisar: EventEmitter<string> = new EventEmitter<string>();

    private subscription: Subscription;

    constructor(private el: ElementRef) { }

    public ngOnInit(): void {
        const pesquisaStream = Observable.fromEvent(this.el.nativeElement, "keyup")
            .map((e: any) => e.target.value) // valor digitado
            .filter((text: string) => text.length === 0 || text.length > 1) // filtra tamanho minimo
            .debounceTime(250)
            .distinctUntilChanged();

      this.subscription = pesquisaStream.subscribe((input) => this.pesquisar.emit(input));
    }

    public ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
}
