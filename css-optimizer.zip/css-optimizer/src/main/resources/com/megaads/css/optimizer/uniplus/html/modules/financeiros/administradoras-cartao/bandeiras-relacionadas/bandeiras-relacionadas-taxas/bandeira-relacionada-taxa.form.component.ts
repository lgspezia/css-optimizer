import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { IParamsData } from "app/core/crud/param-data";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { Modo } from "../../../../../core/crud/grid.crud";
import { identificationRequiredValidator } from "../../../../../core/crud/validadores";
import { ServerError } from "../../../../../core/models/server-error";
import { NumberUtil } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { BandeiraRelacionada, BandeiraRelacionadaWrapper } from "../bandeira-relacionada";
import { BandeiraRelacionadaTaxa } from "./bandeira-relacionada-taxa";

/**
 * @author Luan  on 31/07/2017.
 */
@Component({
  selector: "it-bandeira-relacionada-taxa",
  templateUrl: "bandeira-relacionada-taxa.form.component.html",
})
export class ItBandeiraRelacionadaTaxaFormComponent extends FormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;
  @Input() public idAdministradora: string;
  @Input() public cancelVisible$: Observable<boolean>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public disabledTaxa$: Observable<boolean>;
  public params$: Observable<IParamsData>;
  public formBandRelacTaxas$: BehaviorSubject<FormGroup>;
  public min$: Observable<number>;
  public max$: Observable<number>;
  public submitItem$: Subject<BandeiraRelacionadaWrapper>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<BandeiraRelacionadaTaxa>;

  constructor(private formBuilder: FormBuilder) {
    super();
    this.min$ = Observable.of(1);
    this.max$ = Observable.of(24);
    this.submitItem$ = new Subject();
  }

  public ngOnInit(): void {
    this.disabledTaxa$ = this.isDeleteOrRead$;

    this.formBandRelacTaxas$ = new BehaviorSubject(this.formBuilder.group(new BandeiraRelacionadaTaxa()));

    /**
     * Desabilita botao Cancelar do Form quando for modo de criação e for incluido um item na table
     */
    this.cancelVisible$ = this.isCreate$()
      .combineLatest(this.itFormTable.afterSubmit$, (create: boolean, after: BandeiraRelacionadaTaxa) => !create)
      .startWith(true);

    /**
     * Cria as colunas da table
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "ID", DataType.Number, 0, null, false),
      new ColumnDefinition("idRelacionaBandeira", "idRelacionaBandeira", DataType.Number, 0, null, false),
      new ColumnDefinition("numeroParcelas", "Parcela", DataType.Number, "*", null, true),
      new ColumnDefinition("taxaCredito", "Taxa de Crédito", DataType.Number, "*", "n2", true),
      new ColumnDefinition("taxaDebito", "Taxa de Débito", DataType.Number, "*", "n2", true),
    ]);

    /**
     * Cria o parametro de consulta no servidor
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idBandeiraAdm", id.toString());
        return {endpoint: `taxas-bandeira`, search: params};
      });

    this.addValidators();

    this.initTable();

    this.loadTable();

    this.eventUpdate();

    this.eventReset();

    this.eventSubmitTable();

    this.eventSubmitItem();

    this.updateValidator();
  }

  /**
   * Carrega as taxas da administreadora para a bandeira relacionada somente quando
   * tiver informado a bandeira
   */
  public carregarTaxasAdm() {
    this.addSubscription(this.form$
      .filter((form: FormGroup) => form.get("idBandeira").value)
      .switchMap((form: FormGroup) => {
        this.itFormTable.spinnerService.show();
        const bandeira: BandeiraRelacionada = form.value;
        // Seta o id da administradora, para buscar as taxas no servidor
        bandeira.idAdministradora = NumberUtil.parseFloat(this.idAdministradora);
        return this.itFormTable.httpService.post(`bandeiras-relacionadas/buscar-taxas-adm`, bandeira);
      })
      .combineLatest(this.getControl("idBandeira"), this.getControl("numeroParcelas", this.formBandRelacTaxas$),
        this.getControl("id"),
        (taxas: BandeiraRelacionadaTaxa[], idBandeira: AbstractControl, parcela: AbstractControl, id: AbstractControl) =>
          ({taxas, idBandeira, parcela, id}))
      .subscribe((wrapper: {
        taxas: BandeiraRelacionadaTaxa[], idBandeira: AbstractControl, parcela: AbstractControl, id: AbstractControl
      }) => {
        const taxa: BandeiraRelacionadaTaxa = wrapper.taxas[0];
        // pega a primeira taxa, somente para pegar o idRelacionamento para setar para o form pai.
        wrapper.id.setValue(NumberUtil.parseFloat(taxa.idRelacionaBandeira.toString()));
        // atualiza as validaçõs dos componentes
        wrapper.idBandeira.updateValueAndValidity();
        wrapper.parcela.updateValueAndValidity();

        // seta as informações na tabela e chama o afterSubmit para fazer suas validações
        this.itFormTable.updateItemsSource(wrapper.taxas);
        this.itFormTable.spinnerService.hide();
        this.itFormTable.nextAfterLoadData = true;
        this.itFormTable.afterSubmit$.next();
      }));
  }

  /**
   * Add os validadores dos campos
   */
  private addValidators() {
    this.addSubscription(this.getControl("idBandeira").subscribe((control: AbstractControl) => {
      control.setValidators([identificationRequiredValidator()]);
      control.setAsyncValidators([validItemTable(this.itFormTable, this.modo$)]);
    }));

    this.addSubscription(this.getControl("numeroParcelas", this.formBandRelacTaxas$)
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required]);
        control.setAsyncValidators([numeroParcelaAsyncValidator(this.itFormTable, this.isCreate$())]);
      }));
  }

  /**
   * Inicializa a tabela de itens
   */
  private initTable() {
    this.addSubscription(this.isCreate$()
      .filter((create: boolean) => create)
      .subscribe(() => this.itFormTable.updateItemsSource(null)));
  }

  /**
   * Ajusta os valores que vem da base, para ter certeza que vai ser carregado como number
   */
  private loadTable() {
    this.addSubscription(this.itFormTable.afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((brt: BandeiraRelacionadaTaxa) => {
          brt.idBandeiraAdm = brt.idRelacionaBandeira;
          if (brt.numeroParcelas) {
            brt.numeroParcelas = NumberUtil.parseFloat(brt.numeroParcelas.toString());
          }

          if (brt.taxaCredito) {
            brt.taxaCredito = NumberUtil.parseFloat(brt.taxaCredito.toString());
          }

          if (brt.taxaDebito) {
            brt.taxaDebito = NumberUtil.parseFloat(brt.taxaDebito.toString());
          }
        })));
  }

  /**
   * Seta o id do form pai para o item que esta sendo atualizado da tabela
   */
  private eventUpdate() {
    this.addSubscription(this.afterGet$
      .combineLatest(this.getControl("idBandeiraAdm", this.formBandRelacTaxas$),
        this.getControl("idRelacionaBandeira", this.formBandRelacTaxas$),
        (id: number, idBandeira: AbstractControl, idRelaciona: AbstractControl) => ({idBandeira, idRelaciona}))
      .subscribe((wrapper: { idBandeira: AbstractControl, idRelaciona: AbstractControl }) =>
        wrapper.idBandeira.setValue(wrapper.idRelaciona.value)));
  }

  /**
   * Limpa os campos do form, para uma nova inclusão
   */
  private eventReset() {
    this.addSubscription(this.itFormTable.afterReset$
      .subscribe((form: FormGroup) => form.reset(new BandeiraRelacionadaTaxa())));

  }

  /**
   * Carrega os itens da tabela, ao clicar em gravar para enviar para o servidor
   */
  private eventSubmitTable() {
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((taxas: BandeiraRelacionadaTaxa) =>
        numeroParcelaAsyncValidator$(this.itFormTable, taxas.numeroParcelas, taxas.id, this.isCreate$())
          .combineLatest(this.form$, (invalido: { parcelaValid: string }, formRelBandeira: FormGroup) =>
            ({taxas, invalido, formRelBandeira})))
      .subscribe((obj: {
        taxas: BandeiraRelacionadaTaxa, invalido: { parcelaValid: string }, formRelBandeira: FormGroup
      }) => {

        // como vai ser gravado o form pai junto.. verifica se tem o campo obrigatorio
        if (!obj.formRelBandeira.get("idBandeira").value) {
          this.itFormTable.handleError(new ServerError(null, "WWW104", "Bandeira não informada. Verifique!"));
          return;
        }

        // Verifica se passou a validação
        if (obj.invalido) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.invalido.parcelaValid));
          return;
        }

        // a taxa não pode ser menos que 0 e nem maior que 24
        if (obj.taxas.numeroParcelas <= 0 || obj.taxas.numeroParcelas > 24) {
          this.itFormTable.handleError(new ServerError(null, "PDV305", "Informe uma parcela entre 1 e 24"));
          return;
        }

        const bandeiraRelacionada: BandeiraRelacionada = obj.formRelBandeira.value;

        // se for uma inclusão e o cabeçalho ainda nao foi gravado,
        // adciona as informações necessarias para gravar o cabeçalho e os itens
        if (NumberUtil.numberNullOrZero(bandeiraRelacionada.id)) {
          bandeiraRelacionada.idAdministradora = NumberUtil.parseFloat(this.idAdministradora);
          const bandeiraRelacionadaValor: BandeiraRelacionadaWrapper = new BandeiraRelacionadaWrapper();
          bandeiraRelacionadaValor.relacionaBandeira = bandeiraRelacionada;
          bandeiraRelacionadaValor.bandeiraAdmCartaoTaxa = obj.taxas;

          this.submitItem$.next(bandeiraRelacionadaValor);
        } else { // se o pai ja foi gravado só ajusta os dados do filho
          obj.taxas.idRelacionaBandeira = bandeiraRelacionada.id;
          this.itFormTable.submit$.next(obj.taxas);
        }
      }));
  }

  /**
   * Envia pra o servidor os itens e o cabeçalho para serem gravados
   */
  private eventSubmitItem() {
    this.addSubscription(this.submitItem$.switchMap((bandeira: BandeiraRelacionadaWrapper) => {
      this.itFormTable.spinnerService.show();
      // envia para o servidor, o objeto com o cabeçalho e os itens, para ser gravado
      return this.itFormTable.httpService.post(`bandeiras-relacionadas/incluir`, bandeira)
        .combineLatest(this.getControl("id"), this.getControl("idAdministradora"),
          (resp: { id: number, idItem: number }, controlId: AbstractControl, idAdm: AbstractControl) =>
            ({resp, bandeira, controlId, idAdm}));
    }).subscribe((wrapper: {
      resp: { id: number, idItem: number }, bandeira: BandeiraRelacionadaWrapper, controlId: AbstractControl, idAdm: AbstractControl
    }) => {

      // seta os ids que retornaram do servidor
      wrapper.bandeira.bandeiraAdmCartaoTaxa.id = wrapper.resp.idItem;
      wrapper.bandeira.bandeiraAdmCartaoTaxa.idRelacionaBandeira = wrapper.resp.id;
      // add taxa na tabela
      this.itFormTable.push(wrapper.bandeira.bandeiraAdmCartaoTaxa);
      this.itFormTable.spinnerService.hide();
      this.itFormTable.success("Inclusão feita com sucesso");
      this.itFormTable.afterSubmit$.next(wrapper.bandeira.bandeiraAdmCartaoTaxa);
      this.itFormTable.clear$.next();

      // seta os id para os control
      wrapper.controlId.setValue(wrapper.resp.id);
      wrapper.idAdm.setValue(wrapper.bandeira.relacionaBandeira.idAdministradora);
    }, (error: ServerError) => {
      this.itFormTable.spinnerService.hide();
      this.itFormTable.clear$.next();
      this.itFormTable.handleError(error);
    }));
  }

  /**
   * Atualiza os validadores da tabela, após a inclusao do item.
   */
  public updateValidator() {
    this.addSubscription(this.itFormTable.afterSubmit$
      .combineLatest(this.getControl("idBandeira"), (relaciona: BandeiraRelacionadaTaxa, bandeira: AbstractControl) =>
        ({bandeira}))
      .subscribe((wrapper: { bandeira: AbstractControl }) => wrapper.bandeira.updateValueAndValidity()));
  }
}

/**
 * Valida se estiver em moco de criação, tem que ter pelo menos uma taxa inserida
 * @param {ItFormTableComponent<BandeiraRelacionadaTaxa>} itFormTable
 * @param {Observable<Modo>} modo$
 * @returns {() => Observable<any>}
 */
function validItemTable(itFormTable: ItFormTableComponent<BandeiraRelacionadaTaxa>, modo$: Observable<Modo>) {
  return () => {
    return itFormTable
      .afterLoadData$
      .startWith(true)
      .combineLatest(modo$, (after, modo: Modo) =>
        itFormTable.sourceCollection.length === 0 && modo === Modo.CREATE ?
          {tabelaVazia: "WWW103 - Obrigatório inserir uma taxa."} : null)
      .first();
  };
}

/**
 * Validador de numero de parcelas
 * @param {ItFormTableComponent<BandeiraRelacionadaTaxa>} itFormTabble
 * @param {Observable<boolean>} isCreate$
 * @returns {(control: FormControl) => Observable<{parcelaValid: string}>}
 */
function numeroParcelaAsyncValidator(itFormTabble: ItFormTableComponent<BandeiraRelacionadaTaxa>, isCreate$: Observable<boolean>) {
  return (control: FormControl) => {
    return numeroParcelaAsyncValidator$(itFormTabble, control.value, control.parent.get("id").value, isCreate$);
  };
}

/**
 * Validador de numero de parcelas, para verificar se a parcela já existe na tabela
 * @param {ItFormTableComponent<BandeiraRelacionadaTaxa>} itTable
 * @param {number} valor
 * @param {number} id
 * @param {Observable<boolean>} isCreate$
 * @returns {Observable<{parcelaValid: string}>}
 */
function numeroParcelaAsyncValidator$(itTable: ItFormTableComponent<BandeiraRelacionadaTaxa>,
                                      valor: number, id: number, isCreate$: Observable<boolean>): Observable<{ parcelaValid: string }> {
  return isCreate$
    .switchMap((create: boolean) => create ? itTable.afterLoadData$.startWith(true) : itTable.afterLoadData$)
    .map(() => {
      const existeParcela: boolean = itTable.sourceCollection
        .some((taxas: BandeiraRelacionadaTaxa) => valor === taxas.numeroParcelas &&
          (NumberUtil.numberNullOrZero(id) || NumberUtil.parseFloat(id.toString()) !== taxas.id));
      return existeParcela ? {parcelaValid: `PDV309 - Parcela ${valor} já existe. Verifique!`} : null;
    }).first();
}
