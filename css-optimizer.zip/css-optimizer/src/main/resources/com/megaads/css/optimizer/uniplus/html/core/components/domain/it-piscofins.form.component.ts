import { Component, Input, OnInit } from "@angular/core";
import { AbstractControl } from "@angular/forms";

import { Observable } from "rxjs/Observable";

import { CstPisCofins, getCstsPISCOFINS } from "../../../modules/produtos/produto";
import { EnumUtils } from "../../enuns/enumutil";
import { IDataItem } from "../../models/dataitem";
import { BaseFormComponent } from "../primitive/baseform.component";

/**
 * @author Luan  on 10/08/2017.
 */
@Component({
  selector: "it-pisconfins",
  templateUrl: "it-piscofins.form.component.html",
})
export class ItPisCofinsFormComponent extends BaseFormComponent implements OnInit {

  @Input() public afterGet$: Observable<number>;
  @Input() public enableEntrada: boolean;

  public cstsPisCofinsEntrada$: Observable<IDataItem[]>;
  public cstsPisCofinsSaida$: Observable<IDataItem[]>;

  public decimaisPisCofinsEntrada$: Observable<number>;
  public decimaisPisCofinsSaida$: Observable<number>;

  constructor() {
    super();

    const csts = getCstsPISCOFINS();
    this.cstsPisCofinsSaida$ = csts.saida;
    this.cstsPisCofinsEntrada$ = csts.entrada;

    this.decimaisPisCofinsEntrada$ = Observable.of(4);
    this.enableEntrada = true;
  }

  public ngOnInit(): void {

    /**
     * Combina o afterget com o control de cst para pegar as casas decimais em alterações.
     */
    const afterGetPisCofinsSaida =
      this.afterGet$
        .combineLatest(this.getControl("cstPis"), (id: number, cst: AbstractControl) => cst)
        .map((cst: AbstractControl) => cst.value === CstPisCofins.TRIBUTAVEL_ALIQUOTA_POR_UNIDADE[EnumUtils.id] ? 4 : 2);

    /**
     * Mapeia a cst para pegar as decimais.
     * Faz um merge com o afterget para setar em modo de alteração e inicializa com 2 decimais.
     */
    this.decimaisPisCofinsSaida$ =
      this.getValueChanges("cstPis")
        .map((cstPis: string) => cstPis === CstPisCofins.TRIBUTAVEL_ALIQUOTA_POR_UNIDADE[EnumUtils.id] ? 4 : 2)
        .merge(afterGetPisCofinsSaida)
        .startWith(2);

  }
}
