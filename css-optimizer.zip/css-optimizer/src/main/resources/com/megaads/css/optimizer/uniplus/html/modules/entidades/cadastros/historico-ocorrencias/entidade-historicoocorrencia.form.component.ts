import { Component, Input, OnDestroy, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormGroup } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import {
  ItTipoHistoricoContatoAutoCompleteComponent,
} from "../../../../core/components/domain/it-tipohistoricocontato-autocomplete.component";
import { ItFormTableComponent } from "../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../core/crud/column-definition";
import { FormComponent } from "../../../../core/crud/form-component";
import { IParamsData } from "../../../../core/crud/param-data";
import { ServerError } from "../../../../core/models/server-error";
import { ContextoService } from "../../../../core/services/contexto.service";
import { NumberUtil } from "../../../../core/utils/number.util";
import { ContatoEntidade } from "./contato-entidade";

/**
 * Ocorrências de entidade.
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-historicoocorrencia",
  templateUrl: "entidade-historicoocorrencia.form.component.html",
})
export class ItEntidadeHistoricoOcorrenciaFormComponent extends FormComponent implements OnInit, OnDestroy {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formHistorico$: BehaviorSubject<FormGroup>;

  public params$: Observable<IParamsData>;

  public reloadTipo$: Subject<number>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<ContatoEntidade>;
  @ViewChild(ItTipoHistoricoContatoAutoCompleteComponent) private itTipo: ItTipoHistoricoContatoAutoCompleteComponent;

  constructor(private formBuider: FormBuilder, private contexto: ContextoService) {
    super();

    this.reloadTipo$ = new Subject();
  }

  public ngOnDestroy(): void {
    super.ngOnDestroy();

    this.formHistorico$.unsubscribe();
  }

  public ngOnInit(): void {
    this.formHistorico$ = new BehaviorSubject(this.formBuider.group(new ContatoEntidade()));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idEntidade", "idEntidade", DataType.Number, 0, null, false),
      new ColumnDefinition("idTipoHistoricoContato", "idTipoHistoricoContato", DataType.Number, 0, null, false),
      new ColumnDefinition("datahora", "Data", DataType.Date, 90, "dd/MM/yyyy HH:mm"),
      new ColumnDefinition("descricao", "Descrição", DataType.String, "*"),
      new ColumnDefinition("tipoHistorico", "Tipo", DataType.String, 170),
      new ColumnDefinition("nomeUsuario", "Usuário", DataType.String, 150),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEntidade", id.toString());
        return {endpoint: "contatos-entidade", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$.subscribe(() =>
        this.itFormTable.sourceCollection.forEach((contatoEntidade: ContatoEntidade) => {
          if (contatoEntidade.id) {
            contatoEntidade.id = NumberUtil.parseFloat(contatoEntidade.id.toString());
          }
          if (contatoEntidade.idEntidade) {
            contatoEntidade.idEntidade = NumberUtil.parseFloat(contatoEntidade.idEntidade.toString());
          }
          if (contatoEntidade.idTipoHistoricoContato) {
            contatoEntidade.idTipoHistoricoContato =
              NumberUtil.parseFloat(contatoEntidade.idTipoHistoricoContato.toString());
          }
          if (contatoEntidade.idUsuario) {
            contatoEntidade.idUsuario = NumberUtil.parseFloat(contatoEntidade.idUsuario.toString());
          }
        })));

    /**
     * Após a alteração, recarrega os dados para o autocomplete.
     */
    this.addSubscription(this.itFormTable.afterLoadUpdate$
      .withLatestFrom(this.getControl("idTipoHistoricoContato", this.formHistorico$),
        (contato: ContatoEntidade, tipo: AbstractControl) => ({contato, tipo}))
      .subscribe((wrapper: { contato: ContatoEntidade, tipo: AbstractControl }) => {
        /**
         * Se não possuir item selecionado é porque não possui o objeto e deve ser
         * disparada uma requisição.
         */
        if (!this.itTipo.selectedItem) {
          if (!NumberUtil.numberNullOrZero(wrapper.contato.idTipoHistoricoContato)) {
            if (NumberUtil.numberNullOrZero(wrapper.tipo.value)) {
              wrapper.tipo.setValue(wrapper.contato.idTipoHistoricoContato);
            }
            this.reloadTipo$.next();
          }
        }
      }));

    /**
     * TODO OSIEL TIPAR USUARIO
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable.beforeSubmit$
      .combineLatest(this.afterGet$, this.contexto.usuario$,
        (contatoEntidade: ContatoEntidade, idEntidade: number, usuario: any) =>
          ({contatoEntidade, idEntidade, usuario}))
      .subscribe((wrapper: { contatoEntidade: ContatoEntidade, idEntidade: number, usuario: any }) => {
        wrapper.contatoEntidade.idEntidade = wrapper.idEntidade;
        wrapper.contatoEntidade.idUsuario = wrapper.usuario.id;
        wrapper.contatoEntidade.nomeUsuario = wrapper.usuario.nome;

        if (this.itTipo.selectedItem) {
          wrapper.contatoEntidade.tipoHistorico = this.itTipo.selectedItem.descricao;
        }

        this.itFormTable.submit$.next(wrapper.contatoEntidade);
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new ContatoEntidade())));
  }

}
