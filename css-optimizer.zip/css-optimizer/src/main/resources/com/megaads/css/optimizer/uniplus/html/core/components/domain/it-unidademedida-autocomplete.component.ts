import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { UnidadeMedida } from "../../../modules/estoques/unidades-medida/unidademedida";

@Component({
    selector: "it-unidademedida-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItUnidadeMedidaAutocompleteComponent extends ItAutocompleteComponent<UnidadeMedida> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.label = "Unidade de medida";
        this.url = "unidades-medida";
        this.display = "nome";
    }
}
