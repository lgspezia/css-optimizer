import { AbstractPojo } from "../../../../core/crud/pojo";
import { EnumUtils } from "../../../../core/enuns/enumutil";
import { TipoCartaoManual } from "../administradora-cartao";
import { BandeiraRelacionadaTaxa } from "./bandeiras-relacionadas-taxas/bandeira-relacionada-taxa";

/**
 * @author Luan  on 28/07/2017.
 */
export class BandeiraRelacionada extends AbstractPojo {

  public idBandeira = 0;
  public nomeBandeira = "";
  public idAdministradora = 0;
  public manual = TipoCartaoManual.DESABILITADO[EnumUtils.id];
  public prazoVencimentoCredito = 0;
  public prazoVencimentoDebito = 0;
}

/**
 * Facilitador para enviar o cabeçalho junto com o item quando for inclusão,
 * para gravar o cabeçalho junto com o primeiro item
 */
export class BandeiraRelacionadaWrapper extends AbstractPojo {
  public relacionaBandeira = new BandeiraRelacionada();
  public bandeiraAdmCartaoTaxa = new BandeiraRelacionadaTaxa();
}
