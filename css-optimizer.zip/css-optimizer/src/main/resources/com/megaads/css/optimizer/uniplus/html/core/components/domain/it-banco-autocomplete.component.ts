import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Banco } from "../../../modules/financeiros/bancos/banco";

@Component({
  selector: "it-banco-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItBancoAutocompleteComponent extends ItAutocompleteComponent<Banco> {

  constructor(httpService: HttpService) {
    super(httpService);
    this.url = "bancos";
    this.display = "nome";
    this.label = "Banco";
  }
}
