import { Component } from "@angular/core";
import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Empresa } from "../../../modules/cadastros/empresas/empresa";
/**
 * @author Luan  on 14/06/2017.
 */
@Component({
  selector: "it-empresa-autocomplete",
  templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItEmpresaAutoCompleteComponent extends ItAutocompleteComponent<Empresa> {

  constructor(httpService: HttpService) {
    super(httpService);

    this.label = "Empresa";
    this.display = "razaoSocial";
    this.url = "empresas";
  }
}
