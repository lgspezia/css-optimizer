import { EnumUtils } from "../../../../core/enuns/enumutil";

export enum MotivoDesoneracaoPisCofins {
  OUTROS = <any> {[EnumUtils.id]: "OUTROS", [EnumUtils.display]: "Outros"},
  SUFRAMA = <any> {[EnumUtils.id]: "SUFRAMA", [EnumUtils.display]: "SUFRAMA"}
}
