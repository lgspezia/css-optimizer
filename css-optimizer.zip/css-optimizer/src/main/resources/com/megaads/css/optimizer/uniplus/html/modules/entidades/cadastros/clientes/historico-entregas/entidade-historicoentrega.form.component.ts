import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";

import { DataType } from "wijmo/wijmo";

import { ItTableComponent } from "../../../../../core/components/primitive/it-table.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { ServerError } from "../../../../../core/models/server-error";
import { HttpService } from "../../../../../core/services/http.service";
import { SpinnerService } from "../../../../../core/services/spinner.service";
import { ToasterService } from "../../../../../core/services/toaster.service";
import { HistoricoEntrega } from "./historico-entrega";

/**
 * Históricos de entrega
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-historicoentrega",
  templateUrl: "entidade-historicoentrega.form.component.html",
})
export class ItEntidadeHistoricoEntregaFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;

  public params$: Observable<IParamsData>;

  @ViewChild(ItTableComponent) private itTable: ItTableComponent<HistoricoEntrega>;

  constructor(private spinnerService: SpinnerService, private http: HttpService, private toaster: ToasterService) {
    super();
  }

  public ngOnInit(): void {

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("data", "Data", DataType.Date, 90, "dd/MM/yyyy"),
      new ColumnDefinition("numerodocumento", "Documento", DataType.String, 170),
      new ColumnDefinition("descricaohistoricopadrao", "Histórico", DataType.String, "*"),
      new ColumnDefinition("historicocomplementar", "Complemento", DataType.String, "*"),
    ]);

    this.spinnerService.show();

    this.addSubscription(this.afterGet$
      .switchMap((idEntidade: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEntidade", idEntidade.toString());
        return this.http.get(`clientes/historico-entregas`, {search: params});
      }).subscribe((historicos: HistoricoEntrega[]) => {
        this.itTable.updateItemsSource(historicos);
        this.itTable.clearSelection();
        this.spinnerService.hide();
      }, (error: ServerError) => {
        this.spinnerService.hide();
        this.toaster.pop("error", "Falha na gravação", `${error.codigo} - ${error.mensagem}`);
      }));
  }

}
