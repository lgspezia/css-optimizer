import { Component, Input } from "@angular/core";

import { BaseFormComponent } from "./baseform.component";

@Component({
    // changeDetection: ChangeDetectionStrategy.OnPush,
    selector: "it-inputarea",
    templateUrl: "it-inputarea.component.html",
})
export class ItInputAreaComponent extends BaseFormComponent {
  @Input() public placeholder = "";
  @Input() public len = 120;
  @Input() public cols = 40;
  @Input() public rows = 3;
  @Input() public height = "";
  @Input() public col = 12;
}
