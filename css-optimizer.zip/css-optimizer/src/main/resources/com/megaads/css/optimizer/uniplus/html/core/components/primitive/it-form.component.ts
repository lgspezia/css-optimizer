import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";
import { Subscription } from "rxjs/Subscription";

import { Key } from "wijmo/wijmo";

import { Modo } from "../../crud/grid.crud";

@Component({
  selector: "it-form",
  templateUrl: "it-form.component.html",
})
export class ItFormComponent implements OnInit, OnDestroy {
  @Input() public form$: BehaviorSubject<FormGroup>;
  @Input() public modo$: BehaviorSubject<Modo>;
  /**
   * Evento de submit.
   */
  @Input() public eventSubmit$: Subject<any>;
  /**
   * Determina se o botão cancelar esta visível.
   */
  @Input() public cancelVisible$: Observable<boolean>;

  /**
   * Permite desabilitar o botão gravar dinâmicamente.
   */
  @Input() public disabledSubmit$: BehaviorSubject<boolean>;

  /**
   * Emite evento de cancelamento.
   */
  @Output() public onCancel: EventEmitter<any>;

  private subscription: Subscription;


  constructor(protected activatedRoute: ActivatedRoute) {
    this.cancelVisible$ = Observable.of(true);
    this.disabledSubmit$ = new BehaviorSubject(false);
    this.modo$ = new BehaviorSubject(undefined);
    this.onCancel = new EventEmitter();
  }

  /**
   * Necessário para finalizar o observable do metodo OnInit.
   */
  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  /**
   * Captura os modos de visualizacao e exclusao desabilitando todos os campos - utilizado para informar ao usuário.
   */
  public ngOnInit(): void {
    this.subscription = this.modo$
      .filter((modo: number) => modo === Modo.READ || modo === Modo.DELETE)
      .switchMap(() => this.form$)
      .subscribe((form: FormGroup) => Object.keys(form.controls).forEach((key: any) => form.get(key).disable()));

    /**
     * Mapeia os eventos para capturar os atalhos de F10 E ESC.
     */
    this.subscription
      .add(Observable
        .merge(Observable.fromEvent(document, "keydown"), Observable.fromEvent(document, "keyup"))
        .distinctUntilChanged((a: KeyboardEvent, b: KeyboardEvent) => a.keyCode === b.keyCode && a.type === b.type)
        .filter((event: KeyboardEvent) => event.keyCode === Key.F10 || event.keyCode === Key.Escape)
        .subscribe((event: KeyboardEvent) => event.keyCode === Key.F10 ? this.eventSubmit() : this.eventCancel()));
  }

  /**
   * Somente determinará o próximo ciclo se o componente estiver válido e se não houve disable para o botão. Ou for exclusão.
   */
  public eventSubmit(): void {
    this.subscription.add(this.form$
      .withLatestFrom(this.disabledSubmit$, this.modo$, (form, disable, modo) => ({form, disable, modo}))
      .subscribe((wrapper: { form: FormGroup, disable: boolean, modo: Modo }) => {
        if ((wrapper.form.valid && !wrapper.disable) || wrapper.modo === Modo.DELETE) {
          this.eventSubmit$.next(wrapper.form);
        }
      }));
  }

  public eventCancel(): void {
    this.onCancel.emit(null);
  }
}
