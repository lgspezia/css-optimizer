import { AbstractPojo } from "../../../../core/crud/pojo";
/**
 * @author Luan  on 27/06/2017.
 */
export class FilialCidadeCPOM extends AbstractPojo {

  public idFilial = 0;
  public idEstado = 0;
  public idCidade = 0;

  // Auxiliar
  public cidade = "";
  public estado = "";
}
