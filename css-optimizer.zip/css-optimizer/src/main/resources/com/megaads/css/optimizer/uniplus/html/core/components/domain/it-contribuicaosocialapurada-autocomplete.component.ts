import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { ContribuicaoSocialApurada } from "../../../modules/speds/contribuicoes-sociais-apuradas/contribuicao-social-apurada";

@Component({
    selector: "it-contri-social-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItContribuicaoSocialApuradaAutocompleteComponent extends ItAutocompleteComponent<ContribuicaoSocialApurada> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.display = "descricao";
        this.url = "contribuicoes-sociais-apuradas";
    }
}
