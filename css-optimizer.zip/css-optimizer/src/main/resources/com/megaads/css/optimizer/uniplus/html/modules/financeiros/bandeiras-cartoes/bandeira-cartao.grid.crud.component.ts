import { Component } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { ActivatedRoute } from "@angular/router";

import { Observable } from "rxjs/Observable";

import { applicationInjector } from "../../../app.module";
import { GridCrud } from "../../../core/crud/grid.crud";
import { enumValueValidator } from "../../../core/crud/validadores";
import { EnumUtils } from "../../../core/enuns/enumutil";
import { IDataItem } from "../../../core/models/dataitem";
import { ServerError } from "../../../core/models/server-error";
import { ContextoService } from "../../../core/services/contexto.service";
import { HttpService } from "../../../core/services/http.service";
import { REGEX_NUMBER } from "../../../core/utils/number.util";
import { StringUtil } from "../../../core/utils/string.util";
import { BandeiraCartao, TipoBandeiraNFE } from "./bandeira-cartao";

/**
 * Created by luan on 31/05/17.
 */
@Component({
  templateUrl: "bandeira-cartao.grid.crud.html",
})
export class BandeiraCartaoGridCrudComponent extends GridCrud<BandeiraCartao> {

  public tipoBandeira$: Observable<IDataItem[]>;

  constructor(protected activatedRoute: ActivatedRoute, protected formBuilder: FormBuilder, private contexto: ContextoService) {
    super(activatedRoute, formBuilder, new BandeiraCartao(), "bandeiras-cartoes");

    this.tipoBandeira$ = EnumUtils.getValuesNullOption(TipoBandeiraNFE);

    this.addSubscription(this.getControl("codigo")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(20), Validators.pattern(REGEX_NUMBER)]);
        control.setAsyncValidators([validadorCodigoDescricaoAsync("codigo")]);
      }));

    /**
     * Coloca o valor digitado no campo em Upper
     */
    this.addSubscription(this.getValueChanges("nome")
      .withLatestFrom(this.getControl("nome"), (value: string, control: AbstractControl) => ({value, control}))
      .filter(({value, control}) => !StringUtil.stringNullOrEmpty(value))
      .debounceTime(200)
      .distinctUntilChanged()
      .subscribe(({value, control}: { value: string, control: AbstractControl }) => control.setValue(value.toUpperCase())));

    this.addSubscription(this.getControl("nome")
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.maxLength(50)]);
        control.setAsyncValidators([validadorCodigoDescricaoAsync("nome")]);
      }));

    /**
     * usa o filter para verificar se a licença esta ativa, caso retorne true usa o switchMap para
     * carregar um novo observable para setar a validação ao control
     */
    this.addSubscription(contexto.isLicenciado$("UNINFCEPLUS")
      .filter((licenciado: boolean) => licenciado)
      .switchMap(() => this.getControl("tipoBandeira"))
      .subscribe((control: AbstractControl) => control.setValidators([enumValueValidator(TipoBandeiraNFE, TipoBandeiraNFE.UNDEFINED)])));
  }
}

/**
 * Função que faz requisição no servidor para saber se existe alguma outra bandeira com o código ou descrição
 * igual a que esta sendo validada
 * @param campo
 * @returns {(formControl:FormControl)=>Observable<T>}
 */
export function validadorCodigoDescricaoAsync(campo: string) {
  return (formControl: FormControl) => {
    return new Observable((observer) => {
      /**
       *verifica se o campos tem alguma coisa para validar
       */
      if (StringUtil.stringNullOrEmpty(formControl.value)) {
        observer.next(null);
        return;
      }
      /**
       * Carrega o service e instacia a URL
       * @type {HttpService}
       */
      const httpService: HttpService = applicationInjector.get(HttpService);
      const params: URLSearchParams = new URLSearchParams();

      /**
       * Carrega as informaçãos para passar no paramentro da URL
       * @type {AbstractControl|any}
       */
      const id: AbstractControl = formControl.parent.get("id");
      if (id && id.value) {
        params.set("id", id.value);
      }
      params.set("codigo", formControl.value);
      params.set("campo", campo);

      /**
       * faz a requisição no servidor e se caso retornar alguma exeção, mostra na tela
       */
      httpService.get(`bandeiras-cartoes/validar-codigo-descricao`, {search: params})
        .subscribe(() => {
          observer.next(null);
        }, (error: ServerError) => {
          observer.next({
            validate: error.codigo.concat(" - ").concat(error.mensagem),
          });
        });
    }).first();
  };
}
