import { Component } from "@angular/core";

import { HttpService } from "../../services/http.service";
import { ItAutocompleteComponent } from "../primitive/it-autocomplete.component";
import { Captacao } from "../../../modules/unichefs/captacoes/captacao";

@Component({
    selector: "it-captacao-autocomplete",
    templateUrl: "../primitive/it-autocomplete.component.html",
})
export class ItCaptacaoAutocompleteComponent extends ItAutocompleteComponent<Captacao> {

    constructor(httpService: HttpService) {
        super(httpService);
        this.url = "captacoes";
        this.display = "descricao";
        this.label = "Captação";
    }
}
