import { AbstractPojo } from "../../../core/crud/pojo";
import { EnumUtils } from "../../../core/enuns/enumutil";
/**
 * @author Luan  on 12/06/2017.
 */
export class Empresa extends AbstractPojo {

  public razaoSocial = "";
  public numeroOrdemLivro = "";
  public tipoContabilizacaoSped = TipoContabilizacaoSped.UNDEFINED[EnumUtils.id];

}

export enum TipoContabilizacaoSped {
  UNDEFINED = <any> {[EnumUtils.id]: "UNDEFINED", [EnumUtils.display]: "-- selecione --"},
  CENTRALIZADA = <any> {[EnumUtils.id]: "CENTRALIZADA", [EnumUtils.display]: "Centralizada"},
  DESCENTRALIZADA = <any> {[EnumUtils.id]: "DESCENTRALIZADA", [EnumUtils.display]: "Descentralizada"},
}

