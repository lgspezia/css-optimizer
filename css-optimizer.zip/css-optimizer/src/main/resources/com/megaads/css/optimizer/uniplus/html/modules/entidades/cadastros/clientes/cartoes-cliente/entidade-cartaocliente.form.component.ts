import { Component, Input, OnInit, ViewChild } from "@angular/core";
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";
import { URLSearchParams } from "@angular/http";
import { BehaviorSubject } from "rxjs/BehaviorSubject";
import { Observable } from "rxjs/Observable";
import { Subject } from "rxjs/Subject";

import { DataType } from "wijmo/wijmo";

import { applicationInjector } from "../../../../../app.module";
import { ItFormTableComponent } from "../../../../../core/components/primitive/it-formtable.component";
import { ColumnDefinition } from "../../../../../core/crud/column-definition";
import { FormComponent } from "../../../../../core/crud/form-component";
import { IParamsData } from "../../../../../core/crud/param-data";
import { enumConverter, EnumUtils } from "../../../../../core/enuns/enumutil";
import { IDataItem } from "../../../../../core/models/dataitem";
import { ServerError } from "../../../../../core/models/server-error";
import { DateService } from "../../../../../core/services/date.service";
import { HttpService } from "../../../../../core/services/http.service";
import { NumberUtil, REGEX_NUMBER } from "../../../../../core/utils/number.util";
import { StringUtil } from "../../../../../core/utils/string.util";
import { ConfiguracoesAdicionaisEntidade } from "../../entidade";
import { CartaoCliente, StatusCartaoCliente } from "./entidade-cartaocliente";

/**
 * Cadastros de cartão de clientes.
 *
 * Created by Osiel on 26/05/17.
 */
@Component({
  selector: "it-entidade-cartaocliente",
  templateUrl: "entidade-cartaocliente.form.component.html",
})
export class ItEntidadeCartaoClienteFormComponent extends FormComponent implements OnInit {
  @Input() public afterGet$: Observable<number>;

  public columns$: BehaviorSubject<ColumnDefinition[]>;
  public formCartaoCliente$: BehaviorSubject<FormGroup>;

  public cartaoManual$: Subject<boolean>;
  public usarSenha$: Subject<boolean>;

  public opcoesStatus$: Observable<IDataItem[]>;
  public params$: Observable<IParamsData>;

  @ViewChild(ItFormTableComponent) private itFormTable: ItFormTableComponent<CartaoCliente>;

  constructor(private formBuider: FormBuilder, private date: DateService) {
    super();
    this.cartaoManual$ = new Subject();
    this.usarSenha$ = new Subject();
    this.opcoesStatus$ = EnumUtils.getValues(StatusCartaoCliente);
  }

  public ngOnInit(): void {
    /**
     * Configuração de cartão fidelidade.
     */
    this.addSubscription(this.getControl("configuracoesAdicionaisEntidade")
      .subscribe((control: AbstractControl) => {
        const configuracoes: ConfiguracoesAdicionaisEntidade = control.value;
        if (configuracoes.cartaoFidelidade) {
          this.cartaoManual$.next(!configuracoes.cartaoFidelidade.geraNumeracaoCartao);
          this.usarSenha$.next(configuracoes.cartaoFidelidade.usarSenha);
        }
      }));

    this.formCartaoCliente$ = new BehaviorSubject(this.formBuider.group(new CartaoCliente()));

    /**
     * Validação de senhas em form principal.
     */
    this.addSubscription(this.getControl("senhaCartao2")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(50), validatePassword()])));

    this.addSubscription(this.getControl("senhaCartao1")
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(50)])));

    this.addSubscription(this.getValueChanges("cadastrarSenha")
      .startWith(false)
      .combineLatest(this.getControl("senhaCartao2"), this.getControl("senhaCartao1"),
        (cadastrar: boolean, senha: AbstractControl, repetirSenha: AbstractControl) =>
          ({cadastrar, senha, repetirSenha}))
      .subscribe((wrapper: { cadastrar: boolean, senha: AbstractControl, repetirSenha: AbstractControl }) => {
        if (wrapper.cadastrar) {
          wrapper.senha.enable();
          wrapper.repetirSenha.enable();
        } else {
          wrapper.senha.disable();
          wrapper.repetirSenha.disable();
          wrapper.senha.setValue(null);
          wrapper.repetirSenha.setValue(null);
        }
      }));

    /**
     * Validações de senha em form table
     */
    this.addSubscription(this.getControl("senhaCartao", this.formCartaoCliente$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(50), validatePassword()])));

    this.addSubscription(this.getControl("senhaCartao1", this.formCartaoCliente$)
      .subscribe((c: AbstractControl) => c.setValidators([Validators.required, Validators.maxLength(50)])));

    this.addSubscription(this.getValueChanges("cadastrarSenha", this.formCartaoCliente$)
      .startWith(false)
      .combineLatest(this.getControl("senhaCartao", this.formCartaoCliente$), this.getControl("senhaCartao1", this.formCartaoCliente$),
        (cadastrar: boolean, senha: AbstractControl, repetirSenha: AbstractControl) =>
          ({cadastrar, senha, repetirSenha}))
      .subscribe((wrapper: { cadastrar: boolean, senha: AbstractControl, repetirSenha: AbstractControl }) => {
        if (wrapper.cadastrar) {
          wrapper.senha.enable();
          wrapper.repetirSenha.enable();
        } else {
          wrapper.senha.disable();
          wrapper.repetirSenha.disable();
          wrapper.senha.setValue(null);
          wrapper.repetirSenha.setValue(null);
        }
      }));

    this.addSubscription(this.getControl("cartao", this.formCartaoCliente$)
      .subscribe((control: AbstractControl) => {
        control.setValidators([Validators.required, Validators.pattern(REGEX_NUMBER)]);
        control.setAsyncValidators([validatorCartaoAsync(this.itFormTable, this.afterGet$)]);
      }));

    /**
     * Monta as colunas.
     */
    this.columns$ = new BehaviorSubject([
      new ColumnDefinition("id", "id", DataType.Number, 0, null, false),
      new ColumnDefinition("idEntidade", "idEntidade", DataType.Number, 0, null, false),
      new ColumnDefinition("dataEmissao", "Emissão", DataType.Date, 170, "dd/MM/yyyy"),
      new ColumnDefinition("cartao", "Cartão", DataType.String, "*"),
      new ColumnDefinition("status", "Status", DataType.String, 100, null, true, StatusCartaoCliente, null, enumConverter),
    ]);

    /**
     * Passo os dados necessários para carregar os dados.
     */
    this.params$ = this.afterGet$
      .map((id: number) => {
        const params: URLSearchParams = new URLSearchParams();
        params.set("idEntidade", id.toString());
        return {endpoint: "cartoes-cliente", search: params};
      });

    /**
     * Isso se deve ao fato de quê por alguma razão esses campos estão vindo em formato string
     * e impede o funcionamento do wijmo.
     */
    this.addSubscription(this.itFormTable
      .afterLoadData$
      .subscribe(() =>
        this.itFormTable.sourceCollection.forEach((cartao: CartaoCliente) => {
          if (cartao.id) {
            cartao.id = NumberUtil.parseFloat(cartao.id.toString());
          }
          if (cartao.idEntidade) {
            cartao.idEntidade = NumberUtil.parseFloat(cartao.idEntidade.toString());
          }
        })));

    /**
     * Prepara o objeto para a submissão.
     */
    this.addSubscription(this.itFormTable
      .beforeSubmit$
      .switchMap((cartao: CartaoCliente) => validateCartao$(cartao.cartao, cartao.id, this.itFormTable, this.afterGet$)
        .combineLatest(this.afterGet$,
          (validate: { cartaoValidate: string }, idEntidade: number) => ({validate, idEntidade, cartao})))
      .subscribe((obj: { validate: { cartaoValidate: string }, idEntidade: number, cartao: CartaoCliente }) => {

        /**
         * Validação de cartão.
         */
        if (obj.validate) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(obj.validate.cartaoValidate));
          return;
        }

        /**
         * Validação de senha.
         * @type {{invalidPssw: string}}
         */
        const psw: { invalidPssw: string } = equalsPassword(obj.cartao.senhaCartao, obj.cartao.senhaCartao1);
        if (psw) {
          this.itFormTable.handleError(StringUtil.splitErrorCode(psw.invalidPssw));
          return;
        }

        obj.cartao.idEntidade = obj.idEntidade;

        this.itFormTable.submit$.next(obj.cartao);
        obj.cartao.dataEmissao = this.date.today;
      }, (error) =>
        this.itFormTable.handleError(new ServerError(null, null, "Não foi possível executar a ação"))));

    /**
     * Quando a ação de um novo item for executada limpo o form e as validações dos componentes.
     */
    this.addSubscription(this.itFormTable.afterReset$.subscribe((form: FormGroup) => form.reset(new CartaoCliente())));
  }

}

/**
 * Função de validação de senha.
 * @return {(formControl:FormControl)=>{invalidPssw: string}}
 */
function validatePassword() {
  return (formControl: FormControl) => {
    const senha1: string = formControl.parent.get("senhaCartao1").value;
    return equalsPassword(formControl.value, senha1);
  };
}

/**
 * Retorna null ou objeto com excessão se inválido.
 * @param pssw1: string
 * @param pssw2: string
 * @return {{invalidPssw: string}}
 */
function equalsPassword(pssw1: string, pssw2: string): { invalidPssw: string } {
  return pssw1 !== pssw2 ? {invalidPssw: "ENT51 - As senhas não correspondem. Verifique!"} : null;
}

/**
 * Validador de cartão fidelidade.
 * @param itFormTable: ItFormTableComponent<CartaoCliente>
 * @param afterGet$: Observable<number>
 * @return {(formControl:FormControl)=>Observable<{cartaoValidate: string}>}
 */
function validatorCartaoAsync(itFormTable: ItFormTableComponent<CartaoCliente>, afterGet$: Observable<number>) {
  return (formControl: FormControl) => {
    return validateCartao$(formControl.value, NumberUtil.parseFloat(formControl.parent.get("id").value), itFormTable, afterGet$);
  };
}

/**
 * Validação de cartão fidelidade.
 *
 * @param cartao: string
 * @param id: number
 * @param itFormTable: ItFormTableComponent<CartaoCliente>
 * @param afterGet$: Observable<number>
 * @return {Observable<{ cartaoValidate: string }>}
 */
function validateCartao$(cartao: string, id: number, itFormTable: ItFormTableComponent<CartaoCliente>,
                         afterGet$: Observable<number>): Observable<{ cartaoValidate: string }> {
  return afterGet$.switchMap((idEntidade: number) => {
    if (itFormTable.sourceCollection
        .some((c: CartaoCliente) => c.cartao === cartao && (NumberUtil.numberNullOrZero(id) || id !== c.id))) {
      return Observable.of({cartaoValidate: "WWW56 - Cartão já cadastrado"});
    }

    const http: HttpService = applicationInjector.get(HttpService);
    const params: URLSearchParams = new URLSearchParams();
    params.set("idEntidade", idEntidade.toString());
    params.set("cartao", cartao);

    return http.get(`cartoes-cliente/validar`, {search: params})
      .map(() => null)
      .catch((error: ServerError) => Observable.of({cartaoValidate: `${error.codigo} - ${error.mensagem}`}));
  }).first();
}
