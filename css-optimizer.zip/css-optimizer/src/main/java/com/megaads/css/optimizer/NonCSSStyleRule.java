/**
* Copyright (C) 2015, MEGAADS
*
* Released under the MIT license
*/
package com.megaads.css.optimizer;

/**
 *
 * @author THOQ LUONG Mar 9, 2015 5:55:31 PM
 */
public class NonCSSStyleRule extends CSSRule {
    //--------------------------------------------------------------------------
    //  Members    
    //--------------------------------------------------------------------------
    //  Initialization and releasation
    public NonCSSStyleRule(String content) {
        super(content);
    }
    //--------------------------------------------------------------------------
    //  Getter N Setter
    //--------------------------------------------------------------------------
    //  Method binding
    //--------------------------------------------------------------------------
    //  Implement N Override    
    //--------------------------------------------------------------------------
    //  Utils
    //--------------------------------------------------------------------------
    //  Inner class

}
